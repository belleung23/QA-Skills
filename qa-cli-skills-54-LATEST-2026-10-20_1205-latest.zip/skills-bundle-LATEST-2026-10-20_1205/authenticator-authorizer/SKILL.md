---
name: authenticator-authorizer
description: "Pre-flight authentication and authorization for First Recon AI QA environments. Handles Google SSO login, SSO redirect-loop recovery, and environment readiness checks on Dev (primary test environment, no UI fallback) — and on Production when the ticket title contains [Pro] or [Prod] (with Dev as the only fallback). Use this skill whenever you need to log in to any First Recon AI environment, perform a pre-flight environment check, verify authentication status before testing, or recover from a Keycloak/SSO session error (e.g., 'psfni-guardrails-dev — Oops!, something went wrong'). Triggers on: pre-flight, login, authenticate, environment check, sign in to First Recon, SSO error, guardrails-dev error, couldn't find your session."
---

# Pre-Flight Authentication & Authorization

This skill handles logging into First Recon AI environments and confirming they are ready for testing. It runs BEFORE any other QA trigger command (Test, Bug, Jira, Passed, Automation).

## Shared References

Before proceeding, read:
- `shared-qa-base/references/environments.md` — environment URLs, routing rules, test account, coverage rules
- `shared-qa-base/references/status-definitions.md` — pre-flight status icons

## Environment Routing (read this first)

The pre-flight target depends on the ticket title:

| Ticket Title | Target Environment | Fallback |
|--------------|---------------------|----------|
| No `[Pro]` / `[Prod]` tag | **Dev** — `https://app.dev.firstrecon.ai/` | **None.** If Dev fails, mark Unreachable per rules below — do NOT pre-flight Staging or localhost. |
| Contains `[Pro]` or `[Prod]` | **Production** — `https://app.firstrecon.ai/` | **Dev** — only if Prod has a deployment gap |

Reference URLs (not used as auto-fallbacks):
- Staging: `https://app.staging.firstrecon.ai/` — listed for awareness; never an auto pre-flight target
- Localhost: `http://localhost:3000` — code verification only, no SSO

The SSO Hard Rule and recovery ladder below apply to **any environment** that uses the Keycloak / `psfni-guardrails-*` SSO flow — current and future.

**Test account:** `belle.ung@persefoni.com` (Google SSO)

---

## ⛔ Hard Rule — Never Interact with the Keycloak Error Page

**The single most important rule for SSO recovery.** Applies to every environment that uses Keycloak SSO.

When you land on a `psfni-guardrails-*` error page (e.g. "Oops!, something went wrong", "we couldn't find your session", `invalid_request`, "You may have pressed the back button…"):

1. **Do NOT click anything on that page.** Not "VIEW LOG", not any link, not any button, not the breadcrumb, not "try again" — nothing. The page is in a broken auth state and any click triggers a fresh `invalid_request` error and deepens the loop.
2. **First action must be to refresh the page OR re-type the environment URL** in the address bar (re-type is preferred — it discards the broken redirect query params; refresh re-submits them and may fail again).
3. Only AFTER the page has reloaded to a clean state (login screen or app shell) may you click any button.
4. If the refresh / re-type also lands back on the Keycloak error → repeat re-type once, then move into the recovery ladder. Still no clicks on the error page itself.

> **Why this rule exists:** the Keycloak error page is itself a dead-end. Clicking "VIEW LOG", "try again", or the implicit Google SSO link from this page sends a malformed request back to Keycloak with stale state, which immediately re-renders the same error. The only way out is to leave the page entirely (refresh or fresh URL) before doing anything else.

---

## Pre-Flight Sequence

### Step 1 — Navigate to the Target Environment

Pick the URL by routing rule:
- Normal ticket → `https://app.dev.firstrecon.ai/`
- `[Pro]` / `[Prod]` ticket → `https://app.firstrecon.ai/`

Open the URL in the browser.

- **If the app loads with an active session** → mark `🟢 Ready`, done.
- **If the login screen appears** → proceed to Step 2.
- **If you land on a Keycloak error page** (e.g. `psfni-guardrails-*` with "Oops!, something went wrong" / "we couldn't find your session") → **do not click anything on it** → proceed directly to the **SSO Redirect Loop Recovery** ladder below. Do NOT mark Unreachable yet.

### Step 2 — Standard Login (Google SSO)

1. Click **"Continue with Google"** (only if you are on the clean login screen, NOT on the Keycloak error page)
2. Select `belle.ung@persefoni.com` from the account picker
3. Click **Accept** to continue
4. Wait for redirect back to the target environment
5. Confirm the app shell loads → mark `🔑 Logged In`

If any step above fails, error-pages out, or redirects to Keycloak with a session error → go to the recovery ladder. **Do not click on the Keycloak error page** — start the ladder by leaving the page.

---

## SSO Redirect Loop Recovery Ladder

This is the **exhaustive retry ladder** for the `psfni-guardrails-*` / "couldn't find your session" / broken-redirect failure mode. **Run every step in order before asking the human.** Do not skip steps. Do not mark Unreachable until the full ladder is exhausted. The Hard Rule above governs every step — no clicks on the error page, ever.

All references below use `<TARGET_URL>` as a placeholder — substitute the routed environment URL from Step 1.

### Attempt 1 — Re-type the URL (NO CLICKS on the error page)

The URL often corrupts during the Keycloak redirect. Ignore the current (broken) page entirely.

1. Click into the address bar and manually type `<TARGET_URL>`, then press Enter. (Do NOT click any button on the Keycloak error page first.)
2. Wait for the page to fully reload.
3. If the login screen loads cleanly → go back to **Step 2 — Standard Login**.
4. If the Keycloak error page loads again → **do not click on it** → go to Attempt 2.

### Attempt 2 — Click "Continue with Google" from a fresh load

Sometimes the SSO session cookie is stale but a fresh Google SSO click will re-issue it. The click MUST happen on the clean login screen, not on the error page.

1. Re-type `<TARGET_URL>` in the address bar (fresh load).
2. Wait for the login screen to fully render.
3. As soon as the login screen appears, click **"Continue with Google"** immediately.
4. Select `belle.ung@persefoni.com` and click **Accept**.
5. If redirect completes and app loads → mark `🔄 Re-logged In`, done.
6. If it fails again → **do not click on the error page** → go to Attempt 3.

### Attempt 3 — Re-type + Google SSO, second pass

Repeat Attempt 1 + Attempt 2 one more time. Transient Keycloak/SSO state often clears on the second pass. Every retry begins with a URL re-type, never with a click on the broken page.

- Success → mark `🔄 Re-logged In`, done.
- Failure → go to Human Handoff.

### Human Handoff (last resort)

**Only after all three attempts above have failed.** Stop automation and ask the human to log in manually:

> "I hit the SSO redirect loop on `<environment>` three times (`psfni-guardrails-*` — 'couldn't find your session'). I've tried re-typing the URL and clicking Continue with Google. Can you log in manually in the browser window? Once you're on the app shell, reply 'logged in' and I'll resume testing from where I left off."

**While waiting:**
- Do NOT mark the environment as `🚫 Unreachable` yet.
- Do NOT silently fall back to any other environment.
- Do NOT click anything on the Keycloak error page.
- Preserve the current test state so you can resume at the exact step after the human confirms.

Once the human confirms → mark `🤝 Human-Logged In` (see status definitions) → resume testing.

---

## When to Mark `🚫 Unreachable`

Only mark the target environment `🚫 Unreachable` if **all** of the following are true:
- The full SSO Redirect Loop Recovery ladder completed (all 3 attempts).
- Human handoff was offered and the human confirmed they also cannot log in, OR the user explicitly tells you to skip the target.
- No path forward on the target exists for this session.

A session expiry alone is NEVER a reason to mark Unreachable — it is always recoverable.

### What happens after Unreachable

- **Normal ticket, Dev = Unreachable:** stop pre-flight. Report the failure clearly. **Do not auto-fallback to Staging or localhost for UI testing** — per the new policy, Dev has no UI fallback. Wait for the user to decide next steps (run code verification only, retry later, etc.).
- **`[Pro]`/`[Prod]` ticket, Production = Unreachable:** if the cause looks like a deployment gap (e.g. the fix hasn't shipped to Prod yet), fall back pre-flight to Dev and continue testing there. Note the fallback clearly in the QA report and Jira comment.
- **`[Pro]`/`[Prod]` ticket, Dev fallback also Unreachable:** stop pre-flight, report.

---

## Localhost Flow (code verification only)

Localhost is not a pre-flight target and is not a UI-test fallback. It is a working environment used only for Layer 2 (codebase) verification when needed. Navigate directly to `http://localhost:3000/chat` if doing code work. Requires `bun run dev` running in the project root. The Keycloak Hard Rule does not apply on localhost (no SSO).

---

## Step 3 — Confirm Readiness

Record pre-flight status using the format in `shared-qa-base/references/environments.md`.

| Status | Icon | Meaning |
|--------|------|---------|
| Ready | 🟢 | Session was already active |
| Logged In | 🔑 | Login screen appeared, standard SSO completed |
| Re-logged In | 🔄 | Recovery ladder succeeded on Attempt 1, 2, or 3 |
| Human-Logged In | 🤝 | Human completed the login after SSO loop recovery exhausted |
| Unreachable | 🚫 | All recovery exhausted AND human handoff also failed |

---

## Key Notes

- Test account: `belle.ung@persefoni.com`
- Google SSO is the only supported login method. The email verification code flow is no longer used.
- **Never click anything on the Keycloak `psfni-guardrails-*` error page** — refresh or re-type the URL first. Applies to every environment that uses SSO.
- Never skip the recovery ladder — the SSO redirect loop is the #1 known issue and is almost always recoverable by re-typing the URL + re-clicking Continue with Google **on the clean login screen**.
- Never mark the target environment Unreachable prematurely.
- For normal tickets, **Dev is the only UI target** — no automatic fallback to Staging or localhost.
- For `[Pro]`/`[Prod]` tickets, **Production is primary** with **Dev as the sole fallback** (for deployment-gap scenarios).
- Always resume from the exact test step where the session failed, not from the start.
