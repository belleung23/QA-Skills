---
name: "api-testing-standards"
description: "Design, write, run and review API tests (REST, and GraphQL notes) in Playwright TypeScript for any project: authentication, authorization matrix and tenant isolation (IDOR), status codes, request/response payload and schema, idempotency, pagination, state transitions, then a plain-language report. Ships a tested, config-driven kit — only api.config.ts changes per project. Use whenever writing, generating, reviewing or planning API/backend/endpoint tests, or when a ticket needs API-layer verification."
---

# API Testing Standards

This skill defines what a *good* API test looks like and gives you a **runnable kit** that produces those tests for any project. Use it in three situations: writing new API tests, generating API tests from a ticket or test case, and reviewing API tests someone else wrote. The standards are the same in all three: a review is the same list checked in reverse.

The goal of an API test is to prove, independently of the UI, that an endpoint does what its contract says. That means the right status, the right shape, the right data, the right behaviour on bad input, and the right behaviour for the wrong user. A UI test can pass while the API silently returns the wrong thing. API tests are the layer that catches that.

Every endpoint is tested on **three pillars** first: **payload**, **authentication**, **authorization**. Then come status codes, idempotency, lists and state. If a PR covers only the happy path and skips any pillar, it is not done.

Nothing in this skill is tied to one product. URLs, accounts, tenants, roles, field names and status conventions all come from the project's contract, through environment variables and `api.config.ts`.

---

## 0. Workflow (the agent runs this end to end; the human reviews the report)

1. **Establish the contract.** Find an OpenAPI/Swagger file, GraphQL schema, Postman collection, README or the route handlers. If the docs are missing or stale, read the handler: the code is the truth. For each endpoint, write down:
   - method + path
   - who may call it (roles) and what another tenant gets (`403` or `404`)
   - request fields with type, required, limits, format and enum
   - success status and response shape
   - every error status and the error envelope
   - pagination params, idempotency header, state rules and side effects

   If something is unclear, ask, or mark the case `test.fixme('open question: …')`. Never invent an expected value to make a test pass.
2. **Install the kit** (section 9). Write the files into the repo's existing test layout. Look before creating folders. The generic specs and support files are copied **unchanged**. Only `tests/api.config.ts` is written per project.
3. **Fill `api.config.ts` from the contract** (section 10 has a complete example):
   - one principal per role, plus a highest-role principal in a **second tenant**
   - the conventions (status numbers, error envelope)
   - every endpoint in scope with its `allow` list
   - field rules for create/update bodies
   - idempotency cases, lists, state transitions and partial updates

   Credentials and ids always come from env vars.
4. **Type-check and collect:** `npx tsc --noEmit` and `npx playwright test --list`. Clean output proves only that the code loads. It does **not** prove that a test can fail.
5. **Run** against local/dev/test (never production unless a human approved a read-only run; see `assertNotProduction`). Run twice. A test that flips is flaky: fix the cause, never add retries or weaken an assertion.
6. **Prove the suite can fail.** Break 2–3 rules on purpose and confirm the matching test goes red, then undo the change. For example:
   - add a forbidden role to an `allow` list
   - change `crossTenant` to `[200]`
   - change a field rule to `maxLength: 5`

   A suite that has never failed is not evidence.
7. **Report:** `node tools/qa-report.mjs test-results/results.json --name "<API name>" --kind API`. It writes `reports/<name>_<PASSED|FAILED>_API-Test-Report_<date>.md`. Each failure goes through root-cause analysis (file, line, commit) **before** any ticket is filed. "Environment", "spec gap" and "not reproducible" results are not product bugs.

---

## 1. Pillar 1 — Payload (request and response)

"Payload" means both what you send and what you get back. Test both; most teams only test the response.

### Request payload

For every field in the request body and query string, work through this list. Each row is a distinct code path in the server's validation, and a server that handles one correctly often mishandles the next. The kit generates these rows from `fields` rules.

| Case | Example | Expected |
|---|---|---|
| Valid, typical | normal name/email | success status + stored exactly as sent (after documented normalisation) |
| Required field missing | omit `email` | `400`/`422`, error names the field |
| Present but empty / null | `""`, `null`, `[]` | `400`/`422` unless the contract allows it |
| Wrong type | `12345` for a string, `"12.5"` for a number, `1.5` for an integer | `400`/`422`, never coerced silently, **never `500`** |
| Boundary values | min−1, min, max, max+1 (length or number), decimals beyond precision | min and max accepted, outside rejected |
| Invalid format | bad email, bad UUID, bad ISO date, value outside the enum, a value breaking a pattern (`abc` for "UPPERCASE only") | `400`/`422`. List pattern breakers in the field's `invalid: [...]` — the kit cannot guess them |
| Unknown/extra field | `{"qaUnknownField": "x"}` | ignored **or** rejected — whatever the contract says, consistently |
| Server-controlled field | `id`, `orgId`/`tenantId`, `role`, `status`, `createdAt`, `isOwner` | **never applied** (mass assignment). Check the response **and** the stored value |
| Malformed body | invalid JSON; JSON that is not an object | `400`, not `500` |
| Wrong `Content-Type` | `text/plain` body | `415` (if the contract checks it) |
| Oversized | body above the documented limit | `413` |
| Special characters | unicode, emoji, quotes, `<script>`, `'; DROP TABLE` | stored and returned unchanged, never executed |
| Whitespace | leading/trailing spaces | trimmed or kept per contract — assert which |
| Nested arrays | item missing a field, item with wrong type, too many items, empty array | validated to the same depth as top level |
| Rejected request leaves no trace | 2nd array item invalid → `400`; then resend the same unique data, valid | the resend succeeds (no half-written row blocks it) |

For each rejection, assert the status **and** the error body: the field name and the project's error code. A `400` with an empty body is a bug for API clients.

### Response payload

- Validate the **whole** shape with a strict schema (zod `.strict()` or the OpenAPI schema via ajv), not one lucky field. `"42"` is not `42`, and `null` is not the same as missing.
- **Round trip:** create with payload X, `GET` it, and compare field by field. The `GET` must equal what create returned.
- **Partial update:** a PATCH changes only the fields sent. Every other field is byte-for-byte the same, except documented volatile ones like `updatedAt`.
- **No leaks:** no `passwordHash`, internal margins, secrets, other tenants' data or stack traces. The kit searches every JSON response at any depth for `leakKeys`.
- Formats: ids, ISO 8601 UTC timestamps, money precision, exact enum casing.
- Headers the contract promises: `Content-Type`, `Location` on `201`, `Retry-After` on `429`, `Allow` on `405`. In the kit:
  - `location: true` on an endpoint checks `Location`.
  - `methodNotAllowed.allowHeader: true` checks `Allow`.
  - `conventions.errorContentType` pins the error media type, e.g. `/application\/problem\+json/` for RFC 7807 errors.
- **One error envelope** on every error (`400` `401` `403` `404` `409` `413` `415` `422` `429` `500`), including unknown routes.

## 2. Pillar 2 — Authentication (who are you?)

Run this against **every** protected endpoint, not just login. A single endpoint that forgets the auth middleware is a full data leak.

| Credential state | Expected |
|---|---|
| No credential | `401` |
| Malformed / wrong scheme (`Bearer`, `Bearer abc`, `Basic …`, token without scheme, garbage cookie, wrong API key) | `401` |
| JWT with changed claims but the old signature (e.g. `role: admin`) | `401` |
| Unsigned JWT (`alg: "none"`) | `401` |
| Expired token / expired session | `401` |
| Token for another issuer or audience | `401` |
| Revoked token / logged-out session | `401` |
| Valid credential | continues to authorization |
| Login: wrong password vs unknown user | same status, **same message** (no account enumeration) |
| Login lockout / rate limit (if documented) | `429`/`423` after the threshold, with `Retry-After` |

How the kit builds bad credentials without waiting or guessing:

- **JWT tampering and `alg:none`** are built from a real token (`tokens.ts`). Nothing else is needed. If the bearer tokens are opaque random strings (not JWTs), set `authn.tokenFormat: 'opaque'` and these tests are not generated.
- **Expired / wrong `iss`/`aud`**: if the test environment shares an HS256 secret, set `authn.jwtSecretEnv` and the kit re-signs real claims. Otherwise (RS256) ask the developers for a pre-made expired token in `authn.expiredTokenEnv`. If neither exists, the test is **skipped with a reason** that shows in the report. It never passes silently.
- **Expired sessions (cookies)**: use a test-only hook in `authn.expire`, for example an admin/test endpoint that sets `expires_at` in the past, or a dedicated environment with a short session TTL.
- **Logout**: `authn.logout` logs in fresh, logs out, and proves the old credential now gets `401`.
- Use a **dedicated QA account** for the wrong-password check, because failed logins count toward lockouts.
- Mark logout / revoke-token endpoints with `revokesCredential: true` in config. Their tests then always log in fresh, so they never revoke a credential another test is using.
- Public endpoints (`protected: false`, e.g. a health check) get one test: they work **without** credentials.

## 3. Pillar 3 — Authorization (what may you do?)

Build a **role × action matrix** from the contract and turn every cell into a test. In the kit, the matrix is the `allow` list on each endpoint: tenant-A principals in the list must succeed, everyone else must get `conventions.forbidden`.

```
                 create  read-own  read-others  update-own  update-others  delete  admin-action
anonymous          401     401        401          401          401         401       401
viewer             403     200        403/404      403          403/404     403       403
member             201     200        403/404      200          403/404     403       403
admin (same org)   201     200        200          200          200         204       200
admin (other org)  403/404 403/404    403/404      403/404      403/404     403/404   403/404
```

Use the project's convention consistently for "you may not see this": `403` (exists, forbidden) or `404` (existence hidden). Mixing them leaks information. Record it in `conventions.crossTenant`.

Cases that must be present (the kit generates the first four from config):

- **Every principal on every endpoint.** For each denial, re-read the resource as its owner and assert **nothing changed**.
- **Cross-tenant, path level.** The other tenant's admin calls tenant A's path (`/orgs/{A}/…`).
- **Cross-tenant, object level (IDOR).** The other tenant uses **its own** tenant in the path with tenant A's object id (`/orgs/{B}/invoices/{A's id}`), or simply A's id where the path has no tenant. This is the single most common serious API bug. A path-level check passing tells you nothing about it.
- **List leaks.** Tenant A's new item never appears in tenant B's list, on any page.
- Vertical escalation: a low role sets a privileged field (`role`, `isAdmin`, `orgId`). This is covered by the payload privileged-field test.
- Method coverage: authorization often exists on `GET` and is missing on `PATCH`/`DELETE`/bulk/GraphQL mutations.
- API keys and scopes: a read-scope key cannot write; a key from one project cannot touch another. Model each key as its own principal.
- A user who belongs to several tenants with different roles: model them as **two principals** with the same login (one per tenant). Add a transition case for anything that needs both at once.
- Role change takes effect on the next request (or after the documented token lifetime).
- Field-level rules: a hidden field is **absent**, not just empty, for lower roles.

## 4. Status codes — what each one should mean

Assert the exact status the contract documents. "Any 4xx" is not an assertion.

| Code | Meaning | Typical test |
|---|---|---|
| 200 OK | Read/update succeeded, body returned | GET, PATCH, idempotent replay (some APIs) |
| 201 Created | Resource created | POST create; check `Location` and the new id |
| 202 Accepted | Accepted for async processing | Poll the status resource with `expect.poll` |
| 204 No Content | Success with no body | DELETE, logout |
| 400 Bad Request | Validation / malformed input | Every payload rejection, bad query params |
| 401 Unauthorized | Not authenticated | Pillar 2 |
| 403 Forbidden | Authenticated, not allowed | Pillar 3 (and cross-tenant, if that's the convention) |
| 404 Not Found | Unknown route/resource, or existence hidden | Unknown id, soft-deleted item, cross-tenant (if hidden) |
| 405 Method Not Allowed | Known path, wrong method (with `Allow` header) | `methodNotAllowed`. Some APIs answer `404` by contract — follow it |
| 409 Conflict | Unique violation, invalid state transition, key reuse | Duplicate create, transitions |
| 413 Payload Too Large | Body over the limit | Oversized body |
| 415 Unsupported Media Type | Wrong `Content-Type` | `text/plain` body |
| 422 Unprocessable Entity | Semantically invalid (some APIs use it instead of 400), idempotency key reuse | Per contract |
| 429 Too Many Requests | Rate limit / lockout, with `Retry-After` | Login lockout, rate-limit smoke |
| 500 Internal Server Error | Never the right answer to client input | Any 5xx in a negative test is a bug |

## 5. Idempotency and retries

Networks retry, users double-click and webhooks arrive twice. "Idempotent" means doing it twice has the same effect as doing it once.

- **Safe and idempotent methods:** `GET` must not change anything. `PUT` with the same body twice gives the same result. `DELETE` twice → the second gets `404` (or `204` if the contract says so) and nothing else changes.
- **`POST` with an idempotency key** (`Idempotency-Key`, `X-Idempotency-Key` …):
  - **Same key + same body** → the original result is replayed. The status is the one the contract documents, and the **same id / paymentId** comes back. Exactly **one** real effect.
  - **Same key + different body** → rejected (`409`/`422` per contract), and nothing new is created.
  - **Missing key where it is required** → `400`, nothing created.
  - **Two requests with the same key at the same moment** → exactly one effect. This catches race conditions the sequential test cannot.
- **Measure the effect, not just the status.** `effectCount` counts real rows or items carrying **this request's unique value**. Never use a global total: tests run in parallel, so a total moves on its own and the check becomes flaky or blind.
- **Webhooks / events** (when the API consumes them): duplicate delivery → one effect; out-of-order delivery → correct final state; bad signature → rejected.

## 6. Schemas and contracts

- **zod** (`z.object({...}).strict()`) for each success body. Strict means an unexpected field fails the test, which is how leaks get caught.
- **OpenAPI**: `openApiSchema('openapi.json', 'Invoice')` (`support/openapi.ts`) validates a response against the project's own spec with ajv (6 or 8). OpenAPI 3.0 `nullable` is converted for you. Download the spec from the API or use the repo copy. A test failing here means **either** the API or the spec is wrong. Both are defects.
- **Consumer-driven contract tests (Pact)** between services are a separate layer. These API tests check one provider against its published contract.
- **GraphQL**: errors usually come back as HTTP `200` with an `errors` array. Assert `errors` is absent on success and present (with the right `extensions.code`) on failure. Test authorization per resolver/field, and test query depth/complexity limits.

## 7. Assertion rules

These rules exist because weak assertions produce green tests that prove nothing.

- Assert status **and** body on every request. `expect(res.status()).toBe(200)` alone is not a test.
- Expected values come from an **independent source**: the request you sent, seed data or the contract. Never copy them from the response you are checking, and never from a previous run.
- No conditional assertions (`if (res.ok()) expect(...)`). A test has one defined outcome. Use `test.skip(condition, 'reason')` so a gap is visible in the report.
- No `toBeTruthy()` on response data: it passes on `"undefined"` strings and `[]`.
- After any denied write, re-read as the owner and confirm nothing changed.
- **Raw bodies must be Buffers.** Playwright JSON-encodes a *string* `data` when `Content-Type` is `application/json`, so `'{"bad": '` arrives as a valid JSON string. Your "malformed JSON" test then passes even when the server returns `500`. Always use `data: Buffer.from(raw)` (the kit's `sendRaw`).
- No `waitForTimeout`/sleeps. For async effects use `expect.poll` with a timeout.
- One behaviour per test, and a name that reads like a bug title when it fails.

## 8. Test data, isolation and configuration

- Each test creates what it needs (`setup` in config) with **unique values** (`h.uniq()`). It never relies on data another test left behind, and never modifies data it did not create.
- Seed through the API (or a documented seed script), never by hand in the UI.
- Everything comes from env vars or config: base URL, credentials for every role, tenant ids, secrets. Load with a clear error if something is missing. A test file never contains a literal URL, email, password or key.
- Log in **fresh per test** by default (best isolation). For large suites set `QA_AUTH_CACHE=worker` to log in once per worker and role. The logout and expiry tests, and any endpoint marked `revokesCredential`, always use fresh credentials. Only enable the cache after marking every logout/revoke endpoint.
- `playwright.config.ts` loads `.env` with Node's built-in `process.loadEnvFile` (Node ≥ 21.7; no dotenv needed). Real CI variables win. `test-results/` is wiped at the start of each run, so set `QA_RESULTS_FILE` to keep results from several runs.
- Payload targets can be **update** endpoints (PUT/PATCH) too. The endpoint's `setup` creates a fresh resource for every case, so the field matrix runs against a real id.
- `transitions` steps accept `verify: (body) => { expect(...) }` for checks beyond the status code (state field, error message, totals). Use it for project-specific request sequences, and name them clearly in the report.
- Tests create their own data, so the database does not need a reset between runs.
- `assertNotProduction` refuses production-looking URLs (and any host in `QA_PRODUCTION_HOSTS`).

---

## 9. The kit — files (copy unchanged; only `tests/api.config.ts` is per project)

Layout (adapt the root folder to the repo; keep the relative structure):

```
playwright.config.ts
tools/qa-report.mjs                 # results → Markdown report
tests/
  api.config.ts                     # ← the ONLY per-project file (section 10)
  support/
    types.ts  env.ts  tokens.ts  auth.ts  expect-api.ts  fixture.ts  call.ts  openapi.ts
  api/
    authn.spec.ts  authz.spec.ts  payload.spec.ts  idempotency.spec.ts  behaviour.spec.ts
```

Dependencies: `@playwright/test`, `zod` (3 or 4), optionally `ajv` (6 or 8) for OpenAPI schemas, and `@types/node` for strict TypeScript. API tests need **no browser**. If `tsconfig` `strict` is on, the kit compiles cleanly.

### `playwright.config.ts`

````ts
// playwright.config.ts — API / DB test runner settings. No browser is needed for these specs.
import { defineConfig } from '@playwright/test';

// Load .env without any dependency (Node >= 21.7). Real CI secrets always win over the file.
try { process.loadEnvFile(process.env.QA_ENV_FILE ?? '.env'); } catch { /* no .env file: rely on the environment */ }

export default defineConfig({
  testDir: './tests',
  testMatch: /.*\.spec\.ts$/,
  fullyParallel: true,
  workers: process.env.QA_WORKERS ? Number(process.env.QA_WORKERS) : 4,
  retries: 0, // a retry hides flakiness; fix the cause instead
  timeout: 60_000,
  // test-results/ is wiped at the start of every run: set QA_RESULTS_FILE to keep results of several runs.
  reporter: [['list'], ['json', { outputFile: process.env.QA_RESULTS_FILE ?? 'test-results/results.json' }]],
});
````

### `tools/qa-report.mjs`

````js
#!/usr/bin/env node
// qa-report.mjs — turn Playwright's JSON results into a plain-language Markdown test report. No dependencies.
// Usage: node tools/qa-report.mjs [results.json] [--name "Orders API"] [--kind API|DB] [--out reports/]
import { mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';

const args = process.argv.slice(2);
const opt = (k, d) => { const i = args.indexOf(`--${k}`); return i >= 0 ? args[i + 1] : d; };
const file = args.find((a) => a.endsWith('.json')) ?? 'test-results/results.json';
const name = opt('name', 'API');
const kind = opt('kind', 'API');
const outDir = opt('out', 'reports');

const PILLARS = {
  '@authn': ['Authentication', 'The API accepted a missing, broken, expired or revoked credential — anyone could get in.'],
  '@authz': ['Authorization', 'A role or another tenant could do something the contract forbids — an access-control defect.'],
  '@payload': ['Payload & schema', 'Bad input was accepted, good input was rejected, or the response shape/values are wrong or leak data.'],
  '@idempotency': ['Idempotency', 'A retry created a second effect (duplicate row, second charge) or did not replay the first result.'],
  '@status': ['Status codes & errors', 'Wrong status code or an error outside the agreed error envelope.'],
  '@lists': ['Lists & pagination', 'Paging limits are not enforced, or another tenant\'s items appear in a list.'],
  '@transitions': ['State transitions', 'A forbidden state change was allowed (or an allowed one refused).'],
  '@data-health': ['Data health', 'Rows in the database break a rule that must always hold.'],
  '@db': ['Database effects', 'The request did not write exactly what it should (extra/missing rows, wrong columns, no rollback, wrong tenant).'],
};

const json = JSON.parse(readFileSync(file, 'utf8'));
const tests = [];
(function walk(suite, titles, fileName) {
  for (const s of suite.suites ?? []) walk(s, [...titles, s.title], s.file ?? fileName);
  for (const spec of suite.specs ?? []) for (const t of spec.tests) {
    const r = t.results.at(-1) ?? {};
    const tags = [...new Set([...(spec.tags ?? []).map((x) => (x.startsWith('@') ? x : `@${x}`)), ...((spec.title.match(/@[\w-]+/g)) ?? [])])];
    tests.push({
      title: [...titles.slice(1), spec.title].filter(Boolean).join(' › '),
      file: spec.file ?? fileName, line: spec.line, tags,
      status: t.status === 'skipped' ? 'skipped' : r.status === 'passed' ? 'passed' : 'failed',
      error: (r.error?.message ?? '').replace(/\u001b\[[0-9;]*m/g, '').split('\n').filter(Boolean).slice(0, 4).join(' ').slice(0, 500),
      skip: (t.annotations ?? []).find((a) => a.type === 'skip')?.description ?? '',
      ms: r.duration ?? 0,
    });
  }
})(json, [], '');

const pillarOf = (t) => Object.keys(PILLARS).find((p) => t.tags.includes(p) && p !== '@db') ?? (t.tags.includes('@db') ? '@db' : 'other');
const failed = tests.filter((t) => t.status === 'failed');
const skipped = tests.filter((t) => t.status === 'skipped');
const verdict = failed.length ? 'FAILED' : 'PASSED';
const date = new Date().toISOString().slice(0, 10);
const host = (() => { try { return new URL(process.env.API_BASE_URL ?? '').host || 'n/a'; } catch { return 'n/a'; } })();
const esc = (s) => String(s).replace(/\|/g, '\\|');

const rows = Object.entries(PILLARS).map(([p, [label]]) => {
  const g = tests.filter((t) => pillarOf(t) === p);
  return g.length ? `| ${label} | ${g.length} | ${g.filter((t) => t.status === 'passed').length} | ${g.filter((t) => t.status === 'failed').length} | ${g.filter((t) => t.status === 'skipped').length} |` : null;
}).filter(Boolean);

const md = [
  `# ${name} — ${kind} test report`,
  '',
  `**Verdict: ${verdict}** · ${date} · target host: \`${host}\`${process.env.DB_ENGINE ? ` · DB: ${process.env.DB_ENGINE} (${process.env.DB_ACCESS_MODE ?? 'driver'})` : ''}`,
  '',
  `${tests.length} tests: ${tests.length - failed.length - skipped.length} passed, ${failed.length} failed, ${skipped.length} not run (see "Not covered").`,
  '',
  '## Summary by area',
  '',
  '| Area | Tests | Passed | Failed | Not run |',
  '|---|---:|---:|---:|---:|',
  ...rows,
  '',
  '## Failures',
  '',
  ...(failed.length ? Object.keys(PILLARS).concat('other').flatMap((p) => {
    const g = failed.filter((t) => pillarOf(t) === p);
    if (!g.length) return [];
    const [label, meaning] = PILLARS[p] ?? ['Other', ''];
    return [`### ${label} (${g.length})`, '', meaning ? `What this usually means: ${meaning}` : '', '',
      ...g.map((t) => `- **${esc(t.title)}** — \`${t.file}:${t.line}\`\n  - Result: ${esc(t.error || 'failed')}\n  - Re-run alone: \`npx playwright test ${t.file} -g "${t.title.split(' › ').pop().replace(/[\\^$.*+?()[\]{}|"]/g, '\\$&').slice(0, 80)}"\``), ''];
  }) : ['None.', '']),
  '## Not covered',
  '',
  ...(skipped.length ? skipped.map((t) => `- ${esc(t.title)} — ${esc(t.skip || 'skipped')}`) : ['Everything in scope ran.']),
  '',
  '## Next steps',
  '',
  failed.length
    ? '1. Re-run each failure alone (command below) to rule out flakiness.\n2. Do a root-cause analysis (file, line, commit) before filing a ticket; environment or spec-gap results are not product bugs.\n3. File one ticket per root cause with the request, response and (for DB tests) the exact query and masked rows.'
    : 'No defects found in scope. Review "Not covered" — each line is a gap a human should accept or close.',
  '',
  '## How to reproduce',
  '',
  '```bash',
  'npx playwright test --grep "<part of the test title>"',
  '```',
  '',
  `Raw results: \`${file}\``,
  '',
].join('\n');

mkdirSync(outDir, { recursive: true });
const slug = name.replace(/[^A-Za-z0-9]+/g, '-').replace(/^-|-$/g, '');
const out = join(outDir, `${slug}_${verdict}_${kind}-Test-Report_${date}.md`);
writeFileSync(out, md);
console.log(out);
process.exitCode = failed.length ? 1 : 0;
````

### `tests/support/types.ts`

````ts
// types.ts — the shape of api.config.ts. The generic specs read ONLY this; nothing project-specific lives in them.
import type { APIRequestContext, APIResponse } from '@playwright/test';

export type Method = 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE';
export type TenantKey = 'A' | 'B';
export type Ids = Record<string, string | number>;

/** Any validator with zod's safeParse shape (zod 3 or 4, or the OpenAPI/ajv wrapper in openapi.ts). */
export interface Schema {
  safeParse(input: unknown): { success: boolean; error?: unknown };
}

export type AuthSpec =
  | { kind: 'bearer-login'; path: string; body: () => Record<string, unknown>; tokenPath: string; scheme?: string }
  | { kind: 'bearer-env'; tokenEnv: string; scheme?: string }
  | { kind: 'cookie-login'; path: string; body: () => Record<string, unknown>; cookieName: string }
  | { kind: 'header'; header: string; valueEnv: string }
  | { kind: 'none' };

export interface Principal {
  tenant: TenantKey;
  auth: AuthSpec;
}

export type Credential =
  | { kind: 'bearer'; token: string; scheme: string }
  | { kind: 'cookie'; name: string; value: string }
  | { kind: 'header'; header: string; value: string }
  | { kind: 'none' };

export interface Helpers {
  /** Request context logged in as a principal from config.principals. `fresh` skips the per-worker cache. */
  as(principal: string, opts?: { fresh?: boolean }): Promise<APIRequestContext>;
  /** The credential behind a principal (token, cookie or key) — used to build broken variants. */
  credentialOf(principal: string, opts?: { fresh?: boolean }): Promise<Credential>;
  /** Context with NO credentials. Pass headers yourself. */
  raw: APIRequestContext;
  /** Unique value per call: qa_<run>_<n>[_label]. Letters, digits and underscores only. */
  uniq(label?: string): string;
  tenantId(t: TenantKey): string;
}

export interface PathArgs {
  /** Tenant id to put in the path (owner's tenant, or the caller's for the object-level cross-tenant variant). */
  tenant: string;
  ids: Ids;
}

export interface Endpoint {
  id: string;
  method: Method;
  path: (a: PathArgs) => string;
  body?: (h: Helpers, ids: Ids) => unknown;
  headers?: (h: Helpers) => Record<string, string>;
  /** Default true. false = public endpoint (no authentication expected). */
  protected?: boolean;
  /** Principals of tenant A that may call it. Every other tenant-A principal must get conventions.forbidden. */
  allow: string[];
  success: number | number[];
  /** Schema of a successful response body (strict, so unexpected fields fail). */
  schema?: Schema;
  /** Creates a fresh tenant-A resource for this call and returns its ids. Runs as config.setupPrincipal. */
  setup?: (h: Helpers) => Promise<Ids>;
  /** Owner's view of the resource, used to prove a denied write changed nothing. */
  readBack?: (h: Helpers, ids: Ids) => Promise<APIResponse>;
  /** Default true. false = not tied to a tenant (e.g. GET /me). */
  tenantScoped?: boolean;
  /** true = calling it logs the caller out (logout / revoke-token). Tests then always use a fresh credential. */
  revokesCredential?: boolean;
  /** true = a successful response must carry a Location header (typical for 201 Created). */
  location?: boolean;
}

/** `invalid`: extra values the contract forbids (e.g. lowercase for an UPPERCASE-only pattern) — each must be rejected. */
export type FieldRule =
  | { type: 'string'; invalid?: unknown[]; required?: boolean; nullable?: boolean; minLength?: number; maxLength?: number;
      format?: 'email' | 'uuid' | 'date-time' | 'url'; pattern?: boolean; trims?: boolean; freeText?: boolean }
  | { type: 'enum'; invalid?: unknown[]; required?: boolean; nullable?: boolean; values: string[] }
  | { type: 'number'; invalid?: unknown[]; required?: boolean; nullable?: boolean; min?: number; max?: number; exclusiveMin?: number; maxDecimals?: number }
  | { type: 'integer'; invalid?: unknown[]; required?: boolean; nullable?: boolean; min?: number; max?: number }
  | { type: 'boolean'; invalid?: unknown[]; required?: boolean; nullable?: boolean }
  | { type: 'array'; invalid?: unknown[]; required?: boolean; nullable?: boolean; maxItems?: number; items: Record<string, FieldRule>; validItem: (h: Helpers) => Record<string, unknown> };

export interface PayloadTarget {
  /** Endpoint id (a create/update endpoint) the request-field matrix is sent to. */
  endpoint: string;
  principal: string;
  validBody: (h: Helpers) => Record<string, unknown>;
  fields: Record<string, FieldRule>;
  /** What the contract says about fields it does not know: silently ignore, or 400. */
  unknownFields: 'ignore' | 'reject';
  /** Server-controlled fields a client might try to set (id, tenant, role, status...). Must never be applied. */
  privilegedFields?: (h: Helpers) => Record<string, unknown>;
  /** How the server stores a sent value (e.g. lower-case email, trimmed name). Default: unchanged. */
  normalize?: Record<string, (value: unknown) => unknown>;
  /** Unwrap the resource from a response body (e.g. body => body.data). Default: the body itself. */
  item?: (body: any) => any;
  /** GET the created resource as its owner, for the round-trip check. */
  readBack?: (h: Helpers, created: any) => Promise<APIResponse>;
}
// Payload targets may be create (POST) or update (PUT/PATCH) endpoints: the endpoint's `setup` runs first, so updates get real ids.

export interface IdempotencyCase {
  name: string;
  endpoint: string;
  principal: string;
  header: string;
  /** Missing header must be rejected (conventions.validation). */
  required?: boolean;
  body?: (h: Helpers, ids: Ids) => unknown;
  differentBody?: (h: Helpers, ids: Ids) => unknown;
  firstStatus: number;
  replayStatus: number;
  differentBodyStatus?: number;
  /** Value that must be identical between the first response and the replay (id, paymentId...). */
  identity: (body: any) => unknown;
  /**
   * How many real effects exist for THIS request body (rows/items carrying its unique value).
   * Scope it to the body's own unique data — tests run in parallel, so a global total moves on its own.
   */
  effectCount?: (h: Helpers, ids: Ids, body: any) => Promise<number>;
  /** Also fire two requests with the same key at the same time and require exactly one effect. */
  concurrent?: boolean;
}

export interface ListCase {
  name: string;
  path: (a: PathArgs) => string;
  principal: string;
  sizeParam: string;
  maxSize: number;
  minSize?: number;
  /** 'page' (1-based) or 'offset' (0-based) */
  pager?: { param: string; kind: 'page' | 'offset' };
  items: (body: any) => unknown[];
  total?: (body: any) => number;
  idOf: (item: any) => unknown;
  itemSchema?: Schema;
  /** Creates a tenant-A resource; the cross-tenant principal must never see it in its own list. */
  leakSetup?: (h: Helpers) => Promise<unknown>;
}

export interface TransitionCase {
  name: string;
  setup: (h: Helpers) => Promise<Ids>;
  /** `verify` gets the parsed body of that step for extra checks (use expect() inside). */
  steps: Array<{ name: string; call: (h: Helpers, ids: Ids) => Promise<APIResponse>; expect: number; verify?: (body: any) => void | Promise<void> }>;
}

export interface PartialUpdateCase {
  /** A PATCH endpoint (with setup + readBack). Only the sent fields may change. */
  endpoint: string;
  principal: string;
  body: (h: Helpers, ids: Ids) => Record<string, unknown>;
  /** Fields the server may change on its own (e.g. updatedAt). */
  volatile: string[];
  /** Unwrap the resource from a response body (e.g. body => body.data). */
  item?: (body: any) => any;
}

export interface ApiConfig {
  baseUrlEnv: string;
  tenants: Record<TenantKey, () => string>;
  principals: Record<string, Principal>;
  /** Tenant-A principal that creates fixtures (usually the admin). */
  setupPrincipal: string;
  /** A principal in tenant B with the highest role — used for every cross-tenant check. */
  crossTenantPrincipal: string;
  conventions: {
    unauthenticated: number;
    forbidden: number;
    /** What a tenant gets for another tenant's resource: [404] (hide) or [403] — follow the contract. */
    crossTenant: number[];
    notFound: number;
    validation: number;
    malformedJson: number;
    /** null = the API does not check content type. */
    unsupportedMediaType: number | null;
    payloadTooLarge: { status: number; maxBytes: number } | null;
    conflict: number;
    /** Content type every error must have. Default: any JSON (application/json or application/*+json). */
    errorContentType?: RegExp;
  };
  errorEnvelope: {
    schema: Schema;
    /** Field names reported by a validation error (empty array if none). */
    fieldsOf: (body: any) => string[];
    /** true if validation errors name the offending field. */
    namesFields: boolean;
  };
  /** Keys that must never appear anywhere in a JSON response (checked case-insensitively, at any depth). */
  leakKeys: string[];
  endpoints: Endpoint[];
  authn: {
    /** Principal whose real credential is broken in different ways. */
    probePrincipal: string;
    /** 'opaque' = bearer tokens are random strings, not JWTs: the JWT-forgery tests are not generated. Default 'jwt'. */
    tokenFormat?: 'jwt' | 'opaque';
    /** For JWT bearer auth: env var holding the HS256 secret of the TEST environment (optional). */
    jwtSecretEnv?: string;
    /** Claim changes used for the tampered-token test (keeps the old signature). */
    escalateClaims?: Record<string, unknown>;
    /** Env var holding a pre-made expired token, when signing is not possible (RS256 etc.). */
    expiredTokenEnv?: string;
    logout?: { method: Method; path: string; principal: string };
    /** Project hook that expires a session/credential (e.g. via a test endpoint). */
    expire?: (h: Helpers, credential: Credential) => Promise<void>;
    login?: {
      path: string;
      wrongPassword: () => Record<string, unknown>;
      unknownUser: (h: Helpers) => Record<string, unknown>;
      failStatus: number;
      message: (body: any) => unknown;
    };
  };
  payload: PayloadTarget[];
  idempotency: IdempotencyCase[];
  lists: ListCase[];
  transitions: TransitionCase[];
  partialUpdates: PartialUpdateCase[];
  behaviour: {
    unknownRoute: { path: string; principal: string };
    methodNotAllowed?: { method: Method; path: (a: PathArgs) => string; principal: string; expect: number; allowHeader?: boolean };
    notFound: Array<{ name: string; call: (h: Helpers) => Promise<APIResponse> }>;
    conflicts: Array<{ name: string; endpoint: string; principal: string; body: (h: Helpers) => unknown }>;
    deleteTwice: Array<{ endpoint: string; principal: string; secondStatus: number[] }>;
  };
}
````

### `tests/support/env.ts`

````ts
// env.ts — every URL, account, secret and id comes from the environment. Nothing is hardcoded.

export function env(name: string): string {
  const value = process.env[name];
  if (value === undefined || value === '') {
    throw new Error(`Missing environment variable ${name}. Put it in .env or CI secrets — never in a test file.`);
  }
  return value;
}

export function envOr(name: string, fallback: string): string {
  const value = process.env[name];
  return value === undefined || value === '' ? fallback : value;
}

export function hasEnv(name: string): boolean {
  const value = process.env[name];
  return value !== undefined && value !== '';
}

/**
 * Refuse production-looking targets. Extra hostnames can be listed in QA_PRODUCTION_HOSTS (comma-separated).
 * QA_ALLOW_PRODUCTION=yes-i-am-sure is ONLY for read-only smoke runs that a human approved.
 */
export function assertNotProduction(target: string): void {
  if (process.env.QA_ALLOW_PRODUCTION === 'yes-i-am-sure') return;
  const extra = envOr('QA_PRODUCTION_HOSTS', '').split(',').map((s) => s.trim()).filter(Boolean);
  const looksProd = /(^|[^a-z])(prod|production|live)([^a-z]|$)/i.test(target) || extra.some((h) => target.includes(h));
  if (looksProd) throw new Error(`Refusing to run tests against a production-looking target: ${target}`);
}
````

### `tests/support/tokens.ts`

````ts
// tokens.ts — build bad JWTs from a real one, without any library.
import { createHmac } from 'node:crypto';

const b64url = (input: Buffer | string): string => Buffer.from(input).toString('base64url');
const fromB64url = (input: string): string => Buffer.from(input, 'base64url').toString('utf8');

export interface DecodedJwt {
  header: Record<string, unknown>;
  payload: Record<string, unknown>;
  signature: string;
}

export function isJwt(token: string): boolean {
  return /^[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]*$/.test(token);
}

export function decodeJwt(token: string): DecodedJwt {
  const [h, p, s] = token.split('.');
  if (!h || !p || s === undefined) throw new Error('Not a JWT (expected three dot-separated segments)');
  return { header: JSON.parse(fromB64url(h)), payload: JSON.parse(fromB64url(p)), signature: s };
}

/** HS256-sign a payload. Only possible when the test environment shares the signing secret. */
export function signHs256(payload: Record<string, unknown>, secret: string, header: Record<string, unknown> = { alg: 'HS256', typ: 'JWT' }): string {
  const head = b64url(JSON.stringify(header));
  const body = b64url(JSON.stringify(payload));
  const sig = createHmac('sha256', secret).update(`${head}.${body}`).digest('base64url');
  return `${head}.${body}.${sig}`;
}

/** Change claims but keep the ORIGINAL signature → the server must reject it (signature no longer matches). */
export function tamperClaims(token: string, changes: Record<string, unknown>): string {
  const [h, , s] = token.split('.');
  const { payload } = decodeJwt(token);
  return `${h}.${b64url(JSON.stringify({ ...payload, ...changes }))}.${s}`;
}

/** Unsigned token with header alg "none" and the real claims → must be rejected. */
export function algNone(token: string): string {
  const { header, payload } = decodeJwt(token);
  return `${b64url(JSON.stringify({ ...header, alg: 'none' }))}.${b64url(JSON.stringify(payload))}.`;
}

/** Re-sign a real token's claims with changes (expired, wrong issuer/audience). Needs the HS256 secret. */
export function resignHs256(token: string, secret: string, changes: Record<string, unknown>): string {
  const { header, payload } = decodeJwt(token);
  return signHs256({ ...payload, ...changes }, secret, { ...header, alg: 'HS256' });
}

export const nowSeconds = (): number => Math.floor(Date.now() / 1000);
````

### `tests/support/auth.ts`

````ts
// auth.ts — turns a principal from api.config.ts into a credential and a logged-in request context.
// Supported: bearer token from a login call, bearer token from env, cookie session from a login call, API-key header.
import { request as pwRequest, type APIRequestContext } from '@playwright/test';
import type { ApiConfig, Credential } from './types';
import { assertNotProduction, env } from './env';

const workerCache = new Map<string, Credential>(); // used only when QA_AUTH_CACHE=worker

export function baseUrl(cfg: ApiConfig): string {
  const url = env(cfg.baseUrlEnv);
  assertNotProduction(url);
  return url;
}

function at(obj: unknown, path: string): unknown {
  return path.split('.').reduce<unknown>((o, k) => (o && typeof o === 'object' ? (o as Record<string, unknown>)[k] : undefined), obj);
}

async function login(cfg: ApiConfig, name: string): Promise<Credential> {
  const principal = cfg.principals[name];
  if (!principal) throw new Error(`Unknown principal "${name}". Add it to principals in api.config.ts.`);
  const auth = principal.auth;
  switch (auth.kind) {
    case 'bearer-login':
    case 'cookie-login': {
      const ctx = await pwRequest.newContext({ baseURL: baseUrl(cfg) });
      try {
        const res = await ctx.post(auth.path, { data: auth.body() });
        if (!res.ok()) throw new Error(`Login for "${name}" failed: ${res.status()} ${await res.text()}`);
        if (auth.kind === 'bearer-login') {
          const token = at(await res.json(), auth.tokenPath);
          if (typeof token !== 'string') throw new Error(`Login for "${name}": no string at "${auth.tokenPath}" in the response`);
          return { kind: 'bearer', token, scheme: auth.scheme ?? 'Bearer' };
        }
        const cookie = (await ctx.storageState()).cookies.find((c) => c.name === auth.cookieName);
        if (!cookie) throw new Error(`Login for "${name}": no "${auth.cookieName}" cookie was set`);
        return { kind: 'cookie', name: cookie.name, value: cookie.value };
      } finally {
        await ctx.dispose();
      }
    }
    case 'bearer-env':
      return { kind: 'bearer', token: env(auth.tokenEnv), scheme: auth.scheme ?? 'Bearer' };
    case 'header':
      return { kind: 'header', header: auth.header, value: env(auth.valueEnv) };
    case 'none':
      return { kind: 'none' };
  }
}

export async function credentialFor(cfg: ApiConfig, name: string, fresh = false): Promise<Credential> {
  const cache = !fresh && process.env.QA_AUTH_CACHE === 'worker';
  const hit = cache ? workerCache.get(name) : undefined;
  if (hit) return hit;
  const credential = await login(cfg, name);
  if (cache) workerCache.set(name, credential);
  return credential;
}

export function headersFor(c: Credential): Record<string, string> {
  switch (c.kind) {
    case 'bearer': return { Authorization: `${c.scheme} ${c.token}` };
    case 'cookie': return { Cookie: `${c.name}=${c.value}` };
    case 'header': return { [c.header]: c.value };
    case 'none': return {};
  }
}

export function contextWith(cfg: ApiConfig, c: Credential): Promise<APIRequestContext> {
  return pwRequest.newContext({ baseURL: baseUrl(cfg), extraHTTPHeaders: { Accept: 'application/json', ...headersFor(c) } });
}
````

### `tests/support/expect-api.ts`

````ts
// expect-api.ts — assertions that always say WHAT was sent and WHAT came back, so a failure reads like a bug report.
import { expect, type APIResponse } from '@playwright/test';
import type { ApiConfig, Schema } from './types';

export async function bodyOf(res: APIResponse): Promise<any> {
  const text = await res.text();
  try { return text === '' ? undefined : JSON.parse(text); } catch { return text; }
}

function describe(res: APIResponse, body: unknown): string {
  const shown = typeof body === 'string' ? body : JSON.stringify(body);
  return `${res.url()} → ${res.status()} ${shown === undefined ? '(empty body)' : shown.slice(0, 400)}`;
}

/** Status check whose failure message includes the URL and the response body. Returns the parsed body. */
export async function expectStatus(res: APIResponse, expected: number | number[], why = ''): Promise<any> {
  const body = await bodyOf(res);
  const list = Array.isArray(expected) ? expected : [expected];
  expect(list, `${why ? why + ': ' : ''}expected ${list.join(' or ')} — got ${describe(res, body)}`).toContain(res.status());
  return body;
}

export function expectSchema(schema: Schema, body: unknown, label: string): void {
  const result = schema.safeParse(body);
  expect(result.success, `${label} does not match its schema: ${JSON.stringify(result.error ?? '').slice(0, 600)}\nbody: ${JSON.stringify(body).slice(0, 400)}`).toBe(true);
}

/** Every error must be JSON in the project's one envelope; optionally it must name the bad field. */
export async function expectErrorEnvelope(res: APIResponse, cfg: ApiConfig, field?: string): Promise<any> {
  const body = await bodyOf(res);
  const wanted = cfg.conventions.errorContentType ?? /application\/([\w.-]+\+)?json/i;
  expect(res.headers()['content-type'] ?? '', `error response content type must match ${wanted} — got ${describe(res, body)}`).toMatch(wanted);
  expectSchema(cfg.errorEnvelope.schema, body, `error envelope (${res.status()})`);
  if (field && cfg.errorEnvelope.namesFields) {
    const fields = cfg.errorEnvelope.fieldsOf(body);
    expect(fields.some((f) => f === field || f.startsWith(`${field}[`) || f.startsWith(`${field}.`)),
      `validation error should name "${field}" — fields were [${fields.join(', ')}]`).toBe(true);
  }
  return body;
}

/** Keys that must never appear in a response, at any depth (case-insensitive). Returns the paths found. */
export function findLeaks(value: unknown, leakKeys: string[], path = '$'): string[] {
  const wanted = leakKeys.map((k) => k.toLowerCase());
  if (Array.isArray(value)) return value.flatMap((v, i) => findLeaks(v, leakKeys, `${path}[${i}]`));
  if (value && typeof value === 'object') {
    return Object.entries(value as Record<string, unknown>).flatMap(([k, v]) =>
      [...(wanted.includes(k.toLowerCase()) ? [`${path}.${k}`] : []), ...findLeaks(v, leakKeys, `${path}.${k}`)]);
  }
  return [];
}

export function expectNoLeaks(body: unknown, cfg: ApiConfig, label: string): void {
  const leaks = findLeaks(body, cfg.leakKeys);
  expect(leaks, `${label} leaks fields that must never be returned`).toEqual([]);
}

/** Deep-equal check used after a denied write: the owner's view must be byte-for-byte the same. */
export function expectUnchanged(before: unknown, after: unknown, label: string): void {
  expect(after, `${label}: the resource changed even though the request was denied`).toEqual(before);
}
````

### `tests/support/fixture.ts`

````ts
// fixture.ts — one Playwright fixture `h` that every spec uses. Contexts are disposed after each test.
import { test as base, expect, request as pwRequest, type APIRequestContext } from '@playwright/test';
import { config } from '../api.config';
import { baseUrl, contextWith, credentialFor } from './auth';
import type { Helpers } from './types';

const RUN = process.env.QA_RUN_ID ?? Date.now().toString(36);
let counter = 0;

export const test = base.extend<{ h: Helpers }>({
  h: async ({}, use, testInfo) => {
    const opened: APIRequestContext[] = [];
    const raw = await pwRequest.newContext({ baseURL: baseUrl(config), extraHTTPHeaders: { Accept: 'application/json' } });
    opened.push(raw);
    const h: Helpers = {
      raw,
      async as(principal, opts) {
        const ctx = await contextWith(config, await credentialFor(config, principal, opts?.fresh));
        opened.push(ctx);
        return ctx;
      },
      credentialOf: (principal, opts) => credentialFor(config, principal, opts?.fresh),
      uniq: (label) => `qa_${RUN}_w${testInfo.workerIndex}_${++counter}${label ? `_${label}` : ''}`,
      tenantId: (t) => config.tenants[t](),
    };
    await use(h);
    for (const ctx of opened) await ctx.dispose();
  },
});

export { expect, config };
````

### `tests/support/call.ts`

````ts
// call.ts — send a configured endpoint with a given caller, tenant and ids.
import type { APIRequestContext, APIResponse } from '@playwright/test';
import type { Endpoint, Helpers, Ids } from './types';
import { config } from '../api.config';

export function endpoint(id: string): Endpoint {
  const ep = config.endpoints.find((e) => e.id === id);
  if (!ep) throw new Error(`Endpoint "${id}" is not defined in api.config.ts endpoints`);
  return ep;
}

export async function prepare(h: Helpers, ep: Endpoint): Promise<Ids> {
  return ep.setup ? ep.setup(h) : {};
}

export function pathOf(ep: Endpoint, h: Helpers, ids: Ids, tenant: 'A' | 'B' = 'A'): string {
  return ep.path({ tenant: h.tenantId(tenant), ids });
}

export async function callEndpoint(
  ctx: APIRequestContext, h: Helpers, ep: Endpoint, ids: Ids,
  opts: { tenant?: 'A' | 'B'; headers?: Record<string, string>; omitHeaders?: string[]; body?: unknown } = {},
): Promise<APIResponse> {
  const hasBody = ep.method !== 'GET' && ep.method !== 'DELETE';
  const data = opts.body !== undefined ? opts.body : hasBody && ep.body ? ep.body(h, ids) : undefined;
  const headers: Record<string, string> = { ...(ep.headers ? ep.headers(h) : {}), ...(opts.headers ?? {}) };
  for (const name of opts.omitHeaders ?? []) delete headers[name];
  return ctx.fetch(pathOf(ep, h, ids, opts.tenant ?? 'A'), { method: ep.method, data: data as never, headers });
}

/**
 * Send a raw body with any content type (malformed JSON, wrong media type).
 * MUST be a Buffer: Playwright JSON-encodes a *string* `data` when Content-Type is application/json,
 * so '{"bad": ' would arrive as a valid JSON string and the test would pass for the wrong reason.
 */
export async function sendRaw(ctx: APIRequestContext, h: Helpers, ep: Endpoint, ids: Ids, body: string, contentType: string): Promise<APIResponse> {
  return ctx.fetch(pathOf(ep, h, ids), {
    method: ep.method,
    data: Buffer.from(body, 'utf8'),
    headers: { ...(ep.headers ? ep.headers(h) : {}), 'Content-Type': contentType },
  });
}

export const isProtected = (ep: Endpoint): boolean => ep.protected !== false;
````

### `tests/support/openapi.ts`

````ts
// openapi.ts — use a schema from the project's OpenAPI file as a response contract (optional; needs `ajv`).
// Works with ajv 6 or 8. OpenAPI 3.0 `nullable: true` is converted to JSON Schema `type: [..., "null"]`.
import { readFileSync } from 'node:fs';
import { createRequire } from 'node:module';
import type { Schema } from './types';

const req = createRequire(`${process.cwd()}/package.json`); // resolve ajv from the project root (CJS or ESM projects)

function convert(node: unknown): unknown {
  if (Array.isArray(node)) return node.map(convert);
  if (!node || typeof node !== 'object') return node;
  const out: Record<string, unknown> = {};
  for (const [k, v] of Object.entries(node as Record<string, unknown>)) if (k !== 'nullable') out[k] = convert(v);
  const src = node as Record<string, unknown>;
  if (src.nullable === true) {
    if (typeof src.type === 'string') out.type = [src.type, 'null'];
    if (Array.isArray(src.enum)) out.enum = [...(src.enum as unknown[]), null];
  }
  return out;
}

/** Schema from `components.schemas[name]` of an OpenAPI JSON file (download it from the API or use the repo copy). */
export function openApiSchema(specFile: string, name: string): Schema {
  let validate: ((data: unknown) => boolean) & { errors?: unknown };
  return {
    safeParse(input: unknown) {
      if (!validate) {
        const spec = JSON.parse(readFileSync(specFile, 'utf8'));
        const schemas = convert(spec.components?.schemas ?? {}) as Record<string, unknown>;
        if (!schemas[name]) throw new Error(`OpenAPI file ${specFile} has no components.schemas.${name}`);
        const AjvModule = req('ajv');
        const Ajv = AjvModule.default ?? AjvModule;
        const major = Number(req('ajv/package.json').version.split('.')[0]);
        const ajv = major >= 8 ? new Ajv({ allErrors: true, strict: false }) : new Ajv({ allErrors: true, unknownFormats: 'ignore' });
        validate = ajv.compile({ ...(schemas[name] as object), components: { schemas } });
      }
      const ok = validate(input);
      return ok ? { success: true } : { success: false, error: validate.errors };
    },
  };
}
````

### `tests/api/authn.spec.ts`

````ts
// Pillar 2 — Authentication. Generated from api.config.ts; do not edit per project.
import { test, expect, config } from '../support/fixture';
import { callEndpoint, isProtected, prepare } from '../support/call';
import { expectErrorEnvelope, expectStatus } from '../support/expect-api';
import { algNone, isJwt, nowSeconds, resignHs256, tamperClaims, decodeJwt } from '../support/tokens';
import { contextWith, headersFor } from '../support/auth';
import { hasEnv, env } from '../support/env';
import type { Credential, Endpoint } from '../support/types';

const C = config.conventions;
const probe = config.authn.probePrincipal;
const protectedEndpoints = config.endpoints.filter(isProtected);
const usesBearer = (config.principals[probe]?.auth.kind.startsWith('bearer') ?? false) && config.authn.tokenFormat !== 'opaque'; // JWT checks only apply to JWT bearer tokens
const probeEndpoint: Endpoint | undefined = protectedEndpoints.find((e) => e.method === 'GET' && !e.setup) ?? protectedEndpoints.find((e) => e.method === 'GET');

function brokenVariants(c: Credential): Array<Record<string, string>> {
  switch (c.kind) {
    case 'bearer': return [
      { Authorization: c.scheme },                                  // scheme, no token
      { Authorization: `${c.scheme} not-a-real-token` },            // garbage token
      { Authorization: `Basic ${Buffer.from('qa:qa').toString('base64')}` }, // wrong scheme
      { Authorization: c.token },                                   // token without scheme
    ];
    case 'cookie': return [{ Cookie: `${c.name}=qa-not-a-real-session` }, { Cookie: `${c.name}=` }];
    case 'header': return [{ [c.header]: 'qa-not-a-real-key' }];
    case 'none': return [];
  }
}

async function expectRejected(res: Awaited<ReturnType<typeof callEndpoint>>, why: string): Promise<void> {
  await expectStatus(res, C.unauthenticated, why);
  await expectErrorEnvelope(res, config);
}

for (const ep of protectedEndpoints) {
  test.describe(`${ep.method} ${ep.id} — authentication`, { tag: ['@api', '@authn'] }, () => {
    test('no credentials → unauthenticated', async ({ h }) => {
      const ids = await prepare(h, ep);
      await expectRejected(await callEndpoint(h.raw, h, ep, ids), 'no credentials');
    });

    test('malformed or wrong-scheme credentials → unauthenticated', async ({ h }) => {
      const ids = await prepare(h, ep);
      const variants = brokenVariants(await h.credentialOf(probe));
      test.skip(variants.length === 0, 'probe principal has no credential to break');
      for (const headers of variants) await expectRejected(await callEndpoint(h.raw, h, ep, ids, { headers }), `variant ${JSON.stringify(headers)}`);
    });

    if (usesBearer) {
      test('JWT with changed claims (old signature) → unauthenticated', async ({ h }) => {
        const c = await h.credentialOf(probe);
        test.skip(c.kind !== 'bearer' || !isJwt(c.token), 'credential is not a JWT');
        if (c.kind !== 'bearer') return;
        const ids = await prepare(h, ep);
        const forged = tamperClaims(c.token, config.authn.escalateClaims ?? { qa_tampered: true });
        await expectRejected(await callEndpoint(h.raw, h, ep, ids, { headers: { Authorization: `${c.scheme} ${forged}` } }), 'tampered claims');
      });

      test('unsigned JWT (alg "none") → unauthenticated', async ({ h }) => {
        const c = await h.credentialOf(probe);
        test.skip(c.kind !== 'bearer' || !isJwt(c.token), 'credential is not a JWT');
        if (c.kind !== 'bearer') return;
        const ids = await prepare(h, ep);
        await expectRejected(await callEndpoint(h.raw, h, ep, ids, { headers: { Authorization: `${c.scheme} ${algNone(c.token)}` } }), 'alg none');
      });

      test('expired token → unauthenticated', async ({ h }) => {
        const c = await h.credentialOf(probe);
        const secretEnv = config.authn.jwtSecretEnv;
        const canSign = c.kind === 'bearer' && isJwt(c.token) && !!secretEnv && hasEnv(secretEnv);
        const premade = config.authn.expiredTokenEnv && hasEnv(config.authn.expiredTokenEnv) ? env(config.authn.expiredTokenEnv) : undefined;
        test.skip(!canSign && !premade, config.authn.expire ? 'expiry is covered by "expired session/credential" (authn.expire); set authn.jwtSecretEnv or expiredTokenEnv to also test a forged expired JWT' : 'no way to build an expired token: set authn.jwtSecretEnv (HS256 test secret), authn.expiredTokenEnv, or an authn.expire hook');
        if (c.kind !== 'bearer') return;
        const token = canSign ? resignHs256(c.token, env(secretEnv as string), { iat: nowSeconds() - 7200, exp: nowSeconds() - 3600 }) : (premade as string);
        const ids = await prepare(h, ep);
        await expectRejected(await callEndpoint(h.raw, h, ep, ids, { headers: { Authorization: `${c.scheme} ${token}` } }), 'expired token');
      });

      test('token for another issuer or audience → unauthenticated', async ({ h }) => {
        const c = await h.credentialOf(probe);
        const secretEnv = config.authn.jwtSecretEnv;
        test.skip(!(c.kind === 'bearer' && isJwt(c.token) && secretEnv && hasEnv(secretEnv)), 'needs a JWT and the HS256 test secret (authn.jwtSecretEnv)');
        if (c.kind !== 'bearer') return;
        const claims = decodeJwt(c.token).payload;
        test.skip(claims.iss === undefined && claims.aud === undefined, 'token has no iss/aud claims to change');
        const ids = await prepare(h, ep);
        for (const change of [{ iss: 'qa-wrong-issuer' }, { aud: 'qa-wrong-audience' }]) {
          if (!(Object.keys(change)[0] in claims)) continue;
          const token = resignHs256(c.token, env(secretEnv as string), change);
          await expectRejected(await callEndpoint(h.raw, h, ep, ids, { headers: { Authorization: `${c.scheme} ${token}` } }), `changed ${JSON.stringify(change)}`);
        }
      });
    }
  });
}

test.describe('Session lifecycle', { tag: ['@api', '@authn'] }, () => {
  test('logout revokes the credential that was used', async ({ h }) => {
    const lo = config.authn.logout;
    test.skip(!lo || !probeEndpoint, 'no logout endpoint in api.config.ts (authn.logout)');
    if (!lo || !probeEndpoint) return;
    const cred = await h.credentialOf(lo.principal, { fresh: true });
    const ctx = await contextWith(config, cred);
    try {
      const ids = await prepare(h, probeEndpoint);
      await expectStatus(await callEndpoint(ctx, h, probeEndpoint, ids), probeEndpoint.success, 'credential works before logout');
      const out = await ctx.fetch(lo.path, { method: lo.method });
      if (out.status() >= 300) await expectStatus(out, [200, 204], 'logout');
      await expectRejected(await callEndpoint(h.raw, h, probeEndpoint, ids, { headers: headersFor(cred) }), 'old credential after logout');
    } finally {
      await ctx.dispose();
    }
  });

  test('expired session/credential → unauthenticated', async ({ h }) => {
    const expire = config.authn.expire;
    test.skip(!expire || !probeEndpoint, 'no authn.expire hook in api.config.ts (see the skill: short TTL env or a test hook)');
    if (!expire || !probeEndpoint) return;
    const cred = await h.credentialOf(probe, { fresh: true });
    const ids = await prepare(h, probeEndpoint);
    await expectStatus(await callEndpoint(h.raw, h, probeEndpoint, ids, { headers: headersFor(cred) }), probeEndpoint.success, 'fresh credential works');
    await expire(h, cred);
    await expectRejected(await callEndpoint(h.raw, h, probeEndpoint, ids, { headers: headersFor(cred) }), 'expired credential');
  });

  test('login: wrong password and unknown user fail the same way', async ({ h }) => {
    const lg = config.authn.login;
    test.skip(!lg, 'no login endpoint in api.config.ts (authn.login)');
    if (!lg) return;
    const wrong = await h.raw.post(lg.path, { data: lg.wrongPassword() });
    const unknown = await h.raw.post(lg.path, { data: lg.unknownUser(h) });
    const wrongBody = await expectStatus(wrong, lg.failStatus, 'wrong password');
    const unknownBody = await expectStatus(unknown, lg.failStatus, 'unknown user');
    expect(lg.message(unknownBody), 'unknown user must not be distinguishable from wrong password').toEqual(lg.message(wrongBody));
  });
});
````

### `tests/api/authz.spec.ts`

````ts
// Pillar 3 — Authorization: role × endpoint matrix + cross-tenant (IDOR) checks. Generated from api.config.ts.
import { test, expect, config } from '../support/fixture';
import { callEndpoint, isProtected, pathOf, prepare } from '../support/call';
import { bodyOf, expectErrorEnvelope, expectNoLeaks, expectSchema, expectStatus, expectUnchanged } from '../support/expect-api';
import type { Endpoint, Helpers, Ids } from '../support/types';

const C = config.conventions;
const tenantA = Object.entries(config.principals).filter(([, p]) => p.tenant === 'A').map(([name]) => name);
const other = config.crossTenantPrincipal;

async function snapshot(h: Helpers, ep: Endpoint, ids: Ids): Promise<unknown> {
  return ep.readBack ? bodyOf(await ep.readBack(h, ids)) : undefined;
}

for (const ep of config.endpoints.filter(isProtected)) {
  test.describe(`${ep.method} ${ep.id} — authorization`, { tag: ['@api', '@authz'] }, () => {
    for (const principal of tenantA) {
      const allowed = ep.allow.includes(principal);
      test(`${principal} → ${allowed ? 'allowed' : 'forbidden'}`, async ({ h }) => {
        const ids = await prepare(h, ep);
        const before = allowed ? undefined : await snapshot(h, ep, ids);
        const res = await callEndpoint(await h.as(principal, { fresh: ep.revokesCredential }), h, ep, ids);
        if (allowed) {
          const body = await expectStatus(res, ep.success, `${principal} is allowed by the contract`);
          if (ep.location) expect(res.headers()['location'], `${ep.id}: a successful response must carry a Location header`).toBeTruthy();
          if (ep.schema && body !== undefined) expectSchema(ep.schema, body, `${ep.id} response`);
          if (body !== undefined) expectNoLeaks(body, config, `${ep.id} response`);
        } else {
          await expectStatus(res, C.forbidden, `${principal} is not allowed by the contract`);
          await expectErrorEnvelope(res, config);
          if (ep.readBack) expectUnchanged(before, await snapshot(h, ep, ids), `${ep.id} after a forbidden call by ${principal}`);
        }
      });
    }

    // Cross-tenant only makes sense when the request points at tenant A's data: a tenant id in the path or a seeded object id.
    const touchesTenantA = (h: Helpers, ids: Ids): boolean =>
      Object.keys(ids).length > 0 || pathOf(ep, h, ids, 'A') !== pathOf(ep, h, ids, 'B');

    test(`other tenant (${other}) on tenant A's path → denied`, async ({ h }) => {
      test.skip(ep.tenantScoped === false, 'endpoint is not tenant-scoped');
      const ids = await prepare(h, ep);
      test.skip(!touchesTenantA(h, ids), 'request has no tenant id or object id — covered by list-leak and payload tests');
      const before = await snapshot(h, ep, ids);
      const res = await callEndpoint(await h.as(other, { fresh: ep.revokesCredential }), h, ep, ids, { tenant: 'A' });
      await expectStatus(res, C.crossTenant, 'another tenant must not reach this data');
      await expectErrorEnvelope(res, config);
      if (ep.readBack) expectUnchanged(before, await snapshot(h, ep, ids), `${ep.id} after a cross-tenant call`);
    });

    test(`other tenant uses ITS OWN tenant in the path with tenant A's object id (IDOR) → denied`, async ({ h }) => {
      test.skip(ep.tenantScoped === false || !ep.setup, 'no seeded object id for this endpoint');
      const ids = await prepare(h, ep);
      test.skip(pathOf(ep, h, ids, 'A') === pathOf(ep, h, ids, 'B'), 'path has no tenant segment — same request as the test above');
      const before = await snapshot(h, ep, ids);
      const res = await callEndpoint(await h.as(other, { fresh: ep.revokesCredential }), h, ep, ids, { tenant: 'B' });
      await expectStatus(res, C.crossTenant, 'object-level check: the id belongs to another tenant');
      await expectErrorEnvelope(res, config);
      if (ep.readBack) expectUnchanged(before, await snapshot(h, ep, ids), `${ep.id} after an IDOR attempt`);
    });
  });
}

for (const ep of config.endpoints.filter((e) => !isProtected(e))) {
  test(`${ep.method} ${ep.id} — public endpoint works without credentials`, { tag: ['@api', '@authz'] }, async ({ h }) => {
    const ids = await prepare(h, ep);
    const body = await expectStatus(await callEndpoint(h.raw, h, ep, ids), ep.success, 'public endpoint, no credentials');
    if (ep.schema && body !== undefined) expectSchema(ep.schema, body, `${ep.id} response`);
    if (body !== undefined) expectNoLeaks(body, config, `${ep.id} response`);
  });
}
````

### `tests/api/payload.spec.ts`

````ts
// Pillar 1 — Payload: request-field matrix generated from `fields` rules, plus response schema, leaks and round trip.
import { test, expect, config } from '../support/fixture';
import { callEndpoint, endpoint, prepare, sendRaw } from '../support/call';
import { bodyOf, expectErrorEnvelope, expectNoLeaks, expectSchema, expectStatus } from '../support/expect-api';
import type { FieldRule, Helpers, PayloadTarget } from '../support/types';

type Body = Record<string, unknown>;
interface Case { name: string; build: (h: Helpers) => Body; ok: boolean; field?: string; roundTrip?: string }

const C = config.conventions;
const pad = (base: unknown, length: number): string => ('x'.repeat(length) + String(base ?? '')).slice(-length);
const without = (b: Body, k: string): Body => { const c = { ...b }; delete c[k]; return c; };
const SPECIAL = `QA <script>alert(1)</script> ' " ; DROP TABLE t; -- ✓ 漢字 `;

function wrongTypeValue(rule: FieldRule): unknown {
  switch (rule.type) {
    case 'string': case 'enum': return 12345;
    case 'number': return '12.5';
    case 'integer': return '1';
    case 'boolean': return 'true';
    case 'array': return { not: 'an array' };
  }
}

function fieldCases(t: PayloadTarget, field: string, rule: FieldRule): Case[] {
  const valid = (h: Helpers) => t.validBody(h);
  const set = (value: unknown) => (h: Helpers) => ({ ...valid(h), [field]: value });
  const cases: Case[] = [];
  if (rule.required) cases.push({ name: `${field}: missing → rejected`, build: (h) => without(valid(h), field), ok: false, field });
  else cases.push({ name: `${field}: omitted (optional) → accepted`, build: (h) => without(valid(h), field), ok: true });
  cases.push(rule.nullable
    ? { name: `${field}: null (nullable) → accepted`, build: set(null), ok: true, roundTrip: field }
    : { name: `${field}: null → rejected`, build: set(null), ok: false, field });
  cases.push({ name: `${field}: wrong type → rejected`, build: set(wrongTypeValue(rule)), ok: false, field });
  for (const bad of rule.invalid ?? []) cases.push({ name: `${field}: ${JSON.stringify(bad)} (forbidden by the contract) → rejected`, build: set(bad), ok: false, field });

  if (rule.type === 'string') {
    if (rule.minLength && rule.minLength > 0) {
      cases.push({ name: `${field}: shorter than ${rule.minLength} → rejected`, build: set('x'.repeat(rule.minLength - 1)), ok: false, field });
      if (rule.trims) cases.push({ name: `${field}: only whitespace → rejected`, build: set('   '), ok: false, field });
    }
    if (rule.maxLength !== undefined) {
      cases.push({ name: `${field}: ${rule.maxLength + 1} chars (max+1) → rejected`, build: (h) => ({ ...valid(h), [field]: pad(valid(h)[field], rule.maxLength! + 1) }), ok: false, field });
      if (!rule.format && !rule.pattern) cases.push({ name: `${field}: exactly ${rule.maxLength} chars → accepted`, build: (h) => ({ ...valid(h), [field]: pad(valid(h)[field], rule.maxLength!) }), ok: true, roundTrip: field });
    }
    const badFormats: Record<string, string[]> = { email: ['not-an-email', 'two words@example.test'], uuid: ['not-a-uuid'], 'date-time': ['2024-13-45T99:00:00Z'], url: ['not a url'] };
    for (const bad of rule.format ? badFormats[rule.format] : []) cases.push({ name: `${field}: invalid ${rule.format} "${bad}" → rejected`, build: set(bad), ok: false, field });
    if (rule.freeText) {
      cases.push({ name: `${field}: special characters are stored as plain text`, build: (h) => ({ ...valid(h), [field]: `${h.uniq()} ${SPECIAL}`.slice(0, rule.maxLength ?? 200) }), ok: true, roundTrip: field });
      if (rule.trims) cases.push({ name: `${field}: surrounding spaces are trimmed`, build: (h) => ({ ...valid(h), [field]: `  ${String(valid(h)[field])}  ` }), ok: true, roundTrip: field });
    }
  }
  if (rule.type === 'enum') {
    cases.push({ name: `${field}: value outside the enum → rejected`, build: set('QA_NOT_A_VALUE'), ok: false, field });
    for (const v of rule.values) cases.push({ name: `${field}: "${v}" → accepted`, build: set(v), ok: true, roundTrip: field });
  }
  if (rule.type === 'number' || rule.type === 'integer') {
    const step = rule.type === 'integer' ? 1 : 0.01;
    if (rule.min !== undefined) {
      cases.push({ name: `${field}: below minimum (${rule.min - step}) → rejected`, build: set(+(rule.min - step).toFixed(2)), ok: false, field });
      cases.push({ name: `${field}: minimum (${rule.min}) → accepted`, build: set(rule.min), ok: true, roundTrip: field });
    }
    if (rule.type === 'number' && rule.exclusiveMin !== undefined) cases.push({ name: `${field}: equal to exclusive minimum (${rule.exclusiveMin}) → rejected`, build: set(rule.exclusiveMin), ok: false, field });
    if (rule.max !== undefined) {
      cases.push({ name: `${field}: above maximum → rejected`, build: set(+(rule.max + step).toFixed(2)), ok: false, field });
      cases.push({ name: `${field}: maximum (${rule.max}) → accepted`, build: set(rule.max), ok: true, roundTrip: field });
    }
    if (rule.type === 'integer') cases.push({ name: `${field}: decimal where integer expected → rejected`, build: set(1.5), ok: false, field });
    if (rule.type === 'number' && rule.maxDecimals !== undefined) {
      cases.push({ name: `${field}: ${rule.maxDecimals + 1} decimals → rejected`, build: set(Number((1 + 10 ** -(rule.maxDecimals + 1)).toFixed(rule.maxDecimals + 1))), ok: false, field });
      cases.push({ name: `${field}: ${rule.maxDecimals} decimals → accepted exactly`, build: set(Number((12 + 10 ** -rule.maxDecimals * 34).toFixed(rule.maxDecimals))), ok: true, roundTrip: field });
    }
  }
  if (rule.type === 'array') {
    const item = (h: Helpers) => rule.validItem(h);
    cases.push({ name: `${field}: empty array → accepted`, build: set([]), ok: true });
    cases.push({ name: `${field}: one valid item → accepted`, build: (h) => ({ ...valid(h), [field]: [item(h)] }), ok: true });
    for (const [sub, subRule] of Object.entries(rule.items)) {
      if (subRule.required) cases.push({ name: `${field}[].${sub}: missing in an item → rejected`, build: (h) => ({ ...valid(h), [field]: [item(h), without(item(h), sub)] }), ok: false, field });
      cases.push({ name: `${field}[].${sub}: wrong type in an item → rejected`, build: (h) => ({ ...valid(h), [field]: [item(h), { ...item(h), [sub]: wrongTypeValue(subRule) }] }), ok: false, field });
      if ((subRule.type === 'integer' || subRule.type === 'number') && subRule.min !== undefined) {
        cases.push({ name: `${field}[].${sub}: below minimum in an item → rejected`, build: (h) => ({ ...valid(h), [field]: [item(h), { ...item(h), [sub]: subRule.min! - 1 }] }), ok: false, field });
      }
      if ((subRule.type === 'integer' || subRule.type === 'number') && subRule.max !== undefined) {
        cases.push({ name: `${field}[].${sub}: above maximum in an item → rejected`, build: (h) => ({ ...valid(h), [field]: [item(h), { ...item(h), [sub]: subRule.max! + 1 }] }), ok: false, field });
      }
      if (subRule.type === 'string' && subRule.maxLength !== undefined) {
        cases.push({ name: `${field}[].${sub}: ${subRule.maxLength + 1} chars in an item → rejected`, build: (h) => ({ ...valid(h), [field]: [item(h), { ...item(h), [sub]: 'x'.repeat(subRule.maxLength! + 1) }] }), ok: false, field });
      }
      if (subRule.type === 'enum') {
        cases.push({ name: `${field}[].${sub}: value outside the enum in an item → rejected`, build: (h) => ({ ...valid(h), [field]: [item(h), { ...item(h), [sub]: 'QA_NOT_A_VALUE' }] }), ok: false, field });
      }
    }
    cases.push({ name: `${field}: an item that is not an object → rejected`, build: (h) => ({ ...valid(h), [field]: [item(h), 'qa-not-an-object'] }), ok: false, field });
    if (rule.maxItems !== undefined) cases.push({ name: `${field}: ${rule.maxItems + 1} items → rejected`, build: (h) => ({ ...valid(h), [field]: Array.from({ length: rule.maxItems! + 1 }, () => item(h)) }), ok: false, field });
  }
  return cases;
}

for (const t of config.payload) {
  const ep = endpoint(t.endpoint);
  const item = (body: any) => (t.item ? t.item(body) : body);
  const norm = (field: string, v: unknown) => (t.normalize?.[field] ? t.normalize[field](v) : v);

  test.describe(`${ep.method} ${ep.id} — payload`, { tag: ['@api', '@payload'] }, () => {
    test('valid body → success, matches schema, no leaks, round-trips', async ({ h }) => {
      const ids = await prepare(h, ep); // update targets get a real resource
      const sent = t.validBody(h);
      const res = await callEndpoint(await h.as(t.principal), h, ep, ids, { body: sent });
      const body = await expectStatus(res, ep.success, 'valid body');
      if (ep.schema) expectSchema(ep.schema, body, `${ep.id} response`);
      expectNoLeaks(body, config, `${ep.id} response`);
      const created = item(body);
      for (const [k, v] of Object.entries(sent)) {
        if (!(k in created)) continue;
        if (Array.isArray(v)) expect(created[k], `array "${k}" must come back with the same items, in order`).toMatchObject(v);
        else if (v === null || typeof v !== 'object') expect(created[k], `field "${k}" must be stored as sent (normalised)`).toEqual(norm(k, v));
      }
      if (t.readBack) {
        const again = item(await expectStatus(await t.readBack(h, created), 200, 'read back the created resource'));
        expect(again, 'GET after create must return what create returned').toEqual(created);
      }
    });

    for (const [field, rule] of Object.entries(t.fields)) {
      for (const c of fieldCases(t, field, rule)) {
        test(c.name, async ({ h }) => {
          const ids = await prepare(h, ep); // update targets get a real resource
          const sent = c.build(h);
          const res = await callEndpoint(await h.as(t.principal), h, ep, ids, { body: sent });
          if (c.ok) {
            const body = await expectStatus(res, ep.success, c.name);
            if (ep.schema) expectSchema(ep.schema, body, `${ep.id} response`);
            expectNoLeaks(body, config, `${ep.id} response`);
            if (c.roundTrip) expect(item(body)[c.roundTrip], `"${c.roundTrip}" must come back as sent`).toEqual(norm(c.roundTrip, sent[c.roundTrip]));
          } else {
            await expectStatus(res, C.validation, c.name);
            await expectErrorEnvelope(res, config, c.field);
          }
        });
      }
    }

    test(`unknown field → ${t.unknownFields === 'ignore' ? 'ignored, not echoed' : 'rejected'}`, async ({ h }) => {
      const ids = await prepare(h, ep); // update targets get a real resource
      const sent = { ...t.validBody(h), qaUnknownField: 'qa' };
      const res = await callEndpoint(await h.as(t.principal), h, ep, ids, { body: sent });
      if (t.unknownFields === 'ignore') expect(item(await expectStatus(res, ep.success, 'unknown field ignored'))).not.toHaveProperty('qaUnknownField');
      else { await expectStatus(res, C.validation, 'unknown field'); await expectErrorEnvelope(res, config, 'qaUnknownField'); }
    });

    test('server-controlled fields in the body are never applied (mass assignment)', async ({ h }) => {
      const ids = await prepare(h, ep); // update targets get a real resource
      test.skip(!t.privilegedFields, 'no privilegedFields configured');
      const privileged = t.privilegedFields!(h);
      const res = await callEndpoint(await h.as(t.principal), h, ep, ids, { body: { ...t.validBody(h), ...privileged } });
      if (t.unknownFields === 'reject') {
        await expectStatus(res, C.validation, 'privileged fields');
        await expectErrorEnvelope(res, config, Object.keys(privileged)[0]);
        return;
      }
      const created = item(await expectStatus(res, ep.success, 'privileged fields are ignored'));
      const stored = t.readBack ? item(await expectStatus(await t.readBack(h, created), 200, 'read back after the mass-assignment attempt')) : created;
      for (const [k, v] of Object.entries(privileged)) {
        expect(created[k], `response: "${k}" must not take the client's value`).not.toEqual(v);
        expect(stored?.[k], `stored: "${k}" must not take the client's value`).not.toEqual(v);
      }
    });

    test('a rejected request leaves no trace: fix the bad part, resend the same data → accepted', async ({ h }) => {
      const ids = await prepare(h, ep); // update targets get a real resource
      const valid = t.validBody(h);
      const arrayField = Object.entries(t.fields).find(([, r]) => r.type === 'array');
      const scalarField = Object.entries(t.fields).find(([, r]) => r.type !== 'array');
      // An invalid LAST array item is the classic partial-write trap: item 1 saved, item 2 fails, no rollback.
      const broken = arrayField && arrayField[1].type === 'array'
        ? { ...valid, [arrayField[0]]: [arrayField[1].validItem(h), { ...arrayField[1].validItem(h), ...Object.fromEntries(Object.entries(arrayField[1].items).map(([k, r]) => [k, wrongTypeValue(r)])) }] }
        : { ...valid, [scalarField![0]]: wrongTypeValue(scalarField![1]) };
      const ctx = await h.as(t.principal);
      await expectStatus(await callEndpoint(ctx, h, ep, ids, { body: broken }), C.validation, 'invalid request');
      await expectStatus(await callEndpoint(ctx, h, ep, ids, { body: valid }), ep.success, 'same unique data, now valid — must not collide with leftovers of the rejected request');
    });

    test('malformed JSON → clean 4xx, never 5xx', async ({ h }) => {
      const ids = await prepare(h, ep); // update targets get a real resource
      const res = await sendRaw(await h.as(t.principal), h, ep, ids, '{"qa": ', 'application/json');
      await expectStatus(res, C.malformedJson, 'malformed JSON');
      await expectErrorEnvelope(res, config);
    });

    test('JSON that is not an object → rejected', async ({ h }) => {
      const ids = await prepare(h, ep); // update targets get a real resource
      const res = await sendRaw(await h.as(t.principal), h, ep, ids, '[]', 'application/json');
      await expectStatus(res, C.validation, 'array body');
      await expectErrorEnvelope(res, config);
    });

    test('wrong content type → unsupported media type', async ({ h }) => {
      const ids = await prepare(h, ep); // update targets get a real resource
      test.skip(C.unsupportedMediaType === null, 'contract does not check content type');
      const res = await sendRaw(await h.as(t.principal), h, ep, ids, JSON.stringify(t.validBody(h)), 'text/plain');
      await expectStatus(res, C.unsupportedMediaType as number, 'text/plain body');
      await expectErrorEnvelope(res, config);
    });

    test('oversized body → payload too large', async ({ h }) => {
      const ids = await prepare(h, ep); // update targets get a real resource
      const limit = C.payloadTooLarge;
      test.skip(!limit, 'contract has no body size limit');
      const valid = t.validBody(h);
      const firstString = Object.keys(valid).find((k) => typeof valid[k] === 'string') ?? 'qaPadding';
      const res = await callEndpoint(await h.as(t.principal), h, ep, ids, { body: { ...valid, [firstString]: 'x'.repeat(limit!.maxBytes + 100) } });
      await expectStatus(res, limit!.status, 'oversized body');
      await expectErrorEnvelope(res, config);
    });
  });
}
````

### `tests/api/idempotency.spec.ts`

````ts
// Idempotency: retries with the same key replay the first result and cause exactly one real effect.
import { test, expect, config } from '../support/fixture';
import { callEndpoint, endpoint, prepare } from '../support/call';
import { expectErrorEnvelope, expectStatus } from '../support/expect-api';

const C = config.conventions;

for (const k of config.idempotency) {
  const ep = endpoint(k.endpoint);
  const bodyFor = k.body ?? ep.body;

  test.describe(`${ep.method} ${ep.id} — idempotency: ${k.name}`, { tag: ['@api', '@idempotency'] }, () => {
    test('same key + same body twice → replayed result, exactly one effect', async ({ h }) => {
      const ids = await prepare(h, ep);
      const ctx = await h.as(k.principal);
      const key = h.uniq('idem');
      const body = bodyFor ? bodyFor(h, ids) : undefined;
      const before = k.effectCount ? await k.effectCount(h, ids, body) : 0;
      const first = await expectStatus(await callEndpoint(ctx, h, ep, ids, { body, headers: { [k.header]: key } }), k.firstStatus, 'first request');
      const replay = await expectStatus(await callEndpoint(ctx, h, ep, ids, { body, headers: { [k.header]: key } }), k.replayStatus, 'retry with the same key');
      expect(k.identity(replay), 'the retry must return the SAME resource, not a new one').toEqual(k.identity(first));
      if (k.effectCount) expect(await k.effectCount(h, ids, body), 'exactly one real effect for two requests').toBe(before + 1);
    });

    test('same key + different body → rejected, no new effect', async ({ h }) => {
      test.skip(!k.differentBody || k.differentBodyStatus === undefined, 'contract does not define key reuse with another body');
      const ids = await prepare(h, ep);
      const ctx = await h.as(k.principal);
      const key = h.uniq('idem');
      const firstBody = bodyFor ? bodyFor(h, ids) : undefined;
      await expectStatus(await callEndpoint(ctx, h, ep, ids, { body: firstBody, headers: { [k.header]: key } }), k.firstStatus, 'first request');
      const other = k.differentBody!(h, ids);
      const res = await callEndpoint(ctx, h, ep, ids, { body: other, headers: { [k.header]: key } });
      await expectStatus(res, k.differentBodyStatus!, 'key reused with a different body');
      await expectErrorEnvelope(res, config);
      if (k.effectCount) {
        expect(await k.effectCount(h, ids, other), 'a rejected reuse must not create anything').toBe(0);
        expect(await k.effectCount(h, ids, firstBody), 'the first request still has exactly one effect').toBe(1);
      }
    });

    test('missing key → rejected (key is required)', async ({ h }) => {
      test.skip(!k.required, 'key is optional for this endpoint');
      const ids = await prepare(h, ep);
      const body = bodyFor ? bodyFor(h, ids) : undefined;
      const before = k.effectCount ? await k.effectCount(h, ids, body) : 0;
      const res = await callEndpoint(await h.as(k.principal), h, ep, ids, { body, omitHeaders: [k.header] });
      await expectStatus(res, C.validation, 'missing idempotency key');
      await expectErrorEnvelope(res, config, k.header);
      if (k.effectCount) expect(await k.effectCount(h, ids, body), 'a rejected request must not create anything').toBe(before);
    });

    test('two requests with the same key at the same time → exactly one effect', async ({ h }) => {
      test.skip(!k.concurrent, 'concurrency check not enabled for this case (idempotency[].concurrent)');
      const ids = await prepare(h, ep);
      const ctx = await h.as(k.principal);
      const key = h.uniq('idem');
      const body = bodyFor ? bodyFor(h, ids) : undefined;
      const before = k.effectCount ? await k.effectCount(h, ids, body) : 0;
      const results = await Promise.all([1, 2].map(() => callEndpoint(ctx, h, ep, ids, { body, headers: { [k.header]: key } })));
      for (const r of results) expect(r.status(), `concurrent request returned ${r.status()}: ${await r.text()}`).toBeLessThan(500);
      const okBodies = await Promise.all(results.filter((r) => r.status() < 300).map((r) => r.json()));
      expect(okBodies.length, 'at least one of the two must succeed').toBeGreaterThan(0);
      expect(new Set(okBodies.map((b) => JSON.stringify(k.identity(b)))).size, 'successful responses must point to ONE resource').toBe(1);
      if (k.effectCount) expect(await k.effectCount(h, ids, body), 'two simultaneous requests, one effect').toBe(before + 1);
    });
  });
}
````

### `tests/api/behaviour.spec.ts`

````ts
// Status codes and behaviour: unknown route, wrong method, not found, conflicts, delete twice, lists, state transitions.
import { test, expect, config } from '../support/fixture';
import { callEndpoint, endpoint, prepare } from '../support/call';
import { expectErrorEnvelope, expectSchema, expectStatus } from '../support/expect-api';
import type { Helpers } from '../support/types';

const C = config.conventions;
const B = config.behaviour;

test.describe('Error contract', { tag: ['@api', '@status'] }, () => {
  test('unknown route → not found, in the JSON error envelope', async ({ h }) => {
    const res = await (await h.as(B.unknownRoute.principal)).get(B.unknownRoute.path);
    await expectStatus(res, C.notFound, 'unknown route');
    await expectErrorEnvelope(res, config);
  });

  test('unsupported method on a known path → documented status', async ({ h }) => {
    const m = B.methodNotAllowed;
    test.skip(!m, 'no methodNotAllowed case in api.config.ts');
    const res = await (await h.as(m!.principal)).fetch(m!.path({ tenant: h.tenantId('A'), ids: {} }), { method: m!.method });
    await expectStatus(res, m!.expect, `${m!.method} on a path that does not support it`);
    await expectErrorEnvelope(res, config);
    if (m!.allowHeader) expect(res.headers()['allow'], '405 must list the supported methods in an Allow header').toBeTruthy();
  });

  for (const nf of B.notFound) {
    test(`not found: ${nf.name}`, async ({ h }) => {
      const res = await nf.call(h);
      await expectStatus(res, C.notFound, nf.name);
      await expectErrorEnvelope(res, config);
    });
  }

  for (const cf of B.conflicts) {
    test(`conflict: ${cf.name}`, async ({ h }) => {
      const ep = endpoint(cf.endpoint);
      const ctx = await h.as(cf.principal);
      const body = cf.body(h);
      await expectStatus(await callEndpoint(ctx, h, ep, {}, { body }), ep.success, 'first create');
      const res = await callEndpoint(ctx, h, ep, {}, { body });
      await expectStatus(res, C.conflict, 'duplicate create');
      await expectErrorEnvelope(res, config);
    });
  }

  for (const d of B.deleteTwice) {
    test(`delete twice: ${d.endpoint}`, async ({ h }) => {
      const ep = endpoint(d.endpoint);
      const ids = await prepare(h, ep);
      const ctx = await h.as(d.principal);
      await expectStatus(await callEndpoint(ctx, h, ep, ids), ep.success, 'first delete');
      await expectStatus(await callEndpoint(ctx, h, ep, ids), d.secondStatus, 'second delete');
      if (ep.readBack) await expectStatus(await ep.readBack(h, ids), C.notFound, 'resource is gone for the API after delete');
    });
  }
});

for (const l of config.lists) {
  test.describe(`List: ${l.name}`, { tag: ['@api', '@lists'] }, () => {
    const url = (h: Helpers, params: Record<string, string>) =>
      `${l.path({ tenant: h.tenantId('A'), ids: {} })}?${new URLSearchParams(params).toString()}`;

    test('default page matches the item schema', async ({ h }) => {
      const body = await expectStatus(await (await h.as(l.principal)).get(l.path({ tenant: h.tenantId('A'), ids: {} })), 200, 'list');
      expect(Array.isArray(l.items(body)), 'items must be an array (never null)').toBe(true);
      if (l.total) expect(l.total(body), 'total counts all pages, so it can never be smaller than this page').toBeGreaterThanOrEqual(l.items(body).length);
      if (l.itemSchema) for (const it of l.items(body)) expectSchema(l.itemSchema, it, 'list item');
    });

    for (const bad of [String(l.maxSize + 1), String((l.minSize ?? 1) - 1), 'abc']) {
      test(`${l.sizeParam}=${bad} → rejected`, async ({ h }) => {
        const res = await (await h.as(l.principal)).get(url(h, { [l.sizeParam]: bad }));
        await expectStatus(res, C.validation, `${l.sizeParam}=${bad}`);
        await expectErrorEnvelope(res, config, l.sizeParam);
      });
    }

    test(`${l.sizeParam}=${l.maxSize} (maximum) → accepted`, async ({ h }) => {
      await expectStatus(await (await h.as(l.principal)).get(url(h, { [l.sizeParam]: String(l.maxSize) })), 200, 'maximum page size');
    });

    test('page beyond the last → empty array, not an error', async ({ h }) => {
      test.skip(!l.pager, 'no pager configured');
      const far = l.pager!.kind === 'page' ? '100000' : '100000000';
      const body = await expectStatus(await (await h.as(l.principal)).get(url(h, { [l.pager!.param]: far })), 200, 'far page');
      expect(l.items(body)).toEqual([]);
    });

    test("another tenant's items never appear in this tenant's list", async ({ h }) => {
      test.skip(!l.leakSetup, 'no leakSetup configured');
      const leakedId = await l.leakSetup!(h);
      const other = await h.as(config.crossTenantPrincipal);
      for (let page = 0; page < 20; page++) {
        const params: Record<string, string> = { [l.sizeParam]: String(l.maxSize) };
        if (l.pager) params[l.pager.param] = String(l.pager.kind === 'page' ? page + 1 : page * l.maxSize);
        const ownList = `${l.path({ tenant: h.tenantId('B'), ids: {} })}?${new URLSearchParams(params).toString()}`;
        const items = l.items(await expectStatus(await other.get(ownList), 200, "other tenant's own list"));
        expect(items.map(l.idOf), "tenant A's item leaked into tenant B's list").not.toContain(leakedId);
        if (!l.pager || items.length < l.maxSize) break;
      }
    });
  });
}

for (const tr of config.transitions) {
  test(`State transitions: ${tr.name}`, { tag: ['@api', '@transitions'] }, async ({ h }) => {
    const ids = await tr.setup(h);
    for (const step of tr.steps) {
      const res = await step.call(h, ids);
      const body = await expectStatus(res, step.expect, step.name);
      if (step.expect >= 400) await expectErrorEnvelope(res, config);
      if (step.verify) await step.verify(body);
    }
  });
}

for (const pu of config.partialUpdates) {
  test(`Partial update: ${pu.endpoint} changes only the fields sent`, { tag: ['@api', '@payload'] }, async ({ h }) => {
    const ep = endpoint(pu.endpoint);
    test.skip(!ep.setup || !ep.readBack, 'partial-update check needs setup and readBack on the endpoint');
    const item = (b: any) => (pu.item ? pu.item(b) : b);
    const ids = await prepare(h, ep);
    const before = item(await expectStatus(await ep.readBack!(h, ids), 200, 'read before update'));
    const sent = pu.body(h, ids);
    await expectStatus(await callEndpoint(await h.as(pu.principal), h, ep, ids, { body: sent }), ep.success, 'partial update');
    const after = item(await expectStatus(await ep.readBack!(h, ids), 200, 'read after update'));
    for (const [k, v] of Object.entries(sent)) expect(after[k], `"${k}" must take the sent value`).toEqual(v);
    for (const k of Object.keys(before)) {
      if (k in sent || pu.volatile.includes(k)) continue;
      expect(after[k], `"${k}" was not sent, so it must not change`).toEqual(before[k]);
    }
  });
}
````


---

## 10. Filling `api.config.ts` — complete example

The example below is a fictional "Orgs & Billing" API: JWT bearer login, roles admin/member/viewer/billing, other tenants get `404`, unknown fields are ignored, and there is an OpenAPI file. It shows every option. Replace names, paths and rules with your project's contract.

````ts
// api.config.ts — THE ONLY FILE THAT CHANGES PER PROJECT. Filled from the contract (README / OpenAPI / handlers).
// Project: Orgs & Billing API — JWT bearer, 404 for other tenants, unknown fields ignored.
import { z } from 'zod';
import type { ApiConfig, Helpers, Ids } from './support/types';
import { env, envOr } from './support/env';
import { openApiSchema } from './support/openapi';

const ROLES_A = ['admin', 'member', 'viewer', 'billing'];
const loginAs = (emailEnv: string) => ({
  kind: 'bearer-login' as const, path: '/auth/login', tokenPath: 'accessToken',
  body: () => ({ email: env(emailEnv), password: env('QA_PASSWORD') }),
});

const iso = z.string().datetime();
const User = z.object({
  id: z.string().uuid(), orgId: z.string().uuid(), email: z.string().email(), name: z.string(),
  role: z.enum(['viewer', 'member', 'admin', 'billing']), createdAt: iso, updatedAt: iso,
}).strict();
const UserList = z.object({ items: z.array(User), page: z.number().int(), pageSize: z.number().int(), total: z.number().int() }).strict();
const Me = z.object({ id: z.string().uuid(), email: z.string(), name: z.string(), role: z.string(), orgId: z.string().uuid() }).strict();
const Invoice = openApiSchema(envOr('QA_OPENAPI_FILE', './openapi.json'), 'Invoice'); // contract straight from the API's OpenAPI file
const Payment = z.object({ paymentId: z.string().uuid(), invoiceId: z.string().uuid(), amount: z.number() }).strict();

const validUser = (h: Helpers) => ({ email: `${h.uniq()}@example.test`, name: 'QA User', role: 'member' });
const validInvoice = (h: Helpers) => ({ reference: h.uniq('ref'), total: 120.5, notes: 'keep-me', lines: [{ label: 'QA line', qty: 2 }] });

async function createUser(h: Helpers): Promise<Ids> {
  const res = await (await h.as('admin')).post(`/orgs/${h.tenantId('A')}/users`, { data: validUser(h) });
  if (res.status() !== 201) throw new Error(`setup createUser failed: ${res.status()} ${await res.text()}`);
  return { userId: (await res.json()).id };
}
async function createInvoice(h: Helpers): Promise<Ids> {
  const res = await (await h.as('admin')).post(`/orgs/${h.tenantId('A')}/invoices`, { data: validInvoice(h) });
  if (res.status() !== 201) throw new Error(`setup createInvoice failed: ${res.status()} ${await res.text()}`);
  return { invoiceId: (await res.json()).id };
}
async function createIssuedInvoice(h: Helpers): Promise<Ids> {
  const ids = await createInvoice(h);
  const res = await (await h.as('admin')).patch(`/orgs/${h.tenantId('A')}/invoices/${ids.invoiceId}`, { data: { status: 'issued' } });
  if (res.status() !== 200) throw new Error(`setup issue invoice failed: ${res.status()}`);
  return ids;
}
const getUser = async (h: Helpers, ids: Ids) => (await h.as('admin')).get(`/orgs/${h.tenantId('A')}/users/${ids.userId}`);
const getInvoice = async (h: Helpers, ids: Ids) => (await h.as('admin')).get(`/orgs/${h.tenantId('A')}/invoices/${ids.invoiceId}`);
/** Users in tenant A with this body's email (pages through the list — the API has no email filter). */
async function usersWithEmail(h: Helpers, _ids: Ids, body: { email?: string }): Promise<number> {
  const admin = await h.as('admin');
  let count = 0;
  for (let page = 1; page < 200; page++) {
    const res = await (await admin.get(`/orgs/${h.tenantId('A')}/users?pageSize=100&page=${page}`)).json();
    count += res.items.filter((u: { email: string }) => u.email === String(body?.email).toLowerCase()).length;
    if (res.items.length < 100) break;
  }
  return count;
}

export const config: ApiConfig = {
  baseUrlEnv: 'API_BASE_URL',
  tenants: { A: () => env('QA_TENANT_A_ID'), B: () => env('QA_TENANT_B_ID') },
  principals: {
    admin: { tenant: 'A', auth: loginAs('QA_ADMIN_EMAIL') },
    member: { tenant: 'A', auth: loginAs('QA_MEMBER_EMAIL') },
    viewer: { tenant: 'A', auth: loginAs('QA_VIEWER_EMAIL') },
    billing: { tenant: 'A', auth: loginAs('QA_BILLING_EMAIL') },
    otherTenantAdmin: { tenant: 'B', auth: loginAs('QA_OTHER_TENANT_ADMIN_EMAIL') },
  },
  setupPrincipal: 'admin',
  crossTenantPrincipal: 'otherTenantAdmin',
  conventions: {
    unauthenticated: 401, forbidden: 403, crossTenant: [404], notFound: 404, validation: 400, malformedJson: 400,
    unsupportedMediaType: 415, payloadTooLarge: { status: 413, maxBytes: 10240 }, conflict: 409,
  },
  errorEnvelope: {
    schema: z.object({ error: z.object({ code: z.string(), message: z.string(),
      fields: z.array(z.object({ field: z.string(), message: z.string() })).optional() }).strict() }).strict(),
    fieldsOf: (b) => (b?.error?.fields ?? []).map((f: { field: string }) => f.field),
    namesFields: true,
  },
  leakKeys: ['password', 'passwordHash', 'password_hash', 'refreshTokenHash', 'token_hash'],
  endpoints: [
    { id: 'me', method: 'GET', path: () => '/me', allow: ROLES_A, success: 200, schema: Me, tenantScoped: false },
    { id: 'users.list', method: 'GET', path: ({ tenant }) => `/orgs/${tenant}/users`, allow: ROLES_A, success: 200, schema: UserList },
    { id: 'users.get', method: 'GET', path: ({ tenant, ids }) => `/orgs/${tenant}/users/${ids.userId}`, setup: createUser, allow: ROLES_A, success: 200, schema: User },
    { id: 'users.create', method: 'POST', path: ({ tenant }) => `/orgs/${tenant}/users`, body: (h) => validUser(h), allow: ['admin'], success: 201, schema: User, location: true },
    { id: 'users.update', method: 'PATCH', path: ({ tenant, ids }) => `/orgs/${tenant}/users/${ids.userId}`, setup: createUser, body: () => ({ name: 'Renamed by QA', role: 'admin' }), allow: ['admin'], success: 200, schema: User, readBack: getUser },
    { id: 'users.delete', method: 'DELETE', path: ({ tenant, ids }) => `/orgs/${tenant}/users/${ids.userId}`, setup: createUser, allow: ['admin'], success: 204, readBack: getUser },
    { id: 'invoices.create', method: 'POST', path: ({ tenant }) => `/orgs/${tenant}/invoices`, body: (h) => validInvoice(h), allow: ['admin', 'billing'], success: 201, schema: Invoice },
    { id: 'invoices.get', method: 'GET', path: ({ tenant, ids }) => `/orgs/${tenant}/invoices/${ids.invoiceId}`, setup: createInvoice, allow: ROLES_A, success: 200, schema: Invoice },
    { id: 'invoices.update', method: 'PATCH', path: ({ tenant, ids }) => `/orgs/${tenant}/invoices/${ids.invoiceId}`, setup: createInvoice, body: () => ({ total: 99 }), allow: ['admin', 'billing'], success: 200, schema: Invoice, readBack: getInvoice },
    { id: 'invoices.delete', method: 'DELETE', path: ({ tenant, ids }) => `/orgs/${tenant}/invoices/${ids.invoiceId}`, setup: createInvoice, allow: ['admin', 'billing'], success: 204, readBack: getInvoice },
    { id: 'invoices.pay', method: 'POST', path: ({ tenant, ids }) => `/orgs/${tenant}/invoices/${ids.invoiceId}/pay`, setup: createIssuedInvoice, headers: (h) => ({ 'Idempotency-Key': h.uniq('pay') }), allow: ['admin', 'billing'], success: 201, schema: Payment, readBack: getInvoice },
  ],
  authn: {
    probePrincipal: 'viewer',
    jwtSecretEnv: 'QA_JWT_SECRET',
    escalateClaims: { role: 'admin' },
    logout: { method: 'POST', path: '/auth/logout', principal: 'viewer' },
    login: {
      path: '/auth/login',
      wrongPassword: () => ({ email: env('QA_VIEWER_EMAIL'), password: 'qa-wrong-password' }),
      unknownUser: (h) => ({ email: `${h.uniq()}@nobody.example`, password: 'qa-wrong-password' }),
      failStatus: 401,
      message: (b) => b?.error?.message,
    },
  },
  payload: [
    {
      endpoint: 'users.create', principal: 'admin', validBody: validUser,
      fields: {
        email: { type: 'string', required: true, format: 'email', maxLength: 254, invalid: ['a@b', '@example.test'] },
        name: { type: 'string', required: true, minLength: 1, maxLength: 100, trims: true, freeText: true },
        role: { type: 'enum', required: true, values: ['viewer', 'member', 'admin', 'billing'] },
      },
      unknownFields: 'ignore',
      privilegedFields: (h) => ({ orgId: h.tenantId('B'), id: '00000000-0000-4000-8000-000000000000', createdAt: '2000-01-01T00:00:00.000Z', isOwner: true, passwordHash: 'scrypt$qa$qa' }),
      normalize: { email: (v) => String(v).toLowerCase(), name: (v) => String(v).trim() },
      readBack: (h, created) => getUser(h, { userId: created.id }),
    },
    {
      endpoint: 'invoices.create', principal: 'billing', validBody: validInvoice,
      fields: {
        reference: { type: 'string', required: true, minLength: 1, maxLength: 64, freeText: true },
        total: { type: 'number', required: true, min: 0, max: 9999999999.99, maxDecimals: 2 },
        notes: { type: 'string', nullable: true, maxLength: 500, freeText: true },
        lines: { type: 'array', maxItems: 100, validItem: () => ({ label: 'QA line', qty: 1 }), items: {
          label: { type: 'string', required: true, minLength: 1, maxLength: 100 },
          qty: { type: 'integer', required: true, min: 1, max: 1000000 },
        } },
      },
      unknownFields: 'ignore',
      privilegedFields: (h) => ({ orgId: h.tenantId('B'), number: 'INV-999999', status: 'paid', id: '00000000-0000-4000-8000-000000000000' }),
      readBack: (h, created) => getInvoice(h, { invoiceId: created.id }),
    },
  ],
  idempotency: [
    {
      name: 'create user', endpoint: 'users.create', principal: 'admin', header: 'Idempotency-Key',
      firstStatus: 201, replayStatus: 201, differentBody: (h) => validUser(h), differentBodyStatus: 422,
      identity: (b) => b.id, effectCount: usersWithEmail, concurrent: true,
    },
    {
      name: 'pay invoice', endpoint: 'invoices.pay', principal: 'billing', header: 'Idempotency-Key', required: true,
      firstStatus: 201, replayStatus: 200, identity: (b) => b.paymentId, concurrent: true,
    },
  ],
  lists: [
    {
      name: 'users', path: ({ tenant }) => `/orgs/${tenant}/users`, principal: 'viewer', sizeParam: 'pageSize', maxSize: 100, minSize: 1,
      pager: { param: 'page', kind: 'page' }, items: (b) => b.items, total: (b) => b.total, idOf: (u) => u.id, itemSchema: User,
      leakSetup: async (h) => (await createUser(h)).userId,
    },
  ],
  transitions: [
    {
      name: 'invoice status draft → issued → paid only',
      setup: createInvoice,
      steps: [
        { name: 'draft → paid (skip) is refused', expect: 409, call: async (h, ids) => (await h.as('billing')).patch(`/orgs/${h.tenantId('A')}/invoices/${ids.invoiceId}`, { data: { status: 'paid' } }) },
        { name: 'draft → issued', expect: 200, call: async (h, ids) => (await h.as('billing')).patch(`/orgs/${h.tenantId('A')}/invoices/${ids.invoiceId}`, { data: { status: 'issued' } }) },
        { name: 'issued → draft (back) is refused', expect: 409, call: async (h, ids) => (await h.as('billing')).patch(`/orgs/${h.tenantId('A')}/invoices/${ids.invoiceId}`, { data: { status: 'draft' } }) },
        { name: 'issued → paid', expect: 200, call: async (h, ids) => (await h.as('billing')).patch(`/orgs/${h.tenantId('A')}/invoices/${ids.invoiceId}`, { data: { status: 'paid' } }) },
      ],
    },
  ],
  partialUpdates: [
    { endpoint: 'invoices.update', principal: 'billing', body: () => ({ total: 99 }), volatile: ['updatedAt'] },
    { endpoint: 'users.update', principal: 'admin', body: () => ({ name: 'Only the name changes' }), volatile: ['updatedAt'] },
  ],
  behaviour: {
    unknownRoute: { path: '/qa-no-such-route', principal: 'admin' },
    methodNotAllowed: { method: 'PUT', path: () => '/me', principal: 'admin', expect: 405, allowHeader: true },
    notFound: [
      { name: 'unknown user id', call: async (h) => (await h.as('admin')).get(`/orgs/${h.tenantId('A')}/users/00000000-0000-4000-8000-000000000000`) },
      { name: 'unknown invoice id', call: async (h) => (await h.as('admin')).get(`/orgs/${h.tenantId('A')}/invoices/00000000-0000-4000-8000-000000000000`) },
    ],
    conflicts: [
      { name: 'duplicate email in the same org', endpoint: 'users.create', principal: 'admin', body: validUser },
      { name: 'duplicate invoice reference', endpoint: 'invoices.create', principal: 'billing', body: validInvoice },
    ],
    deleteTwice: [
      { endpoint: 'users.delete', principal: 'admin', secondStatus: [404] },
      { endpoint: 'invoices.delete', principal: 'billing', secondStatus: [404] },
    ],
  },
};
````

**What changes for other kinds of API** (taken from a second verified sample: cookie sessions + API keys, `403` for other tenants, strict bodies):

Excerpts from the second verified config (cookie sessions, API keys as principals, `403` for other tenants, strict bodies, a session-expiry hook, no OpenAPI). Helpers like `createOrder` follow the same pattern as `createInvoice` above:

````ts
// Orders API v2 — cookie sessions + API keys, 403 for other tenants, strict bodies (unknown fields → 400), no OpenAPI.
const session = (userEnv: string) => ({
  kind: 'cookie-login' as const, path: '/api/v2/session', cookieName: 'sid',
  body: () => ({ username: env(userEnv), password: env('QA_PASSWORD') }),
});
const ALL = ['clerk', 'manager', 'auditor', 'readKey', 'writeKey'];

principals: {
  clerk: { tenant: 'A', auth: session('QA_CLERK_USER') },
  manager: { tenant: 'A', auth: session('QA_MANAGER_USER') },
  auditor: { tenant: 'A', auth: session('QA_AUDITOR_USER') },
  readKey: { tenant: 'A', auth: { kind: 'header', header: 'X-Api-Key', valueEnv: 'QA_READ_KEY' } },   // API keys are principals too
  writeKey: { tenant: 'A', auth: { kind: 'header', header: 'X-Api-Key', valueEnv: 'QA_WRITE_KEY' } },
  otherTenantManager: { tenant: 'B', auth: session('QA_OTHER_TENANT_MANAGER_USER') },
},
conventions: { unauthenticated: 401, forbidden: 403, crossTenant: [403], notFound: 404, validation: 400, malformedJson: 400,
  unsupportedMediaType: 415, payloadTooLarge: { status: 413, maxBytes: 16384 }, conflict: 409 },
errorEnvelope: {
  schema: z.object({ message: z.string(), errors: z.array(z.object({ field: z.string(), msg: z.string() }).strict()).optional() }).strict(),
  fieldsOf: (b) => (b?.errors ?? []).map((e: { field: string }) => e.field),
  namesFields: true,
},
endpoints: [
  { id: 'orders.get', method: 'GET', path: ({ ids }) => `/api/v2/orders/${ids.orderId}`, setup: createOrder, allow: ALL, success: 200, schema: One },
  { id: 'orders.create', method: 'POST', path: () => '/api/v2/orders', body: (h) => validOrder(h), allow: ['clerk', 'manager', 'writeKey'], success: 201, schema: One },
  { id: 'orders.delete', method: 'DELETE', path: ({ ids }) => `/api/v2/orders/${ids.orderId}`, setup: createOrder, allow: ['manager'], success: 200, readBack: getOrder },
  // … no tenant in the path: the kit sends tenant A's object id as tenant B and expects 403
],
authn: {
  probePrincipal: 'clerk',
  logout: { method: 'DELETE', path: '/api/v2/session', principal: 'clerk' },
  // Sessions last an hour: expire one through the test-only admin query endpoint instead of waiting.
  expire: async (h, credential) => {
    if (credential.kind !== 'cookie') throw new Error('expire hook expects a cookie session');
    const id = createHash('sha256').update(credential.value).digest('hex');
    const res = await h.raw.post('/internal/query', { headers: { 'X-Admin-Token': env('QA_ADMIN_QUERY_TOKEN') },
      data: { sql: 'UPDATE sessions SET expires_at = ? WHERE id = ?', params: [new Date(Date.now() - 60_000).toISOString(), id] } });
    if (!res.ok()) throw new Error(`expire hook failed: ${res.status()} ${await res.text()}`);
  },
  login: { path: '/api/v2/session', wrongPassword: () => ({ username: env('QA_CLERK_USER'), password: 'qa-wrong-password' }),
    unknownUser: (h) => ({ username: h.uniq(), password: 'qa-wrong-password' }), failStatus: 401, message: (b) => b?.message },
},
payload: [{ endpoint: 'orders.create', principal: 'clerk', validBody: validOrder, item: (b) => b.data,
  fields: { /* … */ }, unknownFields: 'reject',                                        // strict: privileged fields must be REJECTED (400)
  privilegedFields: (h) => ({ orgId: h.tenantId('B'), status: 'cancelled', id: 999999 }),
  readBack: (h, created) => getOrder(h, { orderId: created.id }) }],
idempotency: [{ name: 'create order', endpoint: 'orders.create', principal: 'clerk', header: 'X-Idempotency-Key',
  firstStatus: 201, replayStatus: 200, differentBody: (h) => validOrder(h), differentBodyStatus: 409,
  identity: (b) => b.data.id, effectCount: ordersWithRef /* counts orders carrying THIS body's orderRef */, concurrent: true }],
transitions: [{ name: 'cancel is one-way', setup: createOrder, steps: [
  { name: 'cancel an open order', expect: 200, call: async (h, ids) => (await h.as('manager')).post(`/api/v2/orders/${ids.orderId}/cancel`),
    verify: (b) => expect(b.data.status).toBe('cancelled') },
  { name: 'cancel it again is refused', expect: 409, call: async (h, ids) => (await h.as('manager')).post(`/api/v2/orders/${ids.orderId}/cancel`) },
] }],
behaviour: { /* … */ methodNotAllowed: { method: 'PUT', path: () => '/api/v2/orders', principal: 'clerk', expect: 404 } }, // contract: no 405
````

**Third shape: opaque bearer tokens, RFC 7807 errors, PUT full replace, public endpoints.** These excerpts come from a config a separate agent wrote using only this skill and the API's README:

```ts
const Problem = z.object({ type: z.string(), title: z.string(), status: z.number(), detail: z.string(),
  errors: z.record(z.string(), z.array(z.string())).optional() }).strict();

conventions: { /* … */ crossTenant: [404], errorContentType: /^application\/problem\+json/ },
errorEnvelope: { schema: Problem, fieldsOf: (b) => Object.keys(b?.errors ?? {}), namesFields: true },
endpoints: [
  { id: 'health', method: 'GET', path: () => '/v1/health', protected: false, allow: [], success: 200, tenantScoped: false },
  { id: 'tokens.revoke', method: 'DELETE', path: () => '/v1/tokens/current', allow: ALL, success: 204, tenantScoped: false, revokesCredential: true },
  { id: 'projects.replace', method: 'PUT', path: ({ tenant, ids }) => `/v1/workspaces/${tenant}/projects/${ids.projectId}`,
    setup: createProject, body: () => ({ name: 'Renamed', budgetCents: 10, visibility: 'private' }), allow: ['editor', 'owner'], success: 200, readBack: getProject },
],
authn: {
  probePrincipal: 'editor',
  tokenFormat: 'opaque',                         // random tokens, not JWTs → no JWT-forgery tests
  logout: { method: 'DELETE', path: '/v1/tokens/current', principal: 'guest' },
  expire: async (h, credential) => {             // expire the token through the API's test-only SQL endpoint
    if (credential.kind !== 'bearer') throw new Error('expected a bearer token');
    const id = createHash('sha256').update(credential.token).digest('hex');
    await sql(h, 'UPDATE tokens SET expires_at = ? WHERE id = ?', [new Date(Date.now() - 60_000).toISOString(), id]);
  },
},
payload: [{ endpoint: 'projects.create', /* … */ fields: {
  key: { type: 'string', required: true, minLength: 2, maxLength: 10, pattern: true, invalid: ['abc', 'AB1', 'A-B'] }, // UPPERCASE A–Z only
  /* … */ } }],
```

Environment for a run (example — values come from `.env` / CI secrets, never from the repo):

```bash
API_BASE_URL=https://api.dev.example.com
QA_TENANT_A_ID=…  QA_TENANT_B_ID=…
QA_ADMIN_EMAIL=…  QA_MEMBER_EMAIL=…  QA_VIEWER_EMAIL=…  QA_BILLING_EMAIL=…  QA_OTHER_TENANT_ADMIN_EMAIL=…
QA_PASSWORD=…                       # or one variable per account
QA_JWT_SECRET=…                     # optional: HS256 secret of the TEST environment only
QA_OPENAPI_FILE=./openapi.json      # optional
npx playwright test --grep @api     # or @authn / @authz / @payload / @idempotency / @status / @lists / @transitions
node tools/qa-report.mjs test-results/results.json --name "Orgs API" --kind API
```

CI: run on every PR touching the API. Publish `test-results/results.json` and the report as artifacts. Fail the job on any failed test, and show skipped tests (gaps) in the summary.

---

## 11. Beyond the kit — hand-written, project-specific tests

The kit covers what every API has. Rules that only some contracts have are written by hand, in their own spec file next to the kit's specs. They use the same fixture `h`, `env()` and `expect-api` helpers, so they appear in the same report. Write one for each of these that the contract documents:

- **Login and tokens:** a correct login returns the documented claims and expiry; the refresh flow (the new pair works; the old refresh token is single-use, and the old access token is rejected after refresh, if the contract says so); a disabled or deleted user gets `401`/`403`; lockout or rate limit gives `429`/`423` with `Retry-After`.
- **Role change** takes effect on the next request, or after the documented token lifetime.
- **Tenant isolation beyond item paths:** search, filters, sorting, exports, bulk/batch endpoints and "include related" params never return or touch another tenant's data.
- **Lists:** filtering and sort direction; an empty result is `[]`, never `null`.
- **Field-level rules:** a field hidden from a lower role is **absent**, not just empty.
- **Side effects** (email, queued job, webhook, audit entry): check at least one through whatever is observable (mailbox stub, job table, audit endpoint) with `expect.poll`, never a sleep. Effects visible only in the database belong to the `database-testing` skill.
- **API keys:** a disabled key gets `401`; a key scoped to another project or tenant gets `403`/`404`.
- **Security smoke:** CORS and security headers, if the contract specifies them.

The same rules apply as everywhere: assertions per section 7, one behaviour per test, a name that reads like a bug title, and the tags `@api` plus the matching pillar tag so the report groups them. Hand-written tests count toward the 10–15 tests per PR.

Example for a contract with single-use refresh tokens and a 5-attempt login lockout. It was verified: green on the clean sample API, and red for each of three planted bugs (a reusable refresh token, no lockout, a lockout without `Retry-After`):

```ts
// auth-flows.spec.ts — HAND-WRITTEN, project-specific tests on top of the kit (refresh tokens, login lockout).
// Uses the kit's fixture `h`, env() and expect helpers. Paths and numbers come from THIS project's contract.
import { test, expect, config } from '../support/fixture';
import { env } from '../support/env';
import { expectErrorEnvelope, expectStatus } from '../support/expect-api';

test.describe('Auth flows (project-specific)', { tag: ['@api', '@authn'] }, () => {
  test('refresh: the new pair works and a refresh token is single-use', async ({ h }) => {
    const login = await expectStatus(await h.raw.post('/auth/login', { data: { email: env('QA_VIEWER_EMAIL'), password: env('QA_PASSWORD') } }), 200, 'login');
    const fresh = await expectStatus(await h.raw.post('/auth/refresh', { data: { refreshToken: login.refreshToken } }), 200, 'first refresh');
    const me = await expectStatus(await h.raw.get('/me', { headers: { Authorization: `Bearer ${fresh.accessToken}` } }), 200, 'new access token works');
    expect(me.email, 'the new token belongs to the same user').toBe(env('QA_VIEWER_EMAIL'));
    const reuse = await h.raw.post('/auth/refresh', { data: { refreshToken: login.refreshToken } });
    await expectStatus(reuse, config.conventions.unauthenticated, 'the same refresh token used a second time');
    await expectErrorEnvelope(reuse, config);
  });

  test('login lockout: attempts 1-5 get 401, the 6th gets 429 with Retry-After', async ({ h }) => {
    const email = `${h.uniq()}@nobody.example`; // unknown email counts the same and never locks a real account
    const attempt = () => h.raw.post('/auth/login', { data: { email, password: 'qa-wrong-password' } });
    for (let i = 1; i <= 5; i++) await expectStatus(await attempt(), config.conventions.unauthenticated, `failed attempt ${i}`);
    const sixth = await attempt();
    await expectStatus(sixth, 429, 'attempt 6 must be rate limited');
    await expectErrorEnvelope(sixth, config);
    expect(Number(sixth.headers()['retry-after']), 'Retry-After must be a positive number of seconds').toBeGreaterThan(0);
  });
});
```

## 12. Review checklist (PR review or self-review)

Go through this list and name the file:line for anything missing:

1. Contract referenced (spec, schema, README or handler) and the config matches it.
2. **Payload**: field matrix for every field in scope; strict response schema; round trip; no leaks; partial update; rejected request leaves no trace.
3. **Authentication**: no / malformed / tampered / alg-none / expired / revoked on every protected endpoint (or a visible skip with a reason).
4. **Authorization**: every principal × endpoint; cross-tenant path **and** object-level (IDOR); list leak; denial changes nothing.
5. Status codes exact per contract; one error envelope everywhere; unknown route and wrong method covered.
6. Idempotency: replay, different body, missing key (if required), concurrent; effect counted on this test's own data.
7. Every test asserts status and body; no truthy-only, conditional or self-derived assertions; raw bodies sent as Buffers.
8. Nothing hardcoded; a principal per role and a second tenant; tests create their own uniquely named data and never change data they did not create.
9. Contract rules outside the kit (refresh, lockout, role change, search/export isolation, side effects) have hand-written tests (section 11) or a visible gap.
10. `tsc` and the repo's linter are clean, `--list` collects, the suite passed twice in a row, and at least one deliberate break was seen to fail.

Report the result as **PASS** or **BLOCKED** with findings ordered by severity, each with file:line and a concrete fix. A missing pillar is always at least **High**.

## 13. Scope and delivery

Keep each branch/PR to one resource or one feature, with at most 10–15 hand-written tests (generated matrix tests count as one config change). Use the repo's existing branch-naming convention. Write the PR description in detail:

- which endpoints and which pillars
- the contract source and the role matrix used
- the env vars needed and how to run
- what is skipped and why (open questions)
- the report verdict

Do not add Claude as author, co-author or in any "generated with" line on commits or PRs.

## 14. How this kit was verified

Verified on 19 Oct 2026 by **mutation testing**. Planted bugs were switched on one at a time in three independent sample APIs, each written only from its contract, and the kit had to turn red for every bug a black-box API test can see. The kit files were identical in all three projects; only `api.config.ts` differed.

| Sample API | Shape | Tests | Clean run | Planted bugs caught |
|---|---|---:|---|---|
| Orgs & Billing | PostgreSQL, JWT bearer, `404` for other tenants, unknown fields ignored, OpenAPI | 238 | 230 passed, 8 skipped (reasons shown), 0 failed | **17 / 17** API-visible |
| Orders | SQLite, cookie sessions + API keys, `403` for other tenants, strict bodies, no OpenAPI | 123 | 114 passed, 9 skipped, 0 failed | **14 / 14** API-visible |
| Workbench (unseen) | Opaque bearer tokens, RFC 7807 errors, `PUT` full replace, `405`, multi-workspace users. **Configured blind** by a separate agent that had only this skill and the README | 245 | 202 passed, 43 skipped, 0 failed | **13 / 13** (12 / 13 before `invalid` examples existed) |

- **Bugs caught:**
  - expired JWT accepted, `alg: none` accepted, logout/revoke that doesn't revoke, session/token expiry ignored
  - missing role checks (viewer/auditor/guest allowed), read-scope API key allowed to write
  - object-level IDOR on GET/PUT/DELETE, mass assignment of the tenant id
  - password hash / internal margin / client IP leaking in responses
  - malformed JSON → `500`, wrong type → `500`, `200` instead of `201`, plain-text `404`, plain JSON instead of `problem+json`
  - idempotency key ignored, a retry charging twice
  - page size not capped, PATCH wiping an unsent field
  - cancelling twice allowed, editing an archived project allowed, lowercase accepted for an UPPERCASE key
  - a half-written create with no transaction
- **The hand-written example in section 11** ran next to the full kit on Orgs & Billing: green on the clean API, red for each of 3 more planted bugs (reusable refresh token, no lockout, no `Retry-After`).
- **Not visible to API tests** (missing audit/history row, hard delete instead of soft delete). These are invisible from outside by nature. The `database-testing` skill caught every one of them.
- **Library versions:**
  - Cloud: Playwright 1.56 · zod 3.25 · ajv 6 · Node 22.22.
  - Belle's machine: Playwright 1.61.1 · zod 4.6.6 · Node 22.23. The Orders suite there: 114 passed, 9 skipped, 0 failed.
  - Strict `tsc` was clean for every config.
- **Defects found and fixed in the kit during this testing** (now built in):
  - A malformed-JSON test that passed against a `500` (Playwright JSON-encodes string bodies) → raw bodies are Buffers.
  - Effect counters that moved because tests run in parallel → counted on each request's own data.
  - A list-leak check that queried the wrong tenant's list.
  - Payload rules that couldn't target update endpoints (found by the blind agent) → `setup` ids.
  - Logout endpoints revoking a cached credential → `revokesCredential`.
  - Missing pattern examples → `invalid: [...]`.
- **The previous version of this skill** had standards but no runnable fixtures. Its example imported `../../fixtures/api`, which did not exist, so every agent had to invent auth, tenants and helpers.


## Plain-language glossary

- **Payload**: the data in a request body (what you send) or response body (what you get back).
- **Contract**: the agreed rules for an endpoint: what you send, what you get back, which status for which situation.
- **Schema validation**: checking the whole response has the right fields with the right types, not just one value.
- **Authentication (authn)**: proving who you are. Is the token or session valid?
- **Authorization (authz)**: what you are allowed to do. Right role, right tenant, your own resource?
- **Principal**: one kind of caller in the tests: a role, an API key, or a user in another tenant.
- **IDOR**: Insecure Direct Object Reference. Changing an id in the request to reach someone else's data.
- **Mass assignment**: the server saving fields you should not control (`role`, `orgId`) just because you sent them.
- **Tenant isolation**: one customer's data is never visible to another customer.
- **Idempotent**: doing the same request twice has the same effect as doing it once (safe to retry).
- **Mutation check**: breaking a rule on purpose to prove a test notices. A test that never fails proves nothing.
- **Flaky**: a test that sometimes passes and sometimes fails with no code change. Usually caused by shared data, timing or order dependence.