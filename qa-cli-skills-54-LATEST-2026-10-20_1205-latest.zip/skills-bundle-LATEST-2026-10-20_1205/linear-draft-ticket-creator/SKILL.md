---
name: linear-draft-ticket-creator
description: "Generate a ready-to-copy draft bug issue in chat for manual Linear entry. No API calls — output only. Use this skill whenever the user says 'Bug' followed by AC numbers, test case references, or a free description of a failure. Also use when the user wants to draft a bug report, write up a defect, or create a bug issue template without submitting to Linear. Triggers on: Bug, draft bug ticket, write bug report, create defect report, bug template, draft ticket."
---

# Linear Draft Ticket Creator

This skill generates a complete, ready-to-copy bug issue draft in chat. No Linear API calls are made — the user adds it to Linear and attaches media manually.

## Trigger

`Bug [AC number(s), test case reference(s), or free description]`

## Shared References

Before proceeding, read:
- `shared-qa-base/references/media-rules.md` — media capture rules for evidence

## Step 1 — Identify the Issue

- If an AC number or test case reference is provided: look it up from the most recent `.md` report or Test session output and extract all relevant context
- If a free-text description is provided: use it as the basis and infer context from conversation history
- Re-use existing media from the Test session — do not re-capture if already saved

## Step 2 — Capture Fresh Evidence (UI bugs only, if not already captured)

Only if no media exists for this failure:

1. Re-navigate to the failing screen on Staging (or Dev if Staging unreachable)
2. If session expired: use `session-recovery` skill to re-login
3. Screenshot with failing element highlighted → save per `playwright-media-capture` rules
4. Screen recording of reproduction steps → save per `playwright-media-capture` rules
5. Store files — user attaches to Linear manually
6. Skip for pure backend failures

## Step 3 — Output the Draft Issue

Output a clean, fully populated bug issue draft in this format. The body is plain Markdown — Linear renders Markdown natively when pasted into the issue description, so no wiki-markup or ADF conversion is needed.

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🐛 BUG ISSUE DRAFT  (copy and paste into Linear manually)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Team       : GR
Title      : [GR-{ticketID}] [Short clear description of what is broken]
             e.g. [GR-2904] Validation error not shown when field is empty
Priority   : [Critical / High / Medium / Low]
Labels     : Bug, qa-found, FRAI-Guardrails
Linked To  : [related to / duplicates] [PARENT-ISSUE-ID]  (see linking rules below)

─────────────────────────────────────────────────

## Bug Summary
[One clear sentence — what is broken and exactly where]

## Environment
- Affected: [Staging / Dev — where observed]
- URL: [exact URL]
- Browser: [browser + version]
- Tested by: belle.ung@persefoni.com

## Acceptance Criteria Reference
AC #[n] from [PARENT-ISSUE-ID]: "[full AC text]"

## Steps to Reproduce
1. [Step 1]
2. [Step 2]
3. [Continue...]

## Expected Result
[What should happen per AC or spec]

## Actual Result
[What actually happens — specific and factual]

## Impact
[Who is affected and what they cannot do]

## Attachments (add manually)
📸 ~/Documents/Screenshots/GR-{ticketID}-{AC/TC}{n}.png      ← highlighted screenshot
🎥 ~/Documents/Recording steps/GR-{ticketID}-{AC/TC}{n}.mp4  ← reproduction steps recording
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

## Draft Quality Rules

- Complete every field — the developer reading this must be able to reproduce without follow-up questions
- One full draft block per failing AC/TC if multiple are referenced
- **Title format**: `[GR-{ticketID}] [Short description]` — e.g., `[GR-2904] Validation error not shown when field is empty`
- Labels are always: `Bug`, `qa-found`, `FRAI-Guardrails`
- Linking rules (Linear's relation types are `related` / `duplicate` / `blocks` — there is no dedicated "caused by" type):
  - Parent is **Epic, Story, or Task** and this bug was caused by that work → set as a **sub-issue** (Linear's `parentId`) only if it's truly hierarchical, otherwise use **`related`** and write "Caused by {PARENT}" explicitly in the Bug Summary — Linear has no `Caused` relation type to lean on
  - Parent is **Bug** (not fully fixed) → **`related`** or **`duplicate`** (if it's the same underlying issue) or **`blocks`** (if this bug blocks the other from being verified)
  - Uncertain → **`related`**

> ⚠️ **Critical — bug → epic/story/task linking:**
>
> After the bug issue is created, manually add the relation in Linear's UI (or via
> `issueRelationCreate` if scripting), matching:
>
> | Situation | `type` | this new bug | related issue |
> |-----------|------|-------------|--------------|
> | Bug caused by Epic / Story / Task | `related` (state "Caused by" in the text — Linear has no `caused` type) | `{NEW_BUG_KEY}` | `{PARENT_KEY}` |
> | Bug relates to another Bug | `related` | `{NEW_BUG_KEY}` | `{OTHER_BUG}` |
> | Bug duplicates existing | `duplicate` | `{NEW_BUG_KEY}` | `{EXISTING}` |
>
> **Do not** set this bug as a Linear sub-issue of the parent unless it is genuinely part of that
> work's hierarchy — a causal link and a hierarchical link are different things, same distinction
> the old Jira workflow drew between "Link work items" and "Child work items".

## After Output

Display the Media Files Summary block (from `playwright-media-capture` rules) — remind user to attach manually.
