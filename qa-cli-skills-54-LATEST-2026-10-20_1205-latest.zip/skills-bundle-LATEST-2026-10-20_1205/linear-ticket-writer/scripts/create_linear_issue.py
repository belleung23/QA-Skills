#!/usr/bin/env python3
"""
Create a Linear bug issue from a JSON payload, uploading and attaching evidence files.

Successor to the old create_jira_bug.py. Talks directly to Linear's GraphQL API
(https://api.linear.app/graphql) — no browser automation, no ADF, no wiki markup.
Descriptions/comments are plain Markdown; image attachments are embedded inline
via ![alt](assetUrl) using the permanent asset URL Linear returns from fileUpload.

Usage:
    python3 .claude/skills/linear-ticket-writer/scripts/create_linear_issue.py \
      --payload bug-drafts/GR-1234_bug_payload.json \
      --attachment test-reports/screenshots/GR-5678-TC1.png \
      --attachment manual-testing/evidences/GR-5678/rca/TC-PA-413-console.log

    # Skip the duplicate-title search
    ... --skip-duplicate-check
"""

from __future__ import annotations

import argparse
import json
import mimetypes
import os
import sys
import urllib.error
import urllib.request
from pathlib import Path

LINEAR_API_URL = "https://api.linear.app/graphql"

# FALLBACK PATH ONLY. Prefer the Linear MCP tools (see SKILL.md Method 1).
# Use this script when the MCP is unavailable or erroring.
#
# Verified against the live workspace 2026-08-26:
# team "First Recon AI" (id 78ca6902-2be8-4684-ab17-92fa72b37a64); issues are keyed FRAI-###.
TEAM_KEY = os.environ.get("LINEAR_TEAM_KEY", "FRAI")

# No default assignee. Pass --assignee <email>; the caller decides who owns the bug.
# Unset means the issue is created unassigned rather than silently routed to one person.
ASSIGNEE_EMAIL = os.environ.get("LINEAR_ASSIGNEE_EMAIL") or None

PRIORITY_MAP = {"critical": 1, "high": 2, "medium": 3, "low": 4, "none": 0}


# ---------------------------------------------------------------------------
# Auth
# ---------------------------------------------------------------------------

def load_api_key(env_path: Path) -> str:
    """Read TESTING_LINEAR_API_KEY from a .dev.vars-style file.

    Falls back to the LINEAR_API_KEY env var, and finally to "" (empty) —
    an empty Authorization header is fine in sandboxes where Linear credentials
    are auto-injected by a proxy (e.g. this Claude Cowork environment).
    """
    if env_path.exists():
        for line in env_path.read_text(encoding="utf-8").splitlines():
            stripped = line.strip()
            if stripped.startswith("TESTING_LINEAR_API_KEY="):
                return stripped.split("=", 1)[1].strip().strip("'\"")
    return os.environ.get("LINEAR_API_KEY", "")


def gql(query: str, variables: dict, api_key: str) -> dict:
    body = json.dumps({"query": query, "variables": variables}).encode("utf-8")
    req = urllib.request.Request(
        LINEAR_API_URL,
        data=body,
        method="POST",
        headers={"Content-Type": "application/json", "Authorization": api_key},
    )
    try:
        with urllib.request.urlopen(req) as resp:
            result = json.loads(resp.read())
    except urllib.error.HTTPError as exc:
        raise RuntimeError(f"HTTP {exc.code}: {exc.read().decode()}") from exc
    if "errors" in result:
        raise RuntimeError(f"Linear API error: {result['errors']}")
    return result["data"]


# ---------------------------------------------------------------------------
# Lookups
# ---------------------------------------------------------------------------

def get_team_id(api_key: str) -> str:
    data = gql(
        "query($key: String!) { teams(filter: { key: { eq: $key } }) { nodes { id key } } }",
        {"key": TEAM_KEY},
        api_key,
    )
    nodes = data["teams"]["nodes"]
    if not nodes:
        raise RuntimeError(f"No Linear team found with key '{TEAM_KEY}' — check LINEAR_CHEATSHEET.md §7")
    return nodes[0]["id"]


def get_label_ids(names: list[str], api_key: str) -> list[str]:
    data = gql(
        """query($key: String!) {
          team: teams(filter: { key: { eq: $key } }) {
            nodes { labels(first: 200) { nodes { id name } } }
          }
        }""",
        {"key": TEAM_KEY},
        api_key,
    )
    all_labels = data["team"]["nodes"][0]["labels"]["nodes"]
    by_name = {l["name"].lower(): l["id"] for l in all_labels}
    ids, missing = [], []
    for name in names:
        lid = by_name.get(name.lower())
        if lid:
            ids.append(lid)
        else:
            missing.append(name)
    if missing:
        raise RuntimeError(
            f"Missing Linear label(s): {missing}. Create them on team '{TEAM_KEY}' first "
            "(see LINEAR_CHEATSHEET.md §7)."
        )
    return ids


def get_assignee_id(email: str, api_key: str) -> str | None:
    data = gql(
        "query($email: String!) { users(filter: { email: { eq: $email } }) { nodes { id name } } }",
        {"email": email},
        api_key,
    )
    nodes = data["users"]["nodes"]
    return nodes[0]["id"] if nodes else None


def find_duplicates(title_query: str, api_key: str) -> list[dict]:
    data = gql(
        """query($key: String!, $q: String!) {
          issues(filter: { team: { key: { eq: $key } }, title: { containsIgnoreCase: $q } }, first: 10) {
            nodes { identifier title state { name } }
          }
        }""",
        {"key": TEAM_KEY, "q": title_query},
        api_key,
    )
    return data["issues"]["nodes"]


# ---------------------------------------------------------------------------
# File upload
# ---------------------------------------------------------------------------

def upload_file(path: Path, api_key: str) -> str:
    """Upload a file to Linear's asset storage, return the permanent assetUrl."""
    content_type = mimetypes.guess_type(path.name)[0] or "application/octet-stream"
    size = path.stat().st_size
    data = gql(
        """mutation($contentType: String!, $filename: String!, $size: Int!) {
          fileUpload(contentType: $contentType, filename: $filename, size: $size) {
            success
            uploadFile { uploadUrl assetUrl headers { key value } }
          }
        }""",
        {"contentType": content_type, "filename": path.name, "size": size},
        api_key,
    )
    upload = data["fileUpload"]["uploadFile"]
    headers = {h["key"]: h["value"] for h in upload["headers"]}
    headers["Content-Type"] = content_type
    put_req = urllib.request.Request(
        upload["uploadUrl"], data=path.read_bytes(), method="PUT", headers=headers
    )
    with urllib.request.urlopen(put_req):
        pass
    return upload["assetUrl"]


def attach_to_issue(issue_id: str, url: str, title: str, api_key: str) -> None:
    gql(
        """mutation($issueId: String!, $url: String!, $title: String!) {
          attachmentCreate(input: { issueId: $issueId, url: $url, title: $title }) { success }
        }""",
        {"issueId": issue_id, "url": url, "title": title},
        api_key,
    )


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> int:
    parser = argparse.ArgumentParser(description="Create a Linear bug issue with evidence attachments.")
    parser.add_argument("--payload", required=True, help="Path to the bug payload JSON (title/description/priority/labels)")
    parser.add_argument("--attachment", action="append", default=[], help="Evidence file to upload and attach (repeatable)")
    parser.add_argument("--skip-duplicate-check", action="store_true")
    parser.add_argument("--env-file", default=".dev.vars", help="Env file with TESTING_LINEAR_API_KEY")
    parser.add_argument("--assignee", default=None, help="Assignee email. Overrides LINEAR_ASSIGNEE_EMAIL. Omit to leave unassigned.")
    parser.add_argument("--team", default=None, help=f"Linear team key. Overrides LINEAR_TEAM_KEY (default {TEAM_KEY}).")
    args = parser.parse_args()

    api_key = load_api_key(Path(args.env_file))

    payload_path = Path(args.payload)
    if not payload_path.exists():
        print(f"[ERROR] Payload not found: {payload_path}", file=sys.stderr)
        return 1
    payload = json.loads(payload_path.read_text(encoding="utf-8"))

    title = payload["title"]
    description = payload["description"]
    priority = payload.get("priority")
    if isinstance(priority, str):
        priority = PRIORITY_MAP.get(priority.lower(), 0)
    labels = payload.get("labels", [])

    if not args.skip_duplicate_check:
        dups = find_duplicates(title[:60], api_key)
        open_dups = [d for d in dups if d["state"]["name"].lower() not in ("done", "cancelled", "closed")]
        if open_dups:
            print("[BLOCKED] Possible open duplicate(s) found — not creating a new issue:")
            for d in open_dups:
                print(f"  - {d['identifier']}: {d['title']} ({d['state']['name']})")
            print("Pass --skip-duplicate-check to force creation anyway.")
            return 1

    global TEAM_KEY
    if args.team:
        TEAM_KEY = args.team

    team_id = get_team_id(api_key)
    label_ids = get_label_ids(labels, api_key) if labels else []

    assignee_email = args.assignee or ASSIGNEE_EMAIL
    if assignee_email:
        assignee_id = get_assignee_id(assignee_email, api_key)
        if assignee_id is None:
            print(f"[ERROR] No Linear user found for '{assignee_email}'. "
                  f"Fix the address or omit --assignee to create it unassigned.")
            return 1
    else:
        assignee_id = None
        print("[INFO] No --assignee given — creating the issue unassigned.")

    # Upload evidence BEFORE creating the issue so image assetUrls can be referenced
    # in the description if the caller pre-embedded a placeholder (optional) — attachments
    # are always linked to the issue after creation since attachmentCreate needs an issueId.
    print(f"[INFO] Creating issue on team '{TEAM_KEY}'…")
    create_data = gql(
        """mutation($input: IssueCreateInput!) {
          issueCreate(input: $input) { success issue { id identifier url } }
        }""",
        {
            "input": {
                "teamId": team_id,
                "title": title,
                "description": description,
                "priority": priority,
                "labelIds": label_ids,
                **({"assigneeId": assignee_id} if assignee_id else {}),
            }
        },
        api_key,
    )
    issue = create_data["issueCreate"]["issue"]
    print(f"[OK] Created {issue['identifier']} — {issue['url']}")

    uploaded = []
    for attachment_path in args.attachment:
        p = Path(attachment_path)
        if not p.exists():
            print(f"[WARN] Attachment not found, skipping: {p}", file=sys.stderr)
            continue
        asset_url = upload_file(p, api_key)
        attach_to_issue(issue["id"], asset_url, p.name, api_key)
        uploaded.append((p.name, asset_url))
        print(f"[OK] Attached {p.name}")

    print(f"\nIssue: {issue['identifier']}")
    print(f"URL: {issue['url']}")
    print(f"Attachments: {len(uploaded)}")
    for name, url in uploaded:
        print(f"  - {name} -> {url}")

    return 0


if __name__ == "__main__":
    sys.exit(main())
