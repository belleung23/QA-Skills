---
name: linear-ticket-writer
description: "Create bug issues directly in Linear using the Linear MCP tools — sets title, priority, assignee, labels, relations and attachments, and optionally cross-links a matching Jira ticket. Requires a completed root-cause-forensics RCA before any issue is created; the RCA block goes into the description and sets priority. Labels come from the workspace's real grouped taxonomy (Workspace / Commercial Product / Delivery Surface / Issue Class). Records the environment where the bug was observed per the routing policy — Dev (https://app.dev.firstrecon.ai) for normal tickets (no UI fallback), or Production (https://app.firstrecon.ai) with Dev fallback for [Pro]/[Prod] tickets. Use whenever the user says 'Linear' followed by AC numbers or test case references, or wants to auto-create a bug issue without manual copy-paste. Triggers on: Linear, create Linear issue, file bug in Linear, submit bug to Linear, auto-create issue, push to Linear."
---

# Linear Ticket Writer

Creates bug issues in Linear with evidence attached.

> **Rewritten 2026-08-26.** The previous version carried placeholder workspace values that were all
> wrong and drove everything through a bundled script. See **"What changed"** at the end before
> relying on anything you remember about this skill.

## Two methods — MCP first, always

| | Method | When |
|---|---|---|
| **1** | **Linear MCP tools** | **Default. Use this unless it is unavailable.** No `.dev.vars`, no repo checkout, no API key — works identically in a local session and a cloud sandbox. |
| **2** | `scripts/create_linear_issue.py` | **Fallback only**, when Method 1 cannot be used. |

**Reach for Method 2 only when one of these is true:**

- The Linear MCP tools are not connected in this session.
- An MCP call fails repeatedly with a transport or auth error (not a validation error — fix those
  and retry Method 1).
- You are filing in bulk offline from pre-built payload JSON.

**Method 2 prerequisites** — if any is missing, it cannot run, and the answer is to fix the MCP
rather than to fake them:

- a repo checkout (`$REPO_ROOT`)
- `.dev.vars` in that repo containing `TESTING_LINEAR_API_KEY`
- Python 3 with outbound HTTPS

Never silently fall back. If you use Method 2, **say so in your report and say why**.

---

## Workspace facts (verified live 2026-08-26)

| Fact | Value |
|---|---|
| Linear team | **First Recon AI** — id `78ca6902-2be8-4684-ab17-92fa72b37a64` |
| Team key / issue prefix | **`FRAI`** → issues are `FRAI-5749` |
| Default assignee | **none** — always passed per issue by the requester |
| Jira site | `https://persefoni.atlassian.net` — cloudId `dce2ce03-4355-4e26-8af2-06995df138ef` |
| Jira project for this product | **`GR`** ("Guardails"), Bug issue type id `11328` |

**`GR` is the Jira project key. `FRAI` is the Linear team key.** Different systems, different
numbering. A bug can exist in both and be cross-linked (Step 7) — never assume `GR-1234` and
`FRAI-1234` are the same record.

---

## Tools this skill uses

| Purpose | Tool |
|---|---|
| Create / update an issue, set relations and links | `mcp__Linear__save_issue` |
| Find the assignee's user id | `mcp__Linear__list_users` |
| Duplicate check | `mcp__Linear__list_issues` |
| Confirm a label exists before applying it | `mcp__Linear__list_issue_labels` |
| Attach evidence (3-step) | `mcp__Linear__prepare_attachment_upload` → PUT → `mcp__Linear__create_attachment_from_upload` |
| Cross-reference comment on the parent | `mcp__Linear__save_comment` |
| Jira cross-file | `mcp__Atlassian__createJiraIssue`, `mcp__Atlassian__lookupJiraAccountId` |
| *Fallback for all of the above* | `scripts/create_linear_issue.py` — see Method 2 in each step |

---

## Step 0 — RCA prerequisite (MANDATORY GATE)

> **No issue is created without a completed `root-cause-forensics` RCA.** A bug report that describes
> only a symptom is not ready to file.

| Required from `root-cause-forensics` | Used for |
|---|---|
| Class — 🎨 Frontend / ⚙️ Backend / 🔗 Integration / 🗄️ Data / 🔧 Config | `## Root Cause Analysis` + the Issue Class label |
| Location — `path/to/file.ts:142 — functionName()` | `## Root Cause Analysis` |
| Mechanism — one or two sentences | `## Root Cause Analysis` |
| Confidence — High / Medium / Low | `## Root Cause Analysis` (state it; never inflate it) |
| Type — Regression / Latent defect / Incomplete fix | Priority, and whether to file at all |
| Console log (verbatim, secrets redacted) | `### Console Errors` |
| Network log (verbatim, secrets redacted) | `### Network Failures` |
| RCA `.md` + `-console.log` + `-network.json` paths | Attachments in Step 6 |

**If no RCA exists → stop and run `root-cause-forensics` first.**

**RCA verdicts that mean DO NOT FILE:**

| Verdict | Instead |
|---|---|
| 🔌 **Environment** | Not a bug. Report the env fault; re-test once healthy. |
| 📋 **Spec gap** | Post a Clarification comment via `linear-comment-writer`; escalate the AC ambiguity. |
| ❓ **Not reproducible** | Attach evidence to the parent issue; assert no cause. |
| **Incomplete fix** on the ticket under test | Reopen that issue with the full RCA — do not create a new bug. |

**Priority comes from the RCA class, not the visible symptom.** A 500 on a core write path is
High/Critical even when the user only sees a missing toast. A cosmetic frontend defect with no data
impact stays Low however obvious it looks.

### Confidence is reported, never rounded up

If the RCA pinned a file and line, cite it. If it did not, write **`Location: Not pinned.`** and say
what you do know. *"Stated as a hypothesis, not a confirmed root cause"* is more useful to a developer
than a confident guess that sends them to the wrong file.

**If the code was read from a ref that may be behind the deployed build, say so in the ticket:**

```bash
git log -1 --format='%h %ci' origin/staging   # compare to today
```

If `git fetch` failed or the ref is more than a day old, put this in the RCA section verbatim:

> ⚠️ **Code citation caveat:** read from `origin/<branch>` at a commit dated **<date>**, which is
> behind the deployed build. Behavioural findings are from live observation and stand on their own —
> please re-confirm file and line numbers against current `<branch>`.

---

## Step 1 — Gather the source material

Findings arrive from two places. Both are valid.

### 1a — From a QA report (`.md`) — most common

Sweep findings live in `manual-testing/test-reports/*.md` with IDs like `S5-03`. Read the finding's
full block and carry its evidence across **verbatim**: status codes, timings, stored JSON, console
output, record counts. **Never paraphrase a number.** Cite report path + finding ID in `## Source`.

### 1b — From the QA test suite Google Sheet (TC IDs)

| Sheet column | Maps to |
|---|---|
| Test Case ID | TC identifier in heading |
| Nav | Navigation path |
| Priority | P1 / P2 / P3 |
| Description | Short heading |
| Test Steps | Numbered steps |
| Expected Result | Expected |
| Actual Result | Actual |
| Acceptance Criteria | AC list |

```javascript
const sid = '1tOOMsej7yuwiahUEk0foR-6Mk4fWnzrjbhycTwnUAAM';
const ids = ['TC-PA-443', 'TC-WC-458'];
const sheetName = 'Platform-Admin';
const conditions = ids.map(id => `A = '${id}'`).join(' or ');
const tq = encodeURIComponent(`select * where ${conditions}`);
const url = `https://docs.google.com/spreadsheets/d/${sid}/gviz/tq?tqx=out:csv&sheet=${encodeURIComponent(sheetName)}&tq=${tq}`;
return await (await fetch(url, { credentials: 'include' })).text();
```

Check `sessionStorage` (`tc_TC-PA-443`) first.

**Group by root cause, not by symptom.** Findings sharing one RCA location and mechanism belong in
**one** issue. Distinct root causes get separate issues even when the symptom looks identical.

---

## Step 2 — Duplicate check

```
mcp__Linear__list_issues(query: "<feature> <what broke>", limit: 15)
```

Run 2–3 keyword variants **and** one on the RCA location (file or function name) — the same root
cause often surfaced earlier under different wording.

- Open duplicate → do **not** create. Report the existing issue.
- Closed duplicate → create, then set `duplicateOf`.
- **Adjacent but distinct** → create, add the neighbour via `relatedTo`, and say in the description
  how they differ. *(Real example: FRAI-3622 covers the Scheduled model **advisor** failing;
  FRAI-5750 covers the model **store** never resolving. Same page, different defects.)*

---

## Step 3 — Resolve the assignee

Look the user up first, so a typo fails loudly instead of silently creating an unassigned issue:

```
mcp__Linear__list_users(query: "David")
→ { id: "3bc348d4-…", name: "David Muczynski", email: "david.muczynski@persefoni.com" }
```

`save_issue` accepts a user id, name, email or `"me"` in its **`assignee`** field (not `assigneeId`).
If the requester named nobody, leave it unassigned rather than picking someone.

---

## Step 4 — Labels

> ⚠️ **The previous version's label set does not exist.** It specified `frontend`, `priority-high`,
> `ai-chat`, `qa-found`, `FRAI-Guardrails`, `Bug`. **None of those are labels on this team.** The real
> taxonomy is grouped:

Pick **at most one per group**, only where confident. Labels are optional — an issue with no labels
files fine. **Never invent a label name.**

| Group | Labels |
|---|---|
| **Workspace** | `AI Workspace` · `Platform Admin` · `AI Data Protection` · `Mission Control` · `AI Endpoint Security` |
| **Commercial Product** | `Chat` · `Cowork` · `Pulse` · `Agent Hub` · `Company Knowledge` |
| **Delivery Surface** | `Web App` · `Desktop App` · `Mobile` · `Cross-Surface` · `Endpoint Runtime` · `Slack & Internal Tools` |
| **Issue Class** | `Test / QA` · `Platform Reliability` · `UX / Brand Implementation` · `Security Hardening` · `Runtime Enforcement` · `Policy Control` · `Compliance Evidence` · `Integration` · `Data Pipeline` · `Release Gate` · `Developer Tooling` |

Map the RCA class onto Issue Class:

| RCA class | Issue Class |
|---|---|
| 🎨 Frontend (visual / UX) | `UX / Brand Implementation` |
| ⚙️ Backend / 🗄️ Data | `Platform Reliability` |
| 🔗 Integration / Contract | `Integration` |
| 🔧 Config / Flag | `Platform Reliability` |
| Anything security-enforcing | `Security Hardening` or `Runtime Enforcement` |

**There is no priority label and no `Bug` label.** Priority is only Linear's native numeric field.
A downstream skill needing to identify bugs should key off `Issue Class` or the title prefix.

Verify before applying — the set changes:

```
mcp__Linear__list_issue_labels(team: "78ca6902-2be8-4684-ab17-92fa72b37a64", limit: 100)
```

⚠️ `save_issue`'s `labels` **replaces the whole set** on update. On an existing issue, read the
current labels first and pass them back plus your additions, or you will silently strip them.

---

## Step 5 — Write and create the issue

### Title

```
[Area] Short plain-English statement of what is broken (≤ 80 chars)
```

Good: `[Customize] Tool permissions list contradicts stored policy on both create and delete`
Bad: `Bug in admin`

### Description template

Plain Markdown — Linear renders it natively. No wiki markup, no ADF.

````
## Summary
[2–4 sentences: what feature is affected, what broke, why it matters. Write it so a developer on
their first day understands it. End with the one-line user-visible consequence.]

## Environment
- Affected: <Dev|Staging|Production> — <base URL>
- URL: <exact path where the bug occurs>
- Browser: Chrome
- Tested by: <tester email>
- Area: <workspace / feature area>

---

## Steps to Reproduce
1. [Complete action naming the exact control and input]
2. …
N. Observe [what], so the reader knows where to look.

**Expected:** [complete sentence]
**Actual:** [complete sentence; quote error messages verbatim]

## Acceptance Criteria
- AC1: [complete, testable sentence]
- ACn: A regression test covers [the specific case].

---

## Root Cause Analysis

**Class:** Frontend | Backend | Integration | Data | Config
**Location:** `path/to/file.ts:142` — `functionName()`   (or: **Not pinned.**)
**Mechanism:** [one or two sentences: the faulty behaviour and why bad input reaches it]
**Confidence:** High | Medium | Low — split it if behaviour is certain but the line is not
**Type:** Regression — PR #n (sha, @author, date) | Latent defect | Incomplete fix

[⚠️ code citation caveat here if the ref was stale — see Step 0]

### Console Errors
```
[verbatim, including source:line — or "(no console output — see RCA report)"]
```

### Network Failures
```
METHOD /full/path
  → status statusText (duration)
  Request:  [verbatim, secrets redacted]
  Response: [verbatim, secrets redacted]
```

### Blast Radius
[Other flows on the same code path. Say which are verified vs suspected.]

### Suggested Direction
[Mechanism-level. "Populate scope.tenantId on the template path" — not "add a null check".]

---

## Evidence
**Screenshot:** ![KEY-TCn](ASSET_URL)
**RCA report:** KEY_RCA_TC_date.md (attached)

## Impact
[Who is affected, what workflow is blocked, whether a workaround exists.]

## Source
[Report path + finding ID, or sheet tab + TC IDs, and the date verified.]
````

### Rules

- Never truncate steps. Never write "N/A" — fetch the missing data instead.
- Multiple findings in one issue each get their own `###` block with every field filled.
- AC bullets are complete sentences: *"The form must block submission and show an inline error when
  the required field is empty."* — not *"Should validate."*
- Console and network text in fenced blocks **verbatim**. Developers grep for exact strings.
- **Redact every secret** → `<REDACTED>`, keeping the header name so its presence stays provable.
- Absence is evidence. `(no network request fired — this is the finding)` is a real, useful line.

### Create it — Method 1 (MCP, default)

```
mcp__Linear__save_issue(
  team:        "78ca6902-2be8-4684-ab17-92fa72b37a64",
  title:       "[Area] …",
  description: "<markdown>",
  priority:    2,                              // 1=Urgent 2=High 3=Medium 4=Low 0=None
  assignee:    "david.muczynski@persefoni.com", // omit to leave unassigned
  labels:      ["AI Workspace", "Web App"]      // omit if unsure
)
```

Do **not** pass `id` when creating — that switches the call to update mode.
The response carries the new `FRAI-####` identifier and `url`.

### Create it — Method 2 (script fallback)

Only when Method 1 is unavailable. Write the payload, then run the script.

Payload → `$REPO_ROOT/bug-drafts/{KEY}_bug_payload.json`:

```json
{
  "title": "[Area] …",
  "description": "<the same markdown>",
  "priority": 2,
  "labels": ["AI Workspace", "Web App"]
}
```

```bash
REPO_ROOT=$(git rev-parse --show-toplevel)
python3 "$REPO_ROOT/.claude/skills/linear-ticket-writer/scripts/create_linear_issue.py" \
  --payload  "$REPO_ROOT/bug-drafts/{KEY}_bug_payload.json" \
  --assignee "david.muczynski@persefoni.com" \
  --attachment "$REPO_ROOT/test-reports/screenshots/{KEY}-TC1.png" \
  --attachment "$REPO_ROOT/test-reports/{KEY}_RCA_{TC}_{date}.md" \
  --attachment "$REPO_ROOT/manual-testing/evidences/{KEY}/rca/{TC}-console.log"
```

| Flag | Notes |
|---|---|
| `--payload` | Required. Title / description / priority / labels. |
| `--assignee` | Email. **Omit and the issue is created unassigned** — the script says so rather than guessing. A bad address is a hard error, not a silent skip. |
| `--team` | Overrides the default `FRAI`. |
| `--attachment` | Repeatable, one per evidence file. Handles the upload for you. |
| `--skip-duplicate-check` | Bypasses Step 2. Use only when you have already checked by hand. |
| `--env-file` | Defaults to `.dev.vars`; must contain `TESTING_LINEAR_API_KEY`. |

The script runs its own duplicate check, resolves label names to ids (**failing loudly and naming
any label that does not exist**), uploads each attachment, creates the issue, and prints the new
identifier and URL. Non-zero exit → read the error, fix the payload or path, re-run.

---

## Step 6 — Attach evidence

**Method 2 users:** the script's `--attachment` flags already did this — skip to Step 7.

**Method 1:** three MCP steps per file, and the constraints are strict.

```
1. mcp__Linear__prepare_attachment_upload(
     issue: "FRAI-5749", filename: "GR-11090-TC1.png",
     contentType: "image/png", size: <exact bytes>)
   → { assetUrl, uploadRequest: { url, headers } }

2. PUT the raw bytes to uploadRequest.url, sending every header verbatim.

3. mcp__Linear__create_attachment_from_upload(
     issue: "FRAI-5749", assetUrl: "<assetUrl>", title: "Screenshot — TC1")
```

```bash
curl -X PUT --data-binary @file.png \
  -H "content-type: image/png" \
  -H "x-goog-content-length-range: N,N" \
  -H "cache-control: public, max-age=31536000" \
  -H 'Content-Disposition: attachment; filename="file.png"' \
  "<uploadRequest.url>"
```

**Five ways this fails:**

1. **The signed URL expires in 60 seconds.** Prepare → PUT → finalize without pausing.
2. **One file at a time.** Never batch several `prepare_attachment_upload` calls up front — the
   earlier URLs expire while you prepare the later ones.
3. **Send every signed header verbatim, casing included.** Omitting or altering one returns **403**.
4. **Do not base64-encode or transform the file.** Use `--data-binary` or a `Blob`.
5. `size` must be the **exact** byte count.

`mcp__Linear__create_attachment` (base64) also exists but is **deprecated and for tiny files only** —
prefer the three-step flow above.

**Always attach the RCA `.md` plus its raw console and network logs.** The fenced blocks in the
description are the summary; the raw logs are the record.

To embed a screenshot inline, upload it first, then update the description with the returned
`assetUrl`:

```
mcp__Linear__save_issue(id: "FRAI-5749",
  patch: [{ op: "replace", old_string: "ASSET_URL", new_string: "<assetUrl>" }])
```

---

## Step 7 — Cross-link Jira, when the request asks for both

Create the Linear issue **first**, then the Jira ticket referencing it, then link back, so there is
one source of truth.

```
mcp__Atlassian__lookupJiraAccountId(cloudId: "dce2ce03-…", searchString: "David")

mcp__Atlassian__createJiraIssue(
  cloudId:             "dce2ce03-4355-4e26-8af2-06995df138ef",
  projectKey:          "GR",
  issueTypeName:       "Bug",
  summary:             "<same title>",
  assignee_account_id: "<accountId>",
  contentFormat:       "markdown",
  additional_fields:   { "priority": { "name": "High" } },
  description:         "🔗 **Linear issue (source of truth):** <linear url>\n\n## Summary\n…"
)

mcp__Linear__save_issue(id: "FRAI-5749",
  links: [{ url: "https://persefoni.atlassian.net/browse/GR-11090", title: "Jira: GR-11090" }])
```

**Three things that will bite you:**

1. **`contentFormat: "markdown"` means Markdown.** Jira wiki markup (`h2.`, `{code}`) renders as
   literal text. Use `##` and fenced blocks.
2. **Jira ignores priority unless passed** in `additional_fields` — it silently defaults to Medium.
3. **Jira assignees need `accountId`, not email.**

Keep the full RCA in Linear; the Jira ticket points at it.

---

## Step 8 — Link relations and notify the parent

```
mcp__Linear__save_issue(id: "FRAI-5749", relatedTo: ["FRAI-5160"])
```

| Situation | Field |
|---|---|
| Caused by / relates to a parent Epic, Story or Bug | `relatedTo` — and write *"Caused by {KEY}"* in the description |
| Duplicates an existing issue | `duplicateOf` |
| Literal sub-issue of a parent | `parentId` — Linear's hierarchy, a different thing; rare here |

`relatedTo`, `blockedBy` and `blocks` are **append-only** — existing relations are never removed.

When the RCA found a **Regression** from a PR belonging to a different ticket, link that ticket too.

Then post the cross-reference comment on the parent:

```
mcp__Linear__save_comment(issueId: "FRAI-5160", body:
"Bug issue filed for QA failures: FRAI-5749
Failing cases: <IDs>
Root cause: <class> — <file:line or 'not pinned'> — <one-line mechanism> (<confidence>)
Type: <Regression (PR #n) | Latent defect>")
```

*Method 2 fallback:* `linear-comment-writer` ships `scripts/post_linear_comment.py` for the same
purpose — use it only if the MCP is unavailable.

> ⚠️ Relations and links (`relatedTo`, `duplicateOf`, `links`) are **MCP-only**. The script does not
> set them. If you filed via Method 2, come back and add them with `save_issue` once the MCP is
> working, or record in your report that the issue was left unlinked.

---

## Step 9 — Report back

```
Bug issue created: FRAI-####          Jira: GR-#####  (if created)
URL: https://linear.app/persefoni/issue/FRAI-####
Title: …
Priority: High (2)   — set from RCA class + blast radius
Assignee: <name>     — or "unassigned"
Labels: <list, or "none applied">
Linked to: <KEY> via related | duplicateOf
Root cause: <class> — <file:line or "not pinned"> — <confidence>
Type: Regression (PR #n) | Latent defect | Incomplete fix
Attachments: n files
Covers: <finding IDs / TC IDs>
Method: MCP            ← or: "script fallback — MCP unavailable because <reason>"
```

If you used Method 2, that last line is not optional. A reader needs to know the issue was filed
through the fallback, because relations and links will not have been set.

---

## What changed in this version (2026-08-26)

Every item was a real failure or a wrong value in the previous version.

| Was | Now | Why |
|---|---|---|
| `create_linear_issue.py` was the **only** route | **Linear MCP is Method 1; the script is retained as Method 2 fallback** | The team uses the MCP. The script needs a repo checkout and a secrets file, so it cannot run in a cloud session — but it stays for when the MCP is down. |
| `TEAM_KEY = "GR"` | **`FRAI`** | Linear issues are `FRAI-####`. `GR` is the *Jira* project key — the two were conflated. |
| `ASSIGNEE_EMAIL = "kim.stroh@persefoni.com"` hardcoded | **No default**; resolved per issue via `list_users` | Every bug was silently routed to one person regardless of who was asked for. |
| Labels `frontend`, `priority-high`, `ai-chat`, `qa-found`, `FRAI-Guardrails`, `Bug` | Real grouped taxonomy (Step 4) | **None of those labels exist.** The old set fails the create outright. |
| `priority-*` labels alongside the numeric field | Numeric field only | There is no priority label group. |
| `--attachment` flags were the only upload route | 3-step MCP upload documented with its five failure modes; `--attachment` kept for Method 2 | Different mechanism entirely: 60-second URL expiry, one file at a time, verbatim signed headers. |
| Cross-reference via `post_linear_comment.py` | `mcp__Linear__save_comment` first, script as fallback | MCP-first, same as everything else. |
| — | Relations and links flagged as **MCP-only** | The script cannot set them; filing via Method 2 leaves an issue unlinked unless you go back. |
| — | Report must name which method was used | A fallback-filed issue behaves differently and the reader needs to know. |
| No Jira guidance | Step 7 | Cross-filing is routine, with three non-obvious traps. |
| Sheet fetch mandatory | Sheet **or** QA report (Step 1) | Most findings now arrive as `.md` report IDs, not TC IDs. |
| — | `labels` replaces the whole set on update | Easy way to silently strip an issue's existing labels. |
| Confidence stated once | Split behaviour vs location; stale-ref caveat required | Line numbers from a stale ref send developers to the wrong file. |

**Still true and unchanged:** the RCA gate, the do-not-file verdicts, grouping by root cause,
duplicate checking, the description template, and verbatim evidence with secrets redacted.
