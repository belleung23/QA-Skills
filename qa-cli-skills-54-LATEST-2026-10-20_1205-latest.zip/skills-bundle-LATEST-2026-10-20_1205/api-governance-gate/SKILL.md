---
name: "api-governance-gate"
description: "Advisory gate for new or migrated API endpoints in a PR: resolves the PR's real merge-base (including stacked PRs), builds a complete resolved route inventory at merge-base and head with the tested route_inventory.py, compares them, reconciles against route-ownership.yaml and developer-api-openapi.yaml in both directions, then audits each endpoint for duplication. Triggers on API governance, API audit, new endpoint gate, is this API a duplicate, route ownership check, unregistered API."
---

# API Governance Gate

Is this API **allowed to exist**? Two questions, in order:

1. **Is it registered?** Every new or newly migrated endpoint is declared in the governance artifact that owns its lane - and every governance entry has real code behind it.
2. **Is it unique?** Same functionality under a different path, a different owner worker, or a different backing model **is** duplication - if two endpoints do the same job under different owners, neither is the authoritative owner.

## Status: advisory, not blocking (as of 2026-09-21)

This gate emits **candidate findings**. It does not decide a merge. A 2026-09-21 executable review found the previous embedded extractor failed every one of 12 targeted edge cases and enforced a wrong mount rule, so blocking authority is withdrawn until the rollout conditions below are met.

Until then:

- Emit `GOVERNANCE ADVISORY - N candidate(s)`, never `GOVERNANCE BLOCKED`.
- Hand every candidate to `api-finding-verifier`. Only `api-audit-reporter` writes a merge decision.
- Say in the report header that this run is advisory and why.

**Restore blocking authority only when** all four hold: `route_inventory.py selftest` is green on the version committed to the repo; two blinded paired trials on real PRs agree with human-confirmed findings; **both independent security verification passes have been re-run** (`api-finding-verifier` Rule 5); and a pilot on a small set of real PRs produced no false BLOCKER. Record the date and the evidence in the report that lifts it.

## Pipeline position

```
api-governance-gate  ->  api-standards-gate  ->  api-finding-verifier  ->  api-audit-reporter
   candidates              candidates              evidence + severity      the only decision
```

The two gates write **candidate artifacts** under `docs/analysis/api-audit/<PR>-<date>.candidates.md`. They never write the final report and never print a verdict line that reads like one. `api-audit-reporter` owns the final file and the merge recommendation.

**Authority: report-only.** Never edit `route-ownership.yaml`, `developer-api-openapi.yaml`, route source, or worker files, and never mutate the dependency tree (`bun install`, `npm install`). Ad-hoc helper scripts and throwaway fixtures go in the scratch directory, never in the repo working tree. The one exception is the committed extractor under `scripts/api-governance/` - that is ordinary repo code maintained by PR, not something this gate writes. A `git fetch` to refresh remote-tracking refs is the other permitted exception; if it is refused, record that rather than working around it.

## Shared finding schema

Every candidate this gate emits carries these fields, and all four API skills use the same ones under the same names. They are **independent axes** - do not let one collapse another.

| Field | Values | Rule |
|---|---|---|
| `evidence` | CONFIRMED / UNVERIFIABLE / UNVERIFIED | How far verification got. See below |
| `severity` | BLOCKER / MAJOR / MINOR / INFO | How bad if it ships. Never lowered because something else would also catch it |
| `novelty` | NEW / PRE-EXISTING | Present unchanged at the merge-base? |
| `rule` | file:line or ADR id | The quoted authority. No rule, no finding above MINOR |
| `ci_status` | covered-red / covered-green / uncovered / unknown | Which required check sees it, and its current colour |
| `remediation` | PATCH READY / NEEDS OWNER INPUT | Whether a safe fix can be specified now |
| `gaps` | free text | What could not be determined and what would settle it |

`evidence` has exactly three values, and **REFUTED is not one of them**:

- **CONFIRMED** - the verifier ran a falsification test and failed to kill the finding.
- **UNVERIFIABLE** - the verifier ran and could not determine the answer. Coverage gaps, never a blocker.
- **UNVERIFIED** - not through the verifier yet. **Every candidate this gate emits starts here.**

A candidate the verifier refutes is not a finding at all; it appears only in the verification summary.

`severity` on a candidate is a **proposal**. Record it in the artifact for the reader, but **withhold it from the verifier's claim-only prompt** (`api-finding-verifier` Rule 1) so the second pass is not anchored by this gate's opinion.

`ci_status: covered-red` is **corroborating evidence, never a downgrade**. A required failing check is itself a merge stop.

## Environment and execution tiers

Runs from Claude Code CLI on a dev machine, a Cowork desktop session, or a cloud sandbox with the repo cloned. Use whichever shell reaches the repo: `Bash` when local, `device_bash` with `cd $HOME/mnt/<repo>` for a Cowork-connected folder. Do not assume which.

**Probe once at the start. Do not guess the tier.**

```
which bun gh git python3 2>/dev/null
node -e 'require("esbuild")' 2>&1 | head -2
git rev-parse --verify origin/develop 2>&1 | head -1
curl -s -o /dev/null -w '%{http_code}\n' https://api.github.com
```

| Tier | Condition | Behaviour |
|---|---|---|
| **1 Full** | `bun` present, `node_modules` load cleanly | Run every gate |
| **2 Partial** | `bun` present, some gate fails on a missing dep or blocked network | Run what works; label the rest |
| **3 Static** | no `bun`, or `esbuild`/`tsx` fails on a host/binary mismatch | Gates recorded NOT RUN with their commands |

Tier 3 is normal in a Cowork desktop session: the mount is macOS, `node_modules` holds macOS binaries the Linux VM cannot execute, and `bun.sh` / npm / github.com return 403 through the egress proxy. Not a fault to fix. `git`, `python3` with `pyyaml`, and `grep` carry the whole audit. **Never repair it by installing into the user's `node_modules`.**

State the tier in the header. **Never report a gate as passed unless its output is in hand.**

## Phase 0 - Resolve the target and its real base

**The base is the highest-leverage input. Getting it wrong invalidates every finding.** A hardcoded `origin/develop` once produced eleven false blockers on a stacked PR that introduced no endpoints.

### 0a - Resolve the PR

1. `gh` present and authenticated: `gh pr view <n> --json title,headRefName,baseRefName,isDraft,files,body` then `gh pr diff <n>`.
2. No `gh`, branch fetched locally: use the local refs. To map a PR number to its branch, open the PR page and read head and base off it; `is:pr head:<branch>` maps the other way. Check the state badge - a merged or closed PR is not a pre-merge target.
3. No PR given: compare `origin/develop` with `HEAD`.
4. Ref missing: try `git fetch origin '<refspec>'` once; if refused, ask the user to fetch and record a coverage gap. Do not guess a branch name.

### 0b - Read the declared base. Never assume `develop`.

- **Base is not `develop` -> the branch is stacked.** Say so in the header. Endpoints that appear against `develop` but not against the declared base belong to the *parent* PR.
- **Base cannot be established -> stop.** Report `GOVERNANCE INCOMPLETE` and name what is needed.
- Record Draft state and any reported merge conflict.

### 0c - Compare at the merge-base, never at the base tip

```
git merge-base <declared base> <head>     # this SHA is the comparison point
git merge-base --is-ancestor <base> <head> && echo ANCESTOR || echo DIVERGED
git rev-list --count <base>..<head>; git rev-list --count <head>..<base>
```

The base tip is the wrong comparison point in a way that is silent and dangerous: **when the base branch and this branch both add the same path, the tip already has it, so this branch's own addition disappears from the result.** `route_inventory.py diff` resolves the merge-base itself; `--no-merge-base` exists only to reproduce the old behaviour and should never be used on a real audit.

The same reasoning applies to any raw `git diff` you run by hand: three dots (`<base>...<head>`), never two. Two-dot diffing reports the base's own deletions as this branch's additions - observed on a real pair as 218 changed files and a phantom `app.route(...)` addition, against 29 files and zero endpoints on three dots.

### 0d - Record access provenance and ref age

Record the resolved base SHA, the merge-base SHA, the access path used, and the **age of the local refs**. **Cross-check the file count**: GitHub saying 27 changed files against a local 19 means the refs are stale by eight files' worth of commits - say so in Coverage gaps and say what it means for the verdict.

## Phase 1 - Two-way reconciliation

### Direction 1 - the route inventory

**Do not hand-roll an extractor and do not write one inline.** Direction 1 runs one tested program:

```
python3 scripts/api-governance/route_inventory.py selftest                            # must be green first
python3 scripts/api-governance/route_inventory.py diff <declared base> <head> --json inv.json
```

**Where the script lives, and what to do when it is not there.** Its home is `scripts/api-governance/route_inventory.py`, with `scripts/api-governance/fixtures.py` beside it, added by an ordinary PR like any other repo code. Until that PR lands the file is **not in the checkout**, and this gate records Direction 1 as `NOT RUN` with the command, as a coverage gap - it does not improvise. A regex written in the moment is how the previous version of this skill shipped a wrong mount rule and missed 40% of route files.

If a reviewer supplies a copy from outside the repo (a scratch path, a download), you may run it - but record its path and provenance in Coverage gaps and label the run **unverified provenance**. A script nobody reviewed in a PR is not a tested script, and a green selftest from such a copy does not satisfy the rollout condition above.

**What the program does, and why each part is load-bearing:**

1. **Full inventory on both sides, then compare.** It resolves every `(method, absolute path)` at the merge-base and at head and diffs the two sets. A changed-line strategy cannot work: changing only a mount prefix, or only the value of a path constant, changes the served URL with no new registration line at all, and a route that moves between files adds a registration line with no new URL. Output is `added` / `removed` / `moved`, and `moved` is not a finding.
2. **Mount composition follows the installed framework.** Verified against hono 4.13.5: `app.route('/api/mu', child)` + `child.get('/api/gamma/one')` is served at **`/api/mu/api/gamma/one`** - the mounted path returns 200, the bare absolute path returns 404. **An absolute child path is not an escape hatch from its mount.** Mounts compose through any depth (`/api/outer` + `/inner` + `/deep`), and a child mounted at two prefixes really serves both, so both are emitted.
3. **Symbols resolve in file and import scope.** Two files may each declare `const P`; a global name map collides them and invents paths. Constants resolve from the declaring file or the file the symbol is imported from, nothing else.
4. **The repo's real mounting idioms are supported**, not just `app.route(prefix, subRouter)`: `registerXRoutes(app)` handing the parent router to a function, `app.route(prefix, createXRoutes(deps))` factories, default-exported routers (`import studioRoutes from './studio'` binds the *target* file's `export default`, not the importer's local name), same-file sub-routers, and re-export hops.
5. **Loop and array registration.** `for (const p of [A, B]) app.post(p, h)` and `[A, B].forEach(p => app.put(p, h))` register two endpoints each; collapsing one is a **removal**, not an addition.
6. **Comments are stripped with a string-aware scanner, not a regex.** An unanchored `/\*.*?\*/` eats the `/*` inside `'/api/chat/exports/*'` and splices unrelated lines into garbage paths; an anchored one misses `app.get('/real', h) // app.get('/fake', h)` and invents an endpoint. Both were observed.
7. **Method coverage matches the framework.** get, post, put, delete, patch, **options**, all, and every `on('METHOD', ...)` form. Hono has no `.head()`; a HEAD request is answered by the GET route, so an explicit HEAD registration is extracted but should be verified before being treated as a served surface (observed: `on('HEAD', '/x')` returned 404 to a HEAD request on 4.13.5).
8. **Scope includes every entrypoint**: `worker/index.ts`, `worker/app.ts`, and **every** `workers/<name>/(src/)?index.ts` and `(src/)?app.ts` - not only the gateway. 27 non-gateway worker entrypoints carried 177 registrations that an earlier scope missed entirely. Test and harness files (`__tests__/`, `*.test.*`, `*.spec.*`, browser-harness dirs) are excluded.
9. **Unsupported syntax becomes an explicit gap, never a guess or a silent omission.** Four kinds: `UNROOTED-ROUTER` (a router nothing mounts from an entrypoint), `UNRESOLVED-CONST`, `UNRESOLVED-MOUNT`, `UNRESOLVED-MOUNT-PREFIX`. None is ever a BLOCKER; all go under Coverage gaps for manual classification.

**`UNROOTED-ROUTER` is frequently a real finding, not noise.** A route module nothing mounts is dead surface. Verified on `origin/develop` 2026-09-21: `worker/routes/database-routes.ts` exports `databaseRoutes(app)` with 58 registrations and is imported only by tests. Check each one before dismissing it.

**Observed on `origin/develop`, 2026-09-21** (record your own run's numbers the same way): 740 route-bearing files, **2,672 resolved endpoints**, 14s, gaps 665 `UNROOTED-ROUTER` / 158 `UNRESOLVED-CONST` / 13 `UNRESOLVED-MOUNT` / 13 `UNRESOLVED-MOUNT-PREFIX`.

### Acceptance suite - the script is not trusted until this is green

`scripts/api-governance/fixtures.py` builds throwaway git repos in a temp dir - **never inside the user's checkout** - and asserts one exact answer per case. Re-run it after any change to the extractor and whenever the user asks whether the audit is correct.

| # | Fixture | Expected |
|---|---|---|
| 1 | `alphaRoutes.post('/created')`, file mounted at `/api/alpha` | `POST /api/alpha/created` |
| 2 | `kappaRoutes.route('/', iotaRoutes)` under `/api/kappa`; `iotaRoutes.get('/deep')` | `GET /api/kappa/deep` |
| 3 | `app.post(GAMMA_PATH)`, single-line const | the const's value |
| 4 | multi-line call + multi-line const | the const's value |
| 5 | multi-line literal call | the literal |
| 6 | `app.on('POST', ['/api/v1/old/x','/api/v1/new/x'])` | both paths |
| 7 | `app.all('/api/wild/*/export')` | `/api/wild/{id}/export` |
| 8 | `app.all('/api/prefix/*')` | `/api/prefix` |
| 9 | route on base, re-added with a new handler | **absent** |
| 10 | same router mounted at two prefixes | **both paths** (corrected: Hono serves both; the old `AMBIGUOUS` answer was wrong) |
| 11 | unmounted sub-router | `UNROOTED-ROUTER`, no route |
| 12 | `app.post(MISSING_UNKNOWN_PATH)` | `UNRESOLVED-CONST` |
| 13 | route inside `__tests__/*.test.ts` | **absent** |
| 14 | `// app.get(...)` and `/* app.post(...) */` | **absent** |
| 15 | `cache.get(GAMMA_PATH)`, `headers.get(...)` | **absent** |
| 16 | absolute const on a router mounted at `/api/mu` | **`/api/mu/api/gamma/one`** (corrected against the runtime; the old expectation enforced a 404 path) |
| 17 | `app.all('/api/exports/*')` followed by more registrations | all following routes parsed |
| 18 | stacked: parent adds `/api/parent/x`, child adds nothing | **empty** against the parent |
| 19 | base branch deletes a file the child leaves untouched | **absent** |
| 20 | route under `workers/svc/src/routes/thing.ts` | **found** |
| 21 | route moved from `workers/svc/index.ts` into a new file | **MOVED**, not added |
| 22 | base loops over `[A, B]`; head keeps only `A` | `B` reported as a **removal** |
| 23 | route added directly in a non-gateway `workers/svc/index.ts` | **found** |
| E1 | nested non-root mount `/api/outer` + `/inner` + `/deep` | `/api/outer/inner/deep` |
| E2 | identically named `const P` in two different files | two distinct paths, no collision |
| E3 | `app.options('/api/opt')` and `app.on('HEAD', '/api/hd')` | both present |
| E4 | registration in `workers/svc/src/app.ts` | **found** |
| E5 | trailing inline comment after a real registration | only the real one |
| E6 | `worker/routes/thing.spec.ts` | **absent** |
| E7 | sub-router declared and mounted in the same file | prefixed once, not served twice |
| E8 | parent and child both add `/api/shared/x` | **added** (merge-base, not base tip) |
| E9 | newly added loop over `[CLASSIFY, LEGACY]` | both paths |
| E10 | mount prefix changes, route file untouched | old removed, new added |
| E11 | path constant's value changes | old removed, new added |
| E12 | `[A, B].forEach(p => app.put(p, h))` | both paths |
| E13 | `registerShareRoutes(app)` | every path the function registers |
| E14 | `app.route('/api/catalog', createCatalogRoutes(deps))` | `/api/catalog/list` |
| E15 | default-exported router imported under a different local name | resolved under its mount |

**Provenance of the cases.** 1-16 are the suite this skill has always advertised, with 10 and 16 corrected against the framework. 17-23 and E1-E11 each correspond to a false finding or a miss recorded in the 2026-09-21 review. E12-E15 were added afterwards, from shapes that failed the first time the rewritten extractor was run against this repo's own corpus - `forEach` registration, `register<X>Routes(app)`, `create<X>Routes()` factories, and default-exported routers. Do not drop one, and do not make a case pass by weakening what it expects.

### Direction 2 - governance

```
git diff <merge-base>...<head> -- docs/architecture/governance/route-ownership.yaml docs/api/developer-api-openapi.yaml
```

Every added or modified `prefix:` and every added path key. When the diff is empty, confirm with a blob comparison (`git rev-parse <base>:<file>` vs `<head>:<file>`) so the report can say "byte-identical" rather than "no diff shown".

### Reconcile

| Bucket | Meaning | Proposed severity |
|---|---|---|
| **R1 In code, not in YAML** | Unregistered endpoint | BLOCKER |
| **R2 In YAML, not in code** | Phantom entry | status-dependent, below |
| **R3 In both** | Correctly registered | - |
| **R4 YAML changed, no code change** | A cutover claimed but not made | MAJOR, verify against the handler |

Coverage test: a path is covered when it equals an ownership prefix or starts with `prefix + '/'`, checked against the **branch's** full yaml (added plus inherited). Compute it with a script over the parsed YAML, not by eyeballing greps. Mind the `/api` segment - `/internal/pulse/*` does **not** cover `/api/internal/pulse/*`.

**R2 severity depends on `status`.** `planned` or any `prepared*` status legitimately has no handler yet - INFO at most. R2 is a BLOCKER only when the entry claims a live status (`active`, `active_compatibility`, `bridged`, `legacy`) with no handler. The reverse - a live handler under `prepared_not_active` - is the declared posture for a surface that ships dark; read the `notes` and count how many other entries use that status first.

**When a PR removes ownership entries**, run the reverse check: does any registration survive, and is the path covered by another entry? A removal with surviving code is an R1 in disguise; a removal with no surviving code is a clean retirement - credit it.

**Both directions empty: report NO REGISTRATION OR UNIQUENESS CHANGE - and do not stop there.** A clean verdict here covers registration and uniqueness only; it never means the PR is safe. List every modified route file and every modified file under `packages/*/src/contracts/` and hand them to `api-standards-gate`, because a PR with zero new endpoints can still add a status code, flip an error code, change the meaning of an existing field, or narrow a shared contract. The cheap sweeps:

```
git diff <merge-base>...<head> -- worker workers | grep -nE '^\+.*\b(4[0-9]{2}|5[0-9]{2})\b.*\)'
git diff -U0 <merge-base>...<head> -- packages/*/src/contracts/ | grep -E '^-'
git diff <merge-base>...<head> | grep -nE '^-\s*export '
```

Assign each R1/R3 endpoint one lane:

| Lane | Test | Required |
|---|---|---|
| **A Gateway-routed public** | in `gateway-worker/index.ts` as `app.<m>('/api/...', ... proxyToService(c,'BINDING'))` | ownership entry whose `owner` matches the binding's worker |
| **B Newly migrated** | path was served by `worker/routes/`, now has a `workers/<w>/` handler | ownership entry with a cutover `status` |
| **C External developer-facing** | `/api/v1/*` on `developer-api-worker` | path in `docs/api/developer-api-openapi.yaml` |
| **D Internal service-binding** | `/internal/*` or `/api/internal/*` | contract in `packages/worker-shared/src/contracts/` + ownership entry with `owner` and `ingress_owners` |

A and C can both apply. A bare proxy mount in the gateway is a mount, not an operation. Ambiguous lane: record AMBIGUOUS and ask.

## Phase 2 - Registration requirements

### route-ownership.yaml

Hard-required (`scripts/check-ownership.ts` errors): `prefix`, `owner`, `status`. Warned if absent or literal `GR-XXX`: `jira`. Expected on new entries but not script-validated: `linear`, `ingress_owners`, `notes`, `methods`.

`status` is one of `active`, `active_compatibility`, `bridged`, `legacy`, `planned`, `prepared`, `prepared_dark`, `prepared_not_active`, `prepared_pending_gateway_cutover`, `decommissioned`.

`notes` is the SOC 2 evidence trail (FR-SOC2-006 / FRAI-5040). Empty or generic notes on a new entry is MAJOR even though the script accepts it. A good entry names the caller, the identity rule, the rows or effect bound, the fences honoured with their migration numbers, and the contract path - credit one when you see it.

`gateway_mismatch_exception` needs all of `jira` (`GR-\d+` or `FRAI-\d+`), `reason`, `exit_criteria`. It downgrades an owner mismatch to informational; it never excuses a missing entry.

`prefix: /api` or `/` is rejected as a catch-all.

When proposing a new entry, copy the shape from the **nearest sibling in the same family** and cite its line number.

**Scope limit worth stating in every report:** `ownership:check` only inspects `workers/gateway-worker/index.ts` for `/api/*` proxy registrations. A monolith-served or worker-served `/internal/*` route is outside it entirely.

### developer-api-openapi.yaml

Hand-maintained 3.0.3, declared canonical at `workers/developer-api-worker/routes/developer-routes.ts` (`x-canonical-source`, GR-3711).

**`bun run openapi:check` does not read this file** - it diffs monolith routes against `worker/routes/docs-routes.ts` and `worker/routes/docs/*.ts`. Its only automated guard is the vitest parity test `workers/developer-api-worker/__tests__/openapi-artifact-firewall-parity.test.ts`. A new external endpoint missing from it ships green even in Tier 1. Propose BLOCKER, never a docs nit - and `api-standards-gate` D1 is the same rule, at the same severity.

Per Lane C endpoint: path present, `operationId` unique file-wide, `tags` from the declared list, request schema with required fields, documented error responses, `deprecated: true` on a compatibility alias.

## Phase 3 - Gates

```
bun run ownership:check          # explicit base: bun scripts/check-ownership.ts --base <merge-base sha>
bun run openapi:check
bun run openapi:check:workers
bun run drift:check:ownership
bun run drift:check:openapi
```

**Tier 1/2** - run them, capture output verbatim, read with these caveats: `ownership:check` defaults to diff mode, so only changed routes are errors and a clean run does not prove the wider surface is clean; pass `--base <the Phase 0 merge-base>` on a stacked PR; `ownership:check:strict` is never run in CI; `Could not resolve a base ref` means the run was warnings-only and proves nothing; `openapi:check:workers` exits 1 on any issue but only a missing `/health` is critical; a new route module in a worker listed in `WORKER_ROUTE_MODULES` (`scripts/openapi-check-workers.ts`) that was not added to that map is invisible to the gate.

**A green repo gate validates the current checkout, not this skill's rules.** Never present passing gates as evidence that the audit itself is correct.

**Tier 3** - do not attempt them and do not imply they passed. Record each as `NOT RUN - <probe reason>` with the command, and perform these static substitutes on `git` + `python3` + `grep`:

- **Ownership field validation** - parse with `pyyaml`; assert required fields, the status enum, exception sub-fields, catch-all prefixes.
- **Ownership coverage** - reimplement the script's own `normalizePattern` / `hasOwnershipEntry` (read them out of `scripts/check-ownership.ts`) and cross-check with one independent matcher. Agreement between the two is what makes a Tier 3 R1 trustworthy.
- **Gateway/owner alignment** - grep `gateway-worker/index.ts` for `app.<m>('<path>' ... proxyToService(c,'BINDING')`, map binding to worker, compare to `owner`.
- **Prefix resolution** - first-match-wins in file order (see D2).
- **Worker contract checks** - `GET /health`, the contract file, correlation-id handling, a `validateInternalRequest` call, by grep.

## Phase 4 - Duplication audit

Corpus, every time and every tier: `route-ownership.yaml`; every worker entrypoint; `workers/*/routes/**` and `workers/*/src/routes/**`; `worker/routes/**` and `worker/index.ts`; `docs/api/developer-api-openapi.yaml` and `openapi-specification-docs.yaml`; `packages/worker-shared/src/contracts/**`; `docs/api/monolith-to-micro-workers-api-url-mapping.md`.

Compare **resolved** paths from the inventory, never raw literals - two sub-routers can both register `/pending`. **D3 and D4 are the point of this phase.** When the PR registers no endpoint, D1-D5 are N/A by scope - say that rather than reporting them clean.

**D1 Path collision** - same normalized path + method registered in two different files. BLOCKER.

**D2 Prefix shadowing** - the new prefix is an ancestor or descendant of an existing entry. `check-ownership.ts` resolves **first match in file order**, not longest-prefix, despite the yaml header. **BLOCKER only when the owners differ** - nesting a narrow entry under a broader one with the same owner is a deliberate convention.

```python
import yaml
r = yaml.safe_load(open('docs/architecture/governance/route-ownership.yaml'))['routes']
for i, a in enumerate(r):
    for b in r[i+1:]:
        pa, pb = a.get('prefix',''), b.get('prefix','')
        if pb.startswith(pa.rstrip('/') + '/') and a.get('owner') != b.get('owner'):
            print(f"SHADOW: '{pa}' ({a['owner']}) precedes '{pb}' ({b['owner']})")
```

Report only pairs the diff creates or touches; list the rest as pre-existing debt.

**D3 Functional duplicate** - different path, same job. Screen on: same resource noun and verb semantics; request/response key-set overlap (Jaccard >= 0.6); same D1 tables (cross-check `db-ownership.yaml`); same service binding and contract path constant. A screen hit is a **candidate, not a finding** - open both contracts and compare payloads. Shared addressing with different payloads is adjacency: INFO naming the convergence risk.

**D4 Cross-owner duplicate** - the same domain entity served by different workers reading different tables. Beware shared vocabulary: decide on **ingress auth, downstream binding and verbs**, not the noun. BLOCKER once confirmed; name which owner should hold it per `docs/architecture/governance/MICROSERVICES_CHARTER.md` and `db-ownership.yaml`.

**D5 Sanctioned alias pair** - a deprecated family and its successor. Report as VERIFY and confirm all four properties; any missing one escalates:
- both paths share one handler via `app.on('<METHOD>', ['<old>','<new>'], ...)`
- `Deprecation`, `Sunset`, `Link` (`rel="successor-version"`), `Warning` set **before** `await next()`
- the deprecated path carries `deprecated: true` in the spec
- both paths appear in the spec, successor documented as canonical

**Also report (INFO):** a contract file declaring a path constant with no route registration and no ownership entry.

**Not duplication** - monolith/worker cutover parity pairs; the same path under different methods; a versioned successor whose predecessor is deprecated; a gateway proxy plus the owner worker's handler; a route the inventory reports as `moved`; and two stacked PRs of one program where the parent registers the endpoints.

**Evidence discipline.** Never conclude duplication from path similarity. Open both handlers. A candidate without a quoted line from each side is emitted with `evidence: UNVERIFIED` and a named gap, not asserted.

## Phase 5 - Cross-branch hazards

**Modify/delete conflict.** For every route file the branch changes:

```
git cat-file -e origin/develop:<file> || echo "DELETED on develop: <file>"
git log -1 --format='%h %ad %s' --date=short origin/develop -- <file>
```

A file the branch rewrites and `develop` deleted produces a conflict whose resolution silently decides whether a retired endpoint comes back. Give both resolutions, a recommendation, and what evidence would settle it. Newly **added** files also fail `cat-file -e`; check `git diff --diff-filter=A` first.

**Merge-order dependency (ORD).** For every backend path the branch's **client** code calls:

```
git grep -q "<path fragment>" origin/develop -- worker workers || echo "MISSING on develop: <path>"
```

A miss is a merge-order constraint - report as `ORD-nn`, a merge gate, not an API defect. Name the user-visible failure, the required order, and the command that turns it green. Beware near-miss paths that read like coverage.

**Deploy-order skew.** Workers and the browser bundle deploy as separate jobs. When a PR adds a field the frontend sends and a worker consumes, read the `needs:` graph in `.github/workflows/_production-deploy.yml` and `_staging-deploy.yml`. If the frontend ships first, describe the window. Also check whether a D1 migration the code depends on is apply-before-deploy.

## Phase 6 - Candidate output

Proposed severity: **BLOCKER** (R1, live-status R2, a confirmed duplicate, a modify/delete conflict, a gate that ran and failed) / **ORD** (merge-order constraint - not an API defect, never counted as one) / **MAJOR** (R4, thin `notes`, missing `linear`/`ingress_owners`, `WORKER_ROUTE_MODULES` gap, unverified alias contract) / **MINOR** / **INFO**. Every gap kind from the inventory is a Coverage gap, never a BLOCKER.

Before any candidate is written, apply the three tests that earn their keep on every run:

- **Coverage test.** Is the path covered by an ownership entry? One lookup, and it kills more false findings than anything else. Run it first.
- **Merge-base test.** Does the defect already exist unchanged at the merge-base? Then `novelty: PRE-EXISTING` - still reported, not attributed to this PR.
- **Sibling-convention test.** Do the merged siblings in the same family all do this? Count them; do not eyeball.

Three overall outcomes:

| Outcome | When |
|---|---|
| `GOVERNANCE ADVISORY - no registration or uniqueness change` | Both reconciliation directions empty and the inventory diff empty, after the modified-file handoff below |
| `GOVERNANCE ADVISORY - N candidate(s)` | At least one candidate above INFO |
| `GOVERNANCE INCOMPLETE` | The base could not be established, or a step the verdict rests on could not run - including a missing `route_inventory.py` |

Chat, first line: that outcome. Then one screen: tier, declared base and merge-base, endpoints by lane, reconciliation buckets, gate status, duplication classes run, inventory totals and gap counts. Do not paste the artifact into chat.

Write candidates to `docs/analysis/api-audit/<PR-or-branch>-<YYYY-MM-DD>.candidates.md`:

```
# API governance candidates - <PR #/branch> - <date>
**Status:** ADVISORY (not a merge decision)   **Gate:** api-governance-gate
**Declared base:** <ref> @ <sha>   **Merge-base:** <sha>   **Stacked:** yes/no   **Draft:** yes/no
**Environment:** Tier 1|2|3 (<probe>)   **PR access:** gh | local ref | browser   **Ref age:** <age>
**Inventory:** base <N> / head <N> endpoints, <N> added, <N> removed, <N> moved; gaps <counts>

## 1. Base resolution
Declared base, merge-base, ancestry, ref age, GitHub-vs-local file-count cross-check.
When stacked, the endpoint count under both bases with the difference attributed to the parent.

## 2. Reconciliation
| # | Method | Resolved path | Mount/const source | Lane | Bucket | Code file:line | YAML line | Owner |

## 3. Gate results
Per command: run / NOT RUN + reason, exit code, verbatim output, interpretation, diff-scoped or strict.
Direction 1: the extractor's path, provenance, and its selftest result.

## 4. Candidates
### [GOV-01] <title>
- **Class:** R1|R2|R4|D1..D5|ORD|conflict|gate-failure
- **Endpoint:** METHOD /resolved/path   (raw literal + mount prefix or constant name)
- **Schema:** evidence UNVERIFIED | severity (proposed) <x> | novelty <x> | ci_status <x> | remediation <x>
- **Evidence:** file:line + quoted source (both sides for a duplicate)
- **rule:** governing file and line
- **Impact:** what breaks in production or in audit if it merges
- **Remediation:** paste-ready YAML or spec block, or NEEDS OWNER INPUT with the open question
- **Verify with:** the exact command

Every candidate leaves this gate at `evidence: UNVERIFIED`; `api-finding-verifier` sets the final value.
The proposed severity stays in this artifact and is withheld from the verifier's claim-only prompt.

## 5. Duplication audit (D1-D5)
Which classes ran, the evidence behind each verdict, candidates cleared, or N/A with the reason.

## 6. Clean checks
## 7. Coverage gaps
Every inventory gap by kind with its file:line, ref age, file-count mismatch, moved route files,
any D-class not run, the extractor's provenance if it came from outside the repo, and any
conclusion resting on a source outside the repo. This section is each candidate's `gaps` field.

## 8. Handed to
api-standards-gate: <modified route files and contracts>
api-finding-verifier: <candidate ids>
```

## Failure handling

A base that cannot be established, a ref that will not resolve, a gate that cannot run, a file that cannot be read, or a missing `route_inventory.py`: record it under Coverage gaps with the tier that caused it, state what is needed, and if it blocks the audit report `GOVERNANCE INCOMPLETE`. Never substitute a guess for a check, never substitute `origin/develop` for a base you did not read, and never substitute an inline regex for the tested extractor.