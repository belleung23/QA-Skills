---
name: "performance-report"
description: "Standards and report builder for performance testing in any project. Rates page-speed results (web-performance-audit) and load-test results (load-test-runner) against Google Core Web Vitals, Lighthouse bands, Apdex and common API SLOs — or the project's own perf-standards.json — and writes a plain-language .md report with a PASSED/WARNING/FAILED verdict, findings with evidence, limitations and a glossary. Use after any performance run, or whenever someone asks for a performance report, performance standards or thresholds, SLO limits, 'is this fast enough', or wants existing results re-rated against new limits."
---

# Performance Report

This skill turns raw performance results into a rated report that a QA reviewer can read without opening any JSON. The measurement skills collect numbers; this skill judges them against **written, sourced standards** and explains the outcome in plain words.

Inputs (either or both, in one report):

- `web-results.json` from **web-performance-audit** (one user: page speed)
- `load-results.json` from **load-test-runner** (many users: load, stress, capacity)

**Why a script does the rating.** Percentiles and threshold comparisons done by hand (or by a language model) drift and are not reproducible. `build-report.mjs` computes every percentile, rating and the verdict deterministically, so the same data always gets the same verdict. Your part is the judgement layer: sanity-checking the evidence, writing the analyst notes, and delivering the file.

Run everything yourself, end to end. The person reviewing reads the finished report and screenshots; do not hand them commands to run.

## Step 1 — Get the tool

The tools live in `.perf-kit/` at the project root (or in the working folder when testing a bare URL). If `.perf-kit/build-report.mjs` exists and its version line (`// perf-kit:build-report v5`, line 2) matches the script at the bottom of this file, reuse it. Otherwise overwrite it with the script exactly as given. Node 18+ is the only requirement; it has no dependencies.

The script is long, so copy it out of this file with a command instead of retyping it (`<this SKILL.md>` is the path you read these instructions from), then check it:

```bash
mkdir -p .perf-kit && awk '/^## build-report[.]mjs$/{h=1;next} h&&/^````js$/{p=1;next} p&&/^````$/{exit} p' "<this SKILL.md>" > .perf-kit/build-report.mjs
node --check .perf-kit/build-report.mjs && sed -n 2p .perf-kit/build-report.mjs   # must print the version line
```

If you ever have to patch the script to get a run working, say so in the analyst notes and in your reply, so the skill itself can be fixed.

## Step 2 — Standards

Default standards (built into the script, each with its source):

| Area | Metric | Good | Poor | Source |
|---|---|---|---|---|
| Page | LCP — main content visible | ≤ 2.5 s | > 4.0 s | Core Web Vitals (web.dev) |
| Page | INP — reaction to click/keypress | ≤ 200 ms | > 500 ms | Core Web Vitals (web.dev) |
| Page | CLS — layout jumping | ≤ 0.1 | > 0.25 | Core Web Vitals (web.dev) |
| Page | FCP — first content | ≤ 1.8 s | > 3.0 s | web.dev |
| Page | TTFB — server starts answering | ≤ 0.8 s | > 1.8 s | web.dev |
| Page | TBT — JS freezing the page | ≤ 200 ms | > 600 ms | Lighthouse scoring |
| Page | Page weight | ≤ 2.73 MB | > 4.10 MB | Lighthouse total-byte-weight curve (2,667 / 4,000 KiB) |
| Page | Click → expected result visible | ≤ 1 s | > 3 s | Nielsen 1 s flow limit; 3 s team default |
| Page | Lighthouse performance score | ≥ 90 | < 50 | Lighthouse score bands |
| Load | p95 response time | ≤ 500 ms | > 1 s | Common API SLO (Nielsen / RAIL limits) |
| Load | p99 response time | ≤ 1 s | > 2 s | Common API SLO |
| Load | Error rate | ≤ 0.1 % | > 1 % | 99.9 % / 99 % availability SLOs |
| Load | Apdex (T = `apdexTMs` from the load config, default 500 ms) | ≥ 0.85 | < 0.70 | Apdex Alliance bands |

How results are rated:

- **Statistic:** page metrics use the **p75 across runs** (Google's Core Web Vitals percentile); load uses p95/p99, error rate and Apdex over each scenario, per endpoint as well as overall.
- **Rating:** ✅ Good (meets target) · ⚠️ Needs improvement (between) · ❌ Poor (worse than poor limit) · ➖ Not measured. "Not measured" is never counted as a pass. INP without scripted interactions, or Lighthouse when it is not installed, are not measured.
- **Verdict**, in this order: BLOCKED if nothing could be rated; FAILED if any check is poor; INCOMPLETE if part of the test could not be measured at all (a page where every run failed, a scenario with no completed requests), because a pass would then cover only part of what was asked; WARNING if any check needs improvement; PASSED if every check is good.
- **Error pages:** a page that answered HTTP 4xx/5xx gets a ❌ "the page answered an error (HTTP 500)" finding. Its timings are shown but marked "➖ Not rated (error page)" and are not counted as good, because an error page loading fast says nothing about the real page.
- **Lighthouse** gets a "➖ Not measured" row per page when it could not run (not installed, or browser-connector mode), so the not-measured count is honest.
- **Percentiles need enough requests:** p95 is rated only with 20 or more requests and p99 with 100 or more (per scenario and per endpoint); with fewer, the value is shown with "➖ Not measured (only N requests…)", because the p95 of a handful of requests is just the slowest one.
- **Smoke tests:** a smoke test checks that the setup works, not how fast the system is. When other tests ran, its passing and not-measured checks are left out of the counts, and so are its response times (p95, p99, Apdex): with only a few dozen requests, the first request on each new connection, which also pays for setting the connection up (DNS, TCP, TLS), can be its slowest 5 %. Those times are still shown, marked "not counted". Its errors always count, and when the smoke test is the only test, all of its checks count.
- **Capacity tests don't decide the verdict.** Stress, spike and breakpoint push past normal load on purpose, so failing standards there is expected. Their ratings and "Capacity limit" findings are shown for planning, and the verdict comes from page speed plus the normal-load scenarios (constant, average-load, soak; plus a smoke test only when it fails). They decide the verdict only when nothing else measured real load (no page-speed audit and no constant, average-load or soak test), and the summary then says so, because a breakpoint test always goes over the standard at the top of its ramp.
- **Observations (ℹ️ OBS-xx)** are listed after the rated findings and never change the verdict: static files without cache headers, uncompressed text, repeat visits that re-download everything, console errors, failed requests.
- Sizes are decimal (1 MB = 1,000,000 bytes).

### Project overrides

Teams often have their own SLOs (a search endpoint allowed 1.5 s, a dashboard allowed a slower LCP). Put them in `perf-standards.json` at the project root. Only include what differs. The script merges it over the defaults and labels each overridden row "(project override)" with its source:

```json
{
  "source": "Platform SLOs v3 (Confluence: Performance budgets, 2026-09)",
  "web":  { "LCP": { "good": 3000, "poor": 5000 }, "pages": { "dashboard": { "TBT": { "good": 400, "poor": 900 } } } },
  "load": { "p95": { "good": 300 }, "apdex": { "good": 0.9 }, "endpoints": { "GET /api/search": { "p95": { "good": 1500, "poor": 3000 } } } }
}
```

`web.pages.<page name>` and `load.endpoints.<request name>` scope a limit to one page or endpoint. Apdex's T (the response time that still counts as "satisfied") is not a report setting: it is fixed while the load test runs, by `apdexTMs` in load-config.json, and the report labels Apdex with the T that was used. Use numbers that come from the user, a ticket, or team documentation, and always fill in `source`. Never invent overrides. Never loosen a standard to turn a failing result green unless the user explicitly asks; if they do, the report shows the override and its source, so the change stays visible.

## Step 3 — Build the report

```bash
node .perf-kit/build-report.mjs \
  --results <run-dir>/web-results.json <run-dir>/load-results.json \
  [--standards perf-standards.json] --out <run-dir> --title "<App> — <what was tested>"
```

Pass only the results files that exist: `web-results.json`, `load-results.json`, or both for one combined report.

It writes `<slug>_<PASSED|WARNING|FAILED|INCOMPLETE|BLOCKED>_Performance-Report_<YYYY-MM-DD>.md` into the run directory and prints the verdict and counts. The script runs anywhere with Node 18+ and needs no network, so it can always run where the results are, even when the measurement itself ran through a browser connector on another computer. Keep the report inside the run directory: its screenshot and Lighthouse links are relative to it. If a rebuild changes the verdict (and so the file name), the older report is renamed to `….superseded.md` so only one current report remains.

## Step 4 — Sanity check, then write the analyst notes

Before trusting the verdict, read the report and check these traps. Each one means the run measured the wrong thing. Fix the setup and re-run instead of shipping a misleading report.

- A page shows **"redirected to …"** (usually the login page): the session is missing or expired. The numbers belong to the login page.
- Runs failed (`x/y runs OK` below the planned count), or the page answered 4xx/5xx.
- The LCP element is a cookie banner or spinner instead of the real content. Add a better `waitFor` selector in the audit config.
- A load scenario's errors are all `ECONNREFUSED`/`ENOTFOUND` (wrong URL or server down), `401`/`403` (auth), or `429` (a rate limiter answered: when that limiter is what users complain about, it is the finding, so report it; otherwise you tested the limiter, not the app). The plain-language hint next to "Errors by type" says which.
- The limitations say a scripted interaction "could not run" (its action time and INP are missing: fix the selector), or that "the network never went quiet within 15 s" (add live connections or beacons to `ignoreRequests`, or report a genuinely slow load).
- "Load generator saturated" appears: the test machine was the bottleneck. Re-run with fewer users or with k6.

Then replace the line `_ANALYST-NOTES-PLACEHOLDER…_` with a short paragraph or up to 5 plain bullets:

1. Which findings matter most for real users, and why (e.g. "Product page main image takes 19 s on mobile").
2. The root cause you can actually confirm from the evidence (the LCP element and file size, the endpoint with the errors, the user count where it broke). Label anything else as "likely".
3. What to re-test after a fix, under the same profile, runs and scenario.

Do not change any number, rating or the verdict by hand. If a rating looks wrong, the measurement or the standard is wrong: fix that and rebuild. The "What usually causes this" lines and error hints are generic; when the evidence points elsewhere (a text LCP held back by a web font, a rate limiter that *is* the problem users report), say so in the analyst notes rather than leaving the generic advice unanswered.

The report ends with a one-line markdownlint setting that switches off the line-length and inline-HTML rules (long table rows and the filmstrip table are intentional), so a default markdownlint run stays clean.

## Step 5 — Deliver

- Leave the report in the run directory next to its evidence (`screens/`, `lighthouse/`, raw JSON).
- In your reply, give the verdict, the top 3 findings in one plain line each, and the report path. Do not paste the whole report.
- Explain any technical term the reader may not know. The report ends with a glossary that covers the terms it uses.
- Results stay on disk. Commit them to git or share them only when the user asks.

## What the report contains

A header table first: verdict and counts, target, environment, date with timezone, scope, tools, "run by AI agent — for QA review". Then these numbered sections (when only one kind of test ran, its section is 3 and the later numbers move up by one):

1. **Summary** in plain words, then the agent's assumptions (from the configs' `assumptions`), the capacity estimate and headroom when load tests ran, and the top issues.
2. **Standards applied**, with sources and any project overrides.
3. **Page speed results:** per page × profile, p75 and median against the standard, then:
   - details: LCP element, layout-shift element, long tasks, render-blocking files, heaviest scripts, slowest interaction, largest files
   - repeat-visit line
   - embedded screenshot, after-click screenshots and a loading filmstrip
4. **Load results:** per scenario totals (the error rate with its count, and the response time of successful requests alone when some failed), a per-endpoint table, error types with a plain-language hint, the capacity point (the last user count within standard and the first over it, overall or for any single endpoint; the same breach must last two 5-second windows in a row, and an endpoint is only judged in windows with 20+ of its requests, so one slow request cannot set it), and a 5-second timeline.
5. **Findings**, worst first (`PERF-01`…): what was measured against the standard, evidence, usual causes, what to check. Capacity-test findings come last ("Capacity limit — …"), followed by unrated observations (`OBS-01`…).
6. **Analyst notes** (yours).
7. **Not measured & limitations:** lab vs field data, the exact simulated network/CPU values, the load generator sharing the machine with a localhost server, measurements made through the browser connector on the user's own computer, redirects, failed runs, unstable metrics, aborted scenarios, missing Lighthouse, server-side metrics not collected.
8. **Files & how to re-run:** links to the raw result files and test configs, and the exact commands with the folder to run them from, including which environment variables (secrets) must be set first.

A **Glossary** of the terms the report uses closes it.

## build-report.mjs

````js
#!/usr/bin/env node
// perf-kit:build-report v5 — rates perf-results JSON (web and/or load) against standards and writes a Markdown report.
// Usage: node build-report.mjs --results <file.json> [<file.json> ...] [--standards perf-standards.json] [--out <dir>] [--title "..."]
import fs from 'node:fs';
import path from 'node:path';

const argv = process.argv.slice(2);
const arg = (k, d) => { const i = argv.indexOf(`--${k}`); return i >= 0 ? argv[i + 1] : d; };
const list = (k) => { const i = argv.indexOf(`--${k}`); if (i < 0) return []; const o = []; for (let j = i + 1; j < argv.length && !argv[j].startsWith('--'); j++) o.push(argv[j]); return o; };

export const DEFAULT_STANDARDS = {
  web: {
    LCP: { good: 2500, poor: 4000, unit: 'ms', name: 'Largest Contentful Paint (LCP)', plain: 'when the main content (biggest image or text block) appears', source: 'Google Core Web Vitals (web.dev)' },
    INP: { good: 200, poor: 500, unit: 'ms', name: 'Interaction to Next Paint (INP)', plain: 'how long the page takes to visibly react to a click or key press', source: 'Google Core Web Vitals (web.dev)' },
    CLS: { good: 0.1, poor: 0.25, unit: '', name: 'Cumulative Layout Shift (CLS)', plain: 'how much the content jumps around while loading (0 = no jumping)', source: 'Google Core Web Vitals (web.dev)' },
    FCP: { good: 1800, poor: 3000, unit: 'ms', name: 'First Contentful Paint (FCP)', plain: 'when the first text or image appears', source: 'web.dev' },
    TTFB: { good: 800, poor: 1800, unit: 'ms', name: 'Time to First Byte (TTFB)', plain: 'how long the server takes to start answering', source: 'web.dev' },
    TBT: { good: 200, poor: 600, unit: 'ms', name: 'Total Blocking Time (TBT)', plain: 'how long heavy JavaScript freezes the page while it loads', source: 'Lighthouse scoring' },
    pageWeight: { good: 2730, poor: 4100, unit: 'KB', name: 'Page weight', plain: 'total data downloaded to show the page', source: 'Lighthouse "total byte weight" audit curve (2,667 / 4,000 KiB)' },
    action: { good: 1000, poor: 3000, unit: 'ms', name: 'Action response time', plain: 'time from a click until the expected result is on screen', source: 'Nielsen response-time limits (1 s keeps the flow); 3 s poor limit is a common team default' },
    lighthouse: { good: 90, poor: 50, unit: '/100', higherIsBetter: true, name: 'Lighthouse performance score', plain: "Google's overall lab score for the page", source: 'Lighthouse score bands' },
  },
  load: {
    p95: { good: 500, poor: 1000, unit: 'ms', name: 'p95 response time', plain: '95 out of 100 requests finished within this time', source: 'Common API SLO, built on the 0.1 s / 1 s / 10 s response-time limits (Nielsen; Google RAIL)' },
    p99: { good: 1000, poor: 2000, unit: 'ms', name: 'p99 response time', plain: '99 out of 100 requests finished within this time (the slow tail)', source: 'Common API SLO' },
    errorRate: { good: 0.001, poor: 0.01, unit: '%', name: 'Error rate', plain: 'share of requests that failed or got an unexpected status', source: 'Common availability SLOs: 99.9 % success good, 99 % minimum' },
    apdex: { good: 0.85, poor: 0.7, unit: '', higherIsBetter: true, name: 'Apdex (T = 500 ms)', plain: 'user-satisfaction score from 0 to 1 (1 = everyone happy)', source: 'Apdex Alliance rating bands (Good ≥ 0.85, Fair 0.70–0.84, Poor < 0.70)' },
  },
};

const FENCE = '`'.repeat(3); // built at runtime so this file can sit inside a fenced block in SKILL.md
const isObj = (o) => o && typeof o === 'object' && !Array.isArray(o);
const merge = (a, b) => { const o = { ...a }; for (const [k, v] of Object.entries(b || {})) o[k] = isObj(v) && isObj(a?.[k]) ? merge(a[k], v) : v; return o; };
const overridden = new Set();
function loadStandards(file) {
  if (!file) return DEFAULT_STANDARDS;
  const o = JSON.parse(fs.readFileSync(file, 'utf8'));
  for (const kind of ['web', 'load']) for (const [k, v] of Object.entries(o[kind] || {})) if (isObj(v) && DEFAULT_STANDARDS[kind][k] && ('good' in v || 'poor' in v)) { overridden.add(`${kind}.${k}`); v.source = v.source || o.source || `project override (${path.basename(file)})`; }
  return merge(DEFAULT_STANDARDS, o);
}
const stdFor = (S, kind, metric, subject) => { const scoped = kind === 'web' ? S.web.pages?.[subject]?.[metric] : S.load.endpoints?.[subject]?.[metric]; return scoped ? { ...S[kind][metric], ...scoped, source: scoped.source || 'project override (scoped)' } : S[kind][metric]; };

const pct = (vals, p) => { const v = (vals || []).filter((x) => x != null && !Number.isNaN(x)).sort((a, b) => a - b); if (!v.length) return null; const i = (v.length - 1) * p; const lo = Math.floor(i); return v[lo] + (v[Math.ceil(i)] - v[lo]) * (i - lo); };
const rate = (v, s) => (v == null || Number.isNaN(v) ? 'na' : s.higherIsBetter ? (v >= s.good ? 'good' : v >= s.poor ? 'ni' : 'poor') : v <= s.good ? 'good' : v <= s.poor ? 'ni' : 'poor');
const ICON = { good: '✅ Good', ni: '⚠️ Needs improvement', poor: '❌ Poor', na: '➖ Not measured', skip: '➖ Not rated (error page)' };
const SEV = { poor: 0, ni: 1, good: 2, na: 3, skip: 4 };
function fmt(v, unit) {
  if (v == null || Number.isNaN(v)) return '—';
  if (unit === 'ms') return v >= 1000 ? `${(v / 1000).toFixed(2)} s` : `${Math.round(v)} ms`;
  if (unit === 'KB') return v >= 1000 ? `${(v / 1000).toFixed(2)} MB` : v >= 1 ? `${Math.round(v)} KB` : `${Math.round(v * 1000)} B`;
  if (unit === '%') return `${(v * 100).toFixed(2)} %`;
  if (unit === '/100') return `${Math.round(v)} / 100`;
  if (unit === 'status') return `HTTP ${v}`;
  return Number(v).toFixed(v < 1 ? 3 : 2);
}
const bytes = (b) => fmt(b / 1000, 'KB');
const stdText = (s) => (s.unit === 'status' ? 'a 2xx/3xx answer' : `${s.higherIsBetter ? '≥' : '≤'} ${fmt(s.good, s.unit)} good · ${s.higherIsBetter ? '<' : '>'} ${fmt(s.poor, s.unit)} poor`);
const kneeText = (k, type) => kneeCore(k, type) + (k.firstErr && (!k.firstBad || k.firstErr.vus > k.firstBad.vus) ? `; requests started failing at ~${k.firstErr.vus} users` : '');
const kneeCore = (k, type) => (!k.firstBad ? 'stayed within the response-time standard' : k.brief ? `went over the standard only in isolated 5-second windows (first at ~${k.firstBad.vus} users) and recovered each time — no sustained breach` : k.lastGood ? (k.lastGood.vus >= k.firstBad.vus ? `hovered at the edge of the standard around ~${k.firstBad.vus} users (some windows in, some over)` : `stayed within standard up to ~${k.lastGood.vus} users; first went over at ~${k.firstBad.vus} users`) : ['stress', 'spike', 'breakpoint'].includes(type) ? `was already over standard in the first measured window (~${k.firstBad.vus} users), so the limit is lower${k.pinned ? ' (see the capacity estimate from the finer test)' : ' — a slower ramp would pin it down'}` : `was over standard from its first measured window, at ~${k.firstBad.vus} users`);
const CAPACITY_TYPES = new Set(['stress', 'spike', 'breakpoint']);
const MIN_N = { p95: 20, p99: 100 }; // fewest requests for a percentile to be rated
// Seconds the plan holds its peak user count (e.g. the 45 s of "30 users for 45 s"), not counting ramps.
const plannedSec = (sc) => Math.round((sc.plan?.stages || []).reduce((a, s) => a + s.durationSec, 0));
// A test whose user count climbs for a while (not just a few seconds of ramp-up) — the ones that locate a limit.
const ramping = (s) => CAPACITY_TYPES.has(s.type) || (s.plan?.stages || []).some((st, i, a) => st.target > (i ? a[i - 1].target : s.plan?.startVUs || 0) && st.durationSec >= 10);
const holdSec = (sc) => { const st = sc.plan?.stages || []; const peak = Math.max(sc.plan?.startVUs || 0, ...st.map((s) => s.target)); let lvl = sc.plan?.startVUs || 0, h = 0; for (const s of st) { if (s.target === peak && lvl === peak) h += s.durationSec; lvl = s.target; } return Math.round(h); };
// Event Timing names the low-level event (pointerdown, keydown...); say "click" or "key press" and name the handler.
const ixText = (p) => { const w = p.worstInteraction; const kind = /^key/.test(w.event) ? 'key press' : /^(pointer|mouse|click|touch|tap)/.test(w.event) ? 'click' : w.event; const h = p.heavyScriptsInteraction?.[0]; return `${kind} on \`${w.target}\` took ${Math.round(w.durMs)} ms${h ? ` (mostly ${h.script}, ${h.ms} ms)` : ''}`; };
const short = (u) => { try { const x = new URL(u); return x.pathname + x.search || u; } catch { return u; } };
const isNet = (x) => /^(https?|wss?):/i.test((x && x.url) || ''); // data:/blob: URLs are inline content, not downloads
const secText = (n) => { const u = n >= 3600 ? [n / 3600, 'h'] : n >= 60 ? [n / 60, 'min'] : [n, 's']; const v = Math.round(u[0] * 10) / 10; return `${v} ${u[1]}`; };
const cacheText = (cc) => { if (!cc) return 'no Cache-Control header'; if (/no-store/.test(cc)) return 'no-store: never cached'; if (/no-cache/.test(cc)) return 'no-cache: checked with the server on every visit'; const m = /max-age=(\d+)/.exec(cc); return !m ? cc : +m[1] === 0 ? 'max-age=0: checked with the server on every visit' : +m[1] < 86400 ? `kept for ${secText(+m[1])} only` : cc; };
const slug = (s) => { let x = String(s).toLowerCase().replace(/^https?:\/\//, '').replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, ''); if (x.length > 80) x = x.slice(0, 80).replace(/-[^-]*$/, ''); return x || 'app'; };

const HINTS = {
  LCP: ['Slow server response, render-blocking CSS/JS, or a large hero image/font that downloads late.', 'Compress and resize the LCP image (WebP/AVIF, right dimensions), preload it, serve it from a CDN, and remove render-blocking scripts from <head>.'],
  FCP: ['The server answers slowly, or CSS/JS in <head> must download and run before anything can be drawn.', 'Cut server time first (see TTFB), then inline critical CSS and defer non-critical scripts.'],
  TTFB: ['Slow backend work, cold starts, slow database queries, or redirect chains before the page itself.', 'Check server logs/APM for this route, cache the response, and remove extra redirects.'],
  CLS: ['Something is inserted above existing content after it rendered (banner, ad, cookie bar), or images/embeds have no reserved size.', 'Reserve space (width/height or aspect-ratio, fixed slot height) or insert late content below the fold / as an overlay.'],
  TBT: ['Long JavaScript tasks run after the first paint (hydration, big bundles, heavy loops), freezing the page.', 'Split long tasks, lazy-load non-critical code, and profile the main thread in DevTools Performance.'],
  INP: ['The click handler (or work it triggers) blocks the main thread before the screen can update. (This is separate from the action time: the result can appear within 1 s while the page was still frozen for more than 200 ms first.)', 'Make the handler show feedback first, move heavy work off the main thread or after a yield (setTimeout / scheduler.yield).'],
  action: ['The UI waits on slow work (API call or heavy script) before showing the result.', 'Check the network calls the action makes and the click handler; show optimistic/loading feedback immediately.'],
  pageWeight: ['Large, uncompressed or unnecessary files (images, JS bundles, fonts).', 'Compress/resize images, enable gzip/brotli, code-split JavaScript, and lazy-load below-the-fold media.'],
  lighthouse: ['Several lab metrics are weak at once.', 'Open the Lighthouse HTML report and work through its top "Opportunities".'],
  p95: ['Some requests queue up or wait on a slow dependency (database, external API, limited worker pool).', 'Use the per-endpoint table of this scenario to find the slow endpoint, check server CPU/memory/DB during the test window, and add caching, indexes or capacity.'],
  p99: ['A slow tail: occasional very slow requests (lock waits, GC pauses, cold paths, retries).', 'Trace the slowest requests in APM/logs for the test window.'],
  errorRate: ['The system rejects or fails requests under load (timeouts, 5xx, rate limiting, connection errors).', 'Check the error breakdown and server logs for the test window; find the limit (pool size, rate limit, memory) that was hit.'],
  LCPtext: ['The main content is text, so it waits for the HTML, render-blocking CSS/JS, the data the page fetches before rendering it, and any web font it uses (with font-display: block the text stays invisible until the font arrives).', 'Preload the web font and use font-display: swap or optional (or a system font), subset the font, cut render-blocking files, and fetch or server-render the content data earlier.'],
  httpStatus: ['The server returned an error page (4xx/5xx) for this URL: wrong path, missing permissions, or a server error.', 'Open the URL by hand, check the server logs, and fix the page or the config path before measuring speed.'],
  apdex: ['Too many requests were slower than the satisfaction target or failed.', 'Fix the p95/error findings above — Apdex follows them.'],
};

// Final tidy pass: trim trailing spaces, normalise table pipes, and wrap bare URLs in <> (outside code and links)
// so the report renders cleanly everywhere and passes markdownlint (the file itself turns off the line-length and
// inline-HTML rules, see the end of main()).
function tidy(md) {
  let inFence = false;
  return md.split('\n').map((raw) => {
    if (raw.startsWith(FENCE)) { inFence = !inFence; return raw; }
    if (inFence) return raw;
    let line = raw.replace(/\s+$/, '');
    if (/^\|.*\|$/.test(line)) {
      const cells = line.slice(1, -1).split('|').map((c) => c.trim());
      line = cells.every((c) => /^:?-+:?$/.test(c)) ? `| ${cells.map(() => '---').join(' | ')} |` : `| ${cells.join(' | ')} |`;
    }
    return line.split('`').map((seg, i) => (i % 2 ? seg : seg.replace(/(^|[\s“(])(https?:\/\/[^\s<>`"”)*]+?)(?=[.,;:!?)”*]*(?:\s|$))/g, (m, pre, url, off, str) => (pre === '(' && str[off - 1] === ']' ? m : `${pre}<${url}>`)))).join('`');
  }).join('\n');
}

function main() {
  const files = list('results');
  if (!files.length) { console.error('Usage: node build-report.mjs --results <web-results.json> [<load-results.json>] [--standards perf-standards.json] [--out dir] [--title "..."]'); process.exit(2); }
  const S = loadStandards(arg('standards'));
  const missing = files.filter((f) => !fs.existsSync(f));
  if (missing.length) { console.error(`Results file not found: ${missing.join(', ')}. Run the measurement first, or check the --results paths.`); process.exit(2); }
  const R = files.map((f) => ({ file: f, ...JSON.parse(fs.readFileSync(f, 'utf8')) }));
  const web = R.filter((r) => r.kind === 'web'), load = R.filter((r) => r.kind === 'load');
  const outDir = path.resolve(arg('out', path.dirname(files[0])));
  const rel = (p) => path.relative(outDir, p) || '.';
  const label = arg('title') || R[0].label || R[0].target;
  const checks = []; const limits = []; const glossary = new Set(); const findings = []; const obs = new Map(); const unmeasured = [];
  const observe = (title, detail) => { if (!obs.has(title)) obs.set(title, []); obs.get(title).push(detail); };
  const obsUrls = new Map(); // one line per page and observation, merged across profiles
  const obsCut = new Set(); // measure-page keeps at most 10 files per list, so a list of 10 may be cut short
  const observeUrls = (title, page, items, cut) => { const key = `${title}|${page}`; if (!obsUrls.has(key)) { obsUrls.set(key, new Map()); observe(title, { page, key }); } const m = obsUrls.get(key); for (const [u, l] of items) if (!m.has(u)) m.set(u, l); if (cut || items.length >= 10) obsCut.add(key); };
  const CACHE_OBS = 'Static files are cached only briefly or not at all';
  const L = [];
  const add = (c) => { checks.push(c); return c; };

  // ---------- web ----------
  const webSec = [];
  for (const W of web) {
    for (const n of W.notes || []) limits.push(n);
    for (const pg of W.pages) {
      const subject = `${pg.name} · ${pg.profile}`;
      const fullList = new Set(); // lists measure-page cut at 10 files (counted before inline data: URLs are dropped)
      if (pg.resources) for (const k of ['largest', 'weakCaching', 'uncompressed', 'failed']) if (Array.isArray(pg.resources[k])) { if (pg.resources[k].length >= 10) fullList.add(k); pg.resources[k] = pg.resources[k].filter(isNet); }
      const vary = []; // metrics that varied a lot between runs: one limitation line per page and profile
      webSec.push(`### ${pg.name} — ${pg.profile} (${pg.status >= 400 ? `the page answered HTTP ${pg.status}; ${pg.runs} run` : `${pg.okRuns}/${pg.runs} runs OK, cold cache`})`, '', `URL: ${pg.url}${pg.redirectedTo ? ` → **redirected to ${pg.redirectedTo}**` : ''}`, '');
      if (pg.redirectedTo) limits.push(`**${subject}** redirected to ${pg.redirectedTo} — the numbers describe that page, not the one requested (often a login redirect: missing or expired session).`);
      const errPage = pg.status >= 400;
      if (pg.stoppedEarly) limits.push(`${subject}: ${pg.stoppedEarly}.`);
      else if (pg.okRuns < pg.runs) limits.push(`${subject}: ${pg.runs - pg.okRuns} of ${pg.runs} runs failed (${(pg.errors || []).slice(0, 2).join('; ')}).`);
      if (!pg.okRuns) { unmeasured.push(`${subject}: ${(pg.errors || [])[0] || 'no successful run'}`); }
      if (pg.status >= 400) { const s = { good: 399, poor: 399, unit: 'status', name: 'HTTP status', plain: 'whether the page loaded at all (2xx/3xx = yes)', source: 'HTTP: 4xx/5xx means an error page' }; add({ area: 'web', subject, page: pg, metric: 'httpStatus', value: pg.status, std: s, rating: 'poor' }); webSec.push(`> ❌ **The page answered HTTP ${pg.status}** — the numbers below describe an error page, not the real page.`, ''); }
      for (const [a, err] of Object.entries(pg.interactionErrors || {})) limits.push(`${subject}: the scripted interaction “${a}” could not run (${err}), so its response time and INP were not measured. Fix the selector in the config.`);
      if (pg.longLivedRequests?.length) limits.push(`${subject}: the page keeps ${pg.longLivedRequests.length} connection(s) open (${pg.longLivedRequests.slice(0, 3).map(short).join(', ')}); they were ignored when deciding that the page had finished loading.`);
      if (pg.settleTimedOut?.length) limits.push(`${subject}: the network never went quiet within 15 s (still loading: ${pg.settleTimedOut.slice(0, 3).map(short).join(', ')}); measurements were taken at the 15 s mark.`);
      if (pg.lcpFallbackRuns) limits.push(`${subject}: in ${pg.lcpFallbackRuns} run(s) headless Chrome did not report the paint of the largest image, so LCP was taken from that image's load-finish time (a close approximation).`);
      webSec.push('| Metric | p75 | Median | Standard | Rating |', '|---|---|---|---|---|');
      const rows = [['TTFB', 'TTFB'], ['FCP', 'FCP'], ['LCP', 'LCP'], ['CLS', 'CLS'], ['TBT', 'TBT'], ['INP', 'INP']];
      for (const [k, sk] of rows) {
        const s = stdFor(S, 'web', sk, pg.name); const vals = pg.metrics[k] || [];
        let v = pct(vals, 0.75); const med = pct(vals, 0.5);
        let r = rate(v, s); let why = '';
        if (errPage) r = 'skip';
        else if (k === 'INP' && !pg.interactionsDefined) { r = 'na'; v = null; why = ' (no interactions scripted)'; }
        else if (k === 'INP' && v == null && Object.keys(pg.interactionErrors || {}).length) why = ' (interaction failed)';
        else if (v == null && !pg.okRuns) why = ' (page could not be measured)';
        add({ area: 'web', subject, page: pg, metric: sk, value: v, std: s, rating: r });
        glossary.add(k);
        if (k === 'LCP' && pg.lcpFallbackRuns && v != null) why += ` (estimated from the image's load time in ${pg.lcpFallbackRuns} of ${pg.okRuns} runs)`;
        webSec.push(`| ${s.name} | ${fmt(v, s.unit)} | ${fmt(med, s.unit)} | ${stdText(s)} | ${ICON[r]}${why} |`);
        const spread = vals.filter((x) => x != null); if (!errPage && spread.length >= 3 && k !== 'CLS' && Math.min(...spread) > 0 && Math.max(...spread) / Math.min(...spread) > 1.5 && Math.max(...spread) > 500) vary.push(`${k} ${fmt(Math.min(...spread), 'ms')}–${fmt(Math.max(...spread), 'ms')}`);
      }
      for (const [name, vals] of Object.entries(pg.actions || {})) {
        const s = stdFor(S, 'web', 'action', pg.name); const v = pct(vals, 0.75); const r = errPage ? 'skip' : rate(v, s);
        add({ area: 'web', subject, page: pg, metric: 'action', action: name, value: v, std: s, rating: r });
        const sa = vals.filter((x) => x != null); if (!errPage && sa.length >= 3 && Math.min(...sa) > 0 && Math.max(...sa) / Math.min(...sa) > 1.5 && Math.max(...sa) > 500) vary.push(`“${name}” ${fmt(Math.min(...sa), 'ms')}–${fmt(Math.max(...sa), 'ms')}`);
        webSec.push(`| Action: “${name}” | ${fmt(v, 'ms')} | ${fmt(pct(vals, 0.5), 'ms')} | ${stdText(s)} | ${ICON[r]}${pg.interactionErrors?.[name] ? ' (interaction failed)' : ''} |`);
      }
      if (vary.length) limits.push(`${subject}: ${vary.length > 1 ? 'these' : 'this'} varied a lot between runs, so treat ${vary.length > 1 ? 'them' : 'it'} as less certain: ${vary.join(', ')}.`);
      if (pg.resources) {
        const s = stdFor(S, 'web', 'pageWeight', pg.name); const v = pg.resources.totalBytes / 1000; const r = errPage ? 'skip' : rate(v, s);
        add({ area: 'web', subject, page: pg, metric: 'pageWeight', value: v, std: s, rating: r });
        webSec.push(`| Page weight (${pg.resources.requests} request${pg.resources.requests === 1 ? "" : "s"}) | ${fmt(v, 'KB')} | — | ${stdText(s)} | ${ICON[r]} |`);
      }
      if (pg.lighthouse && !pg.lighthouse.error) {
        const s = stdFor(S, 'web', 'lighthouse', pg.name); const v = pg.lighthouse.scores.performance; const r = rate(v, s);
        add({ area: 'web', subject, page: pg, metric: 'lighthouse', value: v, std: s, rating: r });
        webSec.push(`| Lighthouse performance (v${pg.lighthouse.version}) | ${fmt(v, '/100')} | — | ${stdText(s)} | ${ICON[r]} |`);
      } else if (!errPage && pg.okRuns && W.config?.lighthouse !== false) {
        const s = stdFor(S, 'web', 'lighthouse', pg.name);
        add({ area: 'web', subject, page: pg, metric: 'lighthouse', value: null, std: s, rating: 'na' });
        webSec.push(`| Lighthouse performance | — | — | ${stdText(s)} | ${ICON.na} (${pg.lighthouse?.error ? 'Lighthouse failed' : 'Lighthouse not available'}) |`);
        if (pg.lighthouse?.error) limits.push(`${subject}: ${pg.lighthouse.error}`);
      }
      webSec.push('');
      const ex = [];
      if (pg.lcpElement) ex.push(`LCP element: \`${pg.lcpElement}\`${pg.lcpUrl ? ` (${pg.lcpUrl})` : ''}`);
      if (pg.clsTopSource && pct(pg.metrics.CLS, 0.75) > 0) ex.push(`biggest layout shift moved: \`${pg.clsTopSource}\``);
      if (pg.longTasks?.count) ex.push(`long tasks: ${pg.longTasks.count} (longest ${pg.longTasks.longestMs} ms)`);
      if (pg.worstInteraction) ex.push(`slowest interaction: ${ixText(pg)}`);
      if (pg.resources?.largest?.length) ex.push(`largest files: ${pg.resources.largest.slice(0, 3).map((x) => `${short(x.url)} ${bytes(x.bytes)}${x.ms ? ` (${fmt(x.ms, 'ms')} from request to last byte)` : ''}`).join(', ')}`);
      if (pg.resources?.failed?.length) ex.push(`failed requests: ${pg.resources.failed.map((x) => `${x.status} ${x.url}`).join(', ')}`);
      if (pg.consoleErrors) ex.push(`console errors: ${pg.consoleErrors}`);
      if (pg.renderBlocking?.length) ex.push(`render-blocking files: ${pg.renderBlocking.map((x) => short(x.url)).join(', ')}`);
      if (pg.heavyScriptsBeforePaint?.length) ex.push(`scripts before first paint (delay FCP): ${pg.heavyScriptsBeforePaint.slice(0, 3).map((x) => `${x.script} (${x.ms} ms)`).join(', ')}`);
      if (pg.heavyScriptsLoad?.length) ex.push(`scripts blocking after first paint (TBT): ${pg.heavyScriptsLoad.slice(0, 3).map((x) => `${x.script} (${x.ms} ms)`).join(', ')}`);
      if (pg.heavyScriptsInteraction?.length) ex.push(`heaviest scripts during clicks: ${pg.heavyScriptsInteraction.slice(0, 3).map((x) => `${x.script} (${x.ms} ms)`).join(', ')}`);
      if (pg.lighthouse?.html) ex.push(`Lighthouse report: [${pg.lighthouse.html}](${pg.lighthouse.html})`);
      if (ex.length) webSec.push(`Details — ${ex.join(' · ')}`, '');
      const rv = pg.repeatView;
      if (rv?.metrics) webSec.push(`Repeat visit (warm cache, 1 run): TTFB ${fmt(rv.metrics.TTFB, 'ms')} · FCP ${fmt(rv.metrics.FCP, 'ms')} · LCP ${fmt(rv.metrics.LCP, 'ms')} · downloaded ${bytes(rv.transferredBytes)} in ${rv.requests} requests (first visit: ${bytes(pg.resources?.totalBytes || 0)}).`, '');
      else if (rv?.error) limits.push(`${subject}: repeat-visit run failed (${rv.error}).`);
      if (pg.screenshot) webSec.push(`![${subject}](${pg.screenshot})`, '');
      for (const [a, f] of Object.entries(pg.afterShots || {})) webSec.push(`After “${a}”:`, '', `![${pg.name} ${pg.profile} after ${a}](${f})`, '');
      if (pg.filmstrip?.length) webSec.push('Loading filmstrip (one extra run, frames at the times shown):', '', `<table><tr>${pg.filmstrip.map((f) => `<td align="center">${f.file ? `<img src="${f.file}" width="110" alt="${pg.name} ${pg.profile} at ${fmt(f.ms, 'ms')}">` : '(blank)'}<br>${fmt(f.ms, 'ms')}</td>`).join('')}</tr></table>`, '');
      const res = errPage ? {} : pg.resources || {};
      if (res.weakCaching?.length) observeUrls(CACHE_OBS, pg.name, res.weakCaching.map((x) => [short(x.url), cacheText(x.cacheControl)]), fullList.has('weakCaching'));
      if (res.uncompressed?.length) observeUrls('Files are sent without compression', pg.name, res.uncompressed.map((x) => [short(x.url), bytes(x.bytes)]), fullList.has('uncompressed'));
      if (!errPage && rv?.metrics && (pg.resources?.totalBytes || 0) > 100000 && rv.transferredBytes >= 0.8 * pg.resources.totalBytes) observe('Repeat visits download almost everything again', `${pg.name} (${pg.profile}): ${bytes(rv.transferredBytes)} on the repeat visit vs ${bytes(pg.resources.totalBytes)} on the first`);
      if (!errPage && pg.consoleErrors) observe('JavaScript errors in the console', `${pg.name} (${pg.profile}): ${pg.consoleErrors} error(s)`);
      if (res.failed?.length) observe('Requests that failed while loading', `${pg.name} (${pg.profile}): ${res.failed.map((x) => `${x.status} ${short(x.url)}`).join(', ')}`);
    }
    if (W.config?.ignoreRequests?.length) limits.push(`Requests matching the config's ignoreRequests (${W.config.ignoreRequests.map((x) => `\`${x}\``).join(', ')}) were not waited for when deciding that a page had finished loading.`);
    if (W.pages.some((p) => !p.interactionsDefined)) limits.push('INP is only measured when the test clicks or types on the page; pages without scripted interactions show INP as not measured (never as a pass).');
  }

  // ---------- load ----------
  const loadSec = [];
  // A smoke test checks that the setup works. With so few requests, the first request on each new connection (which
  // also pays for DNS, TCP and TLS) can be its slowest 5 %, so its response times only count when nothing else was tested.
  const smokeTimesInfo = web.length > 0 || load.some((LD) => LD.scenarios.some((s) => s.type !== 'smoke'));
  const NOT_COUNTED = ' — not counted (smoke test, see limitations)';
  // Apdex's T (the "satisfied" limit) is fixed when the test runs (apdexTMs in load-config), so the label shows the T used.
  const apdexName = (scs) => { const Ts = [...new Set(scs.map((x) => x.totals?.apdex?.T ?? x.plan?.apdexTMs).filter((x) => x != null))]; return `Apdex (T = ${(Ts.length ? Ts : [500]).join(' / ')} ms)`; };
  if (load.length && S.load.apdex?.T != null) limits.push(`perf-standards.json sets \`apdex.T\`, but Apdex is worked out while the load test runs, with \`apdexTMs\` from load-config.json (used: ${apdexName(load.flatMap((LD) => LD.scenarios)).replace(/^Apdex \(|\)$/g, '')}). To change T, set apdexTMs there and re-run the load test.`);
  for (const LD of load) {
    for (const n of LD.notes || []) limits.push(n);
    for (const sc of LD.scenarios) {
      const subject = sc.name;
      const peak = Math.max(sc.plan?.startVUs || 0, ...(sc.plan?.stages || []).map((s) => s.target));
      const hold = holdSec(sc);
      loadSec.push(`### ${sc.name} (${sc.type}) — ${sc.maxVUs != null && sc.maxVUs < peak ? `planned peak ${peak} users, reached ${sc.maxVUs}` : `up to ${peak} virtual user${peak === 1 ? '' : 's'}`}, ${sc.aborted ? `${sc.durationSec} s of the planned ${plannedSec(sc)} s` : hold && sc.durationSec - hold > 2 ? `${hold} s at full load (${sc.durationSec} s in total, including ramp-up and the last requests finishing)` : `${sc.durationSec} s`}${sc.aborted ? ' — ⛔ stopped early' : ''}${CAPACITY_TYPES.has(sc.type) ? ' — capacity test' : ''}`, '');
      const top = Object.entries(sc.errors || {}).sort((a, b2) => b2[1] - a[1])[0]?.[0];
      if (sc.aborted) limits.push(`**${sc.name}** was stopped early by the safety brake after ${sc.durationSec} s of the planned ${plannedSec(sc)} s: ${sc.abortReason}. That is itself a result — ${top === '429' ? 'the rate limiter refused this much traffic' : 'the system could not sustain this load'}.`);
      if (sc.generator?.saturated) limits.push(`${sc.name}: the load generator itself was overloaded (${sc.generator.eventLoopLagP95Ms != null ? `its own timers ran ${sc.generator.eventLoopLagP95Ms} ms late (95th percentile)` : `k6 skipped ${sc.generator.droppedIterations} planned iterations`}), so the server may be faster than measured. Re-run with fewer VUs or with k6.`);
      if (sc.type === 'smoke') limits.push(`${sc.name} is a smoke test (${peak} user${peak === 1 ? '' : 's'}) — it proves the script and endpoints work; it says little about capacity.`);
      const t = sc.totals;
      loadSec.push(`Engine: ${sc.engine} · ${t.requests} requests · ${t.rps} req/s · think time ${Array.isArray(sc.plan?.thinkTimeMs) ? sc.plan.thinkTimeMs.join('–') : sc.plan?.thinkTimeMs} ms${sc.mix?.length > 1 ? ` · traffic mix ${sc.mix.map((m) => `${m.name} ×${m.weight}`).join(', ')}` : ''}`, '');
      loadSec.push('| Measure | Value | Standard | Rating |', '|---|---|---|---|');
      for (const k of ['p95', 'p99', 'errorRate', 'apdex']) {
        const s0 = stdFor(S, 'load', k, null); const s = k === 'apdex' ? { ...s0, name: apdexName([sc]) } : s0; const v = k === 'errorRate' ? t.failedRate : k === 'apdex' ? t.apdex?.score : t[k];
        // A percentile needs enough requests to mean anything: p95 of 7 requests is just the slowest one.
        const few = MIN_N[k] && (t.requests || 0) < MIN_N[k]; const r = few ? 'na' : rate(v, s);
        const warmup = sc.type === 'smoke' && smokeTimesInfo && k !== 'errorRate' && (r === 'poor' || r === 'ni');
        add({ area: 'load', subject, scenario: sc, metric: k, value: v, std: s, rating: r, warmup }); glossary.add(k);
        loadSec.push(`| ${s.name} | ${fmt(v, s.unit)}${k === 'errorRate' && v != null && t.requests ? ` (${Math.round(v * t.requests)} of ${t.requests})` : ''}${k === 'apdex' && t.apdex ? ` (${t.apdex.score >= 0.94 ? 'Excellent' : t.apdex.score >= 0.85 ? 'Good' : t.apdex.score >= 0.7 ? 'Fair' : t.apdex.score >= 0.5 ? 'Poor' : 'Unacceptable'})` : ''} | ${stdText(s)} | ${ICON[r]}${few ? ` (only ${t.requests || 0} requests; a ${k} needs ${MIN_N[k]}+)` : ''}${warmup ? NOT_COUNTED : ''} |`);
      }
      loadSec.push(`| Median / max response | ${fmt(t.p50, 'ms')} / ${fmt(t.max, 'ms')} | — | — |`, t.okP95 != null && t.failedRate ? `| Successful requests only: median / p95 | ${fmt(t.okP50, 'ms')} / ${fmt(t.okP95, 'ms')} | — | — |` : null, '');
      if (sc.endpoints?.length) {
        loadSec.push('| Endpoint | Requests | p50 | p95 | p99 | Errors | p95 rating | Error rating |', '|---|---|---|---|---|---|---|---|');
        for (const e of sc.endpoints) {
          const sp = stdFor(S, 'load', 'p95', e.name), se = stdFor(S, 'load', 'errorRate', e.name);
          const rp = (e.requests ?? 0) < MIN_N.p95 ? 'na' : rate(e.p95, sp), re = rate(e.failedRate, se);
          const warmup = sc.type === 'smoke' && smokeTimesInfo && (rp === 'poor' || rp === 'ni');
          if (sc.endpoints.length > 1 || sp !== stdFor(S, 'load', 'p95', null) || se !== stdFor(S, 'load', 'errorRate', null)) { // one endpoint with the default standards = the scenario row; don't count it twice
            add({ area: 'load', subject, scenario: sc, endpoint: e, metric: 'p95', value: e.p95, std: sp, rating: rp, scope: 'endpoint', warmup });
            add({ area: 'load', subject, scenario: sc, endpoint: e, metric: 'errorRate', value: e.failedRate, std: se, rating: re, scope: 'endpoint' });
          }
          loadSec.push(`| ${e.name} | ${e.requests ?? '—'} | ${fmt(e.p50, 'ms')} | ${fmt(e.p95, 'ms')} | ${fmt(e.p99, 'ms')} | ${fmt(e.failedRate, '%')} | ${ICON[rp]}${warmup ? ' (not counted)' : ''} | ${ICON[re]} |`);
        }
        loadSec.push('');
      }
      if (Object.keys(sc.errors || {}).length) loadSec.push(`Errors by type: ${Object.entries(sc.errors).sort((a, b) => b[1] - a[1]).map(([k, v]) => `${k} × ${v}`).join(', ')}${sc.errorHint ? ` — ${sc.errorHint}` : ''}`, '');
      if (sc.rateLimit && Object.keys(sc.rateLimit).length) loadSec.push(`The rate limiter's answer (first 429): ${Object.entries(sc.rateLimit).map(([k, v]) => `\`${k}: ${v}\``).join(', ')}.`, '');
      // Throughput ceiling: with think time, N users should send about N ÷ (think + base response) requests per second.
      // Far fewer, while responses got much slower than at low load, means requests waited in a queue for a fixed capacity.
      const base = Math.min(...load.flatMap((x) => x.scenarios).filter((o) => o.totals?.p50 != null && (o.maxVUs || 0) <= Math.max(2, (sc.maxVUs || 0) / 5)).map((o) => o.totals.p50), sc.timeline?.[0]?.p95 ?? Infinity);
      const thinkS = (Array.isArray(sc.plan?.thinkTimeMs) ? (sc.plan.thinkTimeMs[0] + sc.plan.thinkTimeMs[1]) / 2 : sc.plan?.thinkTimeMs || 0) / 1000;
      const peakW = (sc.timeline || []).filter((w) => w.vus >= 0.9 * (sc.maxVUs || 0) && w.requests >= 10);
      const rpsAtPeak = peakW.length ? peakW.reduce((a, w) => a + w.rps, 0) / peakW.length : null;
      if (sc.endpoints?.length === 1 && Number.isFinite(base) && rpsAtPeak && sc.maxVUs >= 5) {
        const expected = sc.maxVUs / (thinkS + base / 1000);
        if (rpsAtPeak < 0.6 * expected && t.p50 > 3 * base) { sc._ceiling = { rps: Math.round(rpsAtPeak * 10) / 10, expected: Math.round(expected) }; loadSec.push(`**Throughput ceiling:** at ${sc.maxVUs} users the system handled only ~${sc._ceiling.rps} requests/s, while that many users would send about ${sc._ceiling.expected}/s if responses stayed as fast as at low load. Response times grew instead (median ${fmt(base, 'ms')} → ${fmt(t.p50, 'ms')}): requests wait in a queue for a fixed capacity, such as a single worker or a small pool (likely; confirm in the server).`, ''); }
      }
      if (sc.generator?.note && !sc.generator.saturated) limits.push(`${sc.name}: ${sc.generator.note}, so response times are slightly pessimistic.`);
      if (!t.requests) unmeasured.push(`${sc.name}: no requests completed`);
      if (sc.thresholds?.length) loadSec.push(`k6 thresholds: ${sc.thresholds.map((x) => `${x.ok ? '✅' : '❌'} ${x.metric} ${x.threshold}`).join(' · ')}`, '');
      if (sc.timeline?.length > 2) {
        const sp = stdFor(S, 'load', 'p95', null), se = stdFor(S, 'load', 'errorRate', null);
        const tl = sc.timeline.filter((b) => b.requests >= 10);
        // An endpoint's p95 in one 5-second window counts only with 20+ of its requests in that window: with fewer it is
        // simply its slowest request (often one that had to open a new connection). Older results have no per-endpoint
        // counts, so they are estimated from the traffic mix.
        const multi = sc.endpoints?.length > 1;
        const wSum = (sc.mix || []).reduce((a, m) => a + (m.weight || 1), 0);
        const epN = (b, ep) => (b.endpointsN ? b.endpointsN[ep] || 0 : wSum ? (b.requests * ((sc.mix.find((m) => m.name === ep) || {}).weight || 1)) / wSum : b.requests / (sc.endpoints?.length || 1));
        const epOver = (b) => (multi ? Object.entries(b.endpointsP95 || {}).filter(([ep, v]) => epN(b, ep) >= MIN_N.p95 && v > stdFor(S, 'load', 'p95', ep).good) : []);
        const epBad = (b) => epOver(b).map(([ep, v]) => `${ep} p95 ${fmt(v, 'ms')}`);
        const badKeys = (b) => [...(b.p95 > sp.good || b.failedRate > se.good ? ['*'] : []), ...epOver(b).map(([ep]) => ep)];
        const isBad = (b) => badKeys(b).length > 0;
        // A breach counts when it lasts two windows in a row (or is the last window, or is a spike): one noisy
        // 5-second window must not decide the capacity point.
        const sustained = (f) => tl.findIndex((b, i) => f(b) && (i === tl.length - 1 || f(tl[i + 1]) || sc.type === 'spike'));
        // The same breach (overall, or the same endpoint) in two windows in a row, or in the last window, or in a spike.
        let fi = tl.findIndex((b, i) => { const k = badKeys(b); return k.length > 0 && (i === tl.length - 1 || sc.type === 'spike' || badKeys(tl[i + 1]).some((x) => k.includes(x))); });
        const brief = fi < 0 && tl.some(isBad); if (brief) fi = tl.findIndex(isBad);
        const firstBad = fi >= 0 ? tl[fi] : null;
        const lastGood = firstBad && !brief ? [...tl].reverse().find((b) => b.tSec < firstBad.tSec && !isBad(b)) : null;
        const ei = sustained((b) => b.failedRate > se.poor); // the point where requests clearly start failing (not just slowing)
        sc._knee = firstBad ? { firstBad, lastGood, brief, firstErr: ei >= 0 ? tl[ei] : null } : null;
        if (firstBad && sc.endpoints?.length > 1) sc._knee.why = epBad(firstBad).join(', ');
        if (sc.type !== 'smoke') loadSec.push(() => (firstBad ? `**Capacity:** ${kneeText(sc._knee, sc.type)} (t = ${firstBad.tSec} s: p95 ${fmt(firstBad.p95, 'ms')}, errors ${fmt(firstBad.failedRate, '%')}${sc._knee.why ? `; ${sc._knee.why}` : ''}).` : `**Capacity:** every 5-second window stayed within the p95 and error standards${multi ? (tl.some((b) => sc.endpoints.some((e) => epN(b, e.name) >= MIN_N.p95))) ? ', overall and per endpoint' : ' overall (each endpoint had too few requests per window to be judged on its own)' : ''} (peak ${sc.maxVUs} users).`), '');
      }
      if (sc.timeline?.length) {
        const epCols = (sc.endpoints || []).length > 1 && (sc.endpoints || []).length <= 4 && sc.timeline.some((b) => b.endpointsP95) ? sc.endpoints.map((e) => e.name) : [];
        loadSec.push('<details><summary>Timeline (5-second windows)</summary>', '', `| t (s) | Users | Req/s | p95 (all) | Errors |${epCols.map((c) => ` p95 ${c} |`).join('')}`, `|---|---|---|---|---|${epCols.map(() => '---|').join('')}`, ...sc.timeline.map((b) => `| ${b.tSec}${b.tSec > sc.durationSec + 0.5 ? ' (partial)' : ''} | ${b.vus} | ${b.rps} | ${fmt(b.p95, 'ms')} | ${fmt(b.failedRate, '%')} |${epCols.map((c) => ` ${fmt(b.endpointsP95?.[c], 'ms')} |`).join('')}`), '', '</details>', '');
      }
    }
  }
  if (load.some((LD) => LD.scenarios.some((s) => s.runner === 'browser-connector'))) limits.push('Load was generated from the user\'s own computer through the browser tool, over that computer\'s network connection: its Wi-Fi/VPN path and limits are part of the numbers. Fine for small loads and smoke checks; use a dedicated load machine (k6) for capacity planning.');
  if (web.some((W) => W.runner === 'browser-connector')) limits.push('Pages were measured in the browser tool on the user\'s own computer (not a dedicated test machine): other work on that computer adds noise, so compare before/after runs from the same computer only.');
  if (load.some((LD) => /^(localhost|127\.|\[?::1)/.test(new URL(LD.target).hostname))) limits.push('The load generator ran on the **same machine** as the server (localhost), so both competed for CPU and memory; absolute numbers will differ on real hosting, but relative findings (which endpoint is slowest, where it starts to slow down or fail) still hold.');
  if (load.length) limits.push('Server-side resource use (CPU, memory, database load) was not measured by this test; check the application monitoring (APM) or hosting dashboards for the test window to explain any slowdowns or errors.');
  for (const W of web) if (W.profiles) limits.push(`Simulated conditions: ${Object.entries(W.profiles).map(([k, p]) => `**${k}** = ${p.latencyMs} ms latency, ${p.downKbps > 0 ? `${(p.downKbps / 1024).toFixed(1)} Mbps down` : 'unthrottled'}, ${p.cpuSlowdown}× CPU slowdown, ${p.viewport} screen`).join('; ')}. Chrome applies the latency as a minimum per request (a slow server hides it), so these are somewhat gentler than Lighthouse's simulated throttling.`);
  if (web.length) limits.push('Page-speed numbers are **lab measurements** (one simulated user on the test computer with simulated network/CPU). Google defines the Core Web Vitals standards on **field data** from real users at the 75th percentile, so treat these as a strong early signal, not as the official field score.');

  // Stress / spike / breakpoint tests are meant to push past normal load: their ratings describe capacity and are shown,
  // but they only count toward the verdict when nothing else measured real load (no page-speed audit and no constant /
  // average-load / soak scenario; a smoke test does not count as real load).
  const CAPACITY = new Set(['stress', 'spike', 'breakpoint']);
  const hasNormalLoad = load.some((LD) => LD.scenarios.some((s) => s.type !== 'smoke' && !CAPACITY.has(s.type)));
  const capacityDecides = !web.length && !hasNormalLoad && load.some((LD) => LD.scenarios.some((s) => CAPACITY.has(s.type)));
  for (const c of checks) if (c.area === 'load' && CAPACITY.has(c.scenario.type) && !capacityDecides) c.info = true;
  // A passing smoke test proves the setup works, not that performance is good: when there is more to rate, its good
  // ratings are not added to the "good" count (a failing smoke test still counts).
  if (web.length || load.some((LD) => LD.scenarios.some((s) => s.type !== 'smoke'))) for (const c of checks) if (c.area === 'load' && c.scenario.type === 'smoke' && (c.rating === 'good' || c.rating === 'na')) c.uncounted = true;
  const warm = [...new Set(checks.filter((c) => c.warmup).map((c) => c.scenario))];
  if (warm.length) limits.push(`${warm.map((x) => `**${x.name}**`).join(', ')}: the smoke test's response times are shown but **not counted in the verdict**. With only ${warm.map((x) => x.totals.requests).join(' / ')} requests, the first request on each new connection, which also pays for setting the connection up (DNS, TCP and TLS take several network round trips), can be its slowest 5 %. ${load.some((LD) => LD.scenarios.some((x) => x.type !== 'smoke')) ? 'The larger load test measures response times with far more requests.' : "To judge the API's speed, add a constant or average-load test."} Its error rate still counts.`);
  if (checks.some((c) => c.info)) limits.push(`Stress / spike / breakpoint results are shown for capacity planning but are **not counted in the verdict**: those tests deliberately push past normal load. The verdict uses ${[web.length ? 'the page-speed checks' : null, hasNormalLoad ? 'the normal-load scenarios' : null].filter(Boolean).join(' and ')}.`);

  // Capacity: the ramping test with the finest steps gives the estimate; coarser ramps that were over standard from
  // their first window then point to it ("pinned"). Worked out before the findings so both say the same thing.
  const knees = load.flatMap((LD) => LD.scenarios.filter((s) => s._knee && !s._knee.brief && s.type !== 'smoke').map((s) => s._knee));
  const rampKnees = load.flatMap((LD) => LD.scenarios.filter((s) => s._knee && !s._knee.brief && ramping(s)).map((s) => s._knee));
  const best = rampKnees.filter((k) => k.lastGood).sort((a, b) => (a.firstBad.vus - a.lastGood.vus) - (b.firstBad.vus - b.lastGood.vus))[0];
  if (best) for (const k of rampKnees) if (!k.lastGood) k.pinned = true;

  // ---------- findings ----------
  const bad = checks.filter((c) => (c.rating === 'poor' || c.rating === 'ni') && !c.warmup);
  const groups = new Map();
  const scenarioBad = new Set(bad.filter((c) => c.area === 'load' && c.scope !== 'endpoint').map((c) => c.subject));
  for (const c of bad) {
    if (c.area === 'load' && c.scope === 'endpoint' && scenarioBad.has(c.subject)) continue; // folded into the scenario finding as evidence
    const key = c.area === 'web' ? `web|${c.page.name}|${c.metric}|${c.action || ''}` : c.scope === 'endpoint' ? `ep|${c.endpoint.name}|${c.subject}` : `load|${c.subject}`;
    if (!groups.has(key)) groups.set(key, []);
    groups.get(key).push(c);
  }
  const excess = (c) => (c.value == null || !c.std.poor ? 0 : c.std.higherIsBetter ? c.std.poor / Math.max(c.value, 1e-9) : c.value / c.std.poor);
  const gx = (g) => Math.max(...g.map(excess));
  const sorted = [...groups.values()].sort((a, b) => (a[0].info ? 1 : 0) - (b[0].info ? 1 : 0) || Math.min(...a.map((c) => SEV[c.rating])) - Math.min(...b.map((c) => SEV[c.rating])) || gx(b) - gx(a));
  sorted.forEach((g, i) => {
    const c0 = g[0]; const worst = g.some((c) => c.rating === 'poor') ? 'poor' : 'ni';
    const id = `PERF-${String(i + 1).padStart(2, '0')}`;
    const what = c0.area === 'web' ? `${g.map((c) => `${fmt(c.value, c.std.unit)} on ${c.page.profile} (${ICON[c.rating]})`).join(', ')} — standard ${stdText(c0.std)} (${c0.std.source})` : g.map((c) => `${c.std.name} **${fmt(c.value, c.std.unit)}** ${ICON[c.rating]} (standard ${stdText(c.std)})`).join('; ');
    const subj = c0.area === 'web' ? `${c0.page.name} page` : c0.scope === 'endpoint' ? `${c0.endpoint.name} in “${c0.subject}”` : `“${c0.subject}” scenario`;
    const title = (c0.info ? 'Capacity limit — ' : '') + (c0.area === 'load' ? `${subj}: ${[...new Set(g.map((c) => c.std.name.replace(/ \(.*\)/, '')))].join(', ')} outside standard` : `${subj}: ${c0.metric === 'action' ? `“${c0.action}” takes too long` : c0.metric === 'httpStatus' ? `the page answered an error (HTTP ${c0.value})` : `${c0.std.name} ${c0.std.higherIsBetter ? 'too low' : 'too high'}`}`);
    const ev = [];
    if (c0.area === 'web') {
      const p = [...g].sort((a, b2) => SEV[a.rating] - SEV[b2.rating] || excess(b2) - excess(a))[0].page;
      const fonts = (p.resources?.largest || []).filter((x) => /font/i.test(x.type || '') || /\.(woff2?|ttf|otf)(\?|$)/i.test(x.url));
      if (c0.metric === 'LCP' && !p.lcpUrl && fonts.length) ev.push(`web font(s) the text may wait for: ${fonts.map((x) => `${short(x.url)} (${bytes(x.bytes)}${x.ms ? `, ${fmt(x.ms, 'ms')} from request to last byte` : ''})`).join(', ')}`);
      if (c0.metric === 'TTFB') { const others = checks.filter((c) => c.area === 'web' && c.metric === 'TTFB' && c.page.profile === p.profile && c.page.name !== p.name && c.value != null); if (others.length) ev.push(`other pages on the same profile: ${others.map((c) => `${c.page.name} ${fmt(c.value, 'ms')}`).join(', ')} — so the delay is specific to this page's server work`); }
      if (c0.metric === 'LCP' && p.lcpElement) ev.push(`main content element is \`${p.lcpElement}\`${p.lcpUrl ? ` loaded from ${p.lcpUrl}` : ''}; TTFB p75 ${fmt(pct(p.metrics.TTFB, 0.75), 'ms')}`);
      if (c0.metric === 'CLS' && p.clsTopSource) ev.push(`the element that moved most: \`${p.clsTopSource}\``);
      if ((c0.metric === 'TBT' || c0.metric === 'FCP') && p.longTasks) ev.push(`${p.longTasks.count} long task(s), longest ${p.longTasks.longestMs} ms`);
      if (c0.metric === 'TBT' && p.heavyScriptsLoad?.length) ev.push(`scripts blocking the page after first paint (these make up TBT): ${p.heavyScriptsLoad.slice(0, 3).map((x) => `${x.script} (${x.ms} ms)`).join(', ')}`);
      if ((c0.metric === 'FCP' || c0.metric === 'LCP') && p.heavyScriptsBeforePaint?.length) ev.push(`scripts that ran before first paint (they delay FCP, not TBT): ${p.heavyScriptsBeforePaint.slice(0, 3).map((x) => `${x.script} (${x.ms} ms)`).join(', ')}`);
      if ((c0.metric === 'FCP' || c0.metric === 'LCP') && p.renderBlocking?.length) ev.push(`render-blocking files: ${p.renderBlocking.map((x) => short(x.url)).join(', ')}`);
      if ((c0.metric === 'INP' || c0.metric === 'action') && p.heavyScriptsInteraction?.length) ev.push(`script running during the click: ${p.heavyScriptsInteraction.slice(0, 2).map((x) => `${x.script} (${x.ms} ms)`).join(', ')}`);
      if ((c0.metric === 'INP' || c0.metric === 'action') && Object.keys(p.afterShots || {}).length) ev.push(`after-click screenshot: ${Object.values(p.afterShots).map((f) => `[${f}](${f})`).join(', ')}`);
      if ((c0.metric === 'CLS' || c0.metric === 'LCP') && p.filmstrip?.length) ev.push('see the loading filmstrip in section 3');
      if ((c0.metric === 'INP' || c0.metric === 'action') && p.worstInteraction) ev.push(`slowest interaction: ${ixText(p)} before the screen updated`);
      if ((c0.metric === 'pageWeight' || c0.metric === 'LCP') && p.resources?.largest?.length) { const lf = p.resources.largest.filter((x) => c0.metric !== 'LCP' || !fonts.includes(x)).slice(0, 3); if (lf.length) ev.push(`largest files: ${lf.map((x) => `${short(x.url)} (${bytes(x.bytes)}${x.ms ? `, ${fmt(x.ms, 'ms')} from request to last byte` : ''})`).join('; ')}`); }
      if (p.screenshot) ev.push(`screenshot: [${p.screenshot}](${p.screenshot})`);
      if (p.lighthouse?.html) ev.push(`Lighthouse: [${p.lighthouse.html}](${p.lighthouse.html})`);
    } else {
      const sc = c0.scenario;
      if (c0.scope !== 'endpoint' && sc.endpoints?.length) { const badEp = checks.filter((c) => c.scope === 'endpoint' && c.subject === c0.subject && (c.rating === 'poor' || c.rating === 'ni') && !c.warmup).map((c) => c.endpoint.name); const eps = [...sc.endpoints].sort((a, b) => (b.p95 || 0) - (a.p95 || 0)); ev.push(eps.length === 1 ? `endpoint: ${eps[0].name} (p95 ${fmt(eps[0].p95, 'ms')}, errors ${fmt(eps[0].failedRate, '%')})` : `endpoints outside standard: ${[...new Set(badEp)].join(', ') || 'none individually'}; slowest: ${eps[0].name} (p95 ${fmt(eps[0].p95, 'ms')}, errors ${fmt(eps[0].failedRate, '%')})${eps.length > 1 ? `; fastest: ${eps.at(-1).name} (p95 ${fmt(eps.at(-1).p95, 'ms')})` : ''}`); }
      if (sc._knee && sc.type !== 'smoke') ev.push(kneeText(sc._knee, sc.type));
      if (sc._ceiling) ev.push(`throughput levelled off at ~${sc._ceiling.rps} requests/s (about ${sc._ceiling.expected}/s expected without queueing): requests queue for a fixed capacity`);
      if (Object.keys(sc.errors || {}).length && g.some((c) => c.metric === 'errorRate' || c.metric === 'apdex')) ev.push(`errors: ${Object.entries(sc.errors).map(([k, v]) => `${k} × ${v}`).join(', ')}`);
      if (sc.aborted) ev.push(`test stopped early: ${sc.abortReason}`);
    }
    const driver = c0.area === 'load' ? [...g].filter((c) => c.metric !== 'apdex').sort((a, b) => SEV[a.rating] - SEV[b.rating] || excess(b) - excess(a))[0] || c0 : c0;
    const hintKey = driver.metric === 'LCP' && driver.page && !driver.page.lcpUrl ? 'LCPtext' : driver.metric;
    let [cause, fix] = HINTS[hintKey] || ['', ''];
    if (c0.area === 'load' && ['errorRate', 'apdex'].includes(driver.metric) && c0.scenario.errorHint) {
      cause = c0.scenario.errorHint;
      const top = Object.entries(c0.scenario.errors || {}).sort((a, b2) => b2[1] - a[1])[0]?.[0];
      if (top === '429') fix = 'Agree the expected traffic with the team: if real users hit this limit, raise it or make it per user. To load test the app behind it, ask for an allowlisted test path. Never bypass the limiter.';
      else if (/^40[13]$/.test(top)) fix = 'Fix the credentials or session the test uses (token, header name, expiry) and re-run; these numbers say nothing about speed yet.';
    }
    findings.push([`### ${id} ${worst === 'poor' ? '❌' : '⚠️'} ${title}`, '', `- **What we measured:** ${what}`, ev.length ? `- **Evidence:** ${ev.join('; ')}` : null, `- **What usually causes this:** ${cause}`, `- **What to check / fix:** ${fix}`, ''].filter((x) => x != null).join('\n'));
  });

  // ---------- verdict + summary ----------
  const counted = checks.filter((c) => !c.info && !c.uncounted && !c.warmup);
  const count = (r) => counted.filter((c) => c.rating === r).length;
  const infoBad = checks.filter((c) => c.info && (c.rating === 'poor' || c.rating === 'ni')).length;
  const rated = counted.filter((c) => c.rating !== 'na' && c.rating !== 'skip').length;
  // Never call a run PASSED (or WARNING) when part of it could not be measured.
  const verdict = !rated ? 'BLOCKED' : count('poor') ? 'FAILED' : unmeasured.length ? 'INCOMPLETE' : count('ni') ? 'WARNING' : 'PASSED';
  const vIcon = { PASSED: '✅', WARNING: '⚠️', FAILED: '❌', BLOCKED: '⛔', INCOMPLETE: '⛔' }[verdict];
  for (const u of unmeasured) limits.unshift(`**Not measured:** ${u}`);
  const now = new Date(); const off = -now.getTimezoneOffset(); const tz = `UTC${off >= 0 ? '+' : '-'}${String(Math.floor(Math.abs(off) / 60)).padStart(2, '0')}:${String(Math.abs(off) % 60).padStart(2, '0')}`;
  const day = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;
  const summary = [];
  summary.push(`**${vIcon} ${verdict}** — ${count('poor')} check(s) poor, ${count('ni')} need improvement, ${count('good')} good${count('na') ? `, ${count('na')} not measured` : ''}${infoBad ? ` (plus ${infoBad} capacity-test check(s) over standard, shown for information)` : ''}${checks.some((c) => c.warmup) ? '; a smoke test only checks that the setup works, so only its errors can change the verdict' : checks.some((c) => c.uncounted) ? '; a passing smoke test only proves the setup works, so its checks are not counted' : ''}.`);
  if (capacityDecides) summary.push('No normal-load test (constant, average-load or soak) was run, so the **capacity tests decide the verdict**. They push the system until it breaks, so going over the standard near the top of the ramp is expected: read the capacity estimate below, and add a constant test at the expected number of users to judge normal traffic.');
  if (unmeasured.length) summary.push(`**${unmeasured.length} part(s) of the test could not be measured** (${unmeasured.map((u) => u.split(':')[0]).join(', ')}) — see “Not measured & limitations”. ${verdict === 'BLOCKED' ? 'Nothing could be rated.' : verdict === 'INCOMPLETE' ? 'What was measured met the standards, but the run is incomplete.' : ''}`);
  const worstWeb = checks.filter((c) => c.area === 'web' && c.metric === 'LCP' && c.value != null && !(c.page.status >= 400)).sort((a, b) => b.value - a.value)[0];
  if (worstWeb) summary.push(`Slowest page to show its main content: **${worstWeb.subject}** — ${fmt(worstWeb.value, 'ms')} (standard ≤ ${fmt(worstWeb.std.good, 'ms')}).`);
  const seen = new Set();
  for (const c of checks.filter((x) => x.area === 'web' && x.rating === 'poor' && ['CLS', 'INP', 'TBT', 'action', 'TTFB'].includes(x.metric)).sort((a, b) => b.value - a.value)) { const k = `${c.page.name}|${c.metric}|${c.action || ''}`; if (seen.has(k) || seen.size >= 3) continue; seen.add(k); summary.push(`**${c.page.name}** page — ${c.metric === 'action' ? `“${c.action}” takes ${fmt(c.value, 'ms')}` : `${c.std.plain}: ${fmt(c.value, c.std.unit)}`} (poor; standard ${stdText(c.std)}).`); }
  for (const LD of load) for (const sc of LD.scenarios.filter((s) => s.type !== 'smoke')) { const scBad = checks.some((c) => c.area === 'load' && c.scope !== 'endpoint' && c.subject === sc.name && (c.rating === 'poor' || c.rating === 'ni')); const epOver = checks.filter((c) => c.area === 'load' && c.scope === 'endpoint' && c.subject === sc.name && (c.rating === 'poor' || c.rating === 'ni')).map((c) => `${c.endpoint.name} ${c.std.name.replace(/ \(.*\)/, '').replace(' response time', '')} ${fmt(c.value, c.std.unit)}`); const lower = scBad && sc._knee && !sc._knee.lastGood && !sc._knee.brief && !ramping(sc) ? load.flatMap((x) => x.scenarios).filter((o) => o !== sc && o.type !== 'smoke' && (o.maxVUs || 0) < (sc.maxVUs || 0) && !(o._knee && !o._knee.brief) && !checks.some((c) => c.area === 'load' && c.subject === o.name && (c.rating === 'poor' || c.rating === 'ni'))).sort((a, b2) => b2.maxVUs - a.maxVUs)[0] : null; const te = Object.entries(sc.errors || {}).sort((a, b2) => b2[1] - a[1])[0]; const nErr = Object.values(sc.errors || {}).reduce((a, x) => a + x, 0); const errLbl = te && sc.totals.failedRate ? ` (${te[1] === nErr ? 'all' : 'mostly'} ${te[0] === '429' ? 'HTTP 429 from a rate limiter' : /^40[13]$/.test(te[0]) ? `HTTP ${te[0]}: requests rejected as not logged in / not allowed` : /^5\d\d$|5xx/.test(te[0]) ? `HTTP ${te[0]} server errors` : /timeout/.test(te[0]) ? 'timeouts' : te[0]})` : ''; summary.push(`Under **${sc.name}** (up to ${sc.maxVUs} users) 95 % of requests finished within ${fmt(sc.totals.p95, 'ms')} and ${fmt(sc.totals.failedRate, '%')} failed${errLbl}${scBad && sc._knee ? `; it ${kneeText(sc._knee, sc.type)}` : scBad ? '' : epOver.length ? ` — within standard overall, but not every endpoint: ${epOver.join(', ')}` : ' — within standard'}${lower ? ` (${lower.name} with ${lower.maxVUs} users stayed within standard, so the limit lies between ${lower.maxVUs} and ${sc.maxVUs} users)` : ''}${sc.aborted ? ' — the test was stopped early by the safety brake' : ''}.`); }
  if (rampKnees.length > 1) { if (best) summary.push(`**Capacity estimate** (from the ramping test with the finest steps): ${kneeText(best)}${best.why ? ` (first over: ${best.why})` : ''}.`); }
  const normal = load.flatMap((LD) => LD.scenarios.filter((s) => !CAPACITY_TYPES.has(s.type) && s.type !== 'smoke'));
  const kn = rampKnees.length ? rampKnees : knees;
  const firstBreach = best ? best.firstBad.vus : kn.length ? Math.min(...kn.map((k) => k.firstBad.vus)) : null;
  if (normal.length && firstBreach && load.some((LD) => LD.scenarios.some((s) => CAPACITY_TYPES.has(s.type)))) { const n0 = Math.max(...normal.map((s) => s.maxVUs || 0)); const over = normal.filter((s) => checks.some((c) => c.area === 'load' && c.subject === s.name && (c.rating === 'poor' || c.rating === 'ni'))); if (n0) summary.push(over.length ? `**Headroom:** little or none — the ${over.map((s) => `${s.maxVUs}-user “${s.name}”`).join(', ')} normal-load test was already over the standard; the ramp first went over at ~${firstBreach} users.` : `**Headroom:** the standard was first exceeded at ~${firstBreach} users, ${(firstBreach / n0).toFixed(1)}× the ${n0}-user normal load tested.`); }
  if (findings.length) summary.push(`Top issues to look at first: ${findings.filter((f) => !f.includes('Capacity limit —')).concat(findings.filter((f) => f.includes('Capacity limit —'))).slice(0, 3).map((f) => f.split('\n')[0].replace(/^### /, '') + (f.includes('Capacity limit —') ? ' (capacity test, not counted in the verdict)' : '')).join(' · ')}.`);
  if (!findings.length && rated) summary.push(checks.some((c) => c.warmup) ? 'Everything that counts toward the verdict met the standards. The smoke test\'s response times were over the standard, but they are not counted (see “Not measured & limitations”).' : 'Everything measured met the standards.');

  const tools = [...new Set(R.flatMap((r) => (r.kind === 'web' ? [r.tool] : r.scenarios.map((s) => s.engine))))].filter(Boolean).join('; ');
  const scope = [];
  for (const W of web) scope.push(`Page speed: ${[...new Set(W.pages.map((p) => p.name))].length} page(s) × ${[...new Set(W.pages.map((p) => p.profile))].join(', ')} × ${W.pages[0]?.runs} runs`);
  for (const LD of load) scope.push(`Load: ${LD.scenarios.map((s) => { const h = holdSec(s); return `${s.name} (${s.maxVUs} VU${s.maxVUs === 1 ? '' : 's'}, ${s.aborted ? `stopped after ${s.durationSec} s of ${plannedSec(s)} s` : h && s.durationSec - h > 2 ? `${h} s at full load, ${s.durationSec} s in total` : `${s.durationSec} s`})`; }).join(', ')}`);

  L.push(`# Performance Test Report — ${label}`, '', '| Item | Value |', '|---|---|',
    `| **Verdict** | ${vIcon} **${verdict}** — ${count('poor')} poor · ${count('ni')} need improvement · ${count('good')} good${count('na') ? ` · ${count('na')} not measured` : ''}${infoBad ? ` (capacity tests: ${infoBad} over standard, not counted)` : ''} |`,
    `| Target | ${[...new Set(R.map((r) => r.target))].join(', ')} |`, `| Environment | ${[...new Set(R.map((r) => r.environment))].join(', ')} |`,
    `| Date | ${day} ${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')} (${tz}) |`, `| Scope | ${scope.join('<br>')} |`, `| Tools | ${tools} |`, '| Run by | AI agent (automated run) — for QA review |', '',
    '## 1. Summary', '', ...summary.map((s) => `- ${s}`), '');
  const assumptions = [...new Set(R.flatMap((r) => r.assumptions || []))];
  if (assumptions.length) L.push('**Assumptions the agent made** (no one was available to ask):', '', ...assumptions.map((a) => `- ${a}`), '');
  L.push('## 2. Standards applied', '', 'Each result is compared with the standard below: **✅ Good** = meets the target · **⚠️ Needs improvement** = between good and poor · **❌ Poor** = worse than the poor limit · **➖ Not measured** = no data (never counted as a pass).', '');
  L.push(web.length ? '- Page speed is rated on the **75th percentile (p75)** of the runs — the percentile Google uses for Core Web Vitals.' : null, load.length ? '- Load results are rated on **p95 / p99** response time, error rate and Apdex over the whole scenario.' : null, '');
  L.push('| Metric | What it means | Good | Poor | Source |', '|---|---|---|---|---|');
  const used = new Set(checks.map((c) => `${c.area}.${c.metric}`));
  for (const kind of ['web', 'load']) for (const [k, s] of Object.entries(S[kind])) if (isObj(s) && s.good != null && used.has(`${kind}.${k}`)) L.push(`| ${kind === 'load' && k === 'apdex' ? apdexName(load.flatMap((LD) => LD.scenarios)) : s.name} | ${s.plain} | ${s.higherIsBetter ? '≥' : '≤'} ${fmt(s.good, s.unit)} | ${s.higherIsBetter ? '<' : '>'} ${fmt(s.poor, s.unit)} | ${s.source}${overridden.has(`${kind}.${k}`) ? ' **(project override)**' : ''} |`);
  const scoped = [...Object.entries(S.web.pages || {}).map(([p, o]) => [`page “${p}”`, 'web', o]), ...Object.entries(S.load.endpoints || {}).map(([e, o]) => [`endpoint “${e}”`, 'load', o])];
  if (scoped.length) L.push('', 'Scoped project overrides (these replace the row above for that page/endpoint only):', '', ...scoped.flatMap(([who, kind, o]) => Object.entries(o).map(([m, v]) => `- ${who} — ${S[kind][m]?.name || m}: ${stdText({ ...S[kind][m], ...v })}`)));
  L.push('');
  let n = 3;
  if (web.length) L.push(`## ${n++}. Page speed results — one user (time behaviour)`, '', ...webSec);
  if (load.length) L.push(`## ${n++}. Load results — many users`, '', ...loadSec.map((x) => (typeof x === 'function' ? x() : x)));
  const OBS_WHY = { 'JavaScript errors in the console': 'it can break features for real users', 'Requests that failed while loading': 'something the page asked for is missing or broken' };
  const obsText = (d) => { if (typeof d === 'string') return d; const m = [...obsUrls.get(d.key)]; const cut = obsCut.has(d.key); const same = m.length > 1 && m.every(([, l]) => l === m[0][1]); return `${d.page}${same ? ` (all ${m[0][1]})` : ''}: ${m.slice(0, 6).map(([u, l]) => (same ? u : `${u} (${l})`)).join(', ')}${m.length > 6 ? `, and ${cut ? 'at least ' : ''}${m.length - 6} more` : cut ? ', and possibly more' : ''}`; };
  const obsLines = [...obs.entries()].map(([t, d], i) => `### OBS-${String(i + 1).padStart(2, '0')} ℹ️ ${t}\n\n- ${[...new Set(d.map(obsText))].join('\n- ')}\n- _Not rated against a standard — worth a look because ${OBS_WHY[t] || 'it slows real users down, especially on repeat visits and slow networks'}._\n`);
  L.push(`## ${n++}. Findings (worst first)`, '', ...(findings.length ? findings : ['No rated findings — every measured check met its standard.', '']), ...obsLines);
  L.push(`## ${n++}. Analyst notes`, '', '_ANALYST-NOTES-PLACEHOLDER: the agent replaces this line with a short paragraph or up to 5 bullets: which findings matter most for users, likely root causes it confirmed from the evidence, and what to re-test after a fix._', '');
  L.push(`## ${n++}. Not measured & limitations`, '', ...[...new Set(limits)].map((x) => `- ${x}`), '');
  const ranIn = [...web, ...load.flatMap((LD) => LD.scenarios)];
  const cwds = [...new Set([...ranIn.map((x) => x.cwd), ranIn.some((x) => x.cwd === process.cwd() || x.cwdLocal === process.cwd()) ? null : process.cwd()].filter(Boolean))];
  const cfgFiles = [...new Set(R.flatMap((r) => ['web-config.json', 'load-config.json'].map((c) => path.join(path.dirname(path.resolve(r.file)), c))))].filter((f) => fs.existsSync(f));
  const envPairs = new Map(load.flatMap((LD) => [LD.config?.headers, ...(LD.config?.requests || []).map((q) => q.headers)].flatMap((h) => Object.entries(h || {}))).filter(([, v]) => typeof v === 'string' && v.startsWith('env:')).map(([k, v]) => [v.slice(4), k]));
  const envVars = [...envPairs.keys()];
  const states = [...new Set(web.map((W) => W.config?.storageState).filter((s) => typeof s === 'string'))];
  L.push(`## ${n++}. Files & how to re-run`, '', ...R.map((r) => `- Raw results: [${rel(r.file)}](${rel(r.file)})`), ...cfgFiles.map((f) => `- Test config: [${rel(f)}](${rel(f)})`), '', `Commands (run from \`${cwds[0]}\`${cwds.length > 1 ? `; some ran from ${cwds.slice(1).map((c) => `\`${c}\``).join(', ')}` : ''}):`, '', FENCE + 'bash', envVars.length ? `# set first (secrets, never stored in these files): ${envVars.map((v) => `export ${v}="<full ${envPairs.get(v)} header value>"`).join('; ')}` : null, states.length ? `# needs the saved login ${states.join(', ')} — recreate it first if it has expired (web-performance-audit, Step 3)` : null, ...web.map((W) => W.command).filter(Boolean), ...load.flatMap((LD) => LD.scenarios.map((s) => s.command)).filter(Boolean), `node ${path.relative(process.cwd(), process.argv[1])} ${argv.map((a) => (/\s/.test(a) ? JSON.stringify(a) : a)).join(' ')}`, FENCE, '');
  const G = {
    TTFB: 'Time to First Byte — time until the server starts sending the page.', FCP: 'First Contentful Paint — first moment anything (text/image) appears.', LCP: 'Largest Contentful Paint — moment the biggest piece of content appears; the best simple “page is ready” signal.', CLS: 'Cumulative Layout Shift — score for how much content jumps while loading. 0 is perfect.', TBT: 'Total Blocking Time — how long JavaScript kept the page from responding: the part of each long task beyond 50 ms, added up (a 400 ms task adds 350 ms).', INP: 'Interaction to Next Paint — delay between a click/keypress and the screen updating.',
    p95: `p95 / p99 — percentiles: “95 % (or 99 %) of requests were at least this fast”.${web.length ? ' For pages, p75 means 3 out of 4 runs were at least this fast.' : ''}`, errorRate: 'Error rate — failed requests (5xx, timeouts, unexpected status) divided by all requests.', apdex: 'Apdex — 0–1 satisfaction score: requests ≤ T count as satisfied, ≤ 4T as tolerating (half), slower or failed as frustrated.',
  };
  const gl = [...glossary].map((k) => (k === 'p99' ? null : G[k])).filter(Boolean);
  const allSc = load.flatMap((LD) => LD.scenarios); const errKeys = allSc.flatMap((s) => Object.keys(s.errors || {}));
  const types = [...new Set(allSc.map((s) => s.type))];
  const TYPE = { smoke: 'smoke = tiny sanity check', constant: 'constant = a fixed number of users for a fixed time', 'average-load': 'average-load = normal expected traffic, with ramps', stress: 'stress = above-normal traffic', spike: 'spike = a sudden burst', breakpoint: 'breakpoint = ramp up until it breaks', soak: 'soak = a long run to find leaks' };
  if (load.length) gl.push('Virtual user (VU) — one simulated user repeatedly sending requests with short pauses (“think time”).', `Test types used — ${types.map((t) => TYPE[t] || t).join('; ')}.`, 'Req/s — requests per second the system handled (throughput).', 'SLO — service-level objective: a target a team commits to, such as “p95 under 500 ms”.');
  if (errKeys.includes('429')) gl.push('HTTP 429 / rate limiter — a guard that rejects requests above a set rate with “429 Too Many Requests”, often with a Retry-After header saying when to try again.');
  if (errKeys.some((k) => /^5\d\d$|5xx/.test(k)) || web.some((W) => W.pages.some((p) => p.status >= 500))) gl.push('HTTP 5xx — the server failed to handle the request (500 = internal error, 503 = overloaded or unavailable).');
  if (allSc.some((s) => s.aborted)) gl.push('Safety brake — the load tool stops a test early when errors or response times cross a limit, so a struggling system is not pushed further.');
  const pages = web.flatMap((W) => W.pages);
  if (web.length) gl.push('p75 / median — p75: 3 out of 4 runs were at least this fast (Google rates Core Web Vitals on p75); median: the middle run.');
  if (pages.some((p) => p.renderBlocking?.length)) gl.push('Render-blocking file — a CSS/JS file in the page head the browser must download before it can draw anything.');
  if (pages.some((p) => p.longTasks?.count)) gl.push('Long task — a piece of JavaScript running over 50 ms; the page cannot react to the user meanwhile.');
  if (obs.has(CACHE_OBS) || obs.has('Repeat visits download almost everything again')) gl.push('Cache headers — instructions telling the browser how long it may reuse a file; without them repeat visits download everything again.');
  if (pages.some((p) => p.filmstrip?.length || p.repeatView?.metrics)) gl.push('Filmstrip / repeat visit — frames of the page while it loads; a second visit, when the browser may reuse files it cached on the first one.');
  if (glossary.has('INP') && pages.some((p) => Object.keys(p.actions || {}).length)) gl.push('Action time vs INP — action time runs from the click until the expected result is visible, including any network calls, so it can be longer than INP, which only covers the delay until the screen first updates.');
  if (web.length) { const used = [...new Set(pages.map((p) => p.profile))]; const PD = { desktop: 'desktop = fast network, normal CPU', 'mobile-4g': 'mobile-4g = slow 4G network and a 4× slower CPU, like a mid-range phone (the same numbers as Lighthouse’s default mobile test, applied as real throttling, which is somewhat gentler than Lighthouse’s simulation)', 'slow-3g': 'slow-3g = a very slow mobile connection, for checking loading states', none: 'none = no throttling, the raw speed of the test machine' }; gl.push(`Profiles — ${used.map((u) => PD[u] || u).join('; ')}.`, 'Lab vs field data — lab = measured by a test on one machine; field = collected from real users’ browsers.'); }
  L.push('## Glossary', '', ...gl.map((x) => `- ${x}`), '');

  fs.mkdirSync(outDir, { recursive: true });
  const file = path.join(outDir, `${slug(label)}_${verdict}_Performance-Report_${day}.md`);
  // A rebuild can change the verdict and so the file name: mark the older report as outdated (renamed, never deleted).
  const superseded = fs.existsSync(outDir) ? fs.readdirSync(outDir).filter((n) => n.startsWith(`${slug(label)}_`) && n.endsWith(`_Performance-Report_${day}.md`) && path.join(outDir, n) !== file) : [];
  for (const n of superseded) fs.renameSync(path.join(outDir, n), path.join(outDir, n.replace(/\.md$/, '.superseded.md')));
  // Long table rows and the filmstrip's HTML table are intentional; this line keeps a default markdownlint run clean.
  L.push('<!-- markdownlint-configure-file { "MD013": false, "MD033": false, "MD049": false, "MD050": false } -->');
  fs.writeFileSync(file, `${tidy(L.filter((x) => x != null).join('\n')).replace(/\n{3,}/g, '\n\n').replace(/\s+$/, '')}\n`);
  console.log(JSON.stringify({ report: file, verdict, poor: count('poor'), needsImprovement: count('ni'), good: count('good'), notMeasured: count('na'), findings: findings.length }, null, 2));
  if (superseded.length) console.log(`Older report(s) with another verdict renamed to *.superseded.md: ${superseded.join(', ')}`);
  console.log('Next: replace the ANALYST-NOTES-PLACEHOLDER line with your analysis. Do not change any measured numbers or ratings.');
}
main();
````