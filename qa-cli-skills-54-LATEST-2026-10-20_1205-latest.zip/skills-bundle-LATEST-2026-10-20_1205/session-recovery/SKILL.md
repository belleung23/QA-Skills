---
name: session-recovery
description: "Handle session expiry, SSO redirect loops, and re-login during active QA testing on First Recon AI environments (Dev primary, or Production for [Pro]/[Prod] tickets). Use this skill whenever a session expires mid-test, the page redirects to a Keycloak error (e.g., 'psfni-guardrails-dev — Oops!, something went wrong'), a page becomes unresponsive due to auth timeout, or you need to recover and resume testing after being logged out. Triggers on: session expired, logged out unexpectedly, re-login, session timeout, auth expired, need to log back in, SSO redirect loop, guardrails-dev error, couldn't find your session, login flow stuck."
---

# Session Recovery

This skill handles recovering from session expiry, SSO redirect loops, and auth failures that happen **during test execution** (after pre-flight has already completed). The goal is to resume testing from exactly where you left off — never skip a test case because of an auth problem.

## Shared References

Before proceeding, read:
- `shared-qa-base/references/environments.md` — environment URLs, routing rules, test account
- `shared-qa-base/references/status-definitions.md` — re-login status icons

## When This Applies

Session recovery kicks in when any of these happen during an active test:

- The page redirects to a login screen unexpectedly
- The page lands on a Keycloak error (e.g. `psfni-guardrails-*` — "Oops!, something went wrong" / "we couldn't find your session" / `invalid_request`)
- An API call returns 401/403 during test execution
- The page becomes unresponsive or shows an auth-related error
- A navigation action lands on the login page or SSO error page instead of the expected destination

## Environment Context

The environment to recover on is the **environment the test was running on**, not "always Dev":

- **Normal ticket** → test was running on **Dev** (`https://app.dev.firstrecon.ai/`). Recover on Dev. Do not fall back to Staging or localhost.
- **`[Pro]` / `[Prod]` ticket** → test was running on **Production** (`https://app.firstrecon.ai/`). Recover on Production. If Production is genuinely unreachable for deployment-gap reasons, you may fall back to **Dev** — but session recovery itself stays on whichever env the test is currently running against.
- **Localhost** (`http://localhost:3000`) doesn't require login and has no SSO, so it is not subject to this flow.
- **Staging** (`https://app.staging.firstrecon.ai/`) is reference-only — skills don't run tests on it, so recovery on it is not expected.

The rules below apply to **any environment** that uses the Keycloak / `psfni-guardrails-*` SSO flow — current and future.

**Test accounts:** Use the role that matches the active test case. Default to `super_admin` when no role is specified.

| Role             | Email                                          | Admin?    |
| ---------------- | ---------------------------------------------- | --------- |
| super_admin      | belle.ung@persefoni.com                        | Admin     |
| platform_admin   | belle.ung+fraiplatformadmin@persefoni.com      | Admin     |
| chat_user        | belle.ung+fraichat@persefoni.com               | Non-admin |
| customer_success | belle.ung+fraicustomer@persefoni.com           | Non-admin |
| prompt_reviewer  | belle.ung+fraipromptreviewer@persefoni.com     | Non-admin |

If a **Role Test Matrix** was produced by `role-scout`, use the email it specifies for the current test case. Otherwise default to `belle.ung@persefoni.com` (`super_admin`).

---

## ⛔ Hard Rule — Never Interact with the Keycloak Error Page

**The single most important rule in this skill.** Applies to every environment that uses Keycloak SSO.

When you land on a `psfni-guardrails-*` error page (e.g. "Oops!, something went wrong", "we couldn't find your session", `invalid_request`, "You may have pressed the back button…"):

1. **Do NOT click anything on that page.** Not "VIEW LOG", not any link, not any button, not the breadcrumb, not "try again" — nothing. The page is in a broken auth state and any click will trigger a fresh `invalid_request` error and deepen the loop.
2. **First action must be to refresh the page OR re-type the environment URL** in the address bar (re-type is preferred — it discards the broken redirect query params; refresh re-submits them and may fail again).
3. Only AFTER the page has reloaded to a clean state (login screen or app shell) may you click any button.
4. If the refresh / re-type also lands back on the Keycloak error → repeat re-type once, then move into the recovery ladder below. Still no clicks on the error page itself.

> **Why this rule exists:** the Keycloak error page is itself a dead-end. Clicking "VIEW LOG", "try again", or the implicit Google SSO link from this page sends a malformed request back to Keycloak with stale state, which immediately re-renders the same error. The only way out is to leave the page entirely (refresh or fresh URL) before doing anything else.

---

## Recovery Flow

This procedure is **the same recovery ladder** defined in the `authenticator-authorizer` skill, applied mid-test against the **current test environment** (`<CURRENT_ENV_URL>`). Run every attempt in order. Do not skip steps. Do not abandon a test case.

### Attempt 1 — Re-type the environment URL (NO CLICKS on the error page)

The URL commonly corrupts on the session-expiry redirect. Ignore the current (broken) page entirely — do not click anything on it.

1. Click into the address bar and manually type `<CURRENT_ENV_URL>`, then press Enter. (Do NOT click any button on the Keycloak error page first — see Hard Rule above.)
2. Wait for the page to fully reload to a clean state.
3. If the login screen loads cleanly → click **"Continue with Google"**, select the correct role email from the table above, click **Accept**.
4. If the app shell returns → resume the test at the exact step it failed. Mark `🔄 Re-logged In → ✅/❌`.
5. If the Keycloak error page reappears → **do not click anything on it** → go to Attempt 2.

### Attempt 2 — Fresh load + immediate Google SSO

1. Re-type `<CURRENT_ENV_URL>` in the address bar (fresh load — do NOT click anything on the broken page first).
2. Wait for the login screen to fully render.
3. The moment the login screen appears, click **"Continue with Google"**.
4. Select the correct role email from the table above → **Accept**.
5. If redirect completes and the app loads → resume the test. Mark `🔄 Re-logged In → ✅/❌`.
6. If it fails again → **do not click anything on the error page** → go to Attempt 3.

### Attempt 3 — Second pass of Attempt 1 + Attempt 2

Repeat the URL re-type and Google SSO click once more. Transient Keycloak/SSO state often clears on a second pass. The Hard Rule still applies — every retry begins with a URL re-type, never with a click on the broken page.

- Success → resume the test. Mark `🔄 Re-logged In → ✅/❌`.
- Failure → go to Human Handoff.

### Human Handoff (last resort)

**Only after all three attempts have failed.** Pause the test and ask the human to log in manually:

> "I hit the SSO redirect loop three times on `<environment>` while running test `<test-case-id>` at step `<step-n>` (`psfni-guardrails-*` — 'couldn't find your session'). I've already tried re-typing the URL and clicking Continue with Google twice. Can you log in manually in the browser window? Once you're on the app shell, reply 'logged in' and I'll resume testing from this exact step."

**While waiting:**
- Do NOT silently switch environments. For normal tickets, never fall back to Staging or localhost; for `[Pro]`/`[Prod]` tickets, the only Production→Dev fallback is for genuine deployment gaps, not session recovery.
- Do NOT mark the env `🚫 Unreachable` yet.
- Do NOT skip or fail the test case.
- Do NOT click anything on the Keycloak error page.
- Preserve the current test-case ID, step number, and any test state so you can resume precisely.

Once the human confirms "logged in" → resume the test at the exact step → mark `🤝 Human-Logged In → ✅/❌`.

---

## Recording the Recovery

Update the test case row with both the recovery annotation and the final test result:

| Recovery Outcome | Status to Record |
|------------------|------------------|
| Recovered on Attempt 1, 2, or 3 (automated) | `🔄 Re-logged In → ✅/❌` |
| Recovered via human manual login | `🤝 Human-Logged In → ✅/❌` |
| Login screen appeared from a clean state | `🔑 Logged In → ✅/❌` |

The `→ ✅/❌` is the actual test result after recovery. The recovery annotation documents that an auth interruption occurred but does not itself affect pass/fail.

---

## Key Rules

- **Never click anything on the Keycloak `psfni-guardrails-*` error page** — refresh or re-type the URL first. Applies to every environment that uses SSO. (See Hard Rule above.)
- **Recover on the environment the test was running on** — Dev for normal tickets, Production for `[Pro]`/`[Prod]` tickets. Do not silently swap environments during recovery.
- **Never skip a test case** because of a session expiry or SSO loop — always recover and complete it.
- **Never mark the env `🚫 Unreachable`** due to session expiry or SSO loop alone. It is always recoverable, either automatically or via human handoff.
- **Run the full ladder** (Attempt 1 → 2 → 3 → Human Handoff) in order. Do not skip steps.
- **Resume from the exact step** where the interruption happened — never restart the test case from the beginning.
- **Ask the human only as a last resort**, after automated recovery is exhausted.
- **Record every recovery** in the test results for transparency.
- If the same environment expires multiple times in one session, run the ladder each time — there is no limit on recovery attempts.
