---
name: "ci-postcheck-gate"
description: "After a PR merges, prove it actually deployed and works: find its post-merge runs, catch superseded or hidden-failure runs, check the live environment, and compare with the baseline (LANDED_HEALTHY / LANDED_WITH_WARNINGS / NOT_LANDED / REGRESSED). Use it whenever someone asks about a merged PR or fix: did it make it to dev, staging or prod yet, is it live, did the deploy work, did it break develop, is the release out. Short questions like 'is #N on dev yet?' count too."
---

# CI Post-check Gate

Third of three gates:

```
ci-precheck-gate  ──►  ci-run-gate  ──►  ci-postcheck-gate
```

"Merged" is not "deployed", and "deployed" is not "working". Post-merge pipelines are full of
quiet exits — a newer push supersedes the run, a "nothing to deploy" path finishes green, a smoke
job collects zero tests, a health probe is `continue-on-error`. This skill finds the evidence that
**this commit** is running in the environment and that it behaves, or says precisely why not.

Not this skill: CI on an open PR (`ci-run-gate`), merge readiness (`pr-closeout`), ticket-level
functional QA (`manual-test-executor` / repo QA flows), root cause of a found regression
(`root-cause-forensics`). If the repo ships its own deploy-verification scripts or skills, use them
as evidence sources — but cross-check what they probe before trusting a "DOWN" or an "OK".

The agent runs everything; the user approves shared actions and reads the report.

## Ground rules

- **Read-only on environments by default.** GET health/version endpoints and read-only smoke
  suites are fine on dev/staging. Anything that writes data, needs secrets, or targets
  **production** beyond unauthenticated GETs needs the user's explicit approval naming the
  environment. Some tests that look read-only still write (a short-link redirect that counts a
  click, a login that records a session). The smoke suite the pipeline itself runs against that
  environment after every deploy is fine to run, since every deploy already causes its side effects;
  say in the report that you ran it and what it may have recorded. Other data-writing tests need
  approval, or skip them and say so.
- **Never** trigger deploys, rollbacks, break-glass/emergency workflows, or re-runs of deploy jobs
  yourself — re-running an old deploy run can roll the environment back. Recommend them in the
  report with the exact command; a human runs them. The same goes for pushing, re-running CI and
  posting comments: only with explicit approval.
- **One approval** for any shared action you do take (dispatching a read-only smoke workflow,
  posting a ticket/PR comment). List them together, ask once.
- **Downloads need a yes.** Before downloading anything to the user's computer (a CI artifact, a
  report zip), ask and name the exact file, where it comes from and its size. Put it in the work
  dir, or — if the browser saves it to Downloads — touch only that one file there, nothing else.
- **Secrets stay out.** If a check needs a token (test-session mint, automation token), use it only
  if it's already in the user's local env/secret store and they agree; never print or save it.
- **No AI attribution** in any comment you post. **Plain language first** in the report.

## Step 0 — Access and setup

GitHub access ladder as in `ci-run-gate` (`gh` → connector → browser Checks/Actions pages → ask).
GitHub pages sometimes show "Uh oh! There was an error while loading" — reload once, or open the
Checks tab / the run page directly. Live checks need network to the environment: try the user's
machine shell and the cloud shell; if neither reaches the host, read-only GET endpoints
(health/version JSON, login page) can be opened in the browser and read as page text. If nothing
reaches the host, mark those checks NOT_RUN (no network); don't call the environment down.

Work dir: `<repo>/.qa-kit/runs/ci-postcheck-<pr>/` (`.qa-kit/` is git-ignored).

**Project notes.** If `<repo>/.qa-kit/ci-notes.md` exists, read it: lanes, environments, known traps
and false alarms someone verified before. They are leads, never evidence — re-check every fact you
put in the report, or label it "(from project notes, not re-checked)".

### Install the kit

The helper scripts come from the Shift-Left QA Kit. This gate uses `ci-map.py` and `gate-run.py`
(kit `ci-gates`) and `post-ci-check.mjs` with its shared reader and the secret scanner (kit
`ci-guard`).

The scripts are not in this file. They are published, byte for byte, in the **Shift-Left QA Kit**
artifact: https://claude.ai/artifact/A6uQ18siDLrTWJdMEGdVWv (kit version 2026.10.20-1). This skill pins the files it needs, and installs them
into `<repo>/.qa-kit/ci-gates/`:

| File (published path) | Bytes | Fingerprint |
|---|---|---|
| `ci-gates/ci-map.py` | 35,935 | `9f675d2a7e7332e3` |
| `ci-gates/gate-run.py` | 14,416 | `8a08f42c56b1a9d6` |

The fingerprint is the first 16 hex characters of the file's sha256.

1. **Already installed?** Run
   `cd <repo> && node -e 'const c=require("crypto"),fs=require("fs");for(const f of process.argv.slice(1))console.log(c.createHash("sha256").update(fs.readFileSync(f)).digest("hex").slice(0,16),f)' .qa-kit/ci-gates/ci-map.py .qa-kit/ci-gates/gate-run.py`.
   If every file matches the table, the kit is installed: skip steps 2 and 3.
2. **Fetch.** Use the Artifact tool: `action: "read"`, `url: "https://claude.ai/artifact/A6uQ18siDLrTWJdMEGdVWv"`,
   `paths: ["ci-gates/ci-map.py", "ci-gates/gate-run.py"]`. It saves each file locally and prints its sha256. Compare the first 16
   characters with the table. **On any mismatch, stop**: don't run the file, and tell the user that
   the kit and this skill are out of sync.
3. **Install.** Copy the files into `<repo>/.qa-kit/ci-gates/`. Make sure `<repo>/.qa-kit/.gitignore`
   contains `*`, so nothing is ever committed. Then check the syntax (`python3 -c "import ast,sys; ast.parse(open(sys.argv[1]).read())" <file>` for each `.py`) and re-check the
   fingerprints in the repo — a copy can silently land an older version.
   - **Repo on the user's computer, files in the cloud:** copy them with the device file-copy tool.
     Stage them into a **new, timestamped folder every time**, because the copy tool caches by path
     and will otherwise write an old version; then re-check the fingerprints on the computer.
   - **No Artifact tool in this session, or the read is refused:** look on the same machine for
     another repo whose `.qa-kit/ci-gates/` matches the table, and copy from there. Otherwise tell the
     user what is missing. The artifact is private, so a teammate needs it shared with them. Never
     retype a script by hand.
4. **Python.** `ci-map.py` needs Python 3.8+ and PyYAML (`python3 -c "import yaml"`). If PyYAML is missing: `python3 -m pip install --user pyyaml`, or run ci-map on a machine that has it.

The scripts are not in this file. They are published, byte for byte, in the **Shift-Left QA Kit**
artifact: https://claude.ai/artifact/A6uQ18siDLrTWJdMEGdVWv (kit version 2026.10.20-1). This skill pins the files it needs, and installs them
into `<repo>/.qa-kit/ci-guard/`:

| File (published path) | Bytes | Fingerprint |
|---|---|---|
| `ci-guard/secret-scan.mjs` | 38,058 | `19daccd32b08fdf2` |
| `ci-guard/prepush-check.mjs` | 23,254 | `3db85cd35bbe579f` |
| `ci-guard/ci-audit.mjs` | 55,234 | `58f2fbb4d014acfc` |
| `ci-guard/post-ci-check.mjs` | 28,831 | `b31d2cdec77f3732` |
| `ci-guard/pw-report.mjs` | 13,015 | `89e86c27420deedd` |

The fingerprint is the first 16 hex characters of the file's sha256.

1. **Already installed?** Run
   `cd <repo> && node -e 'const c=require("crypto"),fs=require("fs");for(const f of process.argv.slice(1))console.log(c.createHash("sha256").update(fs.readFileSync(f)).digest("hex").slice(0,16),f)' .qa-kit/ci-guard/secret-scan.mjs .qa-kit/ci-guard/prepush-check.mjs .qa-kit/ci-guard/ci-audit.mjs .qa-kit/ci-guard/post-ci-check.mjs .qa-kit/ci-guard/pw-report.mjs`.
   If every file matches the table, the kit is installed: skip steps 2 and 3.
2. **Fetch.** Use the Artifact tool: `action: "read"`, `url: "https://claude.ai/artifact/A6uQ18siDLrTWJdMEGdVWv"`,
   `paths: ["ci-guard/secret-scan.mjs", "ci-guard/prepush-check.mjs", "ci-guard/ci-audit.mjs", "ci-guard/post-ci-check.mjs", "ci-guard/pw-report.mjs"]`. It saves each file locally and prints its sha256. Compare the first 16
   characters with the table. **On any mismatch, stop**: don't run the file, and tell the user that
   the kit and this skill are out of sync.
3. **Install.** Copy the files into `<repo>/.qa-kit/ci-guard/`. Make sure `<repo>/.qa-kit/.gitignore`
   contains `*`, so nothing is ever committed. Then check the syntax (`node --check <file>` for each `.mjs`) and re-check the
   fingerprints in the repo — a copy can silently land an older version.
   - **Repo on the user's computer, files in the cloud:** copy them with the device file-copy tool.
     Stage them into a **new, timestamped folder every time**, because the copy tool caches by path
     and will otherwise write an old version; then re-check the fingerprints on the computer.
   - **No Artifact tool in this session, or the read is refused:** look on the same machine for
     another repo whose `.qa-kit/ci-guard/` matches the table, and copy from there. Otherwise tell the
     user what is missing. The artifact is private, so a teammate needs it shared with them. Never
     retype a script by hand.

What the scripts do here:
- `python3 .qa-kit/ci-gates/ci-map.py …` — which workflows a push to the base branch starts, their
  jobs, steps, environments, concurrency groups and `continue-on-error` flags. Read-only.
- `python3 .qa-kit/ci-gates/gate-run.py run|report …` — runs the live-check plan with timeouts and
  logs, resumable, and prints the result table for the report.
- `node .qa-kit/ci-guard/post-ci-check.mjs --report <results.json|folder>[,more] [--previous <baseline run>] [--must-run-files <the PR's spec files>] [--artifacts <dir>] --md <out.md> --json <out.json>`
  — what a CI run's Playwright tests really did: tests vs runs (several projects, `--repeat-each`),
  passed / failed / flaky (with attempts) / skipped / fixme, tests that **never started** (the run
  stopped early), `test.fail` known bugs, zero-test runs, a table comparing with the previous run,
  the CI run link from the report's metadata, and masked secrets in the downloaded artifacts.
  Exit 1 = FAILED; exit 2 = missing input, or a `playwright test --list` file instead of a run;
  exit 3 = only blob reports were found — merge them first with the command it prints
  (`PLAYWRIGHT_JSON_OUTPUT_NAME=merged.json npx playwright merge-reports --reporter=json <folder>`,
  same Playwright version as CI), then run it on `merged.json`.

## Step 1 — Resolve what merged and where it should be

```bash
gh pr view <N> --json number,title,state,mergedAt,mergeCommit,baseRefName,headRefName,url,files -q '{state,mergedAt,merge:.mergeCommit.oid,base:.baseRefName}'
```

Not merged → stop; offer `ci-run-gate`. Without `gh`: `git log --merges --grep "#<N>" origin/<base>`
or the squash commit `git log --grep "(#<N>)" origin/<base> -1`; in the browser, the PR page's
"merged commit … into <base>" timeline entry gives the commit and the time (read the relative
time's `datetime` attribute). Record both: the merge time is what deploy timing and the baseline hang on.

Map base branch → environment(s) from the push lane:

```bash
python3 .qa-kit/ci-gates/ci-map.py --ref origin/<base> --event push --branch <base> --expand
```

Read its header lines first:
- `# fires (N)` — the workflows a push to `<base>` starts: deploy workflows, their `environment:`
  names, base URLs in `env:`/vars, health/smoke jobs, notify jobs.
- `# not triggered by push (N): … (on: workflow_call; runs anyway, called by …)` — reusable
  workflows the deploy chain calls; their jobs are part of the post-merge run.
- `# then via workflow_run: …` — follow-on workflows that start after a named parent finishes. They
  run from the default branch's copy of their file, and they do **not** show on a PR's Checks page,
  so they are easy to forget; post-merge they often hold the smoke/E2E coverage.

Note `concurrency` groups: shared deploy locks and queue/cancel behaviour decide whether a run can be
replaced. Also note schedules that redeploy or test the same environment (they move the baseline).
Organisation rulesets can add required workflows stored in another repo: a run whose name no file
here explains is one of those, not a mistake in the map.

## Step 2 — Find the runs for the merge commit

```bash
gh api "repos/{owner}/{repo}/actions/runs?head_sha=<MERGE_SHA>&per_page=50" \
  -q '.workflow_runs[] | [.id,.name,.event,.status,.conclusion,.run_attempt,.created_at,.html_url] | @tsv'
```

Expect the push-lane workflows plus their `workflow_run` children. Then check the traps:

- **No run / cancelled / replaced** — a newer push in the same concurrency group took over. A
  cancelled or superseded run proves nothing about this merge. Find the next run on the base branch
  that did deploy and check it contains our commit:
  `git merge-base --is-ancestor <MERGE_SHA> <that run's headSha> && echo contains`.
- **Superseded / admitted-later** — a run that deliberately does nothing because a newer commit is
  queued (search its log for "superseded", "skip", "nothing to deploy", "no changes"). It is often
  green with most jobs skipped — count the skipped jobs before calling it a deploy.
- **Green without deploying** — deploy jobs `skipped` because a change detector found no deployable
  paths. That's correct for docs/test-only PRs (say so: "nothing to deploy — verified by <job>"),
  wrong for code PRs.
- **Waiting** — environment approval or a lock queue ("Pending — waiting for <run>"); report
  NOT_LANDED with the queue position and an estimate from past run durations, not a failure.

## Step 3 — Audit the jobs (don't trust the run's tick)

```bash
gh run view <RUN> --json jobs -q '.jobs[] | [.databaseId,.name,.conclusion] | @tsv'
gh run view <RUN> --json jobs -q '.jobs[] | select(.conclusion=="success") | .name as $j | .steps[] | select(.conclusion=="failure") | "\($j) :: \(.name)"'   # first pass only — often EMPTY for continue-on-error steps
gh api repos/{owner}/{repo}/check-runs/<JOB>/annotations -q '.[] | "\(.annotation_level): \(.message)"' | head
gh run view <RUN> --log --job <JOB> | grep -iE "no tests found|0 passed|pass-with-no-tests|skipp(ed|ing) .*health|superseded|nothing to deploy" | head
```

For every job record: conclusion, whether it **ran tests** (count), whether a failure was
swallowed, and why a skipped job skipped (its `if:`).

**Swallowed failures need the log.** GitHub often records a failed `continue-on-error` step as
*success*, so the step-conclusion query above can come back empty while tests really failed. A job
with `continue-on-error: true` on the job itself is advisory: it can be red without failing the
workflow, so a green workflow says nothing about it. For every step or job `ci-map.py` marks
`CONTINUE-ON-ERROR` (unless a later step re-checks its outcome and fails), and every green job whose
annotations say "Process completed with exit code 1", read that log and count passed/failed tests.

**Test results.** When a job uploads Playwright results (JSON report, blob report zips, test-results),
list the artifacts (`gh api repos/{owner}/{repo}/actions/runs/<RUN>/artifacts -q '.artifacts[] | [.name,.size_in_bytes,.expired] | @tsv'`),
ask before downloading (name, size), then download into the work dir
(`gh run download <RUN> -n <artifact> -D .qa-kit/runs/ci-postcheck-<pr>/artifacts/<run>`) and run:

```bash
node .qa-kit/ci-guard/post-ci-check.mjs --report <dir or results.json>[,<shard 2>,…] \
  --must-run-files <spec files the PR added/changed> --artifacts <dir> \
  --md .qa-kit/runs/ci-postcheck-<pr>/post-ci-<run>.md --json .qa-kit/runs/ci-postcheck-<pr>/post-ci-<run>.json
```

Pass every shard's report (or one merged report). Use its counts in the report, not counts by eye:
"Never started" means the run stopped early (maxFailures, a cancelled job, a failed setup project) —
those tests are unverified, not passed; zero executed tests means the job proves nothing. If
`--artifacts` finds a credential, report it masked as it appears and recommend rotation — never
print the value.

Read the **notices** of verification jobs, not just their colour: teams sometimes make a check
advisory by an owner decision (e.g. "never fails the deploy"), so a green deploy may say nothing
about the feature, and a red one may be unrelated. Quote the notice text in the report.

Note which follow-on workflows **did not run** because they only fire after a successful deploy —
that is missing coverage, not a pass.

For "nothing to deploy" changes (tests, docs), the change detector's own output is the evidence —
e.g. a summary row like `<service> ⏭️ skip unchanged`. Quote it; don't call that run a failure.

## Step 4 — Prove the deployed version contains the commit

Use the strongest evidence available and name it:
1. A version/health endpoint that reports a SHA, build id or version → compare to the merge SHA
   (or confirm it's a descendant with `git merge-base --is-ancestor`).
2. GitHub Deployments: `gh api "repos/{owner}/{repo}/deployments?sha=<SHA>&environment=<env>"` +
   `/deployments/<id>/statuses`. Caution: any job with `environment:` creates a deployment record —
   a notify job that succeeds shows "Deployed" even when the real deploy failed. Check which job
   created each record before trusting it.
3. Platform CLIs if installed and authenticated (e.g. `wrangler deployments list`, `kubectl rollout history`,
   `vercel ls`, `fly releases`) — read-only.
4. Deploy job log lines or job summaries that print the deployed version/SHA.
5. For a frontend change with no version endpoint: fetch the public JS bundle and search it for
   strings the PR added or removed (no login needed).
6. Weakest: deploy job green for a run whose head contains the SHA (say it's indirect).

Per environment: **MATCH** (our SHA or a descendant is live), **BEHIND** (live version predates it),
**UNKNOWN** (no evidence reachable).

Environments move while you check. If a newer deploy finishes during the check (version, build id or
bundle names change), re-check presence at the end and say which build your evidence comes from.

To compare with a CI run that tested the PR's merge result (its report's metadata names a merge
commit "Merge <head> into <base>"), fetch that commit with `git fetch origin pull/<N>/merge`.

## Step 5 — Live checks against the environment

Write a plan (TSV: `id <TAB> what it checks <TAB> timeout-seconds <TAB> command`) — read-only checks
first — and run it with `gate-run.py`:

```bash
python3 .qa-kit/ci-gates/gate-run.py run --plan <plan.tsv> --out .qa-kit/runs/ci-postcheck-<pr>/live --budget 150   # repeat until exit 0 in shells that cut long calls
python3 .qa-kit/ci-gates/gate-run.py report --out .qa-kit/runs/ci-postcheck-<pr>/live        # the table for "Live checks"
```

| Check | How |
|---|---|
| Front door / health | `curl -sS -o /dev/null -w '%{http_code}' <url>` for the health/liveness/login URLs the pipeline itself probes (take them from the workflows, not guesses); check JSON status fields too |
| Smoke suite | the repo's smoke tag/project locally: `BASE_URL=<env> npx playwright test --grep @smoke --reporter=json,line` (use the env var the config reads), or — with approval — dispatch the repo's smoke workflow; read the JSON with `post-ci-check.mjs` |
| The change itself | specs added/changed by the PR (`git diff --name-only <SHA>^1 <SHA> -- '*.spec.*' '*.test.*'`) run against the environment when they're E2E and safe for that env; UI changes → screenshots of the changed screens as evidence |
| Repo verifiers | the repo's own post-deploy scripts/skills (chat probes, version checks) when they're read-only |

gate-run statuses: PASS, FAIL, TIMEOUT, and NOT_RUN — the check could not run here (tool missing,
an environment variable the CI job sets, empty input, out of memory). NOT_RUN is unverified, not
passed and not failed; say what would make it run.

Keep screenshots/traces from Playwright (`--trace on-first-retry`, `screenshot: only-on-failure`, or
explicit `page.screenshot`) in the work dir — reviewers judge by evidence, not ticks.

## Step 5b — If the merge's own run couldn't verify it

When the run for the merge SHA was red for pre-existing reasons, superseded, or skipped its checks,
walk forward through later runs on the base branch and name the **first run whose verification
genuinely passed** and whose head contains the commit (`git merge-base --is-ancestor`). That is the
earliest real evidence the change works in the environment. Also list later commits that touched
the same files (`git log --oneline <SHA>..origin/<base> -- <files of the PR>`): what is live today
may not be exactly what merged. Finally, if the PR body promised its own post-merge validation
("after merge we will…", latency/perf runs, data checks), look for evidence it happened and report
"not evidenced" if none. Also compare the ticket's status with reality: a ticket marked
Released/Done while the environment is BEHIND is a finding to report (and a ticket comment to offer).
Check the PR description's claims too — a wrong claim (e.g. "still covered by tests X" when X is
skipped) is worth a correcting comment, offered for approval. Check claims about files by reading them
at the commit (`git show <sha>:<path>`, `git grep <pattern> <sha>`), not with GitHub code search,
which indexes only the default branch and drops results.
If a revert PR, incident or bot alert points at this change, report it with its status and any clock it
sets (a fix-forward window, a revert deadline): the reader needs to know how long they have. Read the
failing tests yourself before agreeing with a bot's blame. Report it; don't act on it.

**If the change misbehaves live, size the damage** (a few minutes, read-only) before the verdict:
- try other inputs of the same kind (date formats, locales, empty or edge values). Some fail
  *silently wrong* instead of visibly broken, which is worse;
- list lanes that are now red because of it: nightly runs, other open PRs whose advisory E2E runs
  against this environment;
- check whether the change's own tests could have caught it (only one item checked, inputs unlike
  real data), and whether they ran before the merge at all (label-gated or path-filtered suites the
  PR never triggered).
This makes the fix and the ticket cover the whole problem.

## Step 6 — Compare with the baseline

Previous run of the same post-merge workflow on the base branch, before our merge:
`gh run list --workflow <file> --branch <base> --event push -L 6 --json databaseId,headSha,conclusion,createdAt`.
For test jobs, run `post-ci-check.mjs` on the new run with `--previous <the baseline run's report>`:
its "Compared with the previous run" table gives the counts before and now, the tests whose status
changed, and new or vanished tests. For each failing job/test now: was it failing before? →
**pre-existing** (report, not ours) vs **new since this merge** (candidate regression; look at what
else merged in between: `git log --oneline <prev headSha>..<our run headSha>`). Scheduled runs on the
same environment are useful extra baselines.

Then account for **every** run since the merge, up to now, whose head contains the commit — not only
the ones that tell a tidy story:
`gh run list --branch <base> --event push --created ">=<mergedAt>" -L 50 --json databaseId,workflowName,headSha,conclusion,createdAt`
(plus `merge_group`/`schedule`/`workflow_run` runs on the same environment that already ran; don't
wait for future scheduled runs, name them as the next check), keep those where
`git merge-base --is-ancestor <MERGE_SHA> <headSha>` holds, and give each a line: passed, failed (and
whether that failure is pre-existing or new), cancelled, still running. Runs on other branches belong
here only when they test this environment (an E2E lane pointed at it, say). A failing later run that
contains the change and goes unmentioned makes the whole report look cherry-picked.

## Step 7 — Verdict and report

- **LANDED_HEALTHY** — deployed version contains the commit (MATCH), post-merge jobs genuinely
  passed, live checks pass (including any check of what the change itself does), nothing new is failing.
- **LANDED_WITH_WARNINGS** — MATCH and no new failures, but the proof that it landed and works is
  weaker than it should be, for a reason you can name: presence shown only indirectly; a step failure
  swallowed (`continue-on-error`, advisory job); health or smoke coverage the pipeline normally runs was
  skipped, collected 0 tests or had tests that never started; a pre-existing failure hides part of the
  result; a check the pipeline itself runs could not be run here (NOT_RUN); or a live check of what the
  change does gave a result you can't call right or wrong without its owner (it may be by design).
  Name the open question.
- **NOT_LANDED** — no deploy contains the commit yet (cancelled, waiting, superseded with no later
  deploy, deploy failed), or it was rolled back.
- **REGRESSED** — landed, and something is broken because of it: the change itself misbehaves live
  (its own tests or a live check of what it does fail, e.g. a new badge shows "NaN"), or a check that
  passed on the baseline now fails in a way tied to this change or its deploy.
- **UNVERIFIED** — the evidence needed (CI runs, deployed version, live checks) could not be reached.
  List what was proven (e.g. "commit is on develop"), what wasn't, and the access that would settle it.
  Don't upgrade "couldn't check" to healthy or to not-landed.

Pick the verdict from the landing evidence, not from how much more could be tested. Every change has
untested corners, latent code worries and follow-up ideas, and an extra check you chose not to run
because it would write to a shared environment is caution, not a gap. Those go under "Notes and
follow-ups" and leave a clean landing LANDED_HEALTHY. A warning needs one of the reasons above, named
in the report; if you can't name one, the verdict is LANDED_HEALTHY.

**Check the report before you send it.** Every number, time, SHA, count and name in it should come
from a tool output in this run: test counts from `post-ci-check.mjs`, live-check results from
`gate-run.py report`, times from timestamps or `date -u` rather than estimates; quote key lines
instead of paraphrasing them. Mark anything you can't trace as approximate, or leave it out — a wrong
detail makes the reader doubt the right ones. In particular:
- Facts from the project notes are untraced until you re-check them in this run; if you use one
  without re-checking, label it "(from project notes, not re-checked)".
- Counts of your own actions (how many times you loaded or ran something) come from the commands, not
  from memory, and durations ("within an hour") are worked out from the two timestamps.
- Name a person (author, owner, reviewer) only when a tool output names them.
- A command that failed or isn't supported proves nothing: write "couldn't check", not "there are none".
- Keep any timeline or actions table in the order things happened, with times copied from the outputs.
- Text you draft for someone else to post (a PR comment, a ticket update) states only what you
  verified. Mark inferences as such ("likely", "appears to") and leave out promises and statuses
  nobody confirmed, such as "fix in progress" or "fix to follow".
- The Scratch line covers every file you created. Keep them all in the work dir (downloads,
  `curl -o`/`-D` output, screenshots), or list any other path next to it.

Save `<PR>_<VERDICT>_CI-Postcheck_<YYYY-MM-DD>.md` and deliver it. Template:

```markdown
# CI Post-check — PR #<N> <title>   **<VERDICT>**
_<date> · merged <mergedAt> into <base> as <sha12> · environment(s): <env → URL>_

## In plain words
<2–4 sentences: is it live, is it working, anything to worry about, what next.>

## Pipeline runs for <sha12>
| Workflow | Event | Run | Conclusion | Real result (after audit) | Notes |
|---|---|---|---|---|---|

## Is this commit deployed?
| Environment | Evidence | Live version | Status (MATCH/BEHIND/UNKNOWN) |
|---|---|---|---|

## Test results of the post-merge runs
<from post-ci-check.mjs: Tests · Runs · Executed · Passed · Failed · Flaky · Skipped · Fixme · Never started, per run; the PR's own specs (must-run) and their result>

## Live checks
<the gate-run.py report table: check · result · time · note; NOT_RUN rows say why>

## Hidden problems found
- <swallowed step / advisory job / 0-test job / never-started tests / skipped health coverage> — impact

## Compared with baseline (run <id>, <sha12>)
| Job / test | Before | Now | New? |
|---|---|---|---|

## Later runs that contain the commit (merge → now)
| Run | Workflow | Head | Result | Pre-existing or new? |
|---|---|---|---|---|

## Notes and follow-ups (don't change the verdict)
- <test gaps, latent code worries, ideas — or "none">

## Next step
<e.g. post results to the ticket (linear-comment-writer / jira-comment-writer); move ticket (… transition skill);
regression → root-cause-forensics + ticket writer; NOT_LANDED → who to ask and the exact re-deploy command for a human>
Scratch: `<work dir>` (<size, measured last>) — safe to delete.
```

## Promotion lanes (develop → staging → main style repos)

When the base is a promotion target, the same steps apply per hop: promotion PR checks (often
stricter gates than feature PRs), then the post-merge deploy of that environment. A change is
"in production" only when the production deploy run's head contains the commit — trace it hop by
hop (`git merge-base --is-ancestor <SHA> origin/<env-branch>` then that branch's deploy run). A
ticket tracker may mark a change Released before it reaches production; the deploy evidence decides.

## GitLab CI / Jenkins

`ci-map.py` lists GitLab jobs (with `rules`/`only`, includes and `extends` resolved) and Jenkins
stages, but does not evaluate their rules for an event — decide per job whether it runs on a push to
`<base>`, and say which you assumed. Pipelines: `glab ci list` / `glab ci view`, or the Jenkins job
page; the same audit applies (allow_failure = advisory, skipped stages, zero-test jobs).

## Project notes — keep what you verified

At the end, append to `<repo>/.qa-kit/ci-notes.md` (create it if missing; it is git-ignored) only
lessons you **verified in this run** that the next post-check would want: one dated line each
(`- YYYY-MM-DD: <lane / trap / false alarm>, seen in run <id>`). No secrets, tokens, personal data or
guesses. Don't repeat a line that is already there — update it if it changed.

## Hand off

The report's **Next step** line is the hand-off: post the results to the ticket
(`linear-comment-writer` / `jira-comment-writer`) and move it (the matching transition skill) once the
user approves; a REGRESSED verdict goes to `root-cause-forensics`, then the ticket writer; NOT_LANDED
names who can deploy and the exact command for a human to run. Pass the report path, the run ids and
the `post-ci-check` JSON to the next skill so it does not redo the checks.