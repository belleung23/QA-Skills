---
name: "load-test-runner"
description: "Run safe load tests against any HTTP API or web backend: smoke, average-load, stress, spike, breakpoint and soak. Uses k6 when it's installed, otherwise a zero-install Node load generator (also runnable through a connected Playwright browser tool for small loads), and records p50/p95/p99 response times, throughput, error rate, Apdex and the user count where the system starts to break. A built-in safety gate requires the team to own the target, user approval for heavy tests on shared or production environments, and no side-effect endpoints. Use whenever someone asks for load or stress testing, performance under many users, concurrency, capacity, throughput, 'how many users can it handle', spike or soak tests, or API performance. Then hand the results to performance-report for the .md report. For single-user page speed, use web-performance-audit instead."
---

# Load Test Runner (many users)

A load test sends traffic from many simulated users ("virtual users", VUs) and watches how response time and errors change as the load grows. Playwright is the wrong tool for this, because a real browser per user is far too heavy. This skill uses **k6** when it's installed and otherwise a small **Node load generator** that needs nothing beyond Node 18+. Both read the same config and write the same results file, so **performance-report** can rate either one.

Run everything yourself, end to end. Stop only for things the user must decide: approval for heavy or production tests, expected user numbers when the plan depends on them, and credentials.

## Step 1 — Safety gate (before any traffic is sent)

Load tests can take a system down. Check all of these first. Both engines enforce items 2–4 in code: `load-gen.mjs` exits with code 3 (blocked), and `k6-load.js` refuses to start (k6 exit code 107) with the same message.

1. **Ownership.** Only test systems the user's team owns or has written permission to test. Never point load at third-party sites or APIs (SSO providers, payment gateways, LLM or AI APIs, public websites). Leave out endpoints of your own app that fan out to paid or rate-limited third parties, or stub them.
2. **Production.** Only with the user's explicit approval in this conversation. Even then, run smoke plus a light average load, off-peak. Record the approval as `"productionApproved": "<who>, <when>"`.
3. **Heavy tests on shared environments.** Stress, spike, breakpoint and soak on dev or staging slow things down for everyone else. Ask once, stating the peak users, duration and start time. Record `"approvedBy": "<who>, <when>"` and suggest they warn the team channel.
4. **Read-only by default.** POST, PUT, PATCH and DELETE requests are blocked unless marked `"allowWrite": true`. Set that only after confirming the endpoint has no real-world side effects (emails, payments, notifications, webhooks) and test data can be cleaned up (a test tenant, a teardown step). When you discover endpoints from API docs, OpenAPI specs or routes, list the side-effect ones and leave them out unless the user approves.
5. **Protections.** Expect `429` from rate limiters and WAFs. Never try to bypass them. If the user wants to test past them, they arrange an allowlisted test path.

Never edit the config to get around the gate without the user's go-ahead. The gate's messages are written so you can paste them straight into your question to the user.

## Step 2 — Plan the scenarios

| Type | Question it answers | Shape (built in) | Default length |
|---|---|---|---|
| smoke | Does the script work, and is the system fine with 2 users? | 2 VUs flat | 30 s |
| constant | "N users for T" — exactly what the user asked | short ramp (≤ 5 s), then hold N for the full T | 1 m |
| average-load | Does it hold at normal traffic? | ramp to N, hold, ramp down | 5 m |
| stress | What happens above normal? | ramp to N, then to peak (default 2N), hold | 10 m |
| spike | Does it survive a sudden burst and recover? | N → jump to peak (default 5N) → back to N | 3 m |
| breakpoint | Where does it break? | linear ramp to peak (default 10N); stops early when it breaks | 10 m |
| soak | Does it degrade over hours (leaks, pool exhaustion)? | like average-load, long | 1 h |

- **Always run smoke first.** If it fails, fix the URL, auth or script before anything bigger. Keep it no longer than the main test (10–15 s is plenty before a 20-second test). Its percentiles may then show "not measured" (fewer than 20 requests); that is fine for a smoke test. When other tests ran, the report shows the smoke test's response times but doesn't count them (only its errors count), because with so few requests the cost of opening new connections can dominate them.
- **N** is the expected number of concurrent users. Ask the user, or use analytics or a ticket. If nobody knows, use 10 and state that assumption in the report notes.
- **When the user names exact numbers** ("30 users for 45 seconds"), use `constant` so N users are active for the whole T. Ramp-shaped types spend part of the time ramping up and down, so that would quietly run a smaller test than asked.
- **Time caps** ("each test under 1 minute"): count the whole run. For `constant`, `duration` is the hold time and its ramp-up (up to 5 s) comes on top, and every test ends with a few seconds for the last requests to finish. For "under 1 minute", plan about 50 s in total.
- **Default plan** when the user gives no detail: smoke, then average-load (N, 5 min). Add stress, spike or breakpoint when they ask about capacity, limits or "how many users", after the approval in Step 1.3 where needed.
- **Time-capped capacity search** (e.g. "each test under 1 minute"): first run a coarse `breakpoint` (0 → about 5N) to see roughly where it breaks: its **Capacity** line says "stayed within standard up to ~G users; first went over at ~B users" (overall or for any single endpoint). Then run a fine one with `"type": "breakpoint"` and explicit `stages`: a 5-second ramp-in from 0 to about G, or to the user count of your steady normal-load test if that test was already at the edge of the standard, whichever is lower (a fast ramp spends too little time at each level for queues to build, so it can overstate G; starting many users at the same instant makes the first window look worse than it is), then a slow climb to ≈ 1.3·B within the time cap. To find where requests start **failing** (not just slowing), run a separate ramp around the coarse test's "requests started failing at ~F users". Each 5-second window then adds (0.6·B) ÷ (windows in the cap) users: about 1–2 when B is around 30, more when B is larger. That is fine; state the resulting precision ("the limit is between 27 and 29 users") instead of chasing finer steps. The report takes its capacity estimate from the ramping test with the finest steps. If the verdict should also say whether normal traffic is fine, add a `constant` test at the expected number of users; without one, the capacity tests decide the verdict and the report says so.
- **Capacity questions** ("how many users before it breaks"): after the normal-load test, run a `breakpoint` with a slow enough ramp that each 5-second window adds only a few users. A fast ramp jumps straight past the limit, and the report can then only say the limit is "below N". The report shows stress, spike and breakpoint results for capacity planning but leaves them out of the verdict, because those tests are designed to break things. They decide the verdict only when nothing else measured real load (no page-speed audit and no constant, average-load or soak test), and the report then says so.
- **Think time:** `[500, 1500]` ms between requests mimics real users. `0` measures raw throughput; say so in the notes.
- `peakVUs`, `duration`, `vus` and explicit `stages` (`[{ "duration": "1m", "target": 30 }, …]` plus `startVUs`) override the shapes. Every scenario still needs a `type`, even with `stages`: the type decides the safety gate (stress, spike, breakpoint and soak need approval on shared environments) and how the report rates it. Scenario `name`s (default: the type) must be unique.

## Step 3 — Engine and machine

- `k6 version` works → use k6. It's better above ~200 VUs or a few hundred requests per second, and suits CI.
- Otherwise use the Node engine. It's fine up to ~200 VUs on a laptop, and it reports when the load generator itself is the bottleneck. Install k6 only if the user wants that: `brew install k6`, the apt repository, Docker `grafana/k6`, or a binary from the GitHub releases page.
- Run from a machine that can reach the target. Ideally that isn't the same machine as the server under test; for local apps it has to be, so mention it in the notes.
- **This machine can't reach the target, but a Playwright browser tool is connected on the user's computer?** (A browser tool with a "run code" action, e.g. `browser_run_code_unsafe` from the Playwright MCP.) Use **browser-connector mode** (Step 5b): the Node engine runs inside that tool on the user's computer. It is meant for apps only reachable from there (VPN, office network) and for small loads: it is capped at 50 VUs unless `maxVUs` is raised deliberately, and the user's own network connection becomes part of the numbers. For capacity planning, use a real load machine.

## Step 4 — Write the tools and the config

- **Tools:** in `.perf-kit/` at the project root (or the working folder). Reuse `load-gen.mjs` and `k6-load.js` only when their version lines (`// perf-kit:load-gen v5` on line 2, `// perf-kit:k6-load v4` on line 1) match the scripts below; otherwise overwrite them with the scripts exactly as given.

  The script is long, so copy it out of this file with a command instead of retyping it (`<this SKILL.md>` is the path you read these instructions from), then check it:

  ```bash
  mkdir -p .perf-kit && awk '/^## load-gen[.]mjs$/{h=1;next} h&&/^````js$/{p=1;next} p&&/^````$/{exit} p' "<this SKILL.md>" > .perf-kit/load-gen.mjs
  node --check .perf-kit/load-gen.mjs && sed -n 2p .perf-kit/load-gen.mjs   # must print the version line
  ```
  For k6, do the same with the `## k6-load.js` block below (`awk '/^## k6-load[.]js$/{h=1;next} …' > .perf-kit/k6-load.js`). It has no `#!` line, so its version line is line 1 (`sed -n 1p`), and skip `node --check` for it: it is a k6 script.
- **Run directory:** `perf-reports/<YYYY-MM-DD>_<app-slug>/`, or `test-reports/performance/…` if the project already has `test-reports/`. When the same request also includes a page-speed audit, use the same run directory as web-performance-audit.
- **Config** (`<run-dir>/load-config.json`):

```json
{
  "label": "Acme API — catalogue",
  "environment": "staging",
  "baseUrl": "https://api.staging.acme.example",
  "headers": { "Authorization": "env:PERF_AUTH_HEADER" },
  "requests": [
    { "name": "GET /api/products", "method": "GET", "path": "/api/products?page=1", "weight": 3 },
    { "name": "GET /api/search",   "method": "GET", "path": "/api/search?q=shoe",   "weight": 1, "expectStatus": 200 }
  ],
  "thinkTimeMs": [500, 1500],
  "timeoutMs": 10000,
  "apdexTMs": 500,
  "scenarios": [
    { "type": "smoke" },
    { "type": "average-load", "vus": 20, "duration": "5m" },
    { "name": "stress-60", "type": "stress", "vus": 20, "peakVUs": 60, "duration": "10m" }
  ],
  "approvedBy": "",
  "productionApproved": ""
}
```

- `assumptions`: list anything you decided without asking (traffic mix, think time, normal user count, endpoints left out). The report shows them under the summary, and the traffic mix also appears with every scenario.
- `weight` sets the traffic mix. Request `name`s become the per-endpoint rows in the report, so keep them unique and as `METHOD /path`.
- `path` is added to the end of `baseUrl` (so `"baseUrl": "https://host/api"` with `"path": "/items"` calls `https://host/api/items`); a full `https://…` address in `path` is used as is.
- `body` (an object) is sent as JSON with `Content-Type: application/json`, for POST/PUT/PATCH requests that passed the safety gate (`"allowWrite": true`). A request can also have its own `headers`.
- **Secrets:** headers take `env:VAR_NAME`, and the value is read from the environment at run time, both in the shared `headers` and in one request's own `headers`. Never write a token into the config, the results or the report: saved results keep only the `env:` names and show any literal value as `<redacted>`. The variable holds the **whole header value** (`Bearer <token>`, not just the token). Set it in the same command that runs the test (`PERF_AUTH_HEADER="Bearer …" node .perf-kit/load-gen.mjs …`), because each shell call may start fresh. When the user says only one endpoint needs the token, put the header on that request (`"headers": { "Authorization": "env:PERF_AUTH_HEADER" }` inside it) instead of the shared `headers`. For long tests, use a token that won't expire mid-run.
- A request passes when its status is 2xx (or matches `expectStatus`). Redirects count as failures, because a 302 to the login page usually means auth was lost.
- `abort` (`{ "errorRate": 0.1, "p95Ms": 10000 }` by default; `0.05` / `5000` for breakpoint) is the safety brake: it looks at the last 15 seconds and stops the scenario early when the error rate or p95 crosses its limit. `maxVUs` (default 200, or 50 in browser-connector mode) caps the Node engine.

## Step 5 — Run

```bash
node .perf-kit/load-gen.mjs --preflight --config <run-dir>/load-config.json
# Node engine — one scenario per call, smoke first:
node .perf-kit/load-gen.mjs --config <run-dir>/load-config.json --scenario smoke --out <run-dir>
node .perf-kit/load-gen.mjs --config <run-dir>/load-config.json --scenario average-load --out <run-dir>
```

The preflight checks Node, k6, the config, that the target answers, that every `env:` header variable is set, the safety gate, and sends **one** request to each GET endpoint so a wrong path or a rejected token shows up before the test (`FAILED: HTTP 401 — authentication/permission problem`). It never sends anything that changes data, so POST/PUT/PATCH/DELETE endpoints are first exercised by the smoke test: check their status in the smoke results before going bigger.

k6 engine. k6 reads files relative to the script's own folder, so pass **absolute** paths (`$PWD/...`). Header variables come from the shell environment.

```bash
k6 run -e PERF_CONFIG="$PWD/<run-dir>/load-config.json" -e PERF_SCENARIO=average-load \
       -e PERF_SUMMARY="$PWD/<run-dir>/k6-average-load.json" --out csv="<run-dir>/k6-average-load.csv" .perf-kit/k6-load.js
node .perf-kit/load-gen.mjs --from-k6 <run-dir>/k6-average-load.json --k6-csv <run-dir>/k6-average-load.csv \
       --config <run-dir>/load-config.json --scenario average-load --out <run-dir>
```

- The CSV gives the report its 5-second timeline and capacity point; without it the k6 result has totals only.
- k6 exits with `99` when the safety brake (its abort thresholds) stops the test. That is still a result: convert the summary as usual. Exit `107` with "BLOCKED by safety gate" means the gate or the config check refused to start: fix the config or ask the user, as with exit 3.
- Each call adds its scenario to `<run-dir>/load-results.json`; re-running a scenario replaces its entry.
- Exit codes of `load-gen.mjs`: `0` finished, `2` config problem (it lists what to fix: a missing `type`, duplicate names, an empty `requests` list…) or missing env var, `3` blocked by the safety gate (ask the user), `4` stopped by the safety brake. Exit 4 is a valid result: the system could not take that load. Report it; don't retry harder. The report shows the planned and the reached load. Raise a scenario's `abort.errorRate` only when all of these hold: the user asked for that exact load and duration, the target is local or their own test instance, and the errors are cheap rejections (429, 401/403) rather than 5xx or timeouts, which mean the system is struggling. Do it only after a first run stopped, as a copy of the scenario under a new `name` (e.g. `limited-10-no-brake`), so the stopped run stays in the report next to the full one. Record that in `assumptions`.
- Each finished scenario prints a `hint:` line when errors occurred, saying in plain words what the most common error means (an auth problem, a rate limiter, the server down, real slowness). The same hint appears in the report.
- Long scenarios: start them in the background (`nohup … > <run-dir>/<scenario>.log 2>&1 &`) and poll the log. The Node engine prints progress every 10 s.
- Run scenarios one at a time, never in parallel. Leave a short pause between them so queues drain.

## Step 5b — Browser-connector mode (the user's computer sends the load)

Use this when Step 3 pointed here. The run folder must be inside a folder that both this machine and the user's computer see (a connected or shared project folder). `--map "<folder here>=<same folder on the user's computer>"` tells the script where that is, e.g. `--map "$HOME/mnt/my-repo=/Users/alex/code/my-repo"`; leave it out when both are the same machine. The safety gate and the env-var check run here, before anything is sent.

```bash
# 1. Preflight from the user's computer (reachability + one request per GET endpoint)
node .perf-kit/load-gen.mjs --preflight --emit-mcp --config <run-dir>/load-config.json --out <run-dir> --map "<here>=<there>"
#    → run the printed "filename" once with the browser tool's run-code action, then poll until the exit code is not 5:
node .perf-kit/load-gen.mjs --preflight --collect-mcp --config <run-dir>/load-config.json --out <run-dir>
# 2. Each scenario, smoke first, one at a time
node .perf-kit/load-gen.mjs --emit-mcp --config <run-dir>/load-config.json --scenario smoke --out <run-dir> --map "<here>=<there>"
#    → run the printed "filename" once, then poll (every 30–60 s) until the exit code is not 5:
node .perf-kit/load-gen.mjs --collect-mcp --config <run-dir>/load-config.json --scenario smoke --out <run-dir>
```

- The emitted `job-*.js` is a short loader for `job-*.core.js`. It answers within seconds with `started: true` and the test keeps running in the background. If it answers `started: false` with `runInstead`, run that file instead; for any other `started: false`, fix what the `error` says.
- **Run each job file exactly once.** If the tool call times out, the job may well be running: poll `--collect-mcp` instead of starting it again. A second copy is refused while one runs.
- `--collect-mcp` exit codes: `5` still running (it prints elapsed time and progress), `0`/`4` finished (same meaning as above; the scenario is added to `load-results.json`), `1` failed, stalled or never started (it says which), `2` nothing emitted yet.
- The `.core.js` file holds the resolved header values (tokens) while the job runs; the job overwrites it when it finishes, and `--collect-mcp` checks that. If you abandon a run, overwrite that file yourself.

## Step 6 — Check each scenario before moving on

| Symptom in results | Meaning | Action |
|---|---|---|
| preflight `endpoints: … FAILED` | Wrong path, or the token is rejected | Fix before any scenario |
| errors `ECONNREFUSED` / `ENOTFOUND` | Wrong URL or server down | Fix, re-run smoke |
| errors `401` / `403` | Auth missing or expired | Fix token, re-run |
| errors `429` | Rate limiter answered, not the app | Report it as a limit; don't bypass |
| errors `timeout` | Requests took longer than `timeoutMs` | Real slowness: keep and report |
| `generator.saturated: true` | Test machine was the bottleneck | Fewer VUs, or use k6 / a bigger machine |
| smoke not clean | Script or environment problem | Stop: no bigger scenarios until smoke is clean |

## Step 7 — Report

Use **performance-report** with `<run-dir>/load-results.json` (plus `web-results.json` if a page-speed audit ran). The report rates p95, p99, error rate and Apdex per scenario and per endpoint, and shows the capacity point: the last user count within standard and the first one over it.

## load-gen.mjs

````js
#!/usr/bin/env node
// perf-kit:load-gen v5 — zero-install HTTP load generator (Node 18+ fetch) + k6 summary converter.
// Usage:
//   node load-gen.mjs --preflight --config load-config.json
//   node load-gen.mjs --config load-config.json --scenario <name> --out <run-dir>
//   node load-gen.mjs --from-k6 <k6-summary.json> [--k6-csv <k6.csv>] --config load-config.json --scenario <name> --out <run-dir>
// Browser-connector mode (this machine cannot reach the target; a Playwright browser tool on the user's computer can):
//   node load-gen.mjs [--preflight] --emit-mcp --config load-config.json [--scenario <name>] --out <run-dir> [--map <folder-here>=<same-folder-there>]
//   node load-gen.mjs [--preflight] --collect-mcp --config load-config.json [--scenario <name>] --out <run-dir>   (exit 5 = still running)
// Each call adds (or replaces) one scenario in <run-dir>/load-results.json (schema perf-results/1).
import fs from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';

const args = process.argv.slice(2);
const arg = (k, d) => { const i = args.indexOf(`--${k}`); return i >= 0 ? args[i + 1] : d; };
const flag = (k) => args.includes(`--${k}`);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const pct = (v, p) => { if (!v.length) return null; const s = Float64Array.from(v).sort(); const i = (s.length - 1) * p; const lo = Math.floor(i); return s[lo] + (s[Math.ceil(i)] - s[lo]) * (i - lo); };
const r1 = (x) => (x == null ? null : Math.round(x * 10) / 10);
const isObj = (o) => o && typeof o === 'object' && !Array.isArray(o);

const DEFAULT_DURATION = { smoke: '30s', constant: '1m', 'average-load': '5m', stress: '10m', spike: '3m', breakpoint: '10m', soak: '1h' };
const HEAVY = new Set(['stress', 'spike', 'breakpoint', 'soak']);
const TYPES = Object.keys(DEFAULT_DURATION);
const parseDur = (s) => { const m = /^(\d+(?:\.\d+)?)(ms|s|m|h)$/.exec(String(s).trim()); if (!m) throw new Error(`Bad duration "${s}" (use 30s, 5m, 1h)`); return +m[1] * { ms: 1, s: 1000, m: 60000, h: 3600000 }[m[2]]; };

// Same stage shapes as the k6 template (keep in sync).
function stagesFor(sc) {
  if (sc.stages) return { start: sc.startVUs || 0, stages: sc.stages.map((s) => ({ ms: parseDur(s.duration), target: s.target })) };
  const N = sc.vus || (sc.type === 'smoke' ? 2 : 10);
  const D = parseDur(sc.duration || DEFAULT_DURATION[sc.type] || '1m');
  switch (sc.type) {
    case 'smoke': return { start: N, stages: [{ ms: D, target: N }] };
    // "N users for T": short ramp (default 10 % of T, max 5 s), then hold N for the full T
    case 'constant': { const up = sc.rampUp ? parseDur(sc.rampUp) : Math.min(5000, D * 0.1); return { start: 0, stages: [{ ms: up, target: N }, { ms: D, target: N }] }; }
    case 'average-load': case 'soak': return { start: 0, stages: [{ ms: D * 0.15, target: N }, { ms: D * 0.75, target: N }, { ms: D * 0.1, target: 0 }] };
    case 'stress': { const P = sc.peakVUs || N * 2; return { start: 0, stages: [{ ms: D * 0.15, target: N }, { ms: D * 0.15, target: P }, { ms: D * 0.6, target: P }, { ms: D * 0.1, target: 0 }] }; }
    case 'spike': { const P = sc.peakVUs || N * 5; return { start: N, stages: [{ ms: D * 0.25, target: N }, { ms: D * 0.05, target: P }, { ms: D * 0.3, target: P }, { ms: D * 0.05, target: N }, { ms: D * 0.35, target: N }] }; }
    case 'breakpoint': return { start: 0, stages: [{ ms: D, target: sc.peakVUs || N * 10 }] };
    default: throw new Error(`Unknown scenario type "${sc.type}". Use smoke, constant, average-load, stress, spike, breakpoint, soak, or give explicit "stages".`);
  }
}

function resolveHeaders(h = {}) {
  const out = {}; const missing = [];
  for (const [k, v] of Object.entries(h || {})) {
    if (typeof v === 'string' && v.startsWith('env:')) { const val = process.env[v.slice(4)]; if (val == null || val === '') missing.push(v.slice(4)); else out[k] = val; } else out[k] = v;
  }
  return { headers: out, missing };
}
// Shared headers plus each request's own headers, all with "env:NAME" read from the environment.
function resolveAll(cfg) {
  const top = resolveHeaders(cfg.headers); const per = (cfg.requests || []).map((r) => resolveHeaders(r.headers));
  return { headers: top.headers, reqHeaders: per.map((x) => x.headers), missing: [...new Set([...top.missing, ...per.flatMap((x) => x.missing)])] };
}
// What gets saved: "env:NAME" placeholders stay (they hold no secret), literal values are hidden.
const redactHeaders = (h) => Object.fromEntries(Object.entries(h || {}).map(([k, v]) => [k, typeof v === 'string' && v.startsWith('env:') ? v : '<redacted>']));
const redactConfig = (cfg) => ({ ...cfg, headers: redactHeaders(cfg.headers), requests: (cfg.requests || []).map((r) => (r.headers ? { ...r, headers: redactHeaders(r.headers) } : r)) });

// "path" is appended to baseUrl, so baseUrl may carry a prefix such as /api (k6-load.js joins the same way).
// A full http(s):// URL in "path" is used as is.
function joinUrl(base, p) { return /^https?:\/\//i.test(p || '') ? p : `${String(base).replace(/\/+$/, '')}/${String(p || '').replace(/^\/+/, '')}`; }

// Mistakes in the config that would crash the run or make it measure the wrong thing.
function configProblems(cfg) {
  const p = [];
  if (!/^https?:\/\//i.test(cfg.baseUrl || '')) p.push('"baseUrl" must be a full http(s):// URL.');
  const reqs = cfg.requests || [];
  if (!reqs.length) p.push('"requests" is empty: list at least one request ({ "name": "GET /api/x", "method": "GET", "path": "/api/x" }).');
  for (const [i, r] of reqs.entries()) if (!r.name || !r.path) p.push(`requests[${i}] needs both "name" and "path".`);
  const dup = reqs.map((r) => r.name).filter((n, i, a) => n && a.indexOf(n) !== i);
  if (dup.length) p.push(`Request names must be unique (they become the per-endpoint rows): ${[...new Set(dup)].join(', ')}.`);
  for (const sc of cfg.scenarios || []) if (!TYPES.includes(sc.type)) p.push(`Scenario "${sc.name || sc.type || '?'}" needs "type": one of ${TYPES.join(', ')} (also when it has explicit "stages": the type decides the safety gate and how the report rates it, e.g. "breakpoint" for a capacity ramp).`);
  const names = (cfg.scenarios || []).map((x) => x.name || x.type);
  const dn = names.filter((n, i) => n && names.indexOf(n) !== i);
  if (dn.length) p.push(`Scenario names must be unique: ${[...new Set(dn)].join(', ')} (give each a "name").`);
  return p;
}

// Safety gate — the same rules the skill states, enforced in code so a careless config cannot slip through.
function safetyProblems(cfg, sc, connector = false) {
  const p = [];
  const env = String(cfg.environment || '').toLowerCase();
  if (!cfg.environment) p.push('config.environment is missing (local | dev | staging | production | ...).');
  if (/prod/.test(env) && !cfg.productionApproved) p.push('Production target: set "productionApproved": "<who approved, when>" only after the user explicitly approves a production load test in this conversation.');
  if (sc && HEAVY.has(sc.type) && env !== 'local' && !cfg.approvedBy) p.push(`"${sc.type}" on a shared environment (${env}) needs "approvedBy": "<who approved, when>" — it can slow the environment down for everyone.`);
  for (const r of cfg.requests || []) if (!['GET', 'HEAD', 'OPTIONS'].includes((r.method || 'GET').toUpperCase()) && !r.allowWrite) p.push(`${r.name}: ${r.method} changes data. Only load test it with "allowWrite": true after confirming it has no real-world side effects (emails, payments, notifications) and test data can be cleaned up.`);
  let peak = 0; try { if (sc) { const pl = stagesFor(sc); peak = Math.max(pl.start, ...pl.stages.map((s) => s.target)); } } catch { /* reported by configProblems */ }
  const cap = cfg.maxVUs || (connector ? 50 : 200);
  if (peak > cap) p.push(connector && !cfg.maxVUs ? `Peak of ${peak} virtual users: browser-connector mode generates load from the user's own computer, so it is capped at 50. Raise maxVUs deliberately, or run from a load machine with k6.` : `Peak of ${peak} virtual users is above maxVUs (${cap}). Raise maxVUs deliberately, or use k6 for very high load.`);
  return p;
}

// Plain-language meaning of the most common failure, so a 401 storm is not mistaken for a slow server.
function errorHint(errors, n) {
  const top = Object.entries(errors).sort((a, b) => b[1] - a[1])[0]; if (!top || !n) return null;
  const [code, count] = top; const pc = (count / n) * 100; const share = `${pc < 1 ? pc.toFixed(1) : Math.round(pc)}% of requests`;
  if (code === '401' || code === '403') return `${share} were rejected with ${code}: an authentication/permission problem (token missing, wrong or expired), not slowness. Fix the credentials and re-run.`;
  if (code === '429') return `${share} got 429 Too Many Requests: a rate limiter rejected them, quickly, before the app did the work. If real users hit this limiter, that is the finding (the limit is too low for this traffic); if you meant to test the app behind it, agree a test path or limit with the team. Never bypass it.`;
  if (/ECONNREFUSED|ENOTFOUND|EAI_AGAIN|ECONNRESET|UND_ERR_SOCKET/.test(code)) return `${share} failed with ${code}: the server was unreachable or dropped connections (down, wrong URL, or crashed under load).`;
  if (code === 'network/timeout') return `${share} got no HTTP response (timeout or connection error): the server was too slow, unreachable or dropped connections.`;
  if (code === 'timeout') return `${share} timed out: responses took longer than the timeout. That is real slowness under this load.`;
  if (/^5\d\d$/.test(code)) return `${share} returned ${code}: the server failed or shed load (overloaded, crashed, or a dependency failed).`;
  if (/^3\d\d$/.test(code)) return `${share} were redirects (${code}): usually a lost login session or a missing trailing slash.`;
  if (/^4\d\d$/.test(code)) return `${share} returned ${code}: the request itself is wrong (path, method or body).`;
  return `${share} failed with ${code}.`;
}

// rt = { now, cpu, log, headers, engine }: the runtime is passed in so the same code also runs inside a
// browser tool's sandbox (no process, no performance) in browser-connector mode.
async function runScenario(cfg, sc, rt) {
  const now = rt.now;
  const { start, stages } = stagesFor(sc);
  const total = stages.reduce((a, s) => a + s.ms, 0);
  const targetAt = (t) => { let prev = start, acc = 0; for (const s of stages) { if (t <= acc + s.ms) return prev + (s.target - prev) * (s.ms ? (t - acc) / s.ms : 1); acc += s.ms; prev = s.target; } return prev; };
  const pool = cfg.requests.flatMap((r, i) => Array(r.weight || 1).fill(i));
  const headers = rt.headers; const reqHeaders = rt.reqHeaders || [];
  const T = cfg.apdexTMs || 500, timeoutMs = cfg.timeoutMs || 10000, BUCKET = 5000;
  const think = Array.isArray(cfg.thinkTimeMs) ? cfg.thinkTimeMs : [cfg.thinkTimeMs ?? 1000, cfg.thinkTimeMs ?? 1000];
  const abort = { errorRate: sc.type === 'breakpoint' ? 0.05 : 0.1, p95Ms: sc.type === 'breakpoint' ? 5000 : 10000, ...(cfg.abort || {}), ...(sc.abort || {}) };
  const all = [], okLat = []; let fails = 0, sat = 0, tol = 0, fru = 0;
  const per = new Map(cfg.requests.map((r) => [r.name, { lat: [], fails: 0 }]));
  const errors = {}; const buckets = []; let rateLimit = null;
  const vus = new Set(); let seq = 0, want = 0, maxVUs = 0, stop = false, abortReason = null;
  const t0 = now();
  const lag = []; let last = now();
  const lagTimer = setInterval(() => { const n = now(); lag.push(Math.max(0, n - last - 100)); last = n; }, 100);
  const cpu0 = rt.cpu ? rt.cpu() : null;

  const record = (r, ms, ok, code) => {
    const tEnd = now() - t0; const b = (buckets[Math.floor(tEnd / BUCKET)] ||= { lat: [], fails: 0, vus: 0, ep: {} });
    b.lat.push(ms); b.vus = Math.max(b.vus, vus.size); (b.ep[r.name] ||= []).push(ms); all.push(ms); per.get(r.name).lat.push(ms); if (ok) okLat.push(ms);
    if (!ok) { fails++; b.fails++; per.get(r.name).fails++; errors[code] = (errors[code] || 0) + 1; fru++; } else if (ms <= T) sat++; else if (ms <= 4 * T) tol++; else fru++;
  };
  const vuLoop = async (vu) => {
    while (!stop && !vu.stop) {
      const ri = pool[Math.floor(Math.random() * pool.length)]; const r = cfg.requests[ri];
      const st = now(); let ok = false, code = 'error';
      try {
        const res = await fetch(joinUrl(cfg.baseUrl, r.path), { method: r.method || 'GET', redirect: 'manual', signal: AbortSignal.timeout(timeoutMs), headers: { ...headers, ...(r.body ? { 'content-type': 'application/json' } : {}), ...(reqHeaders[ri] || {}) }, body: r.body ? JSON.stringify(r.body) : undefined });
        await res.arrayBuffer(); code = String(res.status);
        if (res.status === 429 && !rateLimit) { rateLimit = {}; for (const [k, v] of res.headers) if (/^(retry-after|x?-?rate-?limit[\w-]*)$/i.test(k)) rateLimit[k.toLowerCase()] = v; }
        ok = r.expectStatus ? [].concat(r.expectStatus).includes(res.status) : res.status >= 200 && res.status < 300;
      } catch (e) { code = e.name === 'TimeoutError' ? 'timeout' : e.cause?.code || e.name || 'error'; }
      record(r, now() - st, ok, code);
      const w = think[0] + Math.random() * (think[1] - think[0]);
      if (!stop && !vu.stop && w > 0) await sleep(w);
    }
    vus.delete(vu);
  };

  let checked = 0;
  while (!abortReason) {
    const el = now() - t0;
    if (el >= total) break;
    want = Math.round(targetAt(el)); maxVUs = Math.max(maxVUs, want);
    const running = [...vus].filter((v) => !v.stop);
    for (let i = running.length; i < want; i++) { const v = { id: ++seq, stop: false }; vus.add(v); vuLoop(v); }
    running.slice(want).forEach((v) => { v.stop = true; });
    const done = Math.floor(el / BUCKET) - 1; // last fully finished bucket
    if (done >= checked && buckets[done]) {
      checked = done + 1;
      // Safety brake over the last 15 s (3 windows): needs 20+ requests, or 5+ requests that ALL failed
      // (slow timeouts produce few requests, but a fully failing system must still stop the test).
      const win = buckets.slice(Math.max(0, done - 2), done + 1).filter(Boolean);
      const lat = win.flatMap((b) => b.lat), nf = win.reduce((a, b) => a + b.fails, 0), vusNow = win.at(-1).vus;
      if (lat.length >= 20 || (lat.length >= 5 && nf === lat.length)) {
        const er = nf / lat.length, p95 = pct(lat, 0.95);
        if (er > abort.errorRate) abortReason = `error rate ${(er * 100).toFixed(1)}% > abort limit ${(abort.errorRate * 100).toFixed(1)}% at ~${vusNow} VUs`;
        else if (p95 > abort.p95Ms) abortReason = `p95 ${Math.round(p95)} ms > abort limit ${abort.p95Ms} ms at ~${vusNow} VUs`;
      }
    }
    if (el >= 1000 && Math.floor(el / 10000) !== Math.floor((el - 100) / 10000)) rt.log(`  t=${Math.round(el / 1000)}s vus=${want} reqs=${all.length} fails=${fails}\n`, { tSec: Math.round(el / 1000), plannedSec: Math.round(total / 1000), vus: want, requests: all.length, fails });
    await sleep(100);
  }
  stop = true;
  const w0 = now(); while (vus.size && now() - w0 < timeoutMs + 1000) await sleep(50);
  clearInterval(lagTimer);
  const dur = (now() - t0) / 1000;
  const n = all.length;
  const lagP95 = pct(lag, 0.95);
  return {
    name: sc.name || sc.type, type: sc.type || 'custom', engine: rt.engine,
    plan: { startVUs: start, stages: stages.map((s) => ({ durationSec: r1(s.ms / 1000), target: s.target })), thinkTimeMs: think, timeoutMs, apdexTMs: T, abort },
    maxVUs, durationSec: r1(dur), aborted: !!abortReason, abortReason,
    totals: { requests: n, rps: r1(n / dur), failedRate: n ? fails / n : null, avg: n ? r1(all.reduce((a, x) => a + x, 0) / n) : null, p50: r1(pct(all, 0.5)), p90: r1(pct(all, 0.9)), p95: r1(pct(all, 0.95)), p99: r1(pct(all, 0.99)), max: r1(n ? Math.max(...all) : null), okP50: r1(pct(okLat, 0.5)), okP95: r1(pct(okLat, 0.95)), apdex: n ? { score: Math.round(((sat + tol / 2) / n) * 1000) / 1000, T, satisfied: sat, tolerating: tol, frustrated: fru } : null },
    endpoints: cfg.requests.map((r) => { const e = per.get(r.name); const k = e.lat.length; return { name: r.name, method: r.method || 'GET', path: r.path, requests: k, failedRate: k ? e.fails / k : null, p50: r1(pct(e.lat, 0.5)), p95: r1(pct(e.lat, 0.95)), p99: r1(pct(e.lat, 0.99)), max: r1(k ? Math.max(...e.lat) : null) }; }),
    errors,
    timeline: buckets.map((b, i) => (b ? { tSec: (i + 1) * (BUCKET / 1000), vus: b.vus, requests: b.lat.length, rps: r1(b.lat.length / (BUCKET / 1000)), p95: r1(pct(b.lat, 0.95)), failedRate: b.lat.length ? b.fails / b.lat.length : null, endpointsP95: Object.fromEntries(Object.entries(b.ep).map(([k, v]) => [k, r1(pct(v, 0.95))])), endpointsN: Object.fromEntries(Object.entries(b.ep).map(([k, v]) => [k, v.length])) } : null)).filter(Boolean),
    generator: (() => { const c = cpu0 ? rt.cpu(cpu0) : null; const cpuPct = c ? Math.round(((c.user + c.system) / 1000 / (dur * 1000)) * 100) : null; return { eventLoopLagP95Ms: r1(lagP95), cpuPct, saturated: lagP95 > 50 || cpuPct > 85, note: lagP95 > 20 ? `the busy load generator added about ${Math.round(lagP95)} ms to measured times (95th percentile)` : null }; })(),
    errorHint: errorHint(errors, n),
    rateLimit: rateLimit && Object.keys(rateLimit).length ? rateLimit : undefined,
  };
}

// k6 summaries come in two shapes: legacy ({ metrics: { name: { values, thresholds } }, state }) and the newer
// machine-readable one ({ results: { metrics: [ { name, values } ] }, config: { duration } }). Read both.
function k6MetricMap(summary) {
  if (summary.metrics && !Array.isArray(summary.metrics)) return summary.metrics;
  const out = {};
  for (const m of summary.results?.metrics || summary.metrics || []) {
    const tags = m.tags && Object.keys(m.tags).length ? `{${Object.entries(m.tags).map(([k, x]) => `${k}:${x}`).join(',')}}` : '';
    out[`${m.name}${tags}`] = m;
  }
  return out;
}

// Optional k6 CSV output (--out csv=...) -> the same 5-second timeline the Node engine records.
async function k6CsvTimeline(file, cfg) {
  const { createInterface } = await import('node:readline');
  const rl = createInterface({ input: fs.createReadStream(file), crlfDelay: Infinity });
  let cols = null, t0 = null; const buckets = [];
  const ts = (x) => { const n = Number(x); return Number.isFinite(n) ? (n > 1e12 ? n / 1000 : n) : Date.parse(x) / 1000; };
  for await (const line of rl) {
    if (!line) continue;
    const f = line.split(',');
    if (!cols) { cols = Object.fromEntries(f.map((c, i) => [c.trim(), i])); continue; }
    const metric = f[cols.metric_name];
    if (metric !== 'http_req_duration' && metric !== 'vus') continue;
    const t = ts(f[cols.timestamp]); if (!Number.isFinite(t)) continue;
    if (t0 == null) t0 = t;
    const b = (buckets[Math.floor((t - t0) / 5)] ||= { lat: [], fails: 0, vus: 0, ep: {} });
    const val = Number(f[cols.metric_value]);
    if (metric === 'vus') { b.vus = Math.max(b.vus, val); continue; }
    b.lat.push(val);
    if (cols.expected_response != null && f[cols.expected_response] === 'false') b.fails++;
    const name = cols.name != null ? f[cols.name] : null; if (name) (b.ep[name] ||= []).push(val);
  }
  let lastVus = 0;
  return buckets.map((b, i) => { if (!b) return null; if (b.vus) lastVus = b.vus; return { tSec: (i + 1) * 5, vus: b.vus || lastVus, requests: b.lat.length, rps: r1(b.lat.length / 5), p95: r1(pct(b.lat, 0.95)), failedRate: b.lat.length ? b.fails / b.lat.length : null, endpointsP95: Object.fromEntries(Object.entries(b.ep).map(([k, v]) => [k, r1(pct(v, 0.95))])), endpointsN: Object.fromEntries(Object.entries(b.ep).map(([k, v]) => [k, v.length])) }; }).filter((b) => b && b.requests);
}

async function fromK6(summary, cfg, scName, csvFile) {
  const m = k6MetricMap(summary); const v = (k, f) => m[k]?.values?.[f] ?? null;
  if (v('http_reqs', 'count') == null) throw new Error('Unrecognised k6 summary: no http_reqs count found. Check the file is the PERF_SUMMARY written by k6-load.js; if k6 changed its format, use the Node engine for this run and say so in the report.');
  const sc = (cfg.scenarios || []).find((s) => (s.name || s.type) === scName) || { type: 'custom' };
  const { start, stages } = stagesFor(sc);
  const planned = stages.reduce((a, s) => a + s.ms, 0) / 1000;
  const dur = summary.state?.testRunDurationMs != null ? summary.state.testRunDurationMs / 1000 : summary.config?.duration ?? planned;
  const s = v('apdex_satisfied', 'count') || 0, t = v('apdex_tolerating', 'count') || 0, f = v('apdex_frustrated', 'count') || 0, n = v('http_reqs', 'count') || 0;
  const thresholds = Object.entries(m).flatMap(([k, mm]) => { const th = mm.thresholds; if (!th) return []; return Array.isArray(th) ? th.map((x) => ({ metric: k, threshold: x.source || x.expression || x.name, ok: x.ok ?? x.passed })) : Object.entries(th).map(([e, r]) => ({ metric: k, threshold: e, ok: r.ok })); });
  const failedThresholds = thresholds.filter((x) => x.ok === false);
  const aborted = dur < planned - 5;
  const errors = {};
  for (const k of ['network', '3xx', '401', '403', '404', '429', '4xx', '500', '502', '503', '504', '5xx', 'unexpected']) { const c = v(`err_${k}`, 'count'); if (c) errors[k === 'network' ? 'network/timeout' : k] = c; }
  const timeline = csvFile ? await k6CsvTimeline(csvFile, cfg) : [];
  return {
    name: scName, type: sc.type || 'custom', engine: `k6${cfg.k6Version ? ` ${cfg.k6Version}` : ''}`,
    plan: { startVUs: start, stages: stages.map((x) => ({ durationSec: r1(x.ms / 1000), target: x.target })), thinkTimeMs: Array.isArray(cfg.thinkTimeMs) ? cfg.thinkTimeMs : [cfg.thinkTimeMs ?? 1000, cfg.thinkTimeMs ?? 1000], timeoutMs: cfg.timeoutMs || 10000, apdexTMs: cfg.apdexTMs || 500 },
    maxVUs: v('vus_max', 'max') ?? v('vus_max', 'value'), durationSec: r1(dur),
    aborted, abortReason: aborted ? `k6 stopped early by the safety brake${failedThresholds.length ? `: ${failedThresholds.map((x) => `${x.metric} ${x.threshold}`).join(', ')}` : ''}` : null,
    totals: { requests: n, rps: r1(v('http_reqs', 'rate') ?? n / dur), failedRate: v('http_req_failed', 'rate'), avg: r1(v('http_req_duration', 'avg')), p50: r1(v('http_req_duration', 'med')), p90: r1(v('http_req_duration', 'p(90)')), p95: r1(v('http_req_duration', 'p(95)')), p99: r1(v('http_req_duration', 'p(99)')), max: r1(v('http_req_duration', 'max')), apdex: s + t + f ? { score: Math.round(((s + t / 2) / (s + t + f)) * 1000) / 1000, T: cfg.apdexTMs || 500, satisfied: s, tolerating: t, frustrated: f } : null },
    endpoints: cfg.requests.map((r, i) => { const d = m[`ep${i}_duration`]?.values; return d ? { name: r.name, method: r.method || 'GET', path: r.path, requests: d.count ?? null, failedRate: v(`ep${i}_failed`, 'rate'), p50: r1(d.med), p95: r1(d['p(95)']), p99: r1(d['p(99)']), max: r1(d.max) } : null; }).filter(Boolean),
    errors, timeline, thresholds, errorHint: errorHint(errors, n),
    generator: { droppedIterations: v('dropped_iterations', 'count') || 0, saturated: (v('dropped_iterations', 'count') || 0) > 0 },
  };
}

// One request per GET endpoint (never anything that changes data) to catch wrong paths and auth before the test.
async function checkEndpoints(cfg, headers, reqHeaders = []) {
  const why = (c) => (/^40[13]$/.test(c) ? 'authentication/permission problem (token missing, wrong or expired)' : c === '429' ? 'rate limited' : c === '404' ? 'not found: check the path' : /^5/.test(c) ? 'server error' : /^3/.test(c) ? 'redirect (often a lost login or a missing trailing slash)' : /^4/.test(c) ? 'the request is wrong (path, method or body)' : c === 'timeout' ? 'no answer within the timeout' : 'unreachable or the connection dropped');
  const out = {};
  for (const [i, r] of (cfg.requests || []).entries()) {
    const m = (r.method || 'GET').toUpperCase();
    if (!['GET', 'HEAD'].includes(m)) { out[r.name] = `skipped (${m} changes data, so it is first sent by the smoke test)`; continue; }
    const t = Date.now();
    try {
      const res = await fetch(joinUrl(cfg.baseUrl, r.path), { method: m, redirect: 'manual', signal: AbortSignal.timeout(cfg.timeoutMs || 10000), headers: { ...headers, ...(reqHeaders[i] || {}) } });
      await res.arrayBuffer();
      const ok = r.expectStatus ? [].concat(r.expectStatus).includes(res.status) : res.status >= 200 && res.status < 300;
      out[r.name] = ok ? `ok (HTTP ${res.status}, ${Date.now() - t} ms)` : `FAILED: HTTP ${res.status} — ${why(String(res.status))}`;
    } catch (e) { const c = e.name === 'TimeoutError' ? 'timeout' : (e.cause && e.cause.code) || e.name || 'error'; out[r.name] = `FAILED: ${c} — ${why(c)}`; }
  }
  return out;
}

// ---------- Browser-connector mode ----------
// The load runs inside a Playwright browser tool on the user's computer (its "run code" action), using that
// tool's Node fetch. The sandbox has no file system and must answer within about a minute, so the job starts in
// the background and saves its files through browser downloads. These functions are copied into the job file
// as source text, so they may only use what that sandbox has.
function toB64(text) { return typeof Buffer !== 'undefined' ? Buffer.from(text, 'utf8').toString('base64') : btoa(unescape(encodeURIComponent(text))); }
function makeSaver(browser) {
  let ctx = null, pg = null, chain = Promise.resolve();
  const save = (abs, b64, mime) => (chain = chain.catch(() => {}).then(async () => {
    if (!pg) { ctx = await browser.newContext({ acceptDownloads: true }); pg = await ctx.newPage(); await pg.setContent('<a id="d" download="f">f</a>'); }
    await pg.evaluate(([d, m]) => { const bin = atob(d); const u = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i); const a = document.getElementById('d'); if (a.href) URL.revokeObjectURL(a.href); a.href = URL.createObjectURL(new Blob([u], { type: m })); }, [b64, mime || 'application/octet-stream']);
    const [dl] = await Promise.all([pg.waitForEvent('download'), pg.click('#d')]);
    await dl.saveAs(abs); await dl.delete().catch(() => {});
  }));
  return { save, saveJson: (abs, obj) => save(abs, toB64(JSON.stringify(obj, null, 2)), 'application/json'), close: async () => { await chain.catch(() => {}); if (ctx) await ctx.close().catch(() => {}); } };
}
async function runLoadJob(page, J) {
  const browser = page.context().browser();
  if (!browser) return { started: false, error: 'This browser tool uses one persistent profile and cannot save files. Start it in isolated mode (e.g. --isolated) or run the scripts on a machine that can reach the target.' };
  const G = browser; // the browser object outlives each run-code call (a call's own globals do not)
  if (G.__perfKitJob && !G.__perfKitJob.done && Date.now() - G.__perfKitJob.at < 3 * 3600e3) return { started: false, alreadyRunning: G.__perfKitJob.id, note: 'Another perf-kit job is still running in this browser. Wait for it (poll --collect-mcp) instead of starting a second one: two at once distort each other.' };
  const job = (G.__perfKitJob = { id: J.id, at: Date.now(), done: false });
  const saver = makeSaver(browser);
  const mcp = `${J.outDir}/mcp`;
  const scrub = () => saver.save(J.jobFile, toB64(`// perf-kit job ${J.id} finished ${new Date().toISOString()}. Its contents were removed because they included resolved request headers.\n`), 'text/javascript').catch(() => {});
  try { await saver.saveJson(`${mcp}/${J.prefix}-started.json`, { jobId: J.id, startedAt: new Date().toISOString(), plannedSec: J.plannedSec }); } catch (e) {
    await scrub(); await saver.close(); job.done = true;
    return { started: false, error: `Could not write into ${mcp} on this computer (${String(e.message || e).split('\n')[0]}). Check that --map points at the same folder on the user's computer.` };
  }
  (async () => {
    if (J.preflight) {
      const out = { jobId: J.id };
      try { const r = await fetch(J.cfg.baseUrl, { redirect: 'manual', signal: AbortSignal.timeout(15000) }); out.target = `${J.cfg.baseUrl} reachable from the user's computer (HTTP ${r.status})${r.status >= 300 ? ' — the base address itself answers like this, which is fine; the endpoint checks below test the real paths' : ''}`; } catch (e) { out.target = `UNREACHABLE from the user's computer: ${(e.cause && e.cause.code) || e.message}`; }
      if (!/UNREACHABLE/.test(out.target)) out.endpoints = await checkEndpoints(J.cfg, J.headers, J.reqHeaders);
      await saver.saveJson(`${mcp}/${J.prefix}-done.json`, out);
      return;
    }
    let lastSave = Date.now();
    const rt = { now: Date.now, cpu: null, headers: J.headers, reqHeaders: J.reqHeaders, engine: 'perf-kit load-gen (Playwright browser tool on the user\'s computer, Node fetch)',
      log: (s, p) => { if (p && Date.now() - lastSave >= 30000) { lastSave = Date.now(); saver.saveJson(`${mcp}/${J.prefix}-progress.json`, { ...p, jobId: J.id }).catch(() => {}); } } };
    const res = await runScenario(J.cfg, J.sc, rt);
    await saver.saveJson(`${mcp}/${J.prefix}-done.json`, { ...res, jobId: J.id });
  })().catch((e) => saver.saveJson(`${mcp}/${J.prefix}-error.json`, { jobId: J.id, error: String((e && e.stack) || e) }).catch(() => {}))
    .finally(async () => { await scrub(); await saver.close(); job.done = true; });
  return { started: true, id: J.id, plannedSec: J.plannedSec, poll: 'Do not run this file again. Poll with: node .perf-kit/load-gen.mjs --collect-mcp ... (exit 5 = still running)' };
}

// Writes the job and a tiny loader for it. Running the loader keeps the browser tool's echo of the call short
// (it prints the code it ran); the loader reads the job file through the browser and runs it. The job file is a
// complete job too: run it directly if the browser tool cannot open local files.
function writeJob(dir, prefix, core, host) {
  const ascii = (s) => s.replace(/[^\t\n\r -~]/g, (c) => `\\u${c.charCodeAt(0).toString(16).padStart(4, '0')}`);
  const coreFile = path.join(dir, `job-${prefix}.core.js`), loader = path.join(dir, `job-${prefix}.js`);
  fs.writeFileSync(coreFile, ascii(core), { mode: 0o600 });
  const hp = host(coreFile).split(/[\\/]/).map((s, i) => (i === 0 && /^[A-Za-z]:$/.test(s) ? s : encodeURIComponent(s))).join('/');
  const url = `file://${hp.startsWith('/') ? '' : '/'}${hp}`;
  fs.writeFileSync(loader, `async (page) => {
// perf-kit loader: reads job-${prefix}.core.js through the browser and starts it. Run this file ONCE.
const fallback = { started: false, runInstead: ${JSON.stringify(host(coreFile))} };
const b = page.context().browser(); if (!b) return { ...fallback, error: 'no separate browser sessions available' };
const ctx = await b.newContext(); let src;
try { const p = await ctx.newPage(); await p.goto(${JSON.stringify(url)}); src = await p.evaluate(() => { const pre = document.querySelector('pre'); return pre ? pre.textContent : document.body.textContent; }); }
catch (e) { return { ...fallback, error: 'could not read the job file: ' + String(e.message).split('\\n')[0] }; } finally { await ctx.close(); }
let job; try { job = (0, eval)('(' + src + ')'); } catch (e) { return { ...fallback, error: 'could not load the job: ' + e.message }; }
return job(page);
}
`);
  return { loader, coreFile };
}

function hostPathFn(map) {
  if (!map) return (p) => path.resolve(p);
  const i = map.lastIndexOf('='); if (i < 1) throw new Error('--map needs <folder here>=<same folder on the user\'s computer>');
  const real = (p) => { try { return fs.realpathSync(p); } catch { return path.resolve(p); } };
  const from = real(map.slice(0, i)), to = map.slice(i + 1).replace(/[\\/]+$/, '');
  return (p) => { const abs = real(p); if (abs !== from && !abs.startsWith(from + path.sep)) throw new Error(`${abs} is not inside ${from}; keep the run folder inside the connected folder`); return to + abs.slice(from.length).split(path.sep).join('/'); };
}

// Overwrites a job file that held resolved headers (the job also does this itself when it finishes).
function scrubJob(file) { if (fs.existsSync(file) && !/^\/\/ perf-kit job .* finished/.test(fs.readFileSync(file, 'utf8'))) fs.writeFileSync(file, '// perf-kit job file removed after collection: it contained resolved request headers.\n'); }

// Status of a browser-connector job from the files it has written. Exit 5 = still running.
// Files are matched to the current job by jobId: old files are overwritten, never deleted (connected folders
// often forbid deleting).
function mcpStatus(dir, prefix, stallMin) {
  const f = (n) => path.join(dir, n);
  const read = (n) => { try { return JSON.parse(fs.readFileSync(f(n), 'utf8')); } catch { return null; } };
  const cur = read(`${prefix}-current.json`)?.jobId;
  if (!cur) { console.error(`No job was emitted in ${dir}: run --emit-mcp first.`); process.exit(2); }
  const mine = (n) => { const j = read(n); return j && j.jobId === cur ? j : null; };
  const age = (t) => Math.round((Date.now() - t) / 1000);
  const core = f(`job-${prefix}.core.js`);
  const err = mine(`${prefix}-error.json`);
  if (err) { scrubJob(core); console.error(`The job failed on the user's computer:\n${err.error}`); process.exit(1); }
  const done = mine(`${prefix}-done.json`);
  if (done) { delete done.jobId; return done; }
  const started = mine(`${prefix}-started.json`);
  if (!started) {
    const jobT = fs.existsSync(f(`job-${prefix}.js`)) ? fs.statSync(f(`job-${prefix}.js`)).mtimeMs : null;
    console.log(jobT && age(jobT) > 120 ? `NOT STARTED: job-${prefix}.js was written ${age(jobT)} s ago and has not started. Run it once with the browser tool (run code, filename = the job file's path on the user's computer). If the tool answered started:false, fix what it says first.` : 'waiting for the job to start…');
    if (jobT && age(jobT) > 600) { scrubJob(core); process.exit(1); }
    process.exit(5);
  }
  const prog = mine(`${prefix}-progress.json`);
  const last = Math.max(Date.parse(started.startedAt), ...[`${prefix}-started.json`, prog ? `${prefix}-progress.json` : null].filter(Boolean).map((n) => fs.statSync(f(n)).mtimeMs));
  const elapsed = age(Date.parse(started.startedAt));
  if (age(last) > stallMin * 60 && elapsed > (started.plannedSec || 0) + stallMin * 60) { scrubJob(core); console.error(`STALLED: no news for ${Math.round(age(last) / 60)} min (planned ${started.plannedSec || '?'} s). The browser was probably closed or the computer slept. Re-emit and run the job again.`); process.exit(1); }
  console.log(`running: ${elapsed} s of ~${started.plannedSec || '?'} s planned${prog ? ` — at ${prog.tSec} s: ${prog.vus} users, ${prog.requests} requests, ${prog.fails} failed` : ''}`);
  process.exit(5);
}

async function main() {
  const cfgPath = arg('config');
  if (!cfgPath) { console.error('Missing --config <load-config.json>'); process.exit(2); }
  const cfg = JSON.parse(fs.readFileSync(cfgPath, 'utf8'));
  const scName = arg('scenario');
  const sc = scName ? (cfg.scenarios || []).find((s) => (s.name || s.type) === scName) : null;
  if (scName && !sc) { console.error(`Scenario "${scName}" not in config. Available: ${(cfg.scenarios || []).map((s) => s.name || s.type).join(', ')}`); process.exit(2); }
  const connector = flag('emit-mcp') || flag('collect-mcp');
  const outDir = path.resolve(arg('out', '.'));
  const rel = (p) => path.relative(process.cwd(), p) || '.';
  const cmdLine = () => `node ${rel(process.argv[1])} ${args.map((a) => (/\s/.test(a) ? JSON.stringify(a) : a)).join(' ')}`;
  const cfgErr = configProblems(cfg);
  if (cfgErr.length && !flag('collect-mcp') && !(flag('preflight') && !flag('emit-mcp'))) { console.error(`Config problems (fix load-config.json):\n- ${cfgErr.join('\n- ')}`); process.exit(2); }
  const safetyList = () => { const s = [...new Set((cfg.scenarios || []).flatMap((x) => safetyProblems(cfg, x, connector).map((p) => `[${x.name || x.type}] ${p}`)))]; return s.length ? s : 'ok'; };

  if (flag('emit-mcp')) {
    const preflight = flag('preflight');
    if (!preflight && !sc) { console.error('Missing --scenario <name>'); process.exit(2); }
    if (!preflight) { const problems = safetyProblems(cfg, sc, true); if (problems.length) { console.error(`BLOCKED by safety gate:\n- ${problems.join('\n- ')}`); process.exit(3); } }
    const { headers, reqHeaders, missing } = resolveAll(cfg);
    if (missing.length) { console.error(`Missing env vars for headers: ${missing.join(', ')}`); process.exit(2); }
    const host = hostPathFn(arg('map'));
    const dir = path.join(outDir, 'mcp'); fs.mkdirSync(dir, { recursive: true });
    const prefix = preflight ? 'load-preflight' : `load-${String(sc.name || sc.type).replace(/[^A-Za-z0-9_-]+/g, '-')}`;
    const coreFile = path.join(dir, `job-${prefix}.core.js`);
    const plannedSec = preflight ? 30 : Math.round(stagesFor(sc).stages.reduce((a, s) => a + s.ms, 0) / 1000);
    const J = { id: `${prefix}-${Date.now().toString(36)}`, prefix, preflight, outDir: host(outDir), jobFile: host(coreFile), plannedSec, cfg, sc, headers, reqHeaders };
    const fns = [pct, r1, sleep, parseDur, stagesFor, joinUrl, errorHint, checkEndpoints, toB64, makeSaver, runScenario, runLoadJob];
    const body = [`// perf-kit:load-gen browser-connector job (${prefix}), generated ${new Date().toISOString()} from ${rel(cfgPath)}.`,
      '// Run it ONCE with the Playwright browser tool (run code, filename = this file). It answers at once and keeps working in the background.',
      '// It holds resolved request headers until it finishes; then it overwrites itself.',
      `const DEFAULT_DURATION = ${JSON.stringify(DEFAULT_DURATION)};`,
      ...fns.map((fn) => (/^(async\s+)?function\b/.test(String(fn)) ? String(fn) : `const ${fn.name} = ${fn};`)), `const J = ${JSON.stringify(J)};`, 'return runLoadJob(page, J);'];
    let hostCwd = process.cwd(); try { hostCwd = host(process.cwd()); } catch {}
    fs.writeFileSync(path.join(dir, `${prefix}-current.json`), JSON.stringify({ jobId: J.id, emittedAt: new Date().toISOString(), emitCommand: cmdLine(), hostCwd }));
    const { loader } = writeJob(dir, prefix, `async (page) => {\n${body.join('\n')}\n}\n`, host);
    console.log(JSON.stringify({ jobFile: rel(loader), runWith: { tool: 'Playwright browser tool → run code (browser_run_code_unsafe)', filename: host(loader), ifItAnswersRunInstead: host(coreFile) }, plannedSeconds: plannedSec, note: Object.keys(headers).length ? 'The job file holds the resolved header values until it finishes; it then overwrites itself, and --collect-mcp checks that.' : undefined, then: `node ${rel(process.argv[1])} ${preflight ? '--preflight ' : ''}--collect-mcp --config ${rel(cfgPath)}${preflight ? '' : ` --scenario ${scName}`} --out ${rel(outDir)}` }, null, 2));
    return;
  }

  if (flag('preflight')) {
    let out;
    if (flag('collect-mcp')) {
      const r = mcpStatus(path.join(outDir, 'mcp'), 'load-preflight', 3);
      scrubJob(path.join(outDir, 'mcp', 'job-load-preflight.core.js'));
      out = { runner: 'browser tool on the user\'s computer', target: r.target, endpoints: r.endpoints || 'not checked' };
    } else {
      const k6 = spawnSync('k6', ['version'], { encoding: 'utf8' });
      out = { node: process.version, fetch: typeof fetch === 'function' ? 'ok' : 'MISSING (need Node 18+)', k6: k6.status === 0 ? k6.stdout.trim() : 'not installed (Node engine will be used)' };
      try { const r = await fetch(cfg.baseUrl, { method: 'GET', redirect: 'manual', signal: AbortSignal.timeout(15000) }); out.target = `${cfg.baseUrl} reachable (HTTP ${r.status})${r.status >= 300 ? ' — the base address itself answers like this, which is fine; the endpoint checks below test the real paths' : ''}`; } catch (e) { out.target = `UNREACHABLE: ${e.cause?.code || e.message}`; }
    }
    if (flag('collect-mcp')) out.headers = 'checked when the job was emitted';
    else {
      out.config = cfgErr.length ? cfgErr : 'ok';
      const { headers, reqHeaders, missing } = resolveAll(cfg);
      out.headers = missing.length ? `MISSING env vars: ${missing.join(', ')}` : 'ok';
      if (!out.target.startsWith('UNREACHABLE') && !missing.length && !cfgErr.length) out.endpoints = await checkEndpoints(cfg, headers, reqHeaders);
    }
    out.safety = safetyList();
    console.log(JSON.stringify(out, null, 2));
    // Judge each line on its own (endpoint names or URLs may contain words like "failed").
    const failed = [out.fetch, out.target, out.headers].some((x) => /^(MISSING|UNREACHABLE)/.test(String(x || ''))) || (out.config && out.config !== 'ok') || (isObj(out.endpoints) && Object.values(out.endpoints).some((v) => String(v).startsWith('FAILED'))) || out.safety !== 'ok';
    process.exit(failed ? 1 : 0);
  }
  if (!sc) { console.error('Missing --scenario <name>'); process.exit(2); }

  fs.mkdirSync(outDir, { recursive: true });
  const file = path.join(outDir, 'load-results.json');
  const results = fs.existsSync(file) ? JSON.parse(fs.readFileSync(file, 'utf8')) : { schema: 'perf-results/1', kind: 'load', label: cfg.label || cfg.baseUrl, target: cfg.baseUrl, environment: cfg.environment, startedAt: new Date().toISOString(), scenarios: [], notes: [] };

  let res;
  const say = (r) => { console.log(`  done: ${r.totals.requests} reqs, ${r.totals.rps}/s, p95 ${r.totals.p95} ms, errors ${((r.totals.failedRate || 0) * 100).toFixed(2)}%${r.aborted ? `  ⛔ ABORTED: ${r.abortReason}` : ''}${r.generator?.saturated ? '  ⚠ load generator saturated' : ''}`); if (r.errorHint) console.log(`  hint: ${r.errorHint}`); };
  if (flag('collect-mcp')) {
    const prefix = `load-${String(sc.name || sc.type).replace(/[^A-Za-z0-9_-]+/g, '-')}`;
    res = mcpStatus(path.join(outDir, 'mcp'), prefix, 5);
    scrubJob(path.join(outDir, 'mcp', `job-${prefix}.core.js`));
    const em = JSON.parse(fs.readFileSync(path.join(outDir, 'mcp', `${prefix}-current.json`), 'utf8'));
    Object.assign(res, { runner: 'browser-connector', cwdLocal: process.cwd(), hostCwd: em.hostCwd, emitCommand: em.emitCommand, jobLoader: rel(path.join(outDir, 'mcp', `job-${prefix}.js`)) });
    console.log(`▶ ${sc.name || sc.type} against ${cfg.baseUrl} (${cfg.environment}) — run by the browser tool on the user's computer`); say(res);
  } else if (arg('from-k6')) {
    res = await fromK6(JSON.parse(fs.readFileSync(arg('from-k6'), 'utf8')), cfg, scName, arg('k6-csv'));
    say(res);
  } else {
    const problems = safetyProblems(cfg, sc);
    if (problems.length) { console.error(`BLOCKED by safety gate:\n- ${problems.join('\n- ')}`); process.exit(3); }
    const { headers, reqHeaders, missing } = resolveAll(cfg);
    if (missing.length) { console.error(`Missing env vars for headers: ${missing.join(', ')}`); process.exit(2); }
    console.log(`▶ ${sc.name || sc.type} against ${cfg.baseUrl} (${cfg.environment})`);
    res = await runScenario(cfg, sc, { now: () => performance.now(), cpu: (prev) => process.cpuUsage(prev), log: (s) => process.stdout.write(s), headers, reqHeaders, engine: `perf-kit load-gen (Node ${process.version} fetch)` });
    say(res);
  }
  res.cwd = res.hostCwd || process.cwd();
  res.command = res.emitCommand ? `${res.emitCommand.replace(/--map ("(?:[^"\\]|\\.)*"|\S+)/, (a, v) => { const x = v.startsWith('"') ? JSON.parse(v) : v; return `--map ${JSON.stringify(`<folder here>=${x.slice(x.lastIndexOf('=') + 1)}`)}`; })}\n# then run ${res.jobLoader} once with the Playwright browser tool (run code), and collect:\n${cmdLine()}` : cmdLine();
  for (const k of ['hostCwd', 'emitCommand', 'jobLoader']) delete res[k];
  res.finishedAt = res.finishedAt || new Date().toISOString();
  results.config = redactConfig(cfg);
  results.assumptions = cfg.assumptions || [];
  res.mix = cfg.requests.map((r) => ({ name: r.name, weight: r.weight || 1 }));
  results.scenarios = results.scenarios.filter((s) => s.name !== res.name).concat(res);
  fs.writeFileSync(file, JSON.stringify(results, null, 2));
  console.log(`Saved ${file}`);
  process.exit(res.aborted ? 4 : 0);
}
main().catch((e) => { console.error(String(e?.stack || e).split('\n').slice(0, 3).join('\n')); process.exit(1); });
````

## k6-load.js

````js
// perf-kit:k6-load v4 — k6 script driven by the same load-config.json as load-gen.mjs.
// k6 resolves relative file paths from THIS script's folder, so pass absolute paths:
//   k6 run -e PERF_CONFIG="$PWD/<run-dir>/load-config.json" -e PERF_SCENARIO=<name> \
//          -e PERF_SUMMARY="$PWD/<run-dir>/k6-<name>.json" --out csv="<run-dir>/k6-<name>.csv" .perf-kit/k6-load.js
// Then:  node .perf-kit/load-gen.mjs --from-k6 <run-dir>/k6-<name>.json --k6-csv <run-dir>/k6-<name>.csv \
//          --config <run-dir>/load-config.json --scenario <name> --out <run-dir>
// Per-endpoint numbers and error types are recorded as plain custom metrics (ep0_duration, err_503, ...), so the
// converter works with both the legacy and the newer machine-readable k6 summary formats.
import http from 'k6/http';
import { sleep } from 'k6';
import { Counter, Rate, Trend } from 'k6/metrics';

const isAbs = (p) => /^([A-Za-z]:)?[\\/]/.test(p || '');
if (!isAbs(__ENV.PERF_CONFIG)) throw new Error(`PERF_CONFIG must be an absolute path (got "${__ENV.PERF_CONFIG}"): k6 resolves relative paths from the script folder. Use -e PERF_CONFIG="$PWD/<run-dir>/load-config.json"`);
const cfg = JSON.parse(open(__ENV.PERF_CONFIG));
const sc = cfg.scenarios.find((s) => (s.name || s.type) === __ENV.PERF_SCENARIO);
if (!sc) throw new Error(`Scenario ${__ENV.PERF_SCENARIO} not found in ${__ENV.PERF_CONFIG}`);

const DEFAULT_DURATION = { smoke: '30s', constant: '1m', 'average-load': '5m', stress: '10m', spike: '3m', breakpoint: '10m', soak: '1h' };
const parseDur = (s) => { const m = /^(\d+(?:\.\d+)?)(ms|s|m|h)$/.exec(String(s).trim()); if (!m) throw new Error(`Bad duration "${s}" (use 30s, 5m, 1h)`); return +m[1] * { ms: 1, s: 1000, m: 60000, h: 3600000 }[m[2]]; };
// Same stage shapes as load-gen.mjs (keep in sync).
function stagesFor(s) {
  if (s.stages) return { start: s.startVUs || 0, stages: s.stages.map((x) => ({ ms: parseDur(x.duration), target: x.target })) };
  const N = s.vus || (s.type === 'smoke' ? 2 : 10);
  const D = parseDur(s.duration || DEFAULT_DURATION[s.type] || '1m');
  if (s.type === 'smoke') return { start: N, stages: [{ ms: D, target: N }] };
  if (s.type === 'constant') { const up = s.rampUp ? parseDur(s.rampUp) : Math.min(5000, D * 0.1); return { start: 0, stages: [{ ms: up, target: N }, { ms: D, target: N }] }; }
  if (s.type === 'average-load' || s.type === 'soak') return { start: 0, stages: [{ ms: D * 0.15, target: N }, { ms: D * 0.75, target: N }, { ms: D * 0.1, target: 0 }] };
  if (s.type === 'stress') { const P = s.peakVUs || N * 2; return { start: 0, stages: [{ ms: D * 0.15, target: N }, { ms: D * 0.15, target: P }, { ms: D * 0.6, target: P }, { ms: D * 0.1, target: 0 }] }; }
  if (s.type === 'spike') { const P = s.peakVUs || N * 5; return { start: N, stages: [{ ms: D * 0.25, target: N }, { ms: D * 0.05, target: P }, { ms: D * 0.3, target: P }, { ms: D * 0.05, target: N }, { ms: D * 0.35, target: N }] }; }
  if (s.type === 'breakpoint') return { start: 0, stages: [{ ms: D, target: s.peakVUs || N * 10 }] };
  throw new Error(`Unknown scenario type ${s.type}`);
}
// Safety gate and config checks, the same rules as load-gen.mjs: k6 can be started without the preflight, so it
// checks them itself and refuses to start (k6 exits with code 107) when one fails.
const TYPES = Object.keys(DEFAULT_DURATION);
const env = String(cfg.environment || '').toLowerCase();
const problems = [];
if (!TYPES.includes(sc.type)) problems.push(`Scenario "${sc.name || sc.type || '?'}" needs "type": one of ${TYPES.join(', ')}.`);
if (!/^https?:\/\//i.test(cfg.baseUrl || '')) problems.push('"baseUrl" must be a full http(s):// URL.');
if (!(cfg.requests || []).length) problems.push('"requests" is empty.');
for (const [i, r] of (cfg.requests || []).entries()) if (!r.name || !r.path) problems.push(`requests[${i}] needs both "name" and "path".`);
const dupOf = (xs) => [...new Set(xs.filter((n, i) => n && xs.indexOf(n) !== i))];
if (dupOf((cfg.requests || []).map((r) => r.name)).length) problems.push(`Request names must be unique: ${dupOf((cfg.requests || []).map((r) => r.name)).join(', ')}.`);
if (dupOf((cfg.scenarios || []).map((x) => x.name || x.type)).length) problems.push(`Scenario names must be unique: ${dupOf((cfg.scenarios || []).map((x) => x.name || x.type)).join(', ')}.`);
if (!cfg.environment) problems.push('config.environment is missing (local | dev | staging | production | ...).');
if (/prod/.test(env) && !cfg.productionApproved) problems.push('Production target: set "productionApproved": "<who approved, when>" only after the user explicitly approves a production load test in this conversation.');
if (['stress', 'spike', 'breakpoint', 'soak'].includes(sc.type) && env !== 'local' && !cfg.approvedBy) problems.push(`"${sc.type}" on a shared environment (${env}) needs "approvedBy": "<who approved, when>" - it can slow the environment down for everyone.`);
for (const r of cfg.requests || []) if (!['GET', 'HEAD', 'OPTIONS'].includes((r.method || 'GET').toUpperCase()) && !r.allowWrite) problems.push(`${r.name}: ${r.method} changes data. Only load test it with "allowWrite": true after confirming it has no real-world side effects.`);
if (problems.length) throw new Error(`BLOCKED by safety gate:\n- ${problems.join('\n- ')}`);

const plan = stagesFor(sc);
const abort = { errorRate: sc.type === 'breakpoint' ? 0.05 : 0.1, p95Ms: sc.type === 'breakpoint' ? 5000 : 10000, ...(cfg.abort || {}), ...(sc.abort || {}) };

export const options = {
  scenarios: { main: { executor: 'ramping-vus', startVUs: plan.start, stages: plan.stages.map((x) => ({ duration: `${Math.max(1, Math.round(x.ms / 1000))}s`, target: x.target })), gracefulRampDown: '10s' } },
  // Safety brakes only: stop early instead of hammering a struggling system (k6 exits with code 99 when they trip).
  thresholds: {
    http_req_failed: [{ threshold: `rate<${abort.errorRate}`, abortOnFail: true, delayAbortEval: '15s' }],
    http_req_duration: [{ threshold: `p(95)<${abort.p95Ms}`, abortOnFail: true, delayAbortEval: '15s' }],
  },
  summaryTrendStats: ['avg', 'min', 'med', 'max', 'p(90)', 'p(95)', 'p(99)', 'count'],
};

const T = cfg.apdexTMs || 500;
const satisfied = new Counter('apdex_satisfied'), tolerating = new Counter('apdex_tolerating'), frustrated = new Counter('apdex_frustrated');
const epDur = cfg.requests.map((r, i) => new Trend(`ep${i}_duration`, true));
const epFail = cfg.requests.map((r, i) => new Rate(`ep${i}_failed`));
const ERR = ['network', '3xx', '401', '403', '404', '429', '4xx', '500', '502', '503', '504', '5xx', 'unexpected'];
const errCount = Object.fromEntries(ERR.map((k) => [k, new Counter(`err_${k}`)]));
const errKey = (st) => (st === 0 ? 'network' : st >= 300 && st < 400 ? '3xx' : ['401', '403', '404', '429', '500', '502', '503', '504'].includes(String(st)) ? String(st) : st >= 400 && st < 500 ? '4xx' : st >= 500 ? '5xx' : 'unexpected');
// Shared headers and each request's own headers; "env:NAME" values come from the environment.
const resolve = (h) => {
  const out = {};
  for (const [k, v] of Object.entries(h || {})) {
    const val = typeof v === 'string' && v.startsWith('env:') ? __ENV[v.slice(4)] : v;
    if (val == null || val === '') throw new Error(`Header ${k} needs the ${v.slice(4)} environment variable: export it in the shell (or pass -e ${v.slice(4)}=...). Never write the value into the config.`);
    out[k] = val;
  }
  return out;
};
const headers = resolve(cfg.headers);
const reqHeaders = cfg.requests.map((r) => resolve(r.headers));
const pool = cfg.requests.flatMap((r, i) => Array(r.weight || 1).fill(i));
const think = Array.isArray(cfg.thinkTimeMs) ? cfg.thinkTimeMs : [cfg.thinkTimeMs ?? 1000, cfg.thinkTimeMs ?? 1000];
// "path" is appended to baseUrl (same as load-gen.mjs); a full http(s):// URL is used as is.
const joinUrl = (base, p) => (/^https?:\/\//i.test(p || '') ? p : `${String(base).replace(/\/+$/, '')}/${String(p || '').replace(/^\/+/, '')}`);
const callbacks = cfg.requests.map((r) => (r.expectStatus ? http.expectedStatuses(...[].concat(r.expectStatus)) : http.expectedStatuses({ min: 200, max: 299 })));

export default function () {
  const i = pool[Math.floor(Math.random() * pool.length)];
  const r = cfg.requests[i];
  const expected = r.expectStatus ? [].concat(r.expectStatus) : null;
  const res = http.request(r.method || 'GET', joinUrl(cfg.baseUrl, r.path), r.body ? JSON.stringify(r.body) : null, {
    headers: Object.assign({}, headers, r.body ? { 'Content-Type': 'application/json' } : {}, reqHeaders[i]),
    tags: { name: r.name }, timeout: `${cfg.timeoutMs || 10000}ms`, redirects: 0, responseCallback: callbacks[i],
  });
  const ok = expected ? expected.includes(res.status) : res.status >= 200 && res.status < 300;
  epDur[i].add(res.timings.duration);
  epFail[i].add(!ok);
  if (!ok) { errCount[errKey(res.status)].add(1); frustrated.add(1); } else if (res.timings.duration <= T) satisfied.add(1); else if (res.timings.duration <= 4 * T) tolerating.add(1); else frustrated.add(1);
  const w = think[0] + Math.random() * (think[1] - think[0]);
  if (w > 0) sleep(w / 1000);
}

export function handleSummary(data) {
  const out = __ENV.PERF_SUMMARY || 'k6-summary.json';
  return { [out]: JSON.stringify(data, null, 2), stdout: `k6 finished. Raw summary -> ${out} (convert it with load-gen.mjs --from-k6)\n` };
}
````