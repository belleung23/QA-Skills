---
name: "dead-test-audit"
description: "Audit any Playwright specs — a folder, a feature area or the whole suite — for tests that cannot fail: no assertion at all, every assertion behind an if-guard, assertions that are true by construction, and results measured then discarded. Also names the non-asserting helpers that cause it and the util exports with no caller. Reports only. Triggers on: tests that do nothing, can this test fail, do these tests actually assert anything, find fake passing tests, assertion audit, always-green tests."
---

# Dead Test Audit

Finds tests that pass whatever the application does.

A Playwright test fails on exactly two things: a thrown error, or a failed `expect()`.
Everything else — a `console.log`, a `console.warn`, a boolean computed and dropped — is
invisible to the runner. A test built only out of those reports green forever and nobody
notices, because green is what you expect to see.

## When to use this and not something else

| Use | For |
| --- | --- |
| **this skill** | auditing **existing** specs — one folder, one feature, or everything |
| `duplication-gate` | checking **newly generated** scripts before they reach a PR (it runs a subset of these checks on the new files only) |
| `automation-aegis` | full code-quality review of a PR — selectors, naming, structure, tagging |

This one answers a narrower question than Aegis and answers it across the whole suite at once.
Run it on a feature area before you trust its coverage number, after inheriting a suite, or
when a feature breaks in production and the tests stayed green.

**Report only.** Deleting or repairing is a separate decision — see *What to do with findings*.

---

## Run it

**Put the script on the machine where the suite lives.** If the repo is in a folder connected
from the user's computer, the detector must be written and run *there* — the Write tool writes
to the cloud container, which cannot see that repo at all. Use the device shell and a quoted
heredoc (`cat > "$TOOL" <<'PYEOF' ... PYEOF`) so nothing is interpolated. Only when the repo is
in the container itself is the Write tool the right way.

Cache it so it is written once, checking in the same shell you will run it from:

```bash
TOOL="$HOME/.qa-tools/deadtest.py"
grep -q 'deadtest v1' "$TOOL" 2>/dev/null || echo "write it"
```

If that path does not already hold `deadtest v1`, write the script at the bottom of this skill
there verbatim. Never retype it from memory — the regexes encode bug fixes (see *Why the
script looks like this*). After writing, confirm it is intact before trusting a result:

```bash
python3 -c "import ast;ast.parse(open('$TOOL').read())" && echo ok
```

```bash
# whole suite
python3 "$TOOL" --root <repo-root> --suite automation --suite electron-automation

# one feature area
python3 "$TOOL" --root <repo-root> --suite automation --scope "user-settings"

# machine-readable
python3 "$TOOL" --root <repo-root> --suite automation --json
```

About 9 seconds for ~3,900 tests. It changes nothing on disk.

---

## The six findings

### 1. ASSERTS NOTHING

No `expect()`, no asserting helper, no throwing wait. The test drives the app and stops.

```typescript
test('should support keyboard message sending', async ({ page }) => {
  const composerInput = page.getByTestId('composer-input');
  if (await composerInput.isVisible()) {
    await composerInput.fill('Test accessibility message');
    await page.keyboard.press('Enter');
    await page.waitForTimeout(1000);
  }
});
```

It types, presses Enter, waits a second, ends. It never checks a message was sent.

### 2. ALL ASSERTIONS CONDITIONAL

Every `expect()` sits inside an `if`. On a slow load, an empty dataset or a feature-flagged-off
page, zero assertions run and the test still passes. **Not automatically a defect** — some data
dependence is legitimate — but it is never *strong*. Treat as a review queue, not a delete list.

Check the guard's testid against the application source. A guard on an element that does not
exist in `src/` means the body has never run at all.

### 3. TAUTOLOGICAL ASSERTION

There is an `expect()`, and it is true by construction:

```typescript
const state = await page.evaluate(() => ({ /* ...rich diagnostic object... */ }));
console.log('Review Queue view control state:', JSON.stringify(state, null, 2));
expect(state !== null && state !== undefined, '...').toBeTruthy();
```

That asserts `page.evaluate()` returned an object, which it always does. Everything actually
measured — whether the title was still English, whether any Japanese rendered — was printed
and thrown away. The shapes caught: `x !== null && x !== undefined`, `x != null`,
`expect(true)`, `bodyText.length > 0`, `expect(x).toBe(x)`, and `status < 500` (a 401 or 404
passes, so an unauthenticated request satisfies it).

### 4. RESULT COMPUTED AND DISCARDED

The measurement is taken and the answer is dropped — either as a bare statement, or bound to a
variable never read again:

```typescript
// Toast should be gone
const _stillVisible = await toast.first().isVisible().catch(() => false);
// Toasts should auto-dismiss (or be dismissible)
// Some toasts may persist - this is acceptable
```

When the comment says both outcomes are acceptable, there is nothing to assert — and this one
spent 10 seconds of fixed wait to reach that conclusion on every run.

### 5. HELPERS THAT CANNOT FAIL — the root cause, read this first

A helper whose name promises a check but which reports with `console.warn` and returns:

```typescript
export async function checkAriaLandmarks(page: Page, context: string): Promise<void> {
  const hasMain = (await page.locator('main, [role="main"]').count()) > 0;
  if (!hasMain) {
    console.warn(`[A11Y] ${context}: Page should have a main landmark`);
  }
}
```

It measures correctly, then whispers. Every test built on it inherits that. In one a11y util,
nine of fourteen helpers were like this and ten tests had been green for months.

This section is listed with its callers so you can see the blast radius. **Fix the helper and
you fix every test at once** — which is almost always better than deleting the tests.

The check is deliberately narrow: only names beginning `check` / `verify` / `assert` /
`expect` / `ensure` / `validate` / `confirm` / `should` / `isX`. A setup helper (`createUser`,
`seedPolicies`, `gotoSettings`) rightly has no assertion and is not reported.

### 6. UTIL EXPORTS WITH NO CALLER

Exported helpers under a `utils/` folder that nothing calls. Dead weight, and often the
unfinished other half of finding 5.

---

## Triage — reject these before reporting anything

The script proposes; you decide. Open each one.

- **An asserting helper the graph missed.** The script follows calls transitively, but check
  the helper really has no `expect()` or `throw` before believing "ASSERTS NOTHING".
- **A throwing wait is an assertion.** `waitForURL`, `waitForSelector`, `waitForFunction`,
  `waitForResponse`, `toPass` all fail the test on timeout with no `expect()` in sight. The
  script knows this — unless the call is followed by `.catch(...)`, which swallows it. If you
  see one of those in a flagged test, check for the `.catch`.
- **A soft assertion still fails the test.** `expect.soft` records and continues, but the test
  ends red. Soft is not the same as absent.
- **Deliberate data-dependence.** A guard on a list that may legitimately be empty is a weak
  test, not a fake one.
- **A quarantined file.** Anything with a module-level `test.fixme(true, ...)` or
  `test.skip(true, ...)` is already excluded — that whole file belongs to whoever owns the
  quarantine.

---

## What to do with findings

Rank by what the fix actually costs:

| Finding | Default action |
| --- | --- |
| Helper that cannot fail | **Fix the helper** — turn the `console.warn` branch into an `expect()`. One change repairs every caller. |
| Tautological assertion | **Fix the assertion** — the test already measures the right thing; assert on it instead of logging it. |
| Result computed and discarded | **Fix the assertion** — assert the variable that was dropped. |
| Asserts nothing, and the intent is clear | Write the missing assertion. |
| Asserts nothing, and it is a leftover probe or investigation script | Delete it. |
| All assertions conditional | Leave; raise the pattern with the team. |

**Repairing changes test outcomes.** Making nine helpers assert will turn some green tests red
— which is the point, but it needs someone who can run the suite and triage what falls out. If
that is not this session, say so and recommend it rather than doing it quietly.

If you do delete, note that these removals **retire their QA sheet rows**. Unlike de-duplication
there is no survivor to fold the TC ID into, because there was never any real coverage. Flag
that to whoever owns the sheet.

---

## Why the script looks like this

Each of these produced a wrong answer before it was fixed. Do not "simplify" them away.

1. **`expect` may be split across lines.** `expect\n  .soft(...)` is what Prettier produces; a
   regex requiring `expect.soft` adjacent reports real tests as assertion-free.
2. **Throwing waits count as assertions** — unless `.catch(...)` follows.
3. **Helpers assert too.** The script builds a transitive call graph over every function in the
   suites and marks those reaching an `expect()` or a `throw`.
4. **Finding a function's body needs care.** Taking the first `{` after the name lands on a
   default parameter (`options: A11yCheckOptions = {}`), so most helpers index as empty and
   every test using one gets wrongly flagged. Skip the parameter list and any return-type
   annotation first.
5. **Count variable uses in the raw body, not the masked one.** Masking blanks template-literal
   contents, so a variable used only inside `` `...${name}...` `` looks unused — that alone was
   six false "discarded" findings out of seven.
6. **`page.evaluate` is not a read-only probe.** It is routinely used for side effects
   (`scrollTo`, `classList.remove`), so including it in the discarded-result check floods the
   output with noise.
7. **The statement splitter counts block statements.** Closing only on a `;` at depth 1 drops
   `for (...) { ... }` and `if (...) { ... }`, which is where many specs keep their assertions.
8. **Narrow the helper check to names that claim to check.** Otherwise every `createX` /
   `seedY` / `gotoZ` setup helper is reported, and the real finding is buried.

---

## Report format

Lead with the root cause, not the count.

```
## Dead test audit — <scope>

<N> of <M> live tests cannot fail.

### Root cause: <K> helpers that never assert
- checkAriaLandmarks (utils/a11y-helpers.ts) — console.warn only — 1 caller
  ...
Fixing these repairs <X> tests at once.

### Cannot fail (<N>)
| Test | Why | Suggested |
| --- | --- | --- |
| file:line title | no expect(), no asserting helper | write the assertion / delete |

### Weak but not fake (<J>)
Every assertion behind an if-guard — listed for review, no action proposed.
```

Nothing is changed. End by naming the one action with the best ratio of tests-repaired to
lines-changed, and say plainly that applying it will turn some currently-green tests red.

---

## The detector

Write this to the cached path verbatim, then run it.

```python
#!/usr/bin/env python3
"""deadtest.py — find Playwright tests that cannot fail, and the helpers that cause it.
# deadtest v1

  python3 deadtest.py --root <repo> --suite automation [--suite electron-automation] [--scope <sub>] [--json]

Prints a findings report. Changes nothing on disk.
"""
import argparse, collections, difflib, hashlib, json, os, re, sys

# ---------- masking -------------------------------------------------------
# Blanks comments and the CONTENTS of string literals, keeping quotes and
# newlines so offsets line up with the raw source. Regex literals are left
# intact on purpose: /compact/i vs /comfortable/i is a real difference and
# blanking them makes parameterised tests look identical.
TOK = re.compile(r"""//[^\n]*|/\*.*?\*/|"(?:\\.|[^"\\\n])*"|'(?:\\.|[^'\\\n])*'|`(?:\\.|[^`\\])*`""", re.S)
def _blank(mo):
    s = mo.group(0)
    if s[:2] in ('//', '/*'):
        return ''.join(c if c == '\n' else ' ' for c in s)
    q = s[0]
    return q + ''.join(c if c == '\n' else ' ' for c in s[1:-1]) + q
def mask(src): return TOK.sub(_blank, src)

def match_close(m, i):
    o = m[i]; c = {'(': ')', '{': '}', '[': ']'}[o]; d = 0
    while i < len(m):
        if m[i] == o: d += 1
        elif m[i] == c:
            d -= 1
            if d == 0: return i
        i += 1
    return -1

MODS = {'describe','skip','fixme','only','serial','parallel','concurrent','failing',
        'each','todo','runIf','skipIf','sequential','for','fails'}
DECL = re.compile(r'(?<![\w$.])(test|it|describe|xit|xdescribe|fit|fdescribe)((?:\.[A-Za-z_$][\w$]*)*)\s*\(')
LIT  = re.compile(r"""['"`]""")

def scan_file(path, rel):
    try: src = open(path, encoding='utf-8', errors='replace').read()
    except Exception: return []
    m = mask(src)
    nl = [0]; st = 0
    while True:
        k = src.find('\n', st)
        if k < 0: break
        nl.append(k + 1); st = k + 1
    import bisect
    out = []
    for mo in DECL.finditer(m):
        base = mo.group(1); chain = [p for p in mo.group(2).split('.') if p]
        if any(p not in MODS for p in chain): continue
        ap = mo.end() - 1; ae = match_close(m, ap)
        if ae < 0: continue
        tm = LIT.search(m, ap + 1, ae)
        title = None
        if tm:
            q = tm.group(0); s = tm.start(); e = m.find(q, s + 1)
            if 0 < e < ae: title = src[s + 1:e]
        bs = be = -1
        ar = m.find('=>', ap, ae)
        if ar > 0:
            k = m.find('{', ar)
            if k >= 0: bs = k; be = match_close(m, k)
        if be < 0 or be > ae: bs, be = ap, ae
        out.append({
            'file': rel, 'line': bisect.bisect_right(nl, mo.start()),
            'suite': base in ('describe','xdescribe','fdescribe') or 'describe' in chain,
            'skip': 'skip' in chain or base == 'xit', 'fixme': 'fixme' in chain,
            'todo': 'todo' in chain, 'title': title,
            'body': src[bs:be + 1], 'mbody': m[bs:be + 1],
            'opts': src[ap:bs if bs > ap else ae],
        })
    return out

# ---------- quarantine ----------------------------------------------------
QUAR = re.compile(r'(?m)^(test\.(fixme|skip)\(|test\.describe\.(fixme|skip))')
def is_quarantined(path):
    try: return bool(QUAR.search(open(path, encoding='utf-8', errors='replace').read()))
    except Exception: return False

# ---------- asserting-helper call graph -----------------------------------
FN    = re.compile(r'(?<![\w$.])(?:export\s+)?(?:default\s+)?(?:async\s+)?function\s*\*?\s*([A-Za-z_$][\w$]*)\s*(?:<[^>(]{0,120}>)?\s*\(')
CONST = re.compile(r'(?<![\w$.])(?:export\s+)?const\s+([A-Za-z_$][\w$]*)\s*(?::\s*[^=\n]{0,200})?=\s*(?:async\s*)?(?:<[^>(]{0,120}>)?\s*\(')
EXPECT = re.compile(r'(?<![\w$.])expect\s*(?:\.\s*(?:soft|poll)\s*)?\(')   # tolerates expect\n  .soft(
THROW  = re.compile(r'(?<![\w$.])throw\s+new\s+\w*Error')
CALL   = re.compile(r'(?<![\w$.])([A-Za-z_$][\w$]*)\s*\(')

def _body_after_params(m, popen):
    """popen = index of the param list's '('. Skip it, skip a return-type
    annotation (which may contain <...>), then take the real body braces.
    Naively taking the first '{' lands on a default param like `opts = {}`."""
    e = match_close(m, popen)
    if e < 0: return None
    i = e + 1; ang = 0
    while i < len(m):
        ch = m[i]
        if ch == '<': ang += 1
        elif ch == '>' and ang > 0: ang -= 1
        elif ch == '{' and ang == 0:
            j = match_close(m, i)
            return (i, j) if j > 0 else None
        elif ch == ';' and ang == 0: return None
        i += 1
    return None

def build_assert_index(roots):
    fns = collections.defaultdict(list)
    for root in roots:
        for dp, _, files in os.walk(root):
            for fn in files:
                if not fn.endswith('.ts'): continue
                try: src = open(os.path.join(dp, fn), encoding='utf-8', errors='replace').read()
                except Exception: continue
                m = mask(src)
                for rx in (FN, CONST):
                    for mo in rx.finditer(m):
                        b = _body_after_params(m, mo.end() - 1)
                        if b: fns[mo.group(1)].append(m[b[0]:b[1] + 1])
    asserting = {n for n, bs in fns.items() if any(EXPECT.search(b) or THROW.search(b) for b in bs)}
    calls = {n: {c for b in bs for c in CALL.findall(b)} for n, bs in fns.items()}
    changed = True
    while changed:
        changed = False
        for n, cs in calls.items():
            if n not in asserting and (cs & asserting):
                asserting.add(n); changed = True
    return asserting

# ---------- no-op detection ----------------------------------------------
# Playwright waits that THROW on failure are assertions even with no expect().
THROWY = re.compile(r'\.\s*(waitForURL|waitForSelector|waitForFunction|waitForResponse|waitForRequest|waitForEvent|toPass)\s*\(')
IFG = re.compile(r'(?<![\w$])if\s*\(')

def _clean_mask(t):
    mm = re.sub(r'/\*.*?\*/', lambda x: ' ' * len(x.group(0)), t['mbody'], flags=re.S)
    return re.sub(r'(?m)//[^\n]*', lambda x: ' ' * len(x.group(0)), mm)

def throwy_unswallowed(mm):
    out = []
    for m in THROWY.finditer(mm):
        i = match_close(mm, m.end() - 1)
        if i < 0: continue
        if not re.match(r'\s*\.\s*catch', mm[i + 1:i + 40]): out.append(m.start())
    return out

def if_regions(mm):
    regions = []
    for m in IFG.finditer(mm):
        i = match_close(mm, m.end() - 1)
        if i < 0: continue
        j = i + 1
        while j < len(mm) and mm[j].isspace(): j += 1
        if j < len(mm) and mm[j] == '{':
            k = match_close(mm, j)
            if k > 0: regions.append((j, k))
        elif j < len(mm):
            k = mm.find(';', j)
            if k > 0: regions.append((j, k))
    return regions

def noop_verdict(t, asserting):
    mm = _clean_mask(t)
    exps = [m.start() for m in EXPECT.finditer(mm)]
    helpers = [c for c in CALL.findall(mm) if c in asserting]
    thr = throwy_unswallowed(mm)
    if not exps and not helpers and not thr:
        return 'ASSERTS NOTHING', 'no expect(), no asserting helper, no throwing wait'
    if exps and not helpers and not thr:
        reg = if_regions(mm)
        if all(any(a < p < b for a, b in reg) for p in exps):
            return 'ALL ASSERTIONS CONDITIONAL', '%d expect(), every one inside an if-block' % len(exps)
    return None, None


# ---------- statement split (block statements included) -------------------
CONT = re.compile(r'^(catch|finally|else|while)\b')
def stmts(t):
    src = t['body']; mm = _clean_mask(t)
    if len(mm) != len(src): return None
    out = []; d = 0; start = None; i = 0; n = len(mm)
    def emit(a, b):
        s = re.sub(r'\s+', ' ', src[a:b]).strip()
        s = re.sub(r'/\*.*?\*/', '', s, flags=re.S)
        return re.sub(r'//[^\n]*', '', s).strip()
    while i < n:
        ch = mm[i]
        if ch in '{([': d += 1; i += 1; continue
        if ch in '})]':
            d -= 1
            # a '}' returning to depth 1 ends a block statement (for/if/try)
            if d == 1 and ch == '}':
                j = i + 1
                while j < n and mm[j].isspace(): j += 1
                if j < n and mm[j] not in ')].,;:=+-*/&|?' and not CONT.match(mm[j:j + 9]):
                    if start is not None:
                        s = emit(start, i + 1)
                        if s: out.append(s)
                    start = None
            i += 1; continue
        if d == 1:
            if start is None and not ch.isspace(): start = i
            if ch == ';' and start is not None:
                s = emit(start, i + 1)
                if s: out.append(s)
                start = None
        i += 1
    return out

# ---------- tautological assertions ---------------------------------------
# expect() arguments that are true by construction, whatever the app did.
TAUT = [
    (re.compile(r'expect\s*\(\s*(\w+)\s*!==?\s*null\s*&&\s*\1\s*!==?\s*undefined'),
     'expect(x !== null && x !== undefined) — page.evaluate() always returns an object'),
    (re.compile(r'expect\s*\(\s*(\w+)\s*!=\s*null\s*\)'),
     'expect(x != null) on a value that is always produced'),
    (re.compile(r'expect\s*\(\s*(?:true|1)\s*[,)]'), 'expect(true) / expect(1)'),
    (re.compile(r'expect\s*\(\s*[\w.]*(?:bodyText|innerText|pageText|text)\w*\.length\s*>\s*0'),
     'expect(bodyText.length > 0) — any rendered page satisfies this'),
    (re.compile(r'\.toBeLessThan\s*\(\s*500\s*\)'),
     'status < 500 — a 401/403/404 passes; assert the status you expect'),
    (re.compile(r'expect\s*\(\s*(\w+)\s*\)\s*\.\s*toBe\s*\(\s*\1\s*\)'), 'expect(x).toBe(x)'),
]

# a standalone statement that computes a value and throws it away
# Read-only probes only. `evaluate` and `waitFor` are excluded: evaluate is
# routinely used for side effects (scrollTo, classList.remove) and waitFor
# throws on timeout, so it is already an assertion.
PROBE = re.compile(r'^(?:await\s+)?[\w.$\[\]\'"()]+\s*\.\s*'
                   r'(isVisible|isEnabled|isChecked|count|textContent|getAttribute|innerText)\s*\(')
BIND = re.compile(r'^(?:const|let|var|return|expect|await\s+expect)\b')

BINDPROBE = re.compile(r'^(?:const|let)\s+(\w+)\s*=\s*(?:await\s+)?[\w.$\[\]\'"()]+\s*\.\s*'
                       r'(?:isVisible|isEnabled|isChecked|count|textContent|getAttribute|innerText)\s*\(')

def discarded_probes(t):
    """Two shapes of 'we measured it and threw the answer away':
       1. a bare expression statement that only reads something;
       2. `const x = await ...isVisible()` where x is never referenced again
          (P5-8.3's `const _stillVisible = ...` is the canonical case)."""
    out = []
    # Count uses in the RAW body with only comments stripped. The masked body
    # blanks template-literal contents, so a variable used only inside
    # `...${name}...` would look unused.
    body_masked = re.sub(r'(?m)//[^\n]*', '', re.sub(r'/\*.*?\*/', '', t['body'], flags=re.S))
    for s in (stmts(t) or []):
        line = s.lstrip()
        mb = BINDPROBE.match(line)
        if mb:
            name = mb.group(1)
            uses = len(re.findall(r'(?<![\w$])%s(?![\w$])' % re.escape(name), body_masked))
            if uses <= 1:
                out.append('%s is assigned and never used — %s' % (name, line[:90]))
            continue
        if BIND.match(line): continue
        if PROBE.match(line) and 'expect' not in line:
            out.append('result discarded — %s' % line[:90])
    return out

def tautologies(t):
    mm = _clean_mask(t)
    src = t['body']
    hits = []
    for rx, why in TAUT:
        if rx.search(src) or rx.search(mm): hits.append(why)
    return sorted(set(hits))

# ---------- helper classification ----------------------------------------
WARNONLY = re.compile(r'console\s*\.\s*(warn|log|error|info)\s*\(')
CHECKY = re.compile(r'^(check|verify|assert|expect|ensure|validate|confirm|should|is[A-Z])')

def classify_helpers(roots):
    """Return (asserting, warn_only, defined_in, callers) for every function."""
    fns = collections.defaultdict(list); where = {}
    for root in roots:
        for dp, _, files in os.walk(root):
            for fn in files:
                if not fn.endswith('.ts'): continue
                p = os.path.join(dp, fn)
                try: src = open(p, encoding='utf-8', errors='replace').read()
                except Exception: continue
                m = mask(src)
                for rx in (FN, CONST):
                    for mo in rx.finditer(m):
                        b = _body_after_params(m, mo.end() - 1)
                        if not b: continue
                        fns[mo.group(1)].append(m[b[0]:b[1] + 1])
                        where.setdefault(mo.group(1), p)
    asserting = {n for n, bs in fns.items() if any(EXPECT.search(b) or THROW.search(b) for b in bs)}
    calls = {n: {c for b in bs for c in CALL.findall(b)} for n, bs in fns.items()}
    changed = True
    while changed:
        changed = False
        for n, cs in calls.items():
            if n not in asserting and (cs & asserting):
                asserting.add(n); changed = True
    # Only names that CLAIM to check something. A setup helper (createX, seedY,
    # gotoZ) legitimately has no assertion; `checkAriaLandmarks` having none is a bug.
    warn_only = {n for n, bs in fns.items()
                 if n not in asserting and CHECKY.match(n)
                 and any(WARNONLY.search(b) or not b.strip('{} \n') for b in bs)}
    return asserting, warn_only, where, fns

def count_callers(roots, names):
    """One pass over the tree: for each file, extract every call name once and
    attribute it. Compiling a regex per function name and scanning every file is
    O(functions x files) and does not finish on a suite this size."""
    want = set(names)
    cnt = collections.Counter(); sites = collections.defaultdict(set)
    for root in roots:
        for dp, _, files in os.walk(root):
            for fn in files:
                if not fn.endswith('.ts'): continue
                p = os.path.join(dp, fn)
                try: m = mask(open(p, encoding='utf-8', errors='replace').read())
                except Exception: continue
                for c in CALL.findall(m):
                    if c in want:
                        cnt[c] += 1; sites[c].add(p)
    return cnt, sites

# ---------- main ----------------------------------------------------------
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--root', required=True)
    ap.add_argument('--suite', action='append', required=True)
    ap.add_argument('--scope', help='only report tests whose path contains this substring')
    ap.add_argument('--json', action='store_true')
    a = ap.parse_args()
    root = os.path.abspath(a.root)
    roots = [os.path.join(root, s) for s in a.suite]

    tests, quar = [], []
    for r in roots:
        for dp, _, files in os.walk(r):
            for fn in files:
                if not fn.endswith('.spec.ts'): continue
                p = os.path.join(dp, fn); rel = os.path.relpath(p, root)
                if is_quarantined(p): quar.append(rel); continue
                tests.extend(scan_file(p, rel))
    live = [t for t in tests if not t['suite'] and t['title'] and t['body']
            and not t['skip'] and not t['fixme'] and not t['todo']]
    if a.scope:
        live = [t for t in live if a.scope in t['file']]

    asserting, warn_only, where, fns = classify_helpers(roots)

    cat = collections.defaultdict(list)
    for t in live:
        v, why = noop_verdict(t, asserting)
        if v:
            cat[v].append((t, why))
            continue
        taut = tautologies(t)
        if taut:
            cat['TAUTOLOGICAL ASSERTION'].append((t, '; '.join(taut)))
            continue
        pr = discarded_probes(t)
        if pr:
            cat['RESULT COMPUTED AND DISCARDED'].append((t, pr[0]))

    # helpers that never fail, and who depends on them
    used = {n for n in warn_only}
    cnt, sites = count_callers(roots, used | set(fns))
    helper_rows = []
    for n in sorted(warn_only):
        ext = sorted(s for s in sites.get(n, ()) if s != where.get(n))
        if ext:
            helper_rows.append((n, os.path.relpath(where.get(n, '?'), root),
                                [os.path.relpath(s, root) for s in ext]))
    dead = sorted(n for n in fns
                  if len(sites.get(n, ())) <= 1 and n in warn_only | asserting
                  and where.get(n) and '/utils/' in where[n].replace(os.sep, '/'))

    if a.json:
        print(json.dumps({k: [('%s:%d %s' % (t['file'], t['line'], t['title']), w) for t, w in v]
                          for k, v in cat.items()} |
                         {'warn_only_helpers': helper_rows, 'unused_in_utils': dead,
                          'quarantined_skipped': len(quar)}, indent=2))
        return

    print('scanned %d live tests (%d quarantined files skipped)' % (len(live), len(quar)))
    for k in ('ASSERTS NOTHING', 'ALL ASSERTIONS CONDITIONAL',
              'TAUTOLOGICAL ASSERTION', 'RESULT COMPUTED AND DISCARDED'):
        rows = cat.get(k, [])
        print('\n== %s (%d) ==' % (k, len(rows)))
        for t, w in sorted(rows, key=lambda x: (x[0]['file'], x[0]['line'])):
            print('  %s:%d  %s\n      %s' % (t['file'], t['line'], t['title'], w))
    print('\n== HELPERS THAT CANNOT FAIL (%d) ==' % len(helper_rows))
    print('   (no expect(), no throw — they console.warn and return; every caller inherits this)')
    for n, defn, callers in helper_rows:
        print('  %s  [%s]' % (n, defn))
        for c in callers[:6]: print('      called from %s' % c)
    if dead:
        print('\n== UTIL EXPORTS WITH NO CALLER (%d) ==' % len(dead))
        for n in dead: print('  %s  [%s]' % (n, os.path.relpath(where[n], root)))

if __name__ == '__main__':
    main()
```