---
name: ticket-inspector
description: "Deep Linear issue inspection: reads issue content, linked GitHub PR diff, and codebase to map full scope of a feature or bug. Extracts AC, repro steps, comments, linked issues, and merged PR details (files changed, diff, commits), then maps to source files, call chains, tests, and regression surface. Routes to Dev (no fallback) for normal tickets, or Production with Dev fallback for [Pro]/[Prod] tickets. Triggers on: analyze ticket, read ticket, understand ticket, inspect ticket, ticket-inspector, what does this ticket do, find related code, ticket scope, deep ticket analysis."
---

# Ticket Analyzer + PR Reader

## Overview

This skill validates and analyses a Linear issue — combining the issue's own content, the linked GitHub PR, and codebase inspection — then immediately runs the manual tests if the ticket is ready.

**What this skill does:**
1. **Type validation** — handles Bug / Task / Story / Subtask (identified via Linear labels — see below)
2. **Criteria extraction** — reads AC/expected results and steps to reproduce
3. **GitHub PR review** — reads the merged PR linked to the issue (via `pr-sentinel`) to understand actual implementation
4. **Testability check** — confirms each step is specific, measurable, and doesn't rely on assumptions
5. **Frontend detection** — identifies if the ticket has frontend/UI components requiring manual UI testing
6. **Root cause / impact mapping** — identifies the affected code area and layer (informed by PR diff)
7. **Verification criteria** — defines minimal, focused evidence
8. **Testing strategy** — picks the routed environment (Dev for normal tickets, Production for `[Pro]`/`[Prod]` tickets)
9. **Auto-execution** — if the ticket is READY, immediately proceeds to run `manual-test-executor` using the verification criteria as test cases.

**Branching after analysis:**
- **READY** → auto-execute `manual-test-executor` (Step 9)
- **NEEDS CLARIFICATION** → output flagged items and stop; do not run tests
- **INCOMPLETE** → request missing info and stop; do not run tests

---

## Workflow

### Step 1 — Validate Issue Type & Check Title for [Pro]/[Prod]

Fetch the Linear issue provided by the user (via GraphQL — see `LINEAR_CHEATSHEET.md` §3):

```graphql
query($id: String!) {
  issue(id: $id) {
    identifier title description priority
    state { name type }
    labels { nodes { name } }
    parent { identifier title }
    children { nodes { identifier title } }
    attachments { nodes { url title } }
    comments { nodes { body createdAt user { name } } }
  }
}
```

Linear has no separate "issue type" field here — infer Bug / Task / Story / Subtask from
labels (a `Bug` label means Bug; a `parent` present usually means Subtask; otherwise default
to Task/Story per whatever the description implies).

Also inspect the **title** for the routing tags:
- If title contains `[Pro]` or `[Prod]` → environment routing is **Production primary, Dev fallback**
- Otherwise → environment routing is **Dev only, no fallback**

Proceed to Step 2.

---

### Step 2 — Extract Issue Information

Read and extract ALL of the following from the issue:

| Field | Extract | Why |
|-------|---------|-----|
| **Issue ID & Type** | GR-XXX, Bug/Task/Story/Subtask (from labels) | Confirm |
| **Title** | Short description + `[Pro]`/`[Prod]` check | Summary + routing |
| **Description** | Full narrative (plain Markdown) | Context |
| **Steps to Reproduce** (if bug) | Numbered list of actions | Testability |
| **Expected Result** | What should happen | Success criteria |
| **Actual Result** (if bug) | What happens instead | Current state |
| **Acceptance Criteria** | All AC listed | Test targets |
| **Linked Issues** | Any parent/child/related (via `parent`, `children`, `issueRelationCreate`-created relations) | Scope understanding |
| **Environment** | Per title routing | Where to test |
| **Priority** | Numeric `priority` field (0–4) | Urgency |
| **Files Changed** | In PR comments or linked PR | Identifies scope |

---

### Step 3 — Read Linked GitHub PR

**This is a required step before codebase analysis** — the merged PR shows the actual implementation, which makes downstream analysis and test cases far more accurate than relying on the issue description alone.

**Delegate this entire step to `pr-sentinel`** — it discovers the linked PR URL(s) from the
Linear issue's `attachments`, confirms real merge status directly via `gh pr view`, and returns
a full Diff Intelligence section (files changed, diff summary, commits, reviewers). Use its
output directly rather than re-fetching the PR here.

If `pr-sentinel` reports 🚫 GATE BLOCKED (PR not merged, or a `do-not-merge` label present):
- Note "⚠️ PR not merged — see PR Sentinel gate report" in the analysis report
- Check if the fix is mentioned inline in comments
- Stop here — do not proceed to codebase analysis or testing on an unmerged fix

If `pr-sentinel` reports `⚠️ No PR linked`:
- Note "⚠️ No merged PR linked to this ticket" in the analysis report
- Proceed with codebase-only analysis but flag this for the QA report

---

### Step 4 — Analyze the Codebase (Informed by PR Diff)

Use the PR diff from Step 3 as the **starting point** for codebase analysis — these are the exact files the developer changed, so they are the highest-priority surface to inspect.

**For UI/Frontend bugs:**
- Open every `.tsx` / `.jsx` / `.ts` / `.css` file from the PR's Files Changed list
- Find the component(s) mentioned in bug title/description
- Locate state/handlers involved in the buggy behavior
- Check for conditional rendering or validation issues
- Note any `data-testid` attributes on interactive elements
- Identify the specific UI interaction that reproduces the bug
- Cross-reference the diff: what did the PR change vs. what's still untouched?
- **FLAG AS**: Frontend UI testing required ✓

**For Backend/API bugs:**
- Open every `.py` / `.go` / `.ts` / `.sql` file from the PR's Files Changed list
- Locate the endpoint(s) affected
- Find the service/business logic
- Trace data flow and error handling
- Check database queries or external API calls
- Cross-reference the diff: which functions / queries / migrations changed?
- **FLAG AS**: API/Backend testing

**For Both Frontend + Backend:**
- Perform both analyses on the PR's full file list
- Map the end-to-end flow
- Identify where frontend and backend responsibilities meet
- **FLAG AS**: Full stack testing required (UI + API)

---

### Step 5 — Testability Assessment

For each step in "Steps to Reproduce" (or each AC for non-bug tickets), check:

1. **Is it specific?** Does it name exact elements/inputs, or is it vague? ("Click the button" ✓ vs "Do something" ✗)
2. **Is it measurable?** Can you objectively verify success? ("Button text changes to 'Loading'" ✓ vs "It works better" ✗)
3. **Is it reproducible?** Can someone follow it without domain knowledge? ("Enter 'test@example.com' in email field" ✓ vs "Use a valid email" ✗)
4. **Are all preconditions clear?** Does it list login, setup, or data requirements? ("While logged in as admin" ✓)
5. **Is the expected outcome specific?** Can it be proven? ("Error message: 'Invalid format'" ✓ vs "Shows error" ✗)

If ANY step fails multiple checks, flag it as requiring clarification from the developer.

---

### Step 6 — Verification Criteria

Define minimal, focused evidence that proves the ticket is satisfied. **Use the PR diff to make criteria more precise** — if the PR shows exactly what the developer changed, your verification criteria should target those changes.

These become the test cases for `manual-test-executor` — minimal, focused verification, NOT a comprehensive regression suite.

---

### Step 7 — Testing Environment & Strategy

The environment is decided by the ticket title.

**Normal ticket (no `[Pro]` / `[Prod]`):**
```
Testing Environment Strategy:
  Primary: Dev — https://app.dev.firstrecon.ai
  Fallback: NONE — a failure on Dev is recorded as ❌ Fail, not retried elsewhere
  Notes: localhost (http://localhost:3000) is available for Layer 2 code verification only
```

**`[Pro]` or `[Prod]` ticket:**
```
Testing Environment Strategy:
  Primary: Production — https://app.firstrecon.ai
  Fallback: Dev — only for Production deployment gaps
  Notes: Any other Prod failure → ❌ Fail (do not retry on Dev)
```

---

### Step 8 — Output Analysis Report

Structure your output as:

```
## Ticket Analysis Report

### ✓ Issue Metadata
- **ID**: [Issue ID]
- **Type**: Bug / Task / Story / Subtask (from labels)
- **Title**: [Title]
- **[Pro]/[Prod] tag**: [Yes / No]
- **Scope**: [Frontend / Backend / Full Stack]
- **Priority**: [Priority]

### ✓ Linked GitHub PR
(from `pr-sentinel`'s Gate Report)
- **PR URL**: [GitHub URL]
- **PR Title**: [Title]
- **Status**: ✓ Merged / ⚠️ Open / ❌ Closed / ⚠️ Not linked
- **Merged**: [Date / commit SHA]
- **Files Changed** (N):
  - `path/to/file1.tsx` — [+lines / -lines] — [what changed]
  - `path/to/file2.py`  — [+lines / -lines] — [what changed]
- **Key diff observations**: [logic changes that matter for testing]

### ✓ Summary
- **What**: [One sentence describing the feature/bug]
- **When**: [When it occurs / preconditions]
- **Impact**: [User-facing impact]

### UI/Frontend Detection
[✓ Frontend UI testing required / ✗ Backend only / ✓ Full stack]

**Why**: [Explanation — cite PR files]

### Reproduction / AC Assessment
| Step / AC | Description | Specificity | Issues |
|-----------|-------------|------------|--------|
| 1         | [step / AC]| ✓/❌        | [gaps] |

⚠️ **Flagged for clarification**: [If any steps are unclear]

### Related Code
- [File path] — [What this file does, and whether it appears in the PR diff]

### Verification Criteria (Proof of Fix / Feature Acceptance)
1. [Evidence criterion 1 — specific, testable]
2. [Evidence criterion 2 — specific, testable]
3. [Evidence criterion 3 — specific, testable]

### Root Cause / Affected Area
**Suspected location**: [service/component name — confirmed by PR diff]
**Affected layer**: [UI / API / Database / External integration]
**Type of change**: [logic error / new feature / validation update / etc]

### Testing Strategy
**Environment**: [Dev (primary, no fallback) / Production (primary) → Dev (fallback for deployment gap)]
**Test Approach**: [Manual UI testing / API testing / Full stack testing]

### Ready for QA?
- **Status**: ✓ READY / ⚠️ NEEDS CLARIFICATION / ❌ INCOMPLETE
- **Reason**: [Brief explanation]
```

After outputting the report, branch:
- **✓ READY** → Step 9 (auto-execute)
- **⚠️ NEEDS CLARIFICATION / ❌ INCOMPLETE** → stop; do not run tests

---

### Step 9 — Auto-Execute Manual Tests (READY tickets only)

Convert verification criteria to test cases:

| # | Type | Priority | Test Description | Test Steps | Expected Result | Actual Result | Status | Screenshot | Recording |
|---|------|----------|-----------------|------------|-----------------|---------------|--------|------------|-----------|
| 1 | Happy Path | 🔴 Critical | [Criterion 1] | [Steps] | [Expected] | — | — | — | — |
| 2 | Happy Path | 🔴 Critical | [Criterion 2] | [Steps] | [Expected] | — | — | — | — |
| 3 | Happy Path | 🟠 High | [Criterion 3] | [Steps] | [Expected] | — | — | — | — |

Run `manual-test-executor` with:
- The issue ID
- The scope (Frontend / Backend / Full Stack) from Step 4
- The test case table above
- The PR diff context from Step 3
- The environment strategy from Step 7 (Dev-only for normal tickets; Prod → Dev for `[Pro]`/`[Prod]` tickets)

`manual-test-executor` will handle pre-flight auth, environment availability, the three test layers, media capture, report generation, and the Linear comment. Hand off cleanly — do not duplicate that work.

---

## Validation Rules

**STOP and flag for clarification if:**
- Steps to reproduce or AC are missing or vague
- Expected result is not clearly defined
- Preconditions (login, setup data) are assumed but not stated
- The description contradicts itself
- `pr-sentinel` reports the linked PR in a non-Merged state — the change isn't in yet, so testing it makes no sense

**PROCEED if:**
- All reproduction steps / AC are clear and specific
- Expected vs actual results are both defined
- Acceptance criteria exist and are testable
- Preconditions are listed
- `pr-sentinel` reports GATE OPEN (or there is no PR but the change is verifiable some other way)

---

## Testing Environment Reference

```
Normal ticket (no [Pro]/[Prod] in title):
  PRIMARY: Dev — https://app.dev.firstrecon.ai
  FALLBACK: NONE
  └─ A failure on Dev is a real failure. No retry on localhost or Staging.

[Pro] / [Prod] ticket:
  PRIMARY: Production — https://app.firstrecon.ai
  FALLBACK: Dev — only for deployment-gap scenarios
  └─ Other Prod failures → ❌ Fail, no Dev fallback.

Other URLs (reference only — never auto-targeted for UI tests):
  - Staging: https://app.staging.firstrecon.ai
  - Localhost: http://localhost:3000 (code verification only)
```

---

## Examples

### Example 1: Clear Frontend Bug with PR (READY → auto-executes on Dev)

**Issue**: GR-2847 — Chat timestamp shows UTC instead of user timezone

**Step 3 — PR Read (via pr-sentinel):**
- PR: `https://github.com/firstrecon/app/pull/4821` — MERGED (confirmed via `gh pr view`)
- Files changed: `src/components/Chat/ChatMessage.tsx`, `src/utils/time.ts`
- Diff: Added `formatLocalTime(ts, userTimezone)` helper; replaced `ts.toUTCString()` with the new helper.

**Analysis Result:**
```
✓ Frontend UI testing required (confirmed by PR diff in ChatMessage.tsx)
✓ Steps are specific, expected outcome measurable
✓ No [Pro]/[Prod] tag → environment: Dev only, no fallback
✓ PR Merged — fix is in
✓ READY → auto-proceeding to manual-test-executor on Dev
```

### Example 2: [Prod] Backend Bug (READY → auto-executes on Production)

**Issue**: GR-2684 — [Prod] dlp_response_detail masking not implemented

**Step 3 — PR Read (via pr-sentinel):**
- PR: `https://github.com/firstrecon/app/pull/4756` — MERGED
- Files changed: `migrations/0073_dlp_response_detail.sql`, `services/dlp/response_handler.py`

**Analysis Result:**
```
✗ Backend API only (no .tsx/.jsx files in PR)
✓ [Prod] tag detected → environment: Production primary, Dev fallback for deployment gap
✓ PR Merged — fix is in
✓ READY → auto-proceeding to manual-test-executor on Production
```

### Example 3: Unclear Bug (NEEDS CLARIFICATION → stops)

**Issue**: GR-2848 — API sometimes returns 500 errors

**Analysis Result:**
```
❌ Steps lack specificity, preconditions missing
⚠️ NEEDS CLARIFICATION — stopping here
```

---

## Notes for QA

- Reading the PR is part of the analysis flow — the diff is often the most informative artifact for deriving test cases
- `pr-sentinel` handles all PR discovery and status confirmation; Chrome/`web_fetch` remain useful only for a human-readable deep read when needed
- Analysis and testing are a continuous flow — the goal is to verify, not just validate
- Verification criteria are deliberately minimal (2-3 items) — proof of fix, not a full regression suite
- `manual-test-executor` handles all testing mechanics: auth, environment routing, media capture, report, Linear comment
- **Dev has no UI fallback** for normal tickets. A failure on Dev is a real failure — do not silently retry on localhost or Staging.
- **`[Pro]`/`[Prod]` tickets are the only ones that touch Production.** Dev is their sole fallback, and only for deployment-gap scenarios.
