---
name: "pr-review-response"
description: "Respond to AI-reviewer (Codex, Greptile, Copilot) or human review findings on your own pull request in any repo — fix or decline each one, reply per thread, and post a review response summary. Triggers: address review comments, respond to Codex/Greptile, review response summary, fix the bot findings, close out review threads."
---

# PR Review Response

Use this after bots or humans have reviewed the user's pull request. Every comment, bot or
human, is evidence to investigate — never dismissed because a bot wrote it, never accepted
without checking. The method here comes from teams that run several AI reviewers at once; it
works on any repo.

## Step 0 — Learn the project's rules

Read the repo's review contract if it has one (`REVIEW.md`, `CONTRIBUTING.md`, `AGENTS.md`,
`CLAUDE.md`, PR template). Note: allowed dispositions, whether an issue/ticket link is required,
commit message convention, branch naming, whether AI co-author/attribution lines are wanted or
forbidden, who may approve, and any "never weaken" list (auth, tests, lint ceilings, CI gates).
If the project says nothing, use the defaults below. Follow the user's own standing preferences
about attribution and commit style over the defaults.

## Step 1 — Inventory every thread

1. Collect all review threads: inline comments (including collapsed "resolved" ones), formal
   reviews, and issue-level comments. `gh api repos/<o>/<r>/pulls/<n>/comments`,
   `.../pulls/<n>/reviews`, `.../issues/<n>/comments`. If the CLI is not authorised, read the PR
   in the browser and expand "Show resolved" threads.
2. For each: who raised it (which bot / which human), file and lines, the commit it reviewed,
   whether it is already resolved.
3. Record which reviewers actually ran on the **current head**. Many bots only run when summoned
   (e.g. an `@codex review` comment) and trials lapse silently. "No threads" means "no findings"
   only if the bot posted a completed review for this head; otherwise record
   "did not run / unavailable".
4. Group duplicates — two bots often raise the same defect. Pick the earliest or most complete
   thread as canonical.

## Step 2 — Decide each disposition

Default to only three dispositions (most review contracts use these or close equivalents):

- **Fixed** — code changed in this PR. The default for anything small (roughly under 100 lines).
- **Declined** — with a concrete technical reason the finding is wrong or does not apply.
  "Out of scope" alone is not a reason; "the shared helper can't be reused here because it
  assumes a single tenant" is.
- **Tracked** — only when the fix is genuinely outside this PR (spans unrelated subsystems).
  Needs a ticket/issue reference. Never track away a P1 / critical finding.

Avoid bare acknowledgements ("noted", "will do", "thanks") and "needs a human" as an answer to
a code comment. Humans are needed for secrets, approvals/merges, applying migrations, or
privileged deploys — not for fixing code.

Never satisfy a finding by weakening an assertion, a lint ceiling, auth, data isolation, i18n,
CI, or a governance check. If the only way to make it pass is to weaken something, that is a
Declined-with-reason conversation, not a fix.

Before deciding each one: reproduce it (run the test, trace the call, read the consumer) and
write one plain-language line of what the finding means. The user should understand it, not
just close it.

## Step 3 — Make the fixes

- One bounded commit per finding or per group of related findings. Stage specific files only —
  never `git add -A` / `git add .`.
- Commit messages in the repo's convention (commonly conventional commits with the ticket id,
  e.g. `test(ci): find workflow steps by id instead of position [TICKET-123]`). Add attribution
  trailers only if the project or user wants them.
- Add or strengthen the test the reviewer asked for. A fix for an "untested path" finding is
  incomplete without a test that reaches that path.
- Finding about tests pinning positions / literal config text: rewrite to find elements by parsed
  properties, or execute the script and assert behavior. Do a mutation check — break the behavior
  on purpose and confirm the new test fails.
- Finding about docs/headers overstating coverage: narrow the text to what is actually checked,
  or strengthen the check — say which you chose.
- Re-run whatever proof the PR body claims (focused unit/e2e suites, `--list` counts, type check,
  lint and format "no new findings vs base", whitespace check, any project guard scripts). If the
  diff touches config/workflow/generated files, grep the test tree for the changed basenames and
  run those suites too.
- Update the PR body's proof/validation section if counts or claims changed.

## Step 4 — Reply on every thread

```
Fixed in <short sha> (<TICKET or "no ticket — <reason>">). <What changed, one or two sentences.>
<Tests: which suite, how many passed, what new coverage was added.> <Gates: type check, lint,
hooks passed.>
```

```
Declined — <concrete technical reason>. <What would have to be true for it to apply.>
```

```
Tracked — <TICKET-ID>: <one-line scope of the follow-up and why it can't ship here>.
```

Duplicate threads get one line: `Duplicate of <link to canonical thread> — Fixed there.` (echo
the real disposition of the canonical thread; never cross-reference two threads to each other).
Resolve each thread after replying.

## Step 5 — Post the review response summary

One issue-level comment:

```
## Review Response Summary
Head: <sha> · <TICKET or "no ticket — <reason, stated as a deviation>">

- Fixed: N (<one phrase per finding>)
- Declined: N (<reason each>)
- Tracked: N (<ticket each>)
- Non-actionable / stale: N (duplicates; informational bot comments such as size advisories,
  changelog, scans)
- Reviewer availability: <Bot A> — reviewed <sha>, K findings | did not run; <Bot B> — …;
  humans — …. An absent review is not a clean review.

### Validation
- <focused suites and counts>
- <type check / lint / format / hooks>
- <CI state when posted: passed / pending / not polled>

All thread replies have been posted. This records review-response completion, not approval or
merge readiness.
```

## Step 6 — Verify before you stop

- Zero unresolved threads; every one carries Fixed / Declined / Tracked.
- PR body matches the new head.
- Commit messages and PR text follow the project's and the user's conventions (including any
  rule about attribution lines).
- Tell the user in plain language what each finding meant, what changed, and what is still
  waiting on a human (approvals, merge queue).

If the user only wants the plan, stop after Step 2 and present the disposition table for
approval. Posting comments and pushing commits are actions the user confirms first.