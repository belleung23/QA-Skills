---
name: pr-sentinel
description: "Deep PR verification gatekeeping skill — checks every PR linked to a Linear issue before testing or analysis proceeds. PRIMARY check: reads the linked GitHub PR URLs off the Linear issue (via its attachments, populated by Linear's GitHub integration), then confirms real-time MERGED/OPEN/CLOSED status directly from GitHub with `gh pr view`. Then reads the full GitHub diff, commit history, and reviewer approvals. Produces a PR Gate Report: ✅ GATE OPEN (all PRs merged) or 🚫 GATE BLOCKED (unmerged PR found). Use whenever you need to verify PRs before testing, confirm a fix has landed, or as a mandatory pre-step before ticket analysis. Triggers on: check PR, verify PR, PR gate, PR sentinel, is the PR merged, check if PR is merged, what changed in this PR, review PR before testing, PR status check, gate check, PR gatekeeper, pre-analysis PR check, check linked PRs."
---

# PR Sentinel 🛡️

## Purpose

The PR Sentinel is the **mandatory gatekeeper** between a Linear issue and any downstream action (analysis, testing, release). It inspects every PR linked to the issue and either:

- ✅ **GATE OPEN** — all PRs are merged; full PR context is extracted and ready to pass to the next step
- 🚫 **GATE BLOCKED** — one or more PRs are unmerged, closed without merge, or missing; downstream steps must stop

> **Rule**: If PR Sentinel is blocked, no testing, analysis, or release action may proceed until the issue is resolved.

> Migrated from Jira. The old primary check was "open the Jira ticket in Chrome, read the
> Development panel's live MERGED/OPEN/CLOSED badge." Chrome is no longer the primary source —
> the new primary check queries the Linear issue's `attachments` for linked GitHub PR URLs
> (Linear's GitHub integration auto-attaches PRs that mention the issue identifier), then asks
> GitHub directly via `gh pr view` for the authoritative, real-time merge status. This is
> **more** reliable than the old browser-scrape, not less — it's a direct API call to the
> actual source of truth (GitHub) instead of a cached badge, and it removes the Chrome
> dependency for the gate decision itself. See `LINEAR_CHEATSHEET.md` §5.

---

## When to Use

- **Standalone**: `"Check the PR for GR-1234"`, `"Is the PR merged on this ticket?"`
- **Pre-analysis gate**: Called by `ticket-inspector` before codebase analysis
- **Pre-test gate**: Called by `manual-test-executor` before any test run
- **Pre-release gate**: Called before marking an issue Ready To Release
- **Ad-hoc audit**: `"What did the PR change?"`, `"Show me the diff for GR-5678"`

---

## Workflow

### Step 1 — Fetch the Linear Issue

```graphql
query($id: String!) {
  issue(id: $id) {
    identifier title priority
    state { name type }
    labels { nodes { name } }
    attachments { nodes { url title metadata } }
  }
}
```

Extract:
- Issue ID (e.g. `GR-1234`)
- Issue title — check for `[Pro]` / `[Prod]` tag (affects which environment the fix should be in)
- Issue kind (Bug / Task / Story / Subtask) — inferred from labels (a `Bug` label means Bug; otherwise Task/Story/etc per whatever label taxonomy is used)
- Workflow state (To Do / In Progress / In Review / Done / Ready To Release)

The issue fetched here **is** the primary spec now — unlike the old Jira flow, there's no
separate "check for a Linear cross-link for richer context" step (Step 4 in the old skill).
That step is gone: everything it used to fetch from a linked Linear ticket now simply lives on
this issue directly.

---

### Step 2 — Extract Linked PR URLs (Primary PR Discovery)

From the `attachments` list fetched in Step 1, filter for entries whose `url` contains
`github.com` and `/pull/`. Linear's GitHub integration attaches these automatically when a
branch or PR references the issue identifier (e.g. a branch named `fix/GR-1234-dlp-masking`,
or a PR title/description containing `GR-1234`).

**If no PR attachments are found:**
→ Record `⚠️ No PR linked` and skip to Step 6 (Gate Decision).

For each PR URL found, record:
| Field | What to capture |
|-------|----------------|
| PR URL | Full GitHub URL, from the attachment |
| Attachment title | Linear's own label for it (usually the PR title) |

---

### Step 3 — Confirm Real-Time Merge Status via GitHub (Primary Status Check)

**This is the authoritative check — do this for every PR URL from Step 2, every time.**

```bash
gh pr view "$PR_URL" --json number,title,state,mergedAt,baseRefName,headRefName,author,reviews,url
```

Record for each PR:

| Field | What to capture |
|-------|----------------|
| PR Number | `#1234` |
| PR Title | The name given by the developer |
| **Status** | **MERGED ✅ / OPEN ⚠️ / CLOSED ❌** — read directly from `state` + `mergedAt` |
| Branch → Target | `headRefName → baseRefName` |
| Reviewers | From `reviews` |
| Updated | Timestamp of last update |

**Why `gh pr view` instead of a cached badge?** It hits GitHub's API directly — there's no
intermediate cache to go stale. A PR merged one minute ago will show `MERGED` immediately.

**Gate decision from this step:**
- If **all PRs show MERGED** → provisional ✅ GATE OPEN (still need diff details from Step 4 for downstream use)
- If **any PR shows OPEN or CLOSED without merge** → 🚫 GATE BLOCKED; record the reason and skip to Step 6

---

### Step 4 — Deep-Read Each PR on GitHub

For each PR URL collected in Step 2, perform a full read using `gh pr view` (already fetched
core fields in Step 3) plus the diff/commits, via `gh` or Chrome browser automation as a
human-readable fallback.

#### 4a. Full PR detail

```bash
gh pr view "$PR_URL" --json number,title,body,state,mergedAt,baseRefName,headRefName,\
labels,milestone,reviews,commits,additions,deletions,changedFiles,files
```

Extract:
- **Status**: Merged ✓ / Open ⚠️ / Closed ❌ (already confirmed in Step 3)
- **Merge commit SHA** and **merge date/time**
- **Base branch** / **Head branch**
- **PR description**: Full body — what the developer says was done, why, and any notes for reviewers
- **Linked issues**: Any `Closes #XX`, `Fixes GR-XX`, or referenced tickets in the description
- **Labels**: (e.g. `bug`, `enhancement`, `do-not-merge`, `WIP`)
- **Milestone** (if present)
- **Reviewers**: Who reviewed, approval status (Approved ✓ / Changes requested ⚠️ / Pending ⏳)
- **Number of commits**
- **Number of files changed**
- **Additions / Deletions** (the `+N / -N` summary)

#### 4b. Files Changed

```bash
gh pr diff "$PR_URL" --name-only
gh pr diff "$PR_URL"
```

For each changed file:
- Record the **file path**
- Note **additions** (+) and **deletions** (-)
- Capture **key diff observations** — focus on logic changes, not whitespace/formatting:
  - New functions or methods added
  - Existing functions modified (what changed)
  - Removed code (what was deleted and why it matters)
  - Config, schema, or migration changes
  - Test files added or modified
  - Any `TODO`, `FIXME`, or `HACK` comments introduced

#### 4c. Commits

```bash
gh pr view "$PR_URL" --json commits
```

Extract:
- **Commit count**
- **Commit messages** (all of them) — these often reveal more context than the PR description
- **Any fixup / merge commits** (signal of iteration)
- **Committers** (may differ from PR author)

#### 4d. Related PRs

Check the PR body and comments for references to:
- Other PRs in the same repo (`#XXXX`)
- PRs in other repos (cross-repo changes)
- Dependency PRs that must merge first
- Revert PRs

If related PRs are found, fetch their status via `gh pr view` and include them in the report.

---

### Step 5 — PR Health Checks

For each PR, evaluate these health signals:

| Check | Pass ✓ | Warning ⚠️ | Fail ❌ |
|-------|--------|-----------|--------|
| **Merge status** | MERGED | — | OPEN / DECLINED / CLOSED without merge |
| **Target branch** | Expected branch (main/develop) | Unexpected branch | Wrong repo |
| **Has description** | Non-empty PR body | Very short (< 2 lines) | Empty |
| **Has approvals** | ≥1 approval | No approvals but merged | Changes requested, still merged |
| **No `WIP` / `do-not-merge` labels** | No such labels | — | Label present |
| **No open blocking comments** | — | Unresolved review threads | Explicit "do not merge" comment |
| **Diff is non-trivial** | Files changed + additions present | Only test/doc changes | Empty diff |
| **Related PRs merged** | All related PRs merged | Some related PRs open | Blocking dependency unmerged |

---

### Step 6 — Gate Decision

After evaluating all PRs:

**✅ GATE OPEN** — All of the following are true:
- At least one PR is linked
- All linked PRs have status **MERGED** (confirmed via `gh pr view`)
- No PRs carry `WIP`, `do-not-merge`, or equivalent labels
- No blocking dependency PRs are unmerged
- The diff is non-empty (code actually changed)

**🚫 GATE BLOCKED** — Any of the following are true:
- A linked PR is **OPEN** (not yet merged)
- A linked PR was **CLOSED** without merging (abandoned)
- A `do-not-merge` / `WIP` label is present on any PR
- A critical dependency PR referenced in the body is unmerged
- No PR is linked at all and there is no other evidence the fix is in

**⚠️ GATE WITH WARNINGS** — Proceed but flag:
- PR was merged without any approvals
- PR description is missing or extremely sparse
- PR has unresolved review comments (merged anyway)
- Related PRs are open but non-blocking (e.g. follow-up work)

---

### Step 7 — Output the PR Gate Report

Always output a structured report:

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🛡️  PR SENTINEL GATE REPORT
Issue: GR-XXXX — [Issue Title]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## Gate Status
[✅ GATE OPEN / 🚫 GATE BLOCKED / ⚠️ GATE OPEN WITH WARNINGS]

Reason: [One-line explanation]

---

## PR Summary (N PR(s) found)

### PR #1 — [PR Title]
- **URL**: https://github.com/...
- **Status**: ✅ MERGED / 🚫 OPEN / ❌ CLOSED
- **Verified via**: Linear issue attachments (PR discovery) + `gh pr view` (authoritative status)
- **Merged**: [Date] → [base branch]
- **Author**: [GitHub username]
- **Reviewers**: [name] ✓ Approved / ⏳ Pending
- **Commits**: N
- **Files changed**: N (+X / -Y lines)
- **Labels**: [label1, label2] or None
- **Linked issues**: [GR-XXXX, #PR-ref] or None

#### PR Description Summary
[Paraphrase of what the developer described — 2-5 sentences]

#### Files Changed
| File | +Lines | -Lines | Key Change |
|------|--------|--------|------------|
| src/components/Chat/ChatMessage.tsx | +24 | -8 | Added timezone formatting helper |
| src/utils/time.ts | +15 | -0 | New formatLocalTime() function |
| tests/utils/time.test.ts | +30 | -0 | Unit tests for new helper |

#### Key Diff Observations
- [What logic changed — concrete, testable observations]
- [Any new validations or error handling added]
- [Any schema/migration changes]
- [Any removed code or deprecated paths]

#### Commit Messages
1. `[SHA] message`
2. `[SHA] message`

#### Related PRs
- [#XXXX — title — MERGED / OPEN] or None

---

## Health Check Summary
| Check | Result |
|-------|--------|
| All PRs merged | ✅ / 🚫 |
| Target branch correct | ✅ / ⚠️ |
| PR has description | ✅ / ⚠️ |
| PR has approvals | ✅ / ⚠️ |
| No WIP/do-not-merge labels | ✅ / 🚫 |
| Non-empty diff | ✅ / ❌ |
| Related PRs all merged | ✅ / ⚠️ |

---

## Diff Intelligence (for downstream use)
- **Scope**: [Frontend / Backend / Full Stack / Config / Infra]
- **Risk level**: [Low / Medium / High] — [one-line reason]
- **Test surface**: [What QA should focus on based on the diff and the Linear issue's own AC]
- **Regression risk**: [What existing features might be affected]

---

## Gate Verdict
[✅ GATE OPEN — Safe to proceed to analysis/testing]
[🚫 GATE BLOCKED — Reason. Action required: [what needs to happen]]
[⚠️ GATE OPEN WITH WARNINGS — Proceed, but note: [warnings]]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

---

### Step 8 — Hand Off (if called as a pre-step)

If PR Sentinel was invoked **as part of a larger workflow** (e.g. by `ticket-inspector` or `manual-test-executor`):

**If ✅ GATE OPEN or ⚠️ GATE OPEN WITH WARNINGS:**
- Pass the full PR Gate Report data to the calling skill
- Calling skill may use the "Diff Intelligence" section directly as its codebase analysis starting point — skip re-fetching the same PR

**If 🚫 GATE BLOCKED:**
- Emit the Gate Report
- Return control to the user with a clear message:
  > "🚫 PR Sentinel has blocked this issue. [Reason]. Testing/analysis cannot proceed until the PR is merged. Please notify the developer and re-run once `gh pr view` shows MERGED."
- **Do not proceed** to the calling skill's next step

---

## Behavior Rules

1. **`gh pr view` is the primary source of truth for merge status.** Always confirm status directly from GitHub for every PR URL found on the Linear issue, every time — don't trust a cached label or the issue's own workflow state.

2. **Never skip the PR check** — even if the ticket looks simple or the PR "probably" merged, always verify via `gh pr view`.

3. **Multiple PRs = check all of them** — an issue with 3 PRs is only GATE OPEN if all 3 are MERGED.

4. **No PR ≠ GATE OPEN** — a missing PR is a warning/block, not permission to proceed.

5. **Don't trust the issue's workflow state** — a Linear issue in "Done" or "Ready To Release" does not guarantee the PR is merged. Always check GitHub directly.

6. **Labels matter** — a MERGED PR with a `do-not-merge` label still gates (it may have been merged by mistake).

7. **Diff Intelligence is required output** — always include scope, risk level, test surface, and regression risk so downstream skills don't have to re-fetch the PR.

---

## Examples

### Example A: Clean GATE OPEN

```
Issue: GR-9854 — Enable authority-outage alerting in production

Step 2 — Linear attachments:
  Found 1 GitHub PR attachment: https://github.com/firstrecon/app/pull/7794

Step 3 — gh pr view:
  PR #7794 — state: MERGED, mergedAt: 2026-08-17T02:11:00Z
  Branch: feature/GR-9854-alerting → main

PR #7794 — MERGED ✅
  Target: main ← feature/GR-9854-alerting
  Files: workers/telemetry/alerting.ts (+87/-12), cron/health-check.ts (+24)
  Approvals: 2 ✓

Gate Status: ✅ GATE OPEN
Test surface: Authority-outage cron trigger; PagerDuty routing; alert timing
Regression risk: Low — new alerting path, no changes to existing flows
```

---

### Example B: GATE BLOCKED (PR still open)

```
Issue: GR-3087 — [Prod] DLP masking missing from response detail

Step 2 — Linear attachments:
  Found 1 GitHub PR attachment: https://github.com/firstrecon/app/pull/4963

Step 3 — gh pr view:
  PR #4963 — state: OPEN (last updated 2 days ago)
  Branch: fix/GR-3087-dlp-masking → main

Gate Status: 🚫 GATE BLOCKED
Reason: PR #4963 is still open — fix has not landed yet.
Action: Notify developer. Re-run PR Sentinel once `gh pr view` shows MERGED.
```

---

### Example C: GATE WITH WARNINGS (merged without approval)

```
Issue: GR-2940 — Update default model to claude-sonnet-4

Step 2 — Linear attachments:
  Found 1 GitHub PR attachment: https://github.com/firstrecon/app/pull/4877

Step 3 — gh pr view:
  PR #4877 — state: MERGED, mergedAt 1 hour ago

PR #4877 — MERGED ⚠️
  Approvals: 0 (merged by author directly)
  Labels: none
  Files: config/defaults.ts (+1/-1)

Gate Status: ⚠️ GATE OPEN WITH WARNINGS
Warning: PR merged without any reviewer approvals.
Proceeding — but flag in QA report.
```

---

## Integration Points

| Calling Skill | How PR Sentinel plugs in |
|--------------|--------------------------|
| `ticket-inspector` | Replaces its Step 3 (Read Linked GitHub PR) — PR Sentinel's Diff Intelligence feeds directly into codebase analysis |
| `manual-test-executor` | Pre-flight gate — if blocked, executor does not start |
| `linear-ticket-transition` | Gate check before Ready To Release transition |
| `test-case-generator` | Diff Intelligence used as primary source for test case scope |
| Standalone | User asks directly about PR status or diff |
