---
name: "flake-surgeon"
description: "Fix Playwright specs that failure-triage classified as FLAKY or BAD TEST, then re-run ONLY those tests via --grep @TC-ID and require 3 consecutive clean passes before declaring them stable. Applies web-first waits, selector hardening, and test isolation — never weakens assertions to force green. Use after triage, or whenever a known-flaky test needs fixing and verifying. Triggers on: fix flaky test, stabilize test, de-flake, fix and rerun, rerun failed test, make this test pass reliably, fix the flaky scripts, repair test, flake surgeon."
---

# Flake Surgeon

Stage 2 of the failure-recovery chain:

`failure-triage` → **flake-surgeon** → `triage-report`

Takes the 🌀 FLAKY and 🧪 BAD TEST rows from the Triage Matrix, repairs them, and proves the repair by re-running **only** those tests until they pass 3 times in a row.

Stack: Playwright + TypeScript. Default env `https://app.dev.firstrecon.ai`.

---

## Hard rules — read before editing anything

1. **Never touch a 🐞 REAL BUG row.** If the app is broken, the test is right. Refuse and send it to `triage-report`.
2. **Never weaken an assertion to make a test pass.** Deleting an `expect`, loosening `toHaveText` to `toContainText` to dodge a real mismatch, swapping to `toHaveCount(0)`, wrapping in try/catch, or adding `test.skip()` are all forbidden as "fixes". A green test that no longer gates anything is worse than a red one.
3. **No `waitForTimeout` in a fix.** Ever. A fix that adds a sleep is not a fix. When the flake is "UI read before the server answered", the fix is a `waitForResponse` / `waitForRequest` registered **before** the action (Pattern E) — not a sleep, not `networkidle`, not a bigger timeout.
4. **One test, one fix, one verification.** Don't batch-edit a whole spec file and re-run everything.
5. If no triage verdict exists for a failure, run `failure-triage` first. Do not fix blind.

---

## Step 1 — Load the work list

Read `triage-matrix.md` (or take the verdicts passed in). Build the queue:

```
Queue (5):
  1. TC-WC-ModelSelector-004  🌀 FLAKY     sleep-then-read vs 700ms animation
  2. TC-WC-Sidebar-009        🌀 FLAKY     strict-mode violation, list reorders
  3. TC-PA-Users-014          🌀 FLAKY     depends on user created by -013
  4. TC-PA-Sidebar-007        🧪 BAD TEST  asserts renamed label "Insights"
  5. TC-WC-Context-002        🔌 ENV       → SKIPPED, not a code fix
```

Process one at a time, in order.

---

## Step 2 — Reproduce the flake before fixing

Establish a baseline so you can prove the fix did something.

```bash
npx playwright test --grep "@TC-WC-ModelSelector-004" --workers=1 --repeat-each=5 --retries=0 --trace=on
```

Record `baseline: N/5 passed`. If it is 5/5 in isolation, the flake is caused by **parallelism or cross-test state**, not by the test's internals — re-run under load to see it:

```bash
npx playwright test --workers=4 --grep "@TC-WC-ModelSelector-004|@TC-WC-Sidebar-009" --retries=0
```

If you cannot reproduce the failure at all after 5 isolated + 1 parallel attempt, do **not** invent a fix. Mark it `⚠️ NOT REPRODUCED`, leave the code untouched, and recommend `--retries=1` monitoring over the next few runs.

---

## Step 3 — Apply the right fix

Match the root cause from triage to a pattern. Read the spec and its page object first; fix at the page-object level when the selector is shared.

### Pattern A — sleep / point-in-time read → web-first assertion

```typescript
// ❌ before
await page.waitForTimeout(500);
expect(await page.locator('.dropdown').isVisible()).toBe(true);

// ✅ after — auto-retries until the animation settles or the timeout trips
await expect(page.getByRole('listbox', { name: 'Model selector' })).toBeVisible();
```

Any `await someLocator.textContent()` / `.isVisible()` / `.count()` feeding a bare `expect` is a point-in-time read. Convert it to `await expect(locator).…`, which polls.

### Pattern B — brittle selector → Playwright-native, scoped

Priority (same as `automation-runner` / `automation-aegis` A3): `getByTestId` → `getByRole` / `getByLabel` / `getByText` → CSS → XPath (last resort).

```typescript
// ❌ nth-child positional, breaks when the list reorders
page.locator('.sidebar-item:nth-child(3)')

// ✅ identity-based
page.getByRole('link', { name: 'Model Catalog' })
```

### Pattern C — strict-mode violation (locator matched N elements)

Scope, don't `.first()`. `.first()` hides the ambiguity and can silently assert the wrong node.

```typescript
// ❌
page.getByText('Delete').first()

// ✅
page.getByRole('row', { name: 'Acme Corp' }).getByRole('button', { name: 'Delete' })
```

### Pattern D — cross-test state / ordering dependency

The test must create everything it needs and clean up after itself.

```typescript
// ❌ relies on a user another spec created
await page.getByRole('row', { name: 'testuser@example.com' }).click();

// ✅ unique per-run data, created in the test
const email = `qa+${Date.now()}@example.com`;
await createUser(page, email);
await page.getByRole('row', { name: email }).click();
```

If the tests are genuinely a sequence, make that explicit with `test.describe.serial(...)` rather than leaving it implicit — but prefer independence.

### Pattern E — race on network: anchor on `waitForResponse` / `waitForRequest`

**Symptom in the trace:** the test read the screen (or a toast, or a row count) while the API call the action triggered was still pending; or a `waitForResponse` timed out even though the Network tab shows the call returned fine (it arrived *before* the listener started).

**Fix:** start listening before the action, match the exact call, then assert on the response **and** the UI. Full rules: `automation-runner` → "Network-anchored assertions" (N1–N7).

```typescript
// ❌ before — wait registered AFTER the click: if the response is fast, the listener misses it → random timeout
await widgetsPage.saveButton.click();
await page.waitForResponse((r) => r.url().includes('/api/v1/widgets') && r.ok());
await expect(page.getByRole('table')).toBeVisible();

// ❌ also before — no network wait at all; reads the table before the server answers
await widgetsPage.saveButton.click();
await expect(page.getByRole('row', { name: 'Widget A' })).toBeVisible(); // passes or fails by timing

// ✅ after — listen first, match path + method, assert status + payload, then the UI
const saveResponse = page.waitForResponse(
  (r) => new URL(r.url()).pathname === WIDGETS_API && r.request().method() === 'POST',
);
await widgetsPage.saveButton.click();
const response = await saveResponse;
expect(response.status()).toBe(201);
const created = readWidget(await response.json()); // unknown → narrowed
await expect(page.getByRole('row', { name: created.name })).toBeVisible();
```

For filter/search/sort flakes, use `page.waitForRequest` the same way and assert the outgoing params (`new URL(request.url()).searchParams`) before asserting the refreshed list.

Checks while fixing:
- **Matcher too loose?** A bare `url().includes(...)` can resolve on a background poll or `OPTIONS` preflight and let the test continue early. Match `pathname` (named constant) + method; add a body check if the endpoint is shared.
- **Endpoint confirmed?** Get the real path from the trace's Network tab or the frontend API client — don't guess.
- **Request always fires?** If the data can come from a client cache, the wait will time out intermittently — wait on the UI state instead, or on the call that does always fire.
- **Keep the UI assertion.** Adding `waitForResponse` never replaces the web-first `expect` on what the user sees (Hard rule 2 — no weakening).
- **Not a fix:** `waitForLoadState('networkidle')` (the app polls, so it settles randomly or never) or bumping `{ timeout }`.

### Pattern E2 — race on navigation

```typescript
// ✅ wait for the URL, then for the data call the page needs (registered before the click)
const listResponse = page.waitForResponse(
  (r) => new URL(r.url()).pathname === WIDGETS_API && r.request().method() === 'GET',
);
await sidebar.widgetsLink.click();
await expect(page).toHaveURL(/\/widgets$/);
expect((await listResponse).status()).toBe(200);
await expect(page.getByRole('table')).toBeVisible();
```

### Pattern F — auth / storage state churn

If the failure is a mid-run redirect to login, reuse a stored session instead of logging in per test — see the **electron-precondition** and **session-recovery** skills for the storage-state file convention.

### Pattern G — 🧪 BAD TEST (stale or wrong expectation)

Do **not** just change the expected value to whatever the app currently renders — that is rubber-stamping. Confirm the new behaviour is intended: check the AC on the Linear issue, or the PR that changed it (`pr-sentinel` / `ticket-inspector`). Then update the assertion and note the ticket reference in the diff:

```typescript
// GR-5210 renamed "Insights" → "Analytics"
await expect(page.getByRole('link', { name: 'Analytics' })).toBeVisible();
```

If you cannot confirm the change was intentional, stop — it may be a real bug wearing a bad-test costume. Kick it back to `failure-triage`.

---

## Step 4 — Re-run ONLY that test, 3× green required

Never re-run the whole suite to verify one fix.

```bash
npx playwright test --grep "@TC-WC-ModelSelector-004" --workers=1 --repeat-each=3 --retries=0
```

Then one pass under realistic parallelism, because isolation hides ordering flakes:

```bash
npx playwright test --workers=4 --retries=0 --grep "@TC-WC-ModelSelector-004"
```

**Stability gate:** `3/3` isolated **and** the parallel run green → ✅ FIXED. Anything less → not fixed.

| Result | Action |
|---|---|
| 3/3 + parallel green | ✅ FIXED — move to next item |
| 2/3 or worse | Fix is wrong or partial. Revert it, re-read the trace, try a different pattern. Max **3 attempts** per test. |
| Passes isolated, fails parallel | Cross-test state — go back to Pattern D |
| New, different error appears | The fix broke something. Revert and reassess. |
| 3 attempts exhausted | ⚠️ UNRESOLVED — revert to original, tag `@known-bug` + `test.fixme()` **with a ticket-style reason**, and escalate in the report. Never leave a silently-skipped test. |

---

## Step 5 — Quality-gate the diff

Before declaring done, run the toolchain and the review gate over what you changed:

```bash
npx tsc --noEmit
npx eslint <changed files>
npx playwright test --list --grep "@TC-..."   # still collects
```

Then run **automation-aegis** on the changed files. A fix that introduces a hardcoded URL, a `.first()` band-aid, or a disabled lint rule is not shippable. 🔴 Blocker → fix before reporting.

---

## Step 6 — Emit the Fix Log

```
=== Flake Surgeon — Fix Log ===

✅ TC-WC-ModelSelector-004   model_selector.spec.ts:88
   Cause : waitForTimeout(500) then isVisible(); dropdown animates ~700ms
   Fix   : Pattern A — await expect(getByRole('listbox')).toBeVisible()
   Verify: baseline 2/5 → 3/3 isolated ✅ · parallel ✅
   Diff  : -2 +1

✅ TC-PA-Users-014           users.spec.ts:120
   Cause : consumed the user created by TC-PA-Users-013
   Fix   : Pattern D — creates its own `qa+<ts>@example.com`, cleans up in afterEach
   Verify: 3/3 isolated ✅ · parallel ✅
   Diff  : -4 +11

✅ TC-PA-Sidebar-007         sidebar.spec.ts:19   [BAD TEST]
   Cause : asserted "Insights"; renamed to "Analytics" in GR-5210 (confirmed in AC)
   Fix   : Pattern G — expectation updated, ticket referenced in comment
   Verify: 3/3 isolated ✅ · parallel ✅

⚠️ TC-WC-Sidebar-009         sidebar.spec.ts:44   UNRESOLVED after 3 attempts
   Cause : strict-mode violation; list order is genuinely non-deterministic from the API
   Tried : scoped by row name; getByTestId; waitForResponse then assert
   Status: reverted, tagged @known-bug + test.fixme('GR-XXXX: sidebar order non-deterministic')
   Needs : product decision on whether the API should return a stable order

Summary: 3 fixed · 1 unresolved · 1 env-skipped
Aegis on diff: ✅ PASS (grade A)
```

---

## Step 7 — Hand off

```
Next: run **triage-report** to consolidate triage + fixes, dedupe-check Linear for the real bugs,
and update the Automation column in the test suite.
```

---

## Hand-off: start the next step yourself

This skill is one link in the shift-left chain. `shift-left-pipeline` owns the full map; the steps
that follow this skill are in the table below. When you finish, start the next step yourself
instead of waiting to be asked.

1. **Find the run.** Look for `<repo>/.qa-kit/runs/*/state.json` that matches this work (same ticket
   or slug, or it lists these spec files). If there is none, create
   `<repo>/.qa-kit/runs/<ticket-or-feature>/state.json` with `"mode": "auto"`.
2. **Record what you did.** Append `{ "stage", "skill", "verdict", "evidence", "at" }` to `history`,
   then set `stage`, `status` and `next`.
3. **Start the next step** from the table, unless a rule below says to stop.

| This skill ended with | Next step |
|---|---|
| Fix Log written (FIXED / UNRESOLVED / NOT REPRODUCED) | `triage-report`, then `shift-left-pipeline` S7 (final run of all changed specs + the stability repeat) |
| A REAL BUG row turned up in the queue | `root-cause-forensics` for it (never fix the test) |

**Don't chain** when the user asked for this step only ("just triage", "report only"), or when the
work is someone else's (reviewing their PR). Finish, and name the next step in one line.

**Shared actions never run on their own.** A push, PR, comment, ticket, CI re-run or sheet update
goes into `pending` with its exact content. Keep going with the local steps; everything in
`pending` is shown together for one yes at the next approval point (`status: "waiting-approval"`).

**Stop and say what's needed** in one or two plain lines, and set `status`, when:
- the chain waits on someone: dev hasn't delivered yet (`waiting-dev`) or CI is running
  (`waiting-ci`);
- a decision only the user can make is needed, the 3-fix-round limit is reached, or access or a
  credential is missing (`blocked`).

The user resumes a stopped chain with "continue <ticket>".

`state.json` (format owned by `shift-left-pipeline`):

```json
{ "slug": "<ticket>", "mode": "auto", "stage": "S6", "status": "running", "next": "flake-surgeon",
  "specs": ["<spec files>"], "pending": [],
  "history": [{ "stage": "S6", "skill": "failure-triage", "verdict": "2 FLAKY, 1 REAL BUG", "evidence": "triage.md", "at": "<ISO time>" }] }
```

---

## Guardrails

- Show the diff for anything beyond a mechanical single-line change; the user can always ask you to revert.
- Keep each fix minimal and scoped to the failing test path. No opportunistic refactors of passing tests.
- If >50% of the queue needs the same fix pattern, say so — the generator or the shared fixture is the real problem, and fixing it once upstream beats fixing it N times.
- Never commit or push unless asked.