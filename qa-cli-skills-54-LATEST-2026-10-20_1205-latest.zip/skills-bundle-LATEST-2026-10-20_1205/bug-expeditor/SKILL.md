---
name: bug-expeditor
description: "Go on a bug expedition through First Recon AI — web app or Electron desktop — hunting for undocumented bugs, usability issues, and edge cases using session-based charters. Covers all workspaces (Chat/Workspace, Platform Admin, Developer Console, Reviewer, Operations Portal, User Settings) and the Electron desktop app. Every confirmed finding gets root-cause-forensics run on it before the report is written. Produces a full .md QA report with findings, RCA verdicts, evidence, and optional Linear issue filing. Trigger on: Explore, ET, bug expedition, exploratory test, explore the app, ET GR-, free testing, find bugs, go explore, explore electron, ET electron, explore desktop, desktop app, or any unscripted quality pass on any part of First Recon AI."
---

# Bug Expeditor

A bug expedition is like exploring uncharted territory — you set out with a charter, navigate the app with curiosity, and report back everything you find. There are no pre-written scripts. The expeditor (Claude) uses product knowledge, heuristics, and real-time observations to roam the application and surface bugs that scripted testing would never reach.

This skill covers the **entire First Recon AI application** — both the web app and the Electron desktop app — and runs a structured-but-dynamic session-based exploration. Read this whole skill before starting.

## Shared References

Before proceeding, read:
- `shared-qa-base/references/environments.md` — environment URLs, routing, test account
- `shared-qa-base/references/status-definitions.md` — status icons
- `shared-qa-base/references/media-rules.md` — screenshot/recording rules

---

## Trigger Patterns

| User says | What to do |
|-----------|-----------|
| `Explore` / `Exploratory test` | Full-app exploration on Dev (web) |
| `ET` | Full-app exploration on Dev (web), shorthand |
| `Explore [area]` / `ET [area]` | Scope exploration to the named area only |
| `ET GR-XXXX` | Explore the feature/area a Linear issue touches (read the issue first via `ticket-inspector`) |
| `ET [Pro]` / `ET [Prod]` | Full-app exploration on Production (web) |
| `Explore Electron` / `ET Electron` | Full exploration of the Electron desktop app |
| `Explore desktop` / `ET desktop app` | Full exploration of the Electron desktop app |
| `Explore [area] Electron` | Scoped Electron exploration (e.g. "Explore chat Electron") |

When a Linear issue ID is provided, read the issue with `ticket-inspector` first to understand the surface area before exploring.

---

## Environment Routing

| Trigger | Target | Fallback |
|---------|--------|---------|
| No `[Pro]`/`[Prod]` tag, no Electron mention | **Dev web** — `https://app.dev.firstrecon.ai` | None. Dev failures are real. |
| Contains `[Pro]` or `[Prod]` | **Production web** — `https://app.firstrecon.ai` | Dev if Production has a deployment gap |
| Contains `Electron` or `desktop` | **Electron app** — `/Applications/First Recon AI.app` | None — Electron failures are real |

Test account: `belle.ung@persefoni.com` (Google SSO for web; same credentials in Electron)

---

## Pre-Flight (mandatory before any exploration)

**For web exploration:**
1. Run `authenticator-authorizer` skill to confirm session is live on the target environment.
2. Sanity check: navigate to the home page — confirm it loads, user is signed in, no banners/errors blocking.

**For Electron exploration:**
1. Launch `/Applications/First Recon AI.app` and wait for the skeleton to resolve (usually within 20s).
2. Confirm the window title reads "First Recon AI", the sidebar is visible, and the user is signed in.
3. Note the app version and model shown (e.g. "OpenAI: gpt-5.2") in the charter.

**Both:** Announce your session charter before starting:

```
🧭 Exploratory Session Charter
Environment: [https://app.dev.firstrecon.ai | Electron desktop app]
Scope: [Full app | named area]
Tester: belle.ung@persefoni.com
Session goal: Hunt for functional, usability, security, and edge-case issues
Time box: ~[N] minutes per area

Starting expedition now...
```

---

## Exploration Scope — Web Workspaces

When doing a full **web** exploration, cover ALL six workspaces in order. When scoped, cover only the named area.

| # | Workspace | Entry URL | Key Surfaces |
|---|-----------|-----------|-------------|
| 1 | **Chat / Workspace** | `/workspace` | Chat, Cowork, Agent Hub, Pulse, Library |
| 2 | **User Settings** | `/settings/account` | Profile, Chat prefs, Language, Notifications |
| 3 | **Platform Admin** | `/admin` | People, Models, DLP, Security, Integrations, AI Studio |
| 4 | **Developer Console** | `/developer` | API Keys, Webhooks, Playground, Billing, Audit Logs |
| 5 | **Reviewer / Prompt Security** | `/reviewer` | Review queue, Policies, Reported messages |
| 6 | **Operations Portal** | `/operations` | Tenants, Users, Feature Flags, Dev Admin |

---

## Exploration Scope — Electron Desktop App

When the target is the Electron app, explore these areas in order:

| # | Area | How to access | Key surfaces |
|---|------|--------------|-------------|
| 1 | **App launch & shell** | Launch app | Window title, skeleton resolution, sidebar, nav items |
| 2 | **AI Chat — core** | Click "AI Chat" in sidebar | Empty state, input, send, streaming, model selector |
| 3 | **AI Chat — toolbar** | Toolbar buttons in chat | Context, Recall, Templates, Improve, Next Steps, Persona |
| 4 | **AI Chat — Knowledge tab** | "Knowledge" tab in chat area | Knowledge content loads, tab is interactive |
| 5 | **Quick Start Templates** | Template cards in empty state | Each template populates input correctly |
| 6 | **First Recon Agent** | "+ First Recon Agent" button | Modal opens, 3 actions present, input works |
| 7 | **Prompt Security** | "Prompt Security" in sidebar | Review queue loads, worklist items resolve (not stuck as skeletons) |
| 8 | **Settings & controls** | Gear icon, bell icon, region selector | Settings accessible, notifications panel, region shown |

### Electron-specific checks to always run

These are areas where Electron behaves differently from web and deserves extra attention:

- **i18n / translation keys** — look for raw key strings like `namespace.key.name` appearing as visible text anywhere (not translated). Especially in banners, tooltips, modals.
- **Response streaming** — does the AI actually deliver a response, or does "Thinking..." hang indefinitely?
- **Voice / microphone button** — is it visible in the chat toolbar? If the JS module loads but the button is absent, that's a gap.
- **Window resize behaviour** — resize the window to narrow (800px) and wide (1440px) — does layout hold?
- **Electron-specific APIs** — note if any browser-specific things (like downloads, file pickers) are wired up correctly.
- **Skeleton resolution** — after every navigation, confirm skeleton/blur placeholders actually resolve to content within 15s.
- **Console errors** — use `read_console_messages` to check for JS errors throughout the session.

---

## Exploration Heuristics (apply everywhere — web and Electron)

### 🔴 SFDPOT Heuristic
- **Structure** — What components exist? Missing, misaligned, or broken layout?
- **Function** — Does it do what it's supposed to? For all inputs?
- **Data** — What data does it store, display, transform? Boundaries respected?
- **Platform** — Browser/OS/viewport? Any rendering issues?
- **Operations** — Under load, slow network, concurrent actions?
- **Time** — Sessions, tokens, expirations, scheduled items

### 🟠 Edge Case Triggers (on any input field)
- Empty values, whitespace-only, null
- Very long strings (500+ chars)
- Special characters: `<script>`, `'`, `"`, `\n`, `%`, `&`
- Unicode and emoji
- Negative numbers, zero, very large numbers
- Past/future dates, invalid date formats

### 🟡 Permission & Role Boundaries
- Can `chat_user` access admin-only pages? (should 403/redirect)
- Can one tenant's data appear to another? (data isolation)
- What happens when feature flags disable a section?

### 🟢 State & Flow Probing
- What happens mid-flow if you navigate away and come back?
- Can forms be submitted twice?
- Does the UI update correctly after CRUD operations (no stale data)?
- What happens if you use the Back button inside a wizard/flow?

### 🔵 Visual & Usability
- Truncated text, overflow, broken icons, missing labels
- Loading states shown and resolved
- Error states in plain language with a recovery action

---

## Bug Severity Classification

| Severity | Criteria | Example |
|----------|----------|---------|
| 🔴 **Critical** | Data loss, security breach, auth bypass, complete feature broken | XSS executes, AI response never arrives |
| 🟠 **High** | Core feature broken, major user-facing error | Chat hangs indefinitely, API key can't be created |
| 🟡 **Medium** | Feature partially broken, significant UX issue | Upload fails on retry, filter resets on reload |
| 🟢 **Low** | Cosmetic, minor UX friction, edge case | Button label truncated, raw i18n key visible |

---

## Root Cause Forensics Gate (MANDATORY on every confirmed finding)

> Exploration finds symptoms. `root-cause-forensics` turns each symptom into a diagnosis. **Run it on every confirmed finding, at the moment you find it — before moving to the next area, and long before the report is written.**

**Why the timing is strict:** the console log and network log for a finding are destroyed by the next navigation, and exploration navigates constantly. If you defer RCA to the end of the session, the evidence for every finding but the last one is already gone. Capture in place, then move on.

Per finding:

```
Bug observed
    ↓
root-cause-forensics  →  freeze console + network  →  reproduce/minimize  →  trace to file:line  →  RCA verdict
    ↓
screenshot-video-capture (FAIL screenshot + recording)
    ↓
add to running tally, continue exploring
```

### Depth by severity

Exploration can surface a lot of findings; RCA depth scales with severity so a session does not stall.

| Severity | Required RCA depth |
|---|---|
| 🔴 Critical / 🟠 High | **Full RCA** — console + network capture, reproduce and minimize, trace to `file:line`, PR/commit correlation, verdict with confidence |
| 🟡 Medium | **Evidence + localization** — console + network capture, reproduce, cause localized to a file or module; exact line may be inferred |
| 🟢 Low | **Evidence only** — console + network capture and a one-line mechanism if it is obvious. Do not spend a code trace on a truncated label. |

Never skip the console + network capture, at any severity. It is cheap, it is perishable, and it is the part you cannot recover later.

### What the RCA changes about a finding

| RCA class | What it means for the expedition |
|---|---|
| 🔌 **Environment** | Not a bug. Drop it from the findings table and note it under Observations. Use `session-recovery` if it is an auth fault, then resume. |
| 📋 **Spec gap** | Behaviour is intentional or the AC is silent. Move it to **Observations (Not Bugs)**, not Bug Findings. |
| ❓ **Not reproducible** | Keep it in the report with all captured evidence, explicitly marked `❓ Not reproducible` — assert no cause. |
| 🎨 / ⚙️ / 🔗 / 🗄️ / 🔧 | Real defect. Stays in Bug Findings with its RCA verdict attached. |

This gate is what keeps an exploratory report from being a list of complaints. Re-check severity **after** the RCA — a cosmetic-looking symptom backed by a 500 on a write path is not Low.

---

## Media Capture During Exploration

For every bug found, capture evidence immediately — `root-cause-forensics` owns the console and network capture; this covers the visual record:

1. **Screenshot** (FAIL style — red highlight + badge) via `screenshot-video-capture` skill
2. **Video recording** for anything that needs steps to reproduce
3. **Console errors** — `read_console_messages` (captured by the RCA gate, saved to the RCA folder)
4. **Network errors** — `read_network_requests` (captured by the RCA gate, saved to the RCA folder)

File naming: `ET-YYYY-MM-DD-{area}-{short-description}.png` / `.mp4`
Save to: `$REPO_ROOT/manual-testing/evidences/exploratory-{date}/`

RCA artifacts for the session go to `$REPO_ROOT/manual-testing/evidences/exploratory-{date}/rca/`.

---

## Running Tally (report to user mid-session)

After each area completes:

```
✅ AI Chat — complete
Found: 2 bugs (1 High, 1 Low)
  🟠 High — "Thinking..." hangs forever → ⚙️ Backend, chat-worker/stream.ts:88 (High confidence)
  🟢 Low  — raw i18n key visible in banner → 🎨 Frontend, locales/en.json missing key
Next: Prompt Security

🔎 Running tally: 2 bugs across 1 area
```

---

## Session Wrap-Up — QA Report

After all areas are explored, generate a full QA report using `qa-report-generator`. Save to: `QA Reports/exploratory-YYYY-MM-DD.md`

Report title format:
- Web exploration: `# Exploratory Testing Report — First Recon AI (Web)`
- Electron exploration: `# Exploratory Testing Report — First Recon AI (Electron Desktop)`
- Both: `# Exploratory Testing Report — First Recon AI (Web + Electron)`

Structure:

```markdown
# Exploratory Testing Report — First Recon AI ([Web | Electron Desktop | Web + Electron])
**Date:** YYYY-MM-DD
**Environment:** [URL or "Electron desktop app — /Applications/First Recon AI.app"]
**Tester:** belle.ung@persefoni.com
**Session Scope:** [Full app | named area]
**Time on Session:** ~Xh Ym

## Executive Summary

| Metric | Value |
|--------|-------|
| Areas Explored | N |
| Total Bugs Found | N |
| 🔴 Critical | N |
| 🟠 High | N |
| 🟡 Medium | N |
| 🟢 Low | N |
| Overall Risk | 🔴 High Risk / 🟡 Medium Risk / 🟢 Low Risk |

**Verdict:** [PASS | FAIL | CONDITIONAL]

## Root Cause Summary

| Bug | Severity | RCA Class | Location | Confidence | Type |
|-----|----------|-----------|----------|-----------|------|
| BUG-01 | 🟠 High | ⚙️ Backend | chat-worker/stream.ts:88 | High | Regression (PR #4821) |
| BUG-02 | 🟢 Low | 🎨 Frontend | locales/en.json | High | Latent defect |

Group bugs sharing one root cause together — one cause, one row, all bug IDs listed.

## Bug Findings
[Each bug: title, severity, area, STR, expected, actual, evidence file, plus its full RCA block —
 class, location, mechanism, confidence, regression type, console + network evidence verbatim]

## Areas With No Findings
[Table of clean areas]

## Observations (Not Bugs)
[Informational notes, plus anything the RCA classified as 📋 Spec gap or 🔌 Environment]

## Evidence Files
[Table: file → area → severity → bug ID. Include RCA .md, -console.log, -network.json per finding]

## Recommended Next Steps
- Critical/High → file via `linear-ticket-writer` (RCA block travels into the description)
- Medium → review with QA lead
- Low → batch cleanup ticket
```

---

## Post-Report Actions

After the report is saved:

1. **Critical or High bugs found** → ask: *"Found [N] critical/high bugs. Want me to file them as Linear issues?"*
   - If yes → invoke `linear-ticket-writer` for each, one issue per finding, each carrying its `## Root Cause Analysis` block
   - Title each ticket with `[Electron]` prefix if it's an Electron-specific bug
   - Attach the finding's RCA `.md` plus its raw `-console.log` / `-network.json`
   - Findings that share a root cause get **one** ticket listing all affected surfaces — not one per symptom

2. **Medium/Low only** → offer: *"All findings are medium/low. Want me to file them or save for later?"*

3. **Never auto-transition any Linear issue** — exploratory sessions aren't scoped to a single ticket.

4. **Never file a finding classified 🔌 Environment or 📋 Spec gap.** Raise those with the user instead.

---

## What This Skill Does NOT Do

- Does not execute scripted regression test cases (use `manual-test-executor` or `production-regression-sweep`)
- Does not deep-analyze a specific Linear issue (use `ticket-inspector` + `test-case-generator`)
- Does not auto-transition tickets
- Does not test backend/API behavior directly — UI-surface focus with network observation as a secondary signal
- Does not diagnose *why* a finding happens — that is `root-cause-forensics`. This skill observes, captures, and hands off.

