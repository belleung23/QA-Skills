---
name: "api-audit-reporter"
description: "Write the detailed API audit report from the verified governance and standards findings. Every blocker carries why it blocks, the root cause, what breaks if merged, a recommended fix or an explicit NEEDS OWNER INPUT, and a verification command - plus a plain-language executive summary. Triggers on write the API audit report, API audit report, explain the blockers, report the API findings, merge decision report."
---

# API Audit Reporter

Turns **verified** findings into one report that two very different readers can act on:

- a **developer**, who needs the exact line, the reason, and a fix they can paste;
- a **decision-maker**, who needs to know in plain language whether this PR can merge and what the business risk is.

```
api-governance-gate  ->  api-standards-gate  ->  api-finding-verifier  ->  api-audit-reporter
   candidates              candidates              evidence + severity      the only decision
```

The two gates write candidate artifacts and advisory outcomes. **This skill writes the only merge decision in the pipeline.** It reads the verifier's output; a candidate that never went through verification arrives at `evidence: UNVERIFIED` and is reported as such, not as a finding.

**Authority: report-only.** The only file written is the report under `docs/analysis/api-audit/`. Never edit source, governance files, or the PR.

## Shared finding schema

Every finding arrives from the gates and the verifier carrying these seven fields, under these exact names. Carry them through unchanged - re-labelling a field on the way into the report is how an axis gets quietly dropped.

| Field | Values |
|---|---|
| `evidence` | CONFIRMED / UNVERIFIABLE / UNVERIFIED |
| `severity` | BLOCKER / MAJOR / MINOR / INFO |
| `novelty` | NEW / PRE-EXISTING at the merge-base |
| `rule` | file:line or ADR id, quoted, with its scope |
| `ci_status` | covered-red / covered-green / uncovered / unknown |
| `remediation` | PATCH READY / NEEDS OWNER INPUT |
| `gaps` | what could not be determined and what would settle it |

`evidence` has exactly three values, and **REFUTED is not one of them**:

- **CONFIRMED** - the verifier ran a falsification test and failed to kill the finding. Reportable at its severity.
- **UNVERIFIABLE** - the verifier ran and could not determine the answer. Section 9, never a blocker.
- **UNVERIFIED** - never went through the verifier. Section 9, with what it would take to settle it.

A candidate the verifier refuted is not a finding; it appears only in the verification summary in section 7.

Two of the seven have a home in the report rather than a slot on the schema line: `rule` is the **Why this blocks** field, and `gaps` is **section 9**. The schema line on each finding therefore carries the other five - `evidence`, `severity`, `novelty`, `ci_status`, `remediation` - and the two below are not optional, just written elsewhere.

## The three axes, kept apart

Of those seven, three are decision-critical, and they are **independent judgements**. Collapsing any two of them is how a report ends up saying NO MERGE while counting zero blockers - which is exactly what a 2026-09-21 trial produced, with a confirmed tenant-isolation defect and a confirmed cross-service signature replay both missing from the blocker list.

| Axis | Question it answers |
|---|---|
| `evidence` | Is the defect proven from quoted source? |
| `severity` | How bad if it ships? |
| `remediation` | Can a safe fix be specified now? |

`novelty` and `ci_status` are **context**: recorded on every finding, never used to move any of the three axes.

The rules that follow from that:

- **A proven security defect stays blocking.** Tenancy, authn/authz, signature or replay: if `evidence` is CONFIRMED, `severity` is BLOCKER and it appears in the blocker count. Nothing about `remediation`, `ci_status` or `novelty` changes that.
- **Not knowing the fix does not unprove the defect.** When you cannot specify a safe patch, the finding keeps its `evidence` and its `severity`, and `remediation` reads `NEEDS OWNER INPUT` with the specific open question. It does **not** become UNVERIFIED, and it does **not** move to section 9.
- **CI coverage is corroboration, never a discount.** Record which required check covers the finding and its colour. A red required check is itself a merge stop; link the failing run and deduplicate the presentation so the reader sees one finding, not two. A green check on a real defect means the check has a blind spot - name the blind spot.
- **Pre-existing changes attribution, not severity.** `novelty: PRE-EXISTING` says the defect is not this PR's doing. It is still reported at its real severity, and it can still block a PR that makes it worse or that ships in the same file.

Every BLOCKER and MAJOR carries all nine fields below, opening with its schema line. MINOR and INFO need What, Where, Why and Recommended fix only.

| Field | What it must contain |
|---|---|
| **What** | One sentence: the defect, not the rule |
| **Where** | `file:line` plus the quoted source line. Both sides for a duplicate |
| **Why this blocks** | The `rule`, quoted from its source with a file/line or ADR reference, **including its scope**. Never "best practice" - name the document |
| **Root cause** | Why it happened, and which existing gate does not catch it - or does, and is currently red |
| **Impact if merged** | The concrete failure: what breaks, for whom, in which environment. No adjectives |
| **Recommended fix** | Paste-ready code or YAML - or `NEEDS OWNER INPUT:` and the exact question that has to be answered first |
| **Alternatives considered** | At least one other option and why it is worse, or "none - this is the only correct shape" |
| **Effort / blast radius** | Rough size (one line / one file / cross-worker) and what else the change touches |
| **Verify with** | The exact command or test that turns this finding green |

## Writing the recommended fix

- **Match the surrounding code.** Read the neighbours first; a fix that introduces a fifth error envelope is not a fix. Cite the sibling you copied the shape from.
- **Prefer the smallest correct change.** If a coded error is missing, add the code - do not restructure the handler.
- **Say where it goes.** Middleware vs handler vs the delegated service changes the outcome: a `Cache-Control` set in the handler does not cover the 401 an auth middleware returns before the handler runs.
- **When there is a genuine choice, present it.** Two shapes, their trade-offs, a recommendation, and the reason.
- **Never invent an API.** If the fix needs a helper, name the real one and its path. If no such helper exists, that is `NEEDS OWNER INPUT`, not a plausible-looking call.
- **An unknown history is allowed.** If you cannot establish why a defect was introduced, write "root cause not established" and say what would establish it. Do not compose a narrative that fits.

### Worked example

```
#### [STD-03] BLOCKER - E1 - 11 of 13 error responses carry no machine-readable token

- **Schema:** evidence CONFIRMED | severity BLOCKER | novelty NEW | ci_status covered-green |
  remediation PATCH READY
- **What:** The WAF callback returns English prose with no stable code on 11 of its 13
  error paths, including all four authentication rejections.
- **Where:** worker/routes/layer2-waf-block-route.ts:85
  `return c.json({ success: false, error: 'Missing X-WAF-Signature header' }, 401);`
  (also :50, :80, :101, :106, :116, :119, :127 ...)
- **Why this blocks:** ADR-048 (docs/architecture/decisions/adr-048-api-error-localization-contract.md,
  "Code namespace convention", line 112) - the backend keeps the English string and adds a stable
  `<DOMAIN>_<CONDITION>` code; the frontend maps the code to `t()`. Scope checked: the ADR's
  "Non-goals" (line 174) excludes workers/developer-api-worker, server-rendered artifacts, and four
  named route files (two operations, two roadmap). This is a monolith worker route, so the rule applies.
- **Root cause:** the handler predates the ADR and was extended in place; two newer paths
  (`WAF_TIMESTAMP_MISSING`, `WAF_TIMESTAMP_INVALID`) were coded and the older ones were not.
  `i18n:check:api-responses` does scan error-shaped bodies including `{ success: false, error }`
  (scripts/check-api-response-i18n.ts:74-78), but it is an exact-count ratchet against
  scripts/api-response-i18n-baseline.json, and these occurrences are baselined - so the check
  stays green while the defect is real. That is the blind spot, not a skipped payload shape.
- **Impact if merged:** no consumer can branch on a WAF rejection reason, and the strings cannot be
  localized. An operator debugging a rejected Cloudflare callback sees free text that may be reworded
  by any later edit, silently breaking whatever matched on it.
- **Recommended fix:** add a code to every rejection, matching the two that already exist:
  ```ts
  return c.json(
    { success: false, error: 'Missing X-WAF-Signature header', code: 'WAF_SIGNATURE_MISSING' },
    401
  );
  ```
  Codes: `WAF_SECRET_NOT_CONFIGURED`, `WAF_TIMESTAMP_OUT_OF_WINDOW`, `WAF_SIGNATURE_MISSING`,
  `WAF_SIGNATURE_INVALID`, `WAF_BODY_EMPTY`, `WAF_BODY_INVALID_JSON`, `WAF_TENANT_ID_INVALID`,
  `WAF_CATEGORIES_INVALID`.
- **Alternatives considered:** replace the prose with snake_case identifiers (the shape used by
  `knowledge-owner-projection-routes.ts`). Also ADR-compliant and a smaller diff, but it drops the
  operator-readable text on a callback that is debugged from logs - prefer prose + code here.
- **Effort / blast radius:** one file, ~11 lines. No caller matches on these strings today
  (verified: no `grep` hits for the literals outside this file), so no consumer migration.
- **Verify with:** `grep -c "code: '" worker/routes/layer2-waf-block-route.ts` returns 13, and
  `bun run i18n:check:api-responses` stays at baseline after the baseline is regenerated in this PR.
```

That is the bar. A developer can act on it without opening anything else; a reviewer can check the reasoning without trusting the auditor.

### Worked example - remediation unknown

```
#### [GOV-04] BLOCKER - cross-service signature replay accepted on the receipt lane

- **Schema:** evidence CONFIRMED | severity BLOCKER | novelty NEW | ci_status uncovered |
  remediation NEEDS OWNER INPUT
- **What:** A signature minted for the detection lane is accepted by the receipt lane.
- **Where:** both handlers read; the quoted lines follow.
- **Why this blocks:** the destinationId rule, quoted from its source with the line ref.
- **Recommended fix:** NEEDS OWNER INPUT - the safe patch depends on which signing version the
  receipt verifier can require without breaking in-flight callers. Question for the owner:
  is minSignatureVersion 5 already enforced on every producer of this lane?
  No paste-ready patch is offered; inventing one here would be a guess at a security boundary.
- **Verify with:** the replay test named below, once the version answer is known.
```

This finding **counts as a blocker**. An unknown fix is an open question, not a downgrade.

## Report structure

Write to `docs/analysis/api-audit/<PR-or-branch>-<YYYY-MM-DD>.md`. Sections 1-2 are for any reader; 3 onward are for engineers.

```
# API Audit - <PR #/branch> - <date>

## 1. Summary
**Can this merge?** YES | NO - <one sentence>
**Blockers:** N    **Majors:** N    **Endpoints audited:** N
**Confidence:** gate-backed (Tier 1) | source-review only (Tier 3, N gates NOT RUN)
**Verification:** N candidates, N confirmed, N refuted, N unverifiable, N unverified;
  security second pass ran | NOT RUN
**Gate authority:** advisory pilot | blocking. When advisory, name what is still outstanding -
  blinded paired trials, both independent security passes, the no-false-BLOCKER pilot. When
  blocking, give the date and the evidence that lifted it.

Three to five sentences, no jargon, no file paths. What the PR adds, what is wrong, what happens
if it ships unfixed, and what it takes to fix. A reader who does not know the codebase should be
able to repeat it accurately to someone else.

| # | Issue | Risk if merged | Fix effort | Remediation |
|---|---|---|---|---|

**Consistency check before publishing:** if the decision is NO MERGE, at least one row above is a
BLOCKER, and the blocker count matches the number of entries in section 4. A NO MERGE with zero
blockers means an axis got collapsed somewhere - go back and find it.

## 2. Decision per PR
| PR | New endpoints | Blockers | Recommendation |
Recommendation is one of: MERGE, FIX FIRST (blockers listed), or NEEDS AUTHOR INPUT (ambiguity named).

## 3. What was audited
Endpoint inventory with host, ingress class, shape, effect, and the file actually audited
(route file or the delegate it forwards to). Which checks were selected and which were N/A.
Route inventory totals at merge-base and head, the extractor's coverage gaps by kind, and - if the
extractor was run from outside the repo - its path and provenance.

## 4. Blockers
Full nine-field entry each, most severe first, each opening with its schema line. Includes every
CONFIRMED security defect, whatever its ci_status and whatever its remediation state.

## 5. Majors / 6. Minors and info
Same shape; minors may use the short form.

## 7. Verified clean
What was checked and passed, plus the candidates that were raised and refuted, with the
falsification test that killed each. Without this the report reads as a list of complaints.

## 8. Gate output
Per command: run / NOT RUN + reason, exit code, verbatim output, interpretation. Say plainly that
a green repo gate validates the current checkout, not this audit's rules.

## 9. Coverage gaps
Every finding's `gaps` field, plus what this audit could NOT determine and why: gates not run,
stale refs, unresolved routes, duplication classes not exercised, checks marked NOT VERIFIED,
a skipped security second pass, and every finding still at evidence UNVERIFIED or UNVERIFIABLE.
A CONFIRMED finding whose remedy is unknown does NOT belong here - it belongs in section 4 with
remediation NEEDS OWNER INPUT. Never leave this section empty by omission; if nothing is
missing, say so explicitly.
```

## Discipline

- **Lead with the decision.** The first line answers "can this merge?". A report that opens with methodology gets closed.
- **Make the counts match the prose.** The summary's numbers are the part people quote; if they disagree with the body, the body is what was right and the numbers are the bug.
- **Separate cannot-merge from should-improve.** Inflating a MINOR to a BLOCKER costs you the next review. Deflating a confirmed security defect costs more.
- **Never report a check that did not apply.** N/A is not a finding and not a gap; it belongs in section 3 as scope.
- **Quote, and scope, the rule.** "Per ADR-048, Code namespace convention, line 112, and its Non-goals at line 174 do not exclude this surface" beats "this violates our standards". Re-read the current implementation of any gate before claiming it has a blind spot - an earlier version of this skill asserted a blind spot that the script's own comments contradict.
- **Give credit in section 7.** A gate that only ever prints problems gets read as noise.
- **Say what you could not check.** A confident report with a silent gap is worse than an honest narrow one.
- **One voice per finding.** No "it seems" or "possibly": either the evidence supports the finding, or its `evidence` field says UNVERIFIABLE or UNVERIFIED and it sits in section 9.