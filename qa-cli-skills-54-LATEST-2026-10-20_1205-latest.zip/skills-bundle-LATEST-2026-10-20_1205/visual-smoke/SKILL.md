---
name: "visual-smoke"
description: "Agent-run UI visual smoke for any web project: screenshot every page, compare with the last run, name what changed, flag new UI with no test, and hand the human a report plus screenshots to review. Triggers on: visual smoke, visual diff, UI diff, compare screenshots, what changed in the UI, daily UI check."
---

# UI Visual Smoke (agent-run, any project)

**The agent does the whole run. The human only reviews the report and the screenshots.**
Never end with "please run this command". If the agent cannot reach the app, say exactly what
blocked it (network, no browser, no session) and stop.

Triggers: `Visual smoke`, `Visual diff`, `UI diff`, "compare the screenshots", "what changed
in the UI", "run the daily UI check", "what needs test coverage".

What it does: screenshots every page, compares each with the previous run, **names** what
changed (new control, removed control, restyle, text that only moved), and lists new controls
that no existing test references.

## The tool (engine)

The engine is a folder of 10 files, `automation/visual-diff/`. Its home today is the
**eng-guardrails-platform** repo (`automation/visual-diff/`). Other projects do not have it;
Step 0 sets it up without changing the project's code.

| File | Role |
| --- | --- |
| `run.mjs` | entry point / loader — every command goes through it |
| `setup-deps.mjs` | `run.mjs setup`: makes the two libraries resolvable (no-op where installed) |
| `agent-capture.ts` | takes the screenshots from a JSON page list; reuses a saved login session |
| `capture-inventory.ts` | records the controls and text on each page |
| `full-page-shot.ts` | full-page screenshot that stays correct on pages taller than 16,000px |
| `compare-screenshots.ts` | pixel diff; names what changed; spots text that only moved |
| `diff-inventory.ts` | writes the report, coverage gaps and `test.fixme` stubs |
| `inventory-types.ts`, `pngjs.d.ts` | types |
| `README.md` | design notes — read before changing the engine |

`visual-smoke.spec.ts` + `capture-route.ts` (+ `__selftest__/`) also live there but are tied to
eng-guardrails-platform's own routes and login. Do not copy them to other projects.

Needs Node 22.18 or newer (`node --version`): `run.mjs` uses `module.registerHooks` and Node's
built-in TypeScript loading. Commands: `setup`, `capture`, `diff` (plus `selftest`,
`visual-selftest` inside eng-guardrails-platform).

## Login is not this skill's job

Login happens BEFORE the visual smoke: the project's own login skill or a person does it. This
skill only reuses the result, a Playwright storage-state file (cookies + local storage). It never
types credentials, never clicks through SSO, and never writes session files into the repo.

- Session file given → every page is captured with that login. Every page of that run is
  labelled `signed-in` — the label only means "a session file was passed", not that the login
  worked. The proof is the session check in Step 4.
- No session file → pages are captured as an anonymous visitor (fine for public pages).
- A session only works for the exact address it was made for (scheme + host + port). Serve or
  open the app at that address — check the `origin` / cookie `domain` inside the file.
- A page that bounces to a sign-in screen → **BLOCKED: redirected to a sign-in page — not logged
  in, or the session expired**. It is never compared. Report it so the login step can be re-run.
- Session file path given but missing → the capture refuses to start ("run the login step first")
  and writes nothing.

## Step 0 — set up the engine (skip only if the project already has `automation/visual-diff/run.mjs`)

Check for the file `run.mjs`, not just the folder: after a first run the project's
`automation/visual-diff/` folder exists (baseline, page lists, stubs) WITHOUT the engine in it,
so every new session still needs this setup.

0. Pick run ids. Normally today's date (`2026-10-17`). When you are given two releases to compare in
   one go and no ids, use the release names (`v1`, `v2`).
1. Get the engine files listed in the table above from eng-guardrails-platform
   `automation/visual-diff/` (on the user's computer: list it, then stage ONLY those 10 files —
   read only, never write there; never stage its `.snapshots/` (real baselines) or `__selftest__/`).
   Copy exactly those 10 by name into your scratch engine folder, not the whole staged folder.
2. Put them in **your own scratch folder**, e.g. `<scratch>/vs-engine/automation/visual-diff/`,
   not inside the project. The project's code stays untouched.
3. Run `node <scratch>/vs-engine/automation/visual-diff/run.mjs setup`. It makes the engine's two
   libraries (`@playwright/test`, `pngjs`) resolvable: if they already resolve it does nothing;
   otherwise (e.g. npm blocked) it writes small stand-ins into `<scratch>/vs-engine/node_modules/`
   (needs the global `playwright` package, preinstalled in the cloud container). Running it again
   is harmless.
4. **Always run commands from the project root** and call the engine by its scratch path:
   `cd <project> && node <scratch>/vs-engine/automation/visual-diff/run.mjs …`.
   The report (`test-reports/ui-diff/`), stubs (`automation/visual-diff/stubs/`), saved
   screenshots (`automation/visual-diff/.snapshots/`) and the spec corpus it searches for
   coverage (`automation/`) are all resolved from the folder you run it in.
5. **Saved screenshots (the baseline) must survive until the next run and must not be
   committed.** Keep them in the project at `automation/visual-diff/.snapshots/` (the default —
   no `--root` needed). If the project's `.gitignore` doesn't already cover that folder, add the
   line `automation/visual-diff/.snapshots/` (create `.gitignore` if there is none) and tell the human. Never keep the baseline only in
   your scratch folder: it is deleted with the session and tomorrow's run would have nothing to
   compare against. If the project folder itself is temporary, say plainly that the baseline
   will not survive.
6. **Save the page list(s) in the project too**, at `automation/visual-diff/pages.json` (or
   `pages-<release>.json`), so the next run reuses exactly the same `path` keys.
7. The run's deliverables land in the project on purpose: the report folder
   `test-reports/ui-diff/` and the stubs `automation/visual-diff/stubs/`. Don't commit anything
   yourself; tell the human which files are new.

Below, `RUN` means `node <engine>/automation/visual-diff/run.mjs` (the scratch path from Step 0,
or the project's own `automation/visual-diff/run.mjs` if the project has the engine).

## Step 1 — make sure the browser can reach the app

Chromium is preinstalled in the cloud container (`PLAYWRIGHT_BROWSERS_PATH=/opt/pw-browsers`);
the user's VM usually has none. Check reachability first: `curl -s -o /dev/null -w '%{http_code}' <url>`
for one or two pages. **Only `200` counts as reachable** — a 404/500 means wrong address or the
wrong server; fix that before capturing.

- **Hosted app:** a proxy `connect_rejected` means the host is not on the egress allowlist —
  report BLOCKED, don't work around it.
- **Static build / local app:** serve it yourself (`python3 -m http.server <port> --bind
  127.0.0.1` from the folder, or `npm run preview`) and stop the server when done. Make sure the
  port isn't already used by something else (`curl` it BEFORE starting your server: it should
  fail), and that the page you get back is your app (check its `<title>`).
- Two releases side by side (e.g. `site/v1`, `site/v2`): serve their parent folder ONCE (at the
  session's address if there is a session file), give each release its own `baseUrl` by path
  (`…/v1/`, `…/v2/`), write one page list per release with the SAME `path` keys, and capture
  each release under its own run id.
- If a session file is in play, serve at the address it was made for (see "Login" above).

Never drive the human's real logged-in browser into an app they did not name for this run.

## Step 2 — check for a baseline

`ls automation/visual-diff/.snapshots/` (or your `--root`). Each run is a folder named by run id.
Reuse `automation/visual-diff/pages*.json` from the last run if it exists.
If there is no earlier run, today's capture only creates the baseline — say so plainly; the first
real comparison is next run. Never invent a comparison against nothing. On a baseline-only run,
skip Step 5 and hand over: the page list with every setting and why, the noise-check result, any
BLOCKED pages, a look at a few screenshots (signed-in page, late-loading pages), and where the
baseline is saved. (If you were given two releases to compare in one go, capture both now under
the run ids you were given.)

## Step 3 — write the page list

```json
{ "baseUrl": "https://app.example.test/",
  "storageState": "auth/state.json",
  "routes": [ { "path": "/users", "url": "users", "name": "Users" } ] }
```

`path` is the stable key used to match runs (keep it identical every day); `url` is resolved
against `baseUrl` (defaults to `path`). `storageState` is optional (or pass
`--storage-state <file>`). `loginPagePattern` (a regex on the final URL + title) overrides the
default sign-in detector if the app's login page has an unusual address.

Two optional settings make real apps stable (both work for the whole list and per route):

- **`"waitFor": "<css selector>"`** — wait until that element is visible before capturing. Use it
  for pages that draw their content late (data loaded by JavaScript, spinners, skeletons): pick
  an element that only exists once the real content is there (e.g. `"#orders-table"`). Without
  it a late page can be photographed as "Loading…". If it never appears within 15 s the page is
  BLOCKED ("never appeared — the page did not finish loading").
- **`"mask": ["<css selector>", …]`** — cover content that changes on its own (clocks, "last
  updated", today's date, rotating tips, ads, avatars) with the same solid box every run. The box
  takes the size of the element you pick, so mask a FIXED-size container (the whole tip box),
  not text whose length varies — otherwise the box itself changes size between runs. Text
  inside a masked area is also left out of the record, so it never shows up as "New text".

```json
{ "baseUrl": "https://app.example.test/", "mask": ["#clock"],
  "routes": [ { "path": "/orders", "url": "orders", "waitFor": "#orders-table", "mask": [".last-sync"] } ] }
```

How to find what needs them: open each page's HTML/screenshot once while writing the list, and
use the **noise check**: capture the same release twice and compare, keeping everything OUTSIDE
the project: capture from the project root (so relative paths like `auth/state.json` resolve) but
into scratch — `cd <project> && RUN capture --config automation/visual-diff/pages.json --run n1
--root <scratch>/noise/snaps`, the same with `--run n2` — then compare from the scratch folder so
the report lands there: `mkdir -p <scratch>/noise && cd <scratch>/noise && RUN diff --from n1 --to n2
--root <scratch>/noise/snaps`. Read that noise report (`<scratch>/noise/test-reports/ui-diff/n2_UI-Visual-Smoke.md`)
and its diff images; it stays in scratch and is not handed over — just say the result in your summary.
With two releases in one go, noise-check each release. Anything that shows up with no real change is self-changing: add a
`mask` (or a `waitFor` if a screenshot shows a spinner) and repeat until the noise check reports
0 changed pages. Do the noise check when the page list is first written and whenever you add
pages or settings; on an ordinary later run it is optional — but if a report shows a "no control
changed" region you can't explain, run it to rule out noise. The noise runs are a side check —
today's real run is captured separately into the project with today's run id. Mask only what
changes on its own; never mask real UI to make a run go green.

The same-day noise check cannot reveal content that changes **between days** (today's date,
"Good morning", "3 days left", this week's offers). Look for it in the page HTML/JS while writing
the list and mask it up front. If a day-to-day report still shows a region whose only change is
such text, call it noise in your summary, add the mask to `pages.json`, and say so.

Which pages: every page a user can open — take them from the project's route list, router
config or sitemap if it has one, otherwise from the built pages / menu, and include pages not in
the menu. **Re-check the router/route list on EVERY run**, not just the first: a page added since
the last run is only found this way (the saved `pages.json` doesn't know about it). Skip routes
with `:params`. **Include the sign-in page** with `"anonymous": true`, so it is captured without
the session (signed in, it would usually redirect away) — changes there matter too. A page that
only exists in the newer release goes only in the newer list (listing it in the older one would
produce a fake "did not load"); it is reported as a new page — then add it to the saved
`pages.json` so every later run keeps checking it. Keep a page that BROKE in `pages.json` too, so
it stays flagged every run until it is fixed or deliberately removed.

Single-page apps that route with `#` (e.g. `/#/orders`): use the hash as the `url`, with a plain
`path` key — `{ "path": "/orders", "url": "#/orders" }`. Sign-in redirects to `#/login` are caught.

**Not-found screens:** a page whose title or first heading says "404" / "not found" is BLOCKED
("page shows a "not found" screen") even when the server answered 200 — single-page apps show
their own not-found view this way. Override with `"notFoundPattern": "<regex>"`, or `""` to switch
it off — for the whole list or for one page (put it on that route). The app's own deliberate 404
page: either leave it out of the list, or keep it with `"notFoundPattern": ""` on that route only,
so every other page keeps the check.

**Compare full runs only.** Every page left out of a run reads as "route disappeared" when that
run is compared with a full baseline. An extra small run (e.g. one page captured without the
session, as a login check) is a side check — inspect its console output and screenshot, but never
use it as `--from`/`--to` against a full run.

## Step 4 — capture

```bash
cd <project> && RUN capture --config <pages.json> --run <run-id> [--storage-state <file>] [--root <dir>]
```

Same conditions every run: viewport 1440×900, page scrolled once for lazy content, animations
off, caret hidden. A page is recorded `BLOCKED` with the reason — never compared — when it fails
to load, returns an HTTP error ("page returned HTTP 404"), shows the app's not-found screen, never
shows its `waitFor` element, or lands on a sign-in screen. A screenshot of what it showed instead
is kept as evidence. The next page starts in a fresh tab so one broken page can't knock out the next.

**Check the session worked:** with a session file, any `BLOCKED … sign-in page` line means the
session is missing, expired or for another address — stop and report it rather than comparing.
Also open one members-only page's screenshot (`<snapshots>/<run>/<page>.png`) and confirm it
shows signed-in content.

**eng-guardrails-platform only:** that repo also has a one-command Playwright run that uses its
own login fixtures (~76 routes, 7 role groups): `npx playwright test automation/visual-diff
--project=chromium` (variants: `UI_DIFF_ROUTES=/admin,/settings`, `UI_DIFF_RUN_ID=<id>`,
`UI_SMOKE_SOFT=1` to annotate instead of fail — say which mode you used). Read the failure
message and the `baseline created` / `not compared` annotations, not just the exit code.

## Step 5 — compare

```bash
cd <project> && RUN diff --from <older-run> --to <newer-run> --stubs [--root <dir>]
```

Always pass `--from` and `--to`; without them it silently takes the two newest run folders.
If the report opens with "⚠ The two runs were captured by different engine versions", the engine
changed since the baseline: re-capture the baseline (current release, new run id) and compare
against that instead — otherwise controls the newer engine records can show up as "new".
Use `run.mjs`, never `npx tsx` or `node file.ts` (only `run.mjs` resolves the engine's imports).

Output, all under `<project>/test-reports/ui-diff/`:
`<to>_UI-Visual-Smoke.md` (the report), `<to>-diff-images/` (red = changed pixels, cyan box = a
detected change), `<to>-screenshots/` (`<page>-before.png` / `<page>-after.png` for every changed
page, `<page>-new-page.png` for new pages, and `<page>-BLOCKED.png` showing what a blocked page
displayed instead — e.g. the not-found screen — next to its `<page>-before.png`). File names come
from the page key: `/` → `root`, `/a/b` → `a__b`. Unchanged pages are not copied; their
screenshots stay in the saved-captures folder (`<snapshots>/<run>/<page>.png`) — mention it, hand
over on request.

## Step 6 — check your own output, then hand it over

Open (Read) the diff image of every page marked changed and confirm the boxes sit on what the
report claims. Then report in plain language:

- pages that BROKE since the last run, first, with their BLOCKED screenshot
- how many pages gained new UI, and which controls (by visible name and page)
- removed controls, text changes (with the new text), restyles, and other blocked pages (with
  the reason)
- the paths of the report, diff images and screenshots folder

If you are the agent talking to the human: deliver those files into the chat as well. If you
are a sub-agent: return the paths to the agent that called you; it delivers them.
Your summary uses plain words: no pixel percentages as severity, no region coordinates, no
selector internals unless asked. (The report file itself does show percentages and coordinates —
they help a reviewer find the spot; leave them.) Do not paste the whole report into chat.

Add your own judgement where the tool can't: e.g. a control marked "already referenced" whose
only reference is in a spec for a DIFFERENT page is probably still a gap — say so and count it
in your summary (the tool writes no stub for it; don't hand-write one); a style change on one
page but not its siblings may be half-finished — say so; a new page no menu links to may be
unreachable — say so; a broken page still linked from the menu sends users to an error — say so;
an existing spec that uses a removed control is now a dead test — say so.

Reading the report's wording: "Compared N routes" counts the pages present in BOTH runs,
including blocked ones; new pages are listed under "New routes" instead (so N is one less per new
page — not a skipped page). The sentence "No route looks different" only covers the pages that
were compared — always also read "Pages that BROKE" and "Could not be compared" below it. A
static element with a testid (a banner, a notice) is listed as a gap marked "Static element —
check its content/visibility", not as something to click. If a page shows only moved content,
look at its diff image for what pushed it — the tool catches label-named and unlabelled
controls, but your eyes are the last check.

## Step 7 — stubs

`--stubs` writes `test.fixme` skeletons to `automation/visual-diff/stubs/` — they can never pass
or count as coverage. Pages captured by `agent-capture` get plain `@playwright/test` stubs (env
tag `@env-TBD`); signed-in pages also get a `test.use({ storageState: 'TODO-…' })` line to point
at the project's login file. eng-guardrails-platform role pages use that repo's auth fixture. A
testid with a row number becomes a pattern (`getByTestId(/^user-row-\d+-edit$/)`). Each stub
still needs: the real TC ID instead of `@TC-TBD`; the page's real URL (the stub uses the page
key); an assertion about what the control DOES (state change, request fired, row updated), not
that it is visible; and a move into its feature folder with the project's tags (TC ID + App path
+ priority + `@regression` + env).

## Reading the output honestly

- **Pixel % is not severity.** One inserted button reflows everything beside it.
- **Reflow** = content that only moved: the same text at a different place (within 40px, or
  anywhere along the same row or column — a new table column slides headers 60–170px), the spot
  text moved away from, controls that are all still there in a new position, and text-free areas
  (borders, edges) whose pixels match the old picture shifted by the same distance. Reflow is
  counted ("Plus N region(s)…"), not listed. Changed pixels that touch each other merge into one
  region, so shifted content right next to a new control can sit inside the region named after
  it — that is correct too. Judge by what a region is NAMED, not by how many regions there are.
- **What a changed region lists:** `NEW` / `GONE` controls; `ONE MORE` / `ONE FEWER` — one
  more (or fewer) copy of a control that also exists elsewhere on the page, e.g. a new "edit"
  link next to a heading, `link "arXiv" (×1 → ×2)`; `New text` / `Removed text` — each changed
  line of wording with its position (`(y 794)`), so several edits inside one big region can be
  found on the screenshot; `+N other control(s) only moved` — counted, not listed. The same
  finding in many places is one row ending `(+26 more places)`.
- **One big region is normal after an edit near the top of a page** — everything below shifts,
  so the changed pixels join up. Read its `New text` / `Removed text` lines, not its size.
- **"no control changed — restyle, copy edit, or different data"** = pixels changed but no control
  changed and nothing just moved (e.g. a new colour, a new column heading, a price that went
  from $10 to $19). The region's real current text is shown. Worth a look, not a finding on its own.
- **Small text edits are caught.** A changed spot smaller than ~240 changed pixels is kept only when
  its text (or a control) actually changed; tiny specks with the same text are dropped as noise.
- **A page that grew** (`sizeChanged`) overstates its percentage badly — say so.
- **Very tall pages are fine.** Browsers can't take one screenshot taller than 16,384px (past that
  line the picture silently repeats the top of the page); the engine captures pages over 16,000px
  in strips and joins them. Up to 5,000 text runs per page are recorded.
- **A new page** only lists controls not seen on any page last run — shared nav links are not
  new features.
- **A blocked page** (did not load, HTTP error, app "not found" screen, `waitFor` never appeared,
  needed login) → "page did not load in <run>: <reason>"; it produces no added/removed controls.
  Blocked is never "clean" and never "everything disappeared". A page that loaded last run and is
  blocked now is listed FIRST, under "⚠ Pages that BROKE since the last run" (and counted at the
  top of the summary) — report those first; they are the likeliest real regressions.
- **A control with no accessible name** is reported as `"(no accessible name)"` with an
  accessibility note — it is new UI AND a screen-reader problem.
- **A control that disappeared** signals a now-dead spec, not automatically a bug.
- **A control that is new on several pages at once** (a new menu link, a header button) is listed
  ONCE under "On several pages at once (shared header / menu) — test once", and the summary counts
  it once ("N distinct"). Report it as one thing to test.
- **What the tool cannot see:** anything not drawn on the page — options inside a closed drop-down,
  a menu that only opens on click, tooltips, other tabs of a tab set, a link whose target changed but
  whose words did not. If you notice such a change (e.g. while reading the page code to choose
  masks), mention it as "found by reading the code, not by the screenshots".
- **Already referenced by a spec** only means the testid/label string appears somewhere under
  `automation/` — even in a comment. It does not prove the spec asserts the behaviour.

## Never loosen these

1. A control **with** a testid is matched only on its testid, contiguously — never on its visible
   label ("Edit"/"Delete" appear in most spec files and would hide every new row action).
2. Generated stubs are excluded from the coverage search, or last run's stub closes its own gap.
3. Never change the 1440×900 viewport casually — it invalidates every baseline, and comparisons
   across viewports are refused.

## Testing this skill (no real project needed)

Planted-change test in the cloud container: a small made-up site with `v1` and `v2`; capture v1
twice (noise check) and v2 once, then diff. Write the planted changes down BEFORE comparing, then
grade each row. For the full test, use a separate builder agent to make the app and a hidden
answer key, then a fresh day-1 agent (baseline), deploy v2, and a fresh day-2 agent (compare).
Verified 2026-10-16/17: "Taskly" demo, 3 fresh agents given only this skill, fresh agents that
built their own sites ("Shelfwise", "PulseHall": all rows passed), and blind two-session
day-1/day-2 tests on JavaScript apps with clocks, random tips, late content, lazy sections and
soft-404s ("Meadowlark", "Spoke & Sprocket" twice): every planted change found by the tool.
Re-tested 2026-10-17 (round 2): a fresh agent ran blind on a new app ("Harbor Ledger", 12 planted
changes incl. a 26,800px page): 11/12 by the tool, the 12th (a new option in a closed drop-down)
by the agent; 0 false alarms. Its skill notes are fixed here.
Verified 2026-10-17 on REAL public pages, no login: 10 pages of the practice site
the-internet.herokuapp.com (noise check: only the 2 pages built to change on every load were
reported; both 404s BLOCKED; masks worked), and older → newer revisions of 3 Wikipedia articles
(one 26,000px tall) graded against Wikipedia's own revision diff: every edit found; round 2 with
3 more articles: every visible edit found, and a link-target-only edit correctly not reported.
To test on real pages without a login, use a public site whose old versions stay reachable
(Wikipedia `index.php?title=<Article>&oldid=<revision>`): the older revision is "day 1", the newer
one "day 2" (same `path` key, different `url`), and the site's own diff is the answer key. Old
and current revisions also differ in banner, footer and "[edit]" links — expected, not noise.

| Planted in v2 | Must report |
| --- | --- |
| nothing (v1 → v1 again) | 0 of N pages changed, 0 gaps |
| Edit button per table row (testid) | NEW Edit + coverage gap; shifted columns counted as reflow ("Plus N region(s)…") or merged into the Edit region |
| removed Export button | GONE Export, in "controls that disappeared" |
| header colour change only | restyle row ("no control changed"), not reflow, no new UI |
| new switch without testid | NEW switch, P3 gap "ask the dev to add a testid" |
| identical page | not listed as changed |
| new page sharing the nav | new route; only its own button, not the nav links |
| page pointed at a dead address (closed port, e.g. 127.0.0.1:59999) | "page did not load" with the error; no fake removals |
| page that returns 404 | BLOCKED "page returned HTTP 404"; no fake removals |
| a spec using the word "Edit" only as a label | Edit still a gap (trap 1) |
| re-run diff after stubs exist | gap count unchanged (trap 2) |
| members-only page, no session (side run, not compared) | BLOCKED "redirected to a sign-in page" |
| same page with a saved session file | captured as the real page (own heading and controls) |
| session file path that doesn't exist | capture refuses to start with a one-line message; no empty run folder left |
| live clock on a page, no mask | noise check shows that page changed, with the clock's `New text` / `Removed text` |
| same clock with `mask` | noise check 0 changed |
| one short text edit (e.g. price $10 → $19) | caught: `New text: "Price: $19 …"` / `Removed text: "Price: $10 …"` |
| page that draws its content ~2 s late, with `waitFor` | captured with the real content, not the spinner |
| `waitFor` selector that never appears | BLOCKED "never appeared — the page did not finish loading" |
| a new control on the sign-in page (`"anonymous": true`) | NEW control on `/login`, captured signed-out |
| a new checkbox named only by its `<label>` (no testid, no aria-label) | NEW checkbox "<label text>", P3 gap |
| a new unlabelled icon button | NEW button "(no accessible name)" + accessibility note |
| a banner inserted at the top pushing the page down | NEW banner (static element); the pushed-down content (incl. text-free edges) counted as reflow |
| a route that now shows the app's own "Page not found" view (server still 200) | under "⚠ Pages that BROKE since the last run" with `<page>-BLOCKED.png`, not as a new feature |
| `#/…` route that redirects to `#/login` without the session | BLOCKED "redirected to a sign-in page (…#/login)" |
| a change near the bottom of a page taller than 16,384px | found (NEW control / New text with its y) — not lost to a repeated top of page |
| one more copy of a link that already exists elsewhere on the page | `ONE MORE: link "…" (×1 → ×2)`, not reflow |
| a sentence reworded inside a block that also shifted | `New text` / `Removed text` lines with their y, not reflow |
| a self-changing box covered by `mask` | no "New text" from inside the box, even on a page that changed elsewhere |
| a new menu link on every page | listed once under "On several pages at once"; summary "N distinct" |
| the app's own 404 page kept with `"notFoundPattern": ""` on that route | captured normally; other pages still BLOCKED on a not-found screen |
| baseline captured by an older engine | report opens with the "different engine versions" warning |
| day 2 in a NEW session (engine not in project) | Step 0 re-run, saved baseline + pages.json reused, compared against day 1 |

In eng-guardrails-platform there are also two built-in self-tests — run them after changing the
engine: `RUN selftest` (3 gaps, 1 new route, `budget-create-button` not a gap) and
`RUN visual-selftest` (1 real region, 10 reflow; needs a browser → cloud container). Re-run the
old reports too: re-diff earlier test runs with the changed engine and compare the summary
counts — they must not change unless the change was meant to.

## Changing the engine (validation gates)

- Edit the engine only in eng-guardrails-platform (its home), then re-run the planted-change test.
- An engine change can change WHAT gets recorded (e.g. 2026-10-17: controls named by their
  `<label>` and unnamed controls are now recorded; then text cap 800 → 5,000 and tall-page
  strips). Bump `ENGINE_VERSION` in `agent-capture.ts` for any such change; every capture stores
  it and the report warns when two runs differ.
- Type-check just the engine on the user's VM (~4 GB RAM): full `tsc -p tsconfig.eslint.json` and
  `eslint` run out of memory there — never claim they passed. Use a temp config in `$HOME`
  extending `automation/tsconfig.json`, with `types:["node"]`,
  `typeRoots:["<repo>/node_modules/@types"]`, `include:[]`, and the visual-diff files in `files`.
  Expect 0 errors under `automation/visual-diff/`.
- Strict mode (`noUncheckedIndexedAccess`): guard array reads with `?? 0` or
  `const [first] = items; if (!first) …`, not `!` (non-null assertion is a lint warning).
- `pngjs` types come from the local `pngjs.d.ts`; don't add `@types/pngjs` without asking.
- eng-guardrails-platform: `npx playwright test automation/visual-diff --list --project=chromium` → 8 tests in 1 file (×3 without `--project`: the config has 3 browsers).
- After copying a changed file onto the user's computer, stage it under a NEW path each time and
  confirm the content landed (compare a `sha256sum`), not just the "written" message — a stale
  copy has landed before.
- Polling a background tsc: `pgrep -f "tsc --noEmit"` matches the shell wrapper itself; use
  `ps -eo args | grep "[b]in/tsc"`. When stopping a local server, kill it by port
  (`kill $(lsof -t -i:<port>)`), not `pkill -f` — that can match and kill your own shell.

Clean tsc and `--list` prove compile and collection only, not that an assertion can fail.