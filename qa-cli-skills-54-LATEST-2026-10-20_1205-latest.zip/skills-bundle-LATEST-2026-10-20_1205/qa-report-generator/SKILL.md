---
name: qa-report-generator
description: "Generate a structured markdown QA test report (.md file) from completed test execution results. Includes ticket summary, test case results, code analysis notes, and media file references. After generating the report, automatically attaches both files (QA Report + Test Cases) to the Linear issue via the linear-comment-writer skill's upload_linear_file.py helper. Use this skill whenever you need to create a QA report, generate a test results document, produce a .md test report, or save test session output to a file. Triggers on: generate report, create QA report, save test results, write .md report, test report, output report."
---

# QA Report Generator

Produces two markdown files per ticket, then **automatically attaches them to the Linear issue**.

1. **Full QA Report** — `$REPO_ROOT/test-reports/{TICKET_KEY}_[PASSED|FAILED]_QA-Report_{date}.md`
2. **Test Cases File** — `$REPO_ROOT/test-cases/{TICKET_KEY}_[PASSED|FAILED]_Test-Cases_{date}.md`

## Shared References

Before proceeding, read:
- `shared-qa-base/references/status-definitions.md` — all status icons and their meanings
- `shared-qa-base/references/media-rules.md` — media file naming and locations

> **Screenshot note:** save_to_disk on mcp__Claude_in_Chrome__computer silently fails. Use mcp__playwright__browser_run_code_unsafe with page.screenshot() to capture evidence. See playwright-media-capture skill for full details including SSO auth steps.

---

## Screenshot & Video — Scope Rules

| Scope | Screenshots (every TC) | Video (FAIL only) |
|-------|------------------------|-------------------|
| **FE** (Frontend only) | Required | Required |
| **FE + BE** (Both) | Required | Required |
| **BE** (Backend only) | Not needed | Not needed |

Only trigger playwright-media-capture / screenshot-video-capture when scope is FE or FE+BE. BE-only tickets skip all screenshots — use — in those columns.

---

## File Naming

Determine PASSED/FAILED **before** naming files:
- **PASSED** — every TC passed
- **FAILED** — any TC failed

```
{TICKET_KEY}_[PASSED|FAILED]_QA-Report_{YYYY-MM-DD}.md    -> $REPO_ROOT/test-reports/
{TICKET_KEY}_[PASSED|FAILED]_Test-Cases_{YYYY-MM-DD}.md   -> $REPO_ROOT/test-cases/
```

---

## File 1 — Full QA Report

```markdown
# {TICKET_KEY} -- {Ticket Title}

## Summary

| Field | Details |
|-------|---------|
| **Ticket ID** | {TICKET_KEY} |
| **Type** | Bug / Task / Story / Sub-task |
| **Scope** | FE / BE / FE+BE |
| **Environment** | Dev (https://app.dev.firstrecon.ai) |
| **Status** | Ready / Logged In / Re-logged In |
| **Overview** | Brief description |
| **Key Context** | Background, linked tickets, dependencies |

## Test Cases

| TC ID | Description | Steps | Expected Result | Actual Result | Status | Evidence |
|-------|-------------|-------|-----------------|---------------|--------|----------|
| TC1 | Happy Path | 1. Navigate 2. Click | Expected outcome | Actual outcome | Pass | ![{TICKET_KEY}-TC1-PASS-desc.png](./{TICKET_KEY}-TC1-PASS-desc.png) |
| TC2 | Negative | 1. Navigate 2. Enter invalid | Error shown | Error shown | Pass | ![{TICKET_KEY}-TC2-PASS-desc.png](./{TICKET_KEY}-TC2-PASS-desc.png) |
| L2-1 | Code check | Inspect file/function | Expected in code | Confirmed in source | BE Pass | -- |

> Evidence column only populated for FE or FE+BE scope. Use -- for BE-only.

## Code Analysis Notes

### Relevant Files
| File | Role / Relevance |
|------|-----------------|
| path/to/file | What this file does |

### Implementation Observations
Findings: logic gaps, missing validations, discrepancies between AC and code.

## Media Files
> FE/FE+BE scope only. Replace with note if not applicable.

| File | Type | TC | Notes |
|------|------|----|-------|
| {TICKET_KEY}-TC1-PASS-desc.png | Screenshot | TC1 | Green badge bottom-right |
| {TICKET_KEY}-TC2-FAIL-desc.webm | Recording | TC2 | Reproduction steps |

> If all passed: No media files -- all test cases passed
> If BE-only: No media files -- backend-only scope
```

---

## File 2 — Test Cases Only

Same table format as the QA Report Test Cases section. Strip Summary, Code Analysis, and Media Files sections. Keep only the header + test cases table, fully filled in.

---

## Auto-Attach to Linear (mandatory after saving files)

After both .md files are saved, attach them to the Linear issue immediately.

> Migrated from Jira. There is no browser upload / `setInputFiles` step anymore — attaching a
> file to a Linear issue is a direct API call (`fileUpload` mutation + signed `PUT`), scriptable
> from Bash in every environment. See `LINEAR_CHEATSHEET.md` §3 and the `linear-comment-writer`
> skill for the full upload flow.

### Step 1 — Resolve REPO_ROOT

```bash
REPO_ROOT=$(find /sessions -maxdepth 5 -name ".git" -type d 2>/dev/null | head -1 | xargs dirname 2>/dev/null)
[ -z "$REPO_ROOT" ] && echo "[ERROR] Cannot find repo root" && exit 1
echo "REPO_ROOT=$REPO_ROOT"
```

### Step 2 — Upload files via `upload_linear_file.py`

```bash
python3 "$REPO_ROOT/.claude/skills/linear-comment-writer/scripts/upload_linear_file.py" \
  "$REPO_ROOT/test-reports/{TICKET_KEY}_[PASSED|FAILED]_QA-Report_{date}.md" \
  "$REPO_ROOT/test-cases/{TICKET_KEY}_[PASSED|FAILED]_Test-Cases_{date}.md"
  # FE/FE+BE only -- also pass evidence files, e.g.:
  # "$REPO_ROOT/manual-testing/evidences/{TICKET_KEY}/{TICKET_KEY}-TC1-PASS-desc.png"
```

This calls Linear's `fileUpload` mutation and `PUT`s each file directly, printing one
`filename -> assetUrl` line per file. No navigation to the issue page and no `setInputFiles` —
record each `assetUrl` for use by `linear-comment-writer` and, optionally, `attachmentCreate` so
the files also show in the issue's attachment list.

### Step 3 — Verify and proceed to linear-comment-writer

Confirm the number of `assetUrl` lines matches expected (2 files for BE, 2 + evidence for
FE/FE+BE). Then invoke `linear-comment-writer` for the table-based Markdown comment.

---

## Report Rules

- **One report + one test-cases file per ticket** — never combine multiple tickets
- **Determine PASSED/FAILED first**, name files before writing content
- **Evidence column**: FE/FE+BE only — use -- for BE-only rows
- **Auto-attach after saving** — both .md files go to the Linear issue immediately
- **Evidence files** (screenshots/videos): included in the same upload batch for FE/FE+BE scope
- **Linear comment**: table format — see `linear-comment-writer` skill for the exact structure
