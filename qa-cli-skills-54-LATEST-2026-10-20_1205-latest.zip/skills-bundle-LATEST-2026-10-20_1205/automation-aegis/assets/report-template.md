# 🛡️ Automation Aegis — Quality Gate Report

**Scope:** <PR link / branch / files reviewed>
**Reviewed files:** <N files>
**Date:** <YYYY-MM-DD>

---

## Verdict

> ## <✅ AEGIS PASS  |  🚫 AEGIS BLOCKED>
> **Grade: <A | B | C / BLOCKED>** — <one-line justification>

Blockers: **<n>** · Major: **<n>** · Minor: **<n>**

---

## Toolchain gates

| Gate | Result |
|------|--------|
| `eslint .` | <✅ clean / ❌ n errors> |
| `tsc --noEmit` | <✅ clean / ❌ errors> |
| `playwright test --list` | <✅ N tests / M files / ❌ collection error> |

---

## Findings

Ordered by severity. Every finding is actionable.

### 🔴 Blockers

1. **[A?] `file.spec.ts:LINE`** — <what's wrong>.
   **Fix:** <exact change>
   ```ts
   // ❌ before
   ...
   // ✅ after
   ...
   ```

_(none — omit this section if empty)_

### 🟡 Major

1. **[A?] `file.spec.ts:LINE`** — <what's wrong>. **Fix:** <change>

### 🔵 Minor

1. **[A?] `file.spec.ts:LINE`** — <note>. **Fix:** <change>

---

## What's good ✅

<Brief credit for what the code does well — grounded assertions, correct fixme tagging, live-verified guards, clean structure, etc.>

---

## Next steps

- <Fix the N blockers, then re-run Aegis.>
- <Optional: address 🟡 items this round vs. defer with a note.>
