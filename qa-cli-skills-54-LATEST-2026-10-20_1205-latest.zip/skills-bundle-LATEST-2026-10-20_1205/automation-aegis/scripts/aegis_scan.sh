#!/usr/bin/env bash
# Automation Aegis — static scanner for Playwright + TypeScript automation code.
# Flags common quality-gate violations, then runs the toolchain gates if a package.json is present.
# Usage: bash aegis_scan.sh <path-to-dir-or-file> [more paths...]
# Output is SIGNAL, not a verdict — confirm each hit in context (some are legitimate).

set -uo pipefail

TARGETS=("${@:-.}")
RED=$'\033[31m'; YEL=$'\033[33m'; BLU=$'\033[34m'; GRN=$'\033[32m'; DIM=$'\033[2m'; RST=$'\033[0m'
blocker=0; major=0; minor=0

# Collect .ts files under the given targets (spec + support code).
mapfile -t FILES < <(
  for t in "${TARGETS[@]}"; do
    if [ -f "$t" ]; then echo "$t";
    elif [ -d "$t" ]; then find "$t" -type f -name '*.ts' 2>/dev/null;
    fi
  done | sort -u
)

if [ "${#FILES[@]}" -eq 0 ]; then
  echo "No .ts files found under: ${TARGETS[*]}"; exit 0
fi

echo "${DIM}Automation Aegis — scanning ${#FILES[@]} TypeScript file(s)${RST}"
echo

# hit SEVERITY LABEL PATTERN [grep-flags]
hit() {
  local sev="$1" label="$2" pat="$3"; shift 3
  local flags=("$@")
  local out
  out=$(grep -REnH "${flags[@]}" -- "$pat" "${FILES[@]}" 2>/dev/null)
  [ -z "$out" ] && return 0
  case "$sev" in
    BLOCKER) echo "${RED}🔴 BLOCKER — $label${RST}"; blocker=$((blocker+1));;
    MAJOR)   echo "${YEL}🟡 MAJOR   — $label${RST}"; major=$((major+1));;
    MINOR)   echo "${BLU}🔵 MINOR   — $label${RST}"; minor=$((minor+1));;
  esac
  echo "$out" | sed 's/^/     /'
  echo
}

echo "── Pattern checks ─────────────────────────────────────────"
echo

# A2 — hardcoded waits / timeouts
hit BLOCKER "A2 hardcoded timeout: waitForTimeout()"        'waitForTimeout\s*\('
hit BLOCKER "A2 hardcoded sleep: setTimeout in test flow"   'setTimeout\s*\('
hit MAJOR   "A2 per-call { timeout: N } override"           '\{\s*timeout:\s*[0-9]'

# A3 — Playwright-only pseudo-selectors used in browser context (querySelector/evaluate/waitForFunction)
hit BLOCKER "A3 Playwright-only pseudo-selector (:text-is/:has-text/:visible) — invalid in querySelector/evaluate" ':text-is\(|:has-text\(|:visible'

# A1 — assertions
hit MAJOR   "A1 possible false-pass: exact getByText + toHaveCount" 'toHaveCount\s*\(\s*0\s*\)'
hit BLOCKER "A1 console.log PASS/FAIL used instead of a real assertion" 'console\.(log|info|error)\([^)]*\b(PASS|FAIL|PASSED|FAILED)\b'

# A4/A11 — hardcoded absolute machine paths (portability)
hit BLOCKER "A4 hardcoded absolute machine path (/Users, /home, C:\\)" '/Users/|/home/[a-zA-Z]|[A-Z]:\\\\Users'

# A3 — hardcoded build-hashed bundle filenames (Rollup/Vite hashes change every rebuild)
# Matches -CX-FH5WV.js (two-token), -CN_EpZpk.js (underscore), -Dn-vcs0s.js (mixed)
hit MAJOR   "A3 hardcoded build-hashed asset filename (changes every rebuild)" '-[A-Za-z0-9]{2}-[A-Za-z0-9]{4,8}\.(js|css|mjs|cjs)|-[A-Za-z]{2,}_[A-Za-z0-9]{4,8}\.(js|css|mjs|cjs)'

# A10 — TypeScript type safety
hit MAJOR   "A10 gratuitous any / as any"                   ':\s*any\b|as\s+any\b'
hit MAJOR   "A10 raw fs/child_process require (prefer safe-fs wrapper)" "require\\(['\"](fs|child_process)['\"]\\)"

# A6 — tagging
hit MAJOR   "A6 @known-bug without test.fixme nearby (verify manually)" '@known-bug'

# A8 — focused / disabled tests
hit BLOCKER "A8 focused test committed: test.only / describe.only" '\.only\s*\('
hit MINOR   "A8 leftover console.log"                       'console\.log\s*\('

# A7 — lint suppressions
hit MAJOR   "A7 lint/type suppression"                      'eslint-disable|@ts-ignore|@ts-nocheck'

# A4 — hardcoding
hit MAJOR   "A4 hardcoded absolute URL (use baseURL)"       'https?://[a-zA-Z0-9.-]+'
hit MAJOR   "A4 hardcoded localhost/port"                   'localhost:[0-9]+|127\.0\.0\.1'

# A9 — secrets hygiene
hit BLOCKER "A9 possible secret token (phx_/api key)"       'phx_[A-Za-z0-9]|(api|secret|access)[_-]?key\s*[:=]'

# A1 — tests missing any expect (per-file check)
missing_expect=""
for f in "${FILES[@]}"; do
  case "$f" in *.spec.ts)
    if grep -qE '\btest\s*\(|\btest\.fixme\s*\(' "$f" 2>/dev/null \
       && ! grep -qE '\bexpect\s*\(' "$f" 2>/dev/null; then
      missing_expect+="     $f"$'\n'
    fi ;;
  esac
done
if [ -n "$missing_expect" ]; then
  echo "${RED}🔴 BLOCKER — A1 spec file with test() but no expect() assertion${RST}"
  echo "$missing_expect"; blocker=$((blocker+1))
fi

# A8.4 — scratch / investigation specs present (must be testIgnore'd or deleted)
scratch=$(printf '%s\n' "${FILES[@]}" | grep -Ei '/(_investigate|scratch|_debug|_tmp)/' || true)
if [ -n "$scratch" ]; then
  echo "${YEL}🟡 MAJOR   — A8.4 scratch/investigation specs present — exclude via testIgnore or delete${RST}"
  echo "$scratch" | sed 's/^/     /'; echo; major=$((major+1))
fi

echo "── Toolchain gates ────────────────────────────────────────"
echo
PKG_DIR=""
for t in "${TARGETS[@]}"; do
  d=$([ -f "$t" ] && dirname "$t" || echo "$t")
  while [ "$d" != "/" ] && [ "$d" != "." ]; do
    [ -f "$d/package.json" ] && { PKG_DIR="$d"; break; }
    d=$(dirname "$d")
  done
  [ -n "$PKG_DIR" ] && break
done

if [ -z "$PKG_DIR" ]; then
  echo "${DIM}No package.json found — skipping eslint / tsc / playwright gates. Run them manually in the suite root.${RST}"
else
  echo "${DIM}Package root: $PKG_DIR${RST}"
  run_gate() { echo "→ $1"; ( cd "$PKG_DIR" && eval "$2" ) >/tmp/aegis_gate.log 2>&1 \
      && echo "  ${GRN}✅ clean${RST}" \
      || { echo "  ${RED}❌ failed (A7 blocker)${RST}"; tail -n 15 /tmp/aegis_gate.log | sed 's/^/     /'; blocker=$((blocker+1)); }; }
  command -v npx >/dev/null 2>&1 && {
    run_gate "eslint"                'npx --no-install eslint . 2>/dev/null || npx eslint .'
    run_gate "tsc --noEmit"          'npx --no-install tsc --noEmit -p tsconfig.json 2>/dev/null || npx tsc --noEmit'
    run_gate "playwright test --list" 'npx --no-install playwright test --list 2>/dev/null || npx playwright test --list'
  } || echo "${DIM}npx not available — run the gates manually.${RST}"
fi

echo
echo "── Scan summary ───────────────────────────────────────────"
echo "  ${RED}🔴 Blocker signals: $blocker${RST}   ${YEL}🟡 Major: $major${RST}   ${BLU}🔵 Minor: $minor${RST}"
if [ "$blocker" -gt 0 ]; then
  echo "  ${RED}Provisional: 🚫 AEGIS BLOCKED — confirm each blocker, then finalize the report.${RST}"
else
  echo "  ${GRN}Provisional: ✅ no blocker signals — complete the manual rubric review before passing.${RST}"
fi
echo "${DIM}  Reminder: this is signal only. Verify every hit against references/rules.md before writing the verdict.${RST}"
