# Automation Aegis — Rule Catalog

The full rubric Aegis enforces on Playwright + TypeScript automation code. Each rule has a severity, the reason it exists, and a ❌ bad / ✅ good example. Severities:

- 🔴 **Blocker** — blocks the gate. Must be fixed before merge.
- 🟡 **Major** — should be fixed; does not block on its own.
- 🔵 **Minor** — polish; report and move on.

Every rule here traces to a real review finding on the Persefoni marketing-site and Electron automation suites — weak/false-pass assertions, hardcoded `/Users/belleung/` paths fixed with env vars + `test.skip` guards, console-only PASS/FAIL logging replaced with real `expect()`, explicit types stripped to `any`, `_investigate/` debug specs leaking into the default run, `package.json` scripts pointing at renamed dirs, blanket eslint suppressions, and description-vs-diff narrative inaccuracies.

## Table of contents

- [A1. Assertions](#a1-assertions)
- [A2. Waiting & timing](#a2-waiting--timing)
- [A3. Selectors](#a3-selectors)
- [A4. No hardcoding](#a4-no-hardcoding)
- [A5. Naming conventions](#a5-naming-conventions)
- [A6. Tagging & taxonomy](#a6-tagging--taxonomy)
- [A7. Toolchain gates](#a7-toolchain-gates)
- [A8. Structure & maintainability](#a8-structure--maintainability)
- [A9. Scope & hygiene](#a9-scope--hygiene)
- [A10. TypeScript type safety](#a10-typescript-type-safety)
- [A11. Portability & CI execution](#a11-portability--ci-execution)

---

## A1. Assertions

**A1.1 🔴 Every test must contain at least one `expect`.** A test with no assertion verifies nothing — it only checks that no exception was thrown.

**A1.2 🔴 No `console.log`-based PASS/FAIL in place of a real assertion.** A test that logs its outcome but never calls `expect()` always "passes" in CI regardless of what actually happened. This was a real finding: a spec logged `PASS`/`FAIL` to the console instead of gating.

❌ Logs the result but never fails the test:
```ts
const exists = fs.existsSync(localeBundle);
console.log(exists ? 'PASS: en bundle present' : 'FAIL: en bundle missing');
```
✅ Assert so the test actually fails when the condition is false:
```ts
expect(fs.existsSync(localeBundle), `EN locale bundle missing at ${localeBundle}`).toBe(true);
```

**A1.3 🔴 Assertions must be falsifiable.** The most dangerous defect: an assertion that can never fail and therefore "passes" without testing anything.

❌ Silent false-pass — the label renders as two adjacent SVG `<text>` nodes (`<text>AGENT</text><text>SECURITY</text>`), so an exact-text match never resolves and the count trivially becomes 0:
```ts
await expect(page.getByText('AGENT SECURITY', { exact: true })).toHaveCount(0);
```
✅ Assert against what the user actually reads — the normalized rendered text:
```ts
const body = (await page.locator('body').innerText()).replace(/\s+/g, ' ');
expect(body).toContain('AGENT SECURITY');
```

**A1.4 🟡 Assert the whole set, not a convenient subset.** If four English answer options should be present, assert all four — checking two leaves the other two unguarded.

**A1.5 🟡 Test title must match the assertion.** If the title says "hero CTA links to /contact", the assertion must check the `href`, not merely that the button is visible.

**A1.6 🔵 Prefer web-first assertions** (`toBeVisible`, `toHaveText`, `toHaveURL`) over manual `expect(await locator.count()).toBe(...)` — they auto-retry and read more clearly.

---

## A2. Waiting & timing

**A2.1 🔴 No hardcoded timeouts / fixed sleeps.** They make suites slow and flaky and hide real races. (In one suite audit `waitForTimeout()` appeared ~2,098 times — flagged as fragile under CI load; move to event-based waits.)

❌
```ts
await page.waitForTimeout(2000);
await new Promise(r => setTimeout(r, 500));
```
✅ Wait on a condition, not the clock:
```ts
await expect(panel).toBeVisible();            // auto-retries
await page.waitForLoadState('networkidle');
await page.waitForSelector('[data-testid="results"]');
```

**A2.2 🔴 For animations/transitions, poll across the window** rather than reading state once at an arbitrary instant. A single opacity read during a 220 ms transition is a coin-flip.

❌
```ts
const opacity = await panel.evaluate(el => getComputedStyle(el).opacity);
expect(Number(opacity)).toBeLessThan(1);      // depends on exact timing
```
✅
```ts
const sawOverlap = await page.waitForFunction(() => {
  const p = document.querySelector('[data-testid="solutions-panel"]');
  return p && getComputedStyle(p).opacity !== '0';
}, { timeout: 1000 }).then(() => true).catch(() => false);
expect(sawOverlap).toBe(true);
```

**A2.3 🟡 No arbitrary per-call `{ timeout: N }` sprinkled to "fix" flakiness.** Tune the config; use explicit timeouts only where genuinely justified (and say why).

---

## A3. Selectors

**A3.1 🔴 No Playwright-only pseudo-selectors in browser-side code.** `:text-is()`, `:has-text()`, `:visible`, `>>` are Playwright locator syntax — **not** native CSS. Passed to `querySelector`/`evaluate`/`waitForFunction` they return `null`, so the test silently no-ops (false negative).

❌
```ts
await page.waitForFunction(() =>
  document.querySelector('.nav__dd:has(button:text-is("Solutions")) .ddpanel'));
```
✅ Use a Playwright locator, or native CSS inside the browser:
```ts
await expect(page.locator('.nav__dd', { hasText: 'Solutions' })
  .locator('.ddpanel')).toBeVisible();
```

**A3.2 🟡 Prefer stable, semantic locators** in this order: `getByRole` → `getByTestId` → `getByLabel` → `getByText` → CSS. Avoid XPath and long CSS chains.

**A3.3 🟡 Avoid brittle shared-class selectors.** If `.ddpanel--list` is shared by Solutions *and* Resources, a selector on it targets the wrong element. Use a unique `data-testid` or `role`+`name`.

**A3.4 🟡 Don't hardcode build-hashed filenames.** Bundle assets like `useSessionAuth-CX-FH5WV.js` or `localModels-Dn-vcs0s.js` get a new hash on every rebuild, so a spec that pins the literal name breaks each release. Discover the file by glob/prefix pattern at runtime instead.

**A3.5 🟡 Ground selectors in real source.** Don't guess at a class or id that "should" exist — confirm it. Selectors that can't be grounded belong in a `test.fixme()` with a note, not a passing test.

---

## A4. No hardcoding

**A4.1 🔴 No hardcoded absolute machine paths.** A path like `/Users/belleung/dev/...` or `C:\Users\...` fails on every machine except the author's — the #1 portability defect found in the Electron suite.

❌
```ts
const appPath = '/Users/belleung/first-recon-extracted/dist-electron/main.cjs';
fs.mkdirSync('/Users/belleung/evidence', { recursive: true });
```
✅ Env var with a sane fallback, and skip when unavailable (see A11):
```ts
const appPath = process.env.EXTRACTED_APP_PATH ?? path.join(__dirname, '../fixtures/app');
const evidenceDir = process.env.EVIDENCE_DIR ?? path.join(__dirname, '../evidence');
test.skip(!fs.existsSync(appPath), 'EXTRACTED_APP_PATH not set — skipping bundle inspection');
```

**A4.2 🟡 No hardcoded environment values** — URLs, hosts, ports, tenant IDs, account emails, API keys, magic constants — inline in specs.

❌ `await page.goto('https://staging.example.com:3000/product/app');`
✅ `await page.goto('/product/app');` with `baseURL` in `playwright.config.ts`.

**A4.3 🟡 No hardcoded expected data that should be parameterized.** Long literal lists belong in a named constant/fixture reused by title and assertion, so they can't drift apart.

**A4.4 🔵 Extract repeated literals** (labels, routes) into `constants.ts` so a copy in five specs doesn't rot independently.

---

## A5. Naming conventions

**A5.1 🟡 Spec file naming:** `tests/<area>/<feature-in-kebab-case>.spec.ts` (e.g. `dropdowns/tco-calculator-users-lower-bound.spec.ts`). One clear feature per file; group by area folder.

**A5.2 🟡 Descriptive `describe`/`test` titles** stating expected behavior — "shows required-field asterisks on contact form", not "test1".

**A5.3 🔵 Identifier casing:** `camelCase` variables/functions, `PascalCase` for page-object classes, `UPPER_SNAKE_CASE` for constants.

---

## A6. Tagging & taxonomy

**A6.1 🟡 `@regression` is reserved for guards of already-fixed defects.** An open bug has nothing fixed to regress against, so it must **not** carry `@regression` — otherwise `--grep @regression` pulls in skipped known-bug noise.

**A6.2 🔴 Open bugs use `@known-bug` + `test.fixme()`** — never a plain `test.skip` with no marker, and never a test written so it falsely passes against a still-broken page.

**A6.3 🟡 Priority tag required** on every test title: `@p1` / `@p2` / `@p3`. (A frequent real finding: known-bug specs missing their `@p2` tag.)

**A6.4 🟡 Every `skip`/`fixme` carries a reason string** — ideally a ticket reference (`test.fixme(true, 'GR-9468: fade-in overlap')`). A bare `test.skip()` with no rationale is unreviewable.

**A6.5 🔵 Domain tags** (`@i18n`, `@visual`, `@a11y`) applied where relevant so filtered runs are accurate.

---

## A7. Toolchain gates

Run and record the result of each — these mirror the "Acceptance / Proof" block on a good PR:

**A7.1 🔴 `npx eslint .`** → exit 0, no errors.
**A7.2 🔴 `npx tsc --noEmit -p tsconfig.json`** → exit 0.
**A7.3 🔴 `npx playwright test --list`** → collects cleanly; test/file count matches the PR's stated numbers.
**A7.4 🟡 Lint suppressions must be narrow and accurately justified.** Don't blanket-disable `no-unsafe-*`, `no-console`, or security rules; each `eslint-disable`/`@ts-ignore` needs a correct inline reason. A real finding: an override comment claimed the suppressed rules were "downstream effects of typed `evaluate()` callbacks" when ~43 files actually used direct `fs`/`child_process` — a misleading rationale.
**A7.5 🟡 One lint/type config per directory.** Two parallel configs for the same folder (a root override *and* a standalone `eslint.config.mjs`) drift out of sync over time — consolidate or clearly document why both exist.

---

## A8. Structure & maintainability

**A8.1 🔵 Reuse via Page Object Model / helpers.** The same selector copy-pasted across specs is a maintenance trap — extract a page object or fixture.

**A8.2 🔵 Tests must be independent** — no reliance on execution order or state left by a previous test. Set up state in `beforeEach`; clean up in `afterEach`.

**A8.3 🔴 No focused tests committed** (`test.only`, `describe.only`) — they silently drop the rest of the suite in CI.

**A8.4 🟡 Scratch / investigation specs must not run by default.** A `tests/e2e/_investigate/` directory of debug specs was pulled into the default run — either exclude it via `testIgnore: ['**/e2e/_investigate/**']` in `playwright.config.ts`, or delete it before merge.

**A8.5 🔵 No leftover `console.log`, commented-out code, or dead helpers.**

---

## A9. Scope & hygiene

**A9.1 🔵 Diff scoped to intended files.** Test PRs should not drag in unrelated reports, scratch output, or config. Flag stray files.

**A9.2 🔴 Secrets hygiene.** No tokens or secret files staged — scan for `phx_`, `.dev.vars`, `*.token`, `*.key`, obvious API keys. (Also sanity-check any new devDependencies are official, not typosquats.)

**A9.3 🟡 `package.json` scripts must resolve to real paths.** After a suite reorg, targeted scripts like `"test:chat": "playwright test tests/e2e/chat"` silently return "No tests found" if the dir was renamed to `tests/e2e/ai-chat`. Every script path and referenced file (e.g. `scripts/inspect-app.js`) must exist.

**A9.4 🔵 Description matches the diff — including *how*.** Claims in the PR body (test counts, "removed a duplicate paragraph", "added `testIgnore`", which files got the path fix) must be true against the actual diff, and all scope must be disclosed (new devDependencies, new config files). Real findings: a PR claimed to add a line that already existed, misattributed a fix to the wrong files, and omitted a whole standalone eslint config + 4 new deps. Note inaccuracies even when non-blocking.

---

## A10. TypeScript type safety

**A10.1 🟡 No gratuitous `any` / `as any`.** Stripping real types to `any` removes the compiler's safety net. A real finding: a spec's explicit `ElectronApplication`, `Page`, `Dialog`, `HTMLButtonElement` types were all silently replaced with `any` — restore them.

**A10.2 🟡 Narrow union returns before property access.** When `page.evaluate()` returns `A | B`, accessing `.listRect` / `.newTestids` without narrowing is a type error on the branch that lacks them. Narrow first (discriminant check) or shape the return type.

**A10.3 🟡 Prefer a safe-fs wrapper over raw `fs` / `child_process`.** If the suite provides a safe-fs helper (path validation, no arbitrary `rm`), use it instead of dropping to raw `require('fs')` / `require('child_process')` — and never introduce unsafe dynamic `fs.rm`/`eval`.

---

## A11. Portability & CI execution

**A11.1 🔴 Env-dependent tests must guard with `test.skip(!condition, reason)`.** A spec that reads an optional path/app must skip cleanly when it's absent — not throw. Real finding: `gr-7670` called `fs.readdirSync(bundlePath)` in a fallback branch with no guard, throwing `ENOENT` instead of skipping, while its three sibling specs all had the guard.

❌
```ts
const files = fs.readdirSync(bundlePath);   // ENOENT when path absent
```
✅
```ts
test.skip(!fs.existsSync(bundlePath), 'EXTRACTED_APP_PATH unset — skipping bundle inspection');
const files = fs.readdirSync(bundlePath);
```

**A11.2 🟡 Sibling specs share the same guard pattern.** If four bundle-inspection specs need the same env guard, all four must have it identically — a lone missing one is the flake.

**A11.3 🟡 New specs must actually be wired into a CI pipeline.** Adding 166 spec files whose workflow lives at a path GitHub Actions never picks up (e.g. `electron-automation/.github/workflows/test-electron.yml` instead of repo-root `.github/workflows/`) means the tests are *source, not verified coverage*. "CI green" then only proves lint/type/build — not that the tests pass against a running app. Flag added-but-never-run suites; cap the grade accordingly.
