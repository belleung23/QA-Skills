# Persefoni Review Standards — A12–A17 + PR closeout contract

Rules A12–A17 extend `rules.md`. Every one traces to a real review finding on
**PR #11493** (`test(automation): Add Playwright coverage for User Settings (TC-US-001..272)`,
merged 2026-08-20) — reviewed by David Muczynski (`muczynski-persefoni`), Kyle Stroh
(`kstrohPersefoni`), Greptile, and Codex across 5+ rounds. The PR-level contract at the bottom is
the repo's own canonical `REVIEW.md`, which `AGENTS.md` designates as owning "how PRs are reviewed,
repaired, and declared merge-ready."

Severities match `rules.md`: 🔴 Blocker · 🟡 Major · 🔵 Minor.

---

## A12. Shared-account & shared-state isolation

The automation suites share a small pool of real accounts (`chat_user`, `platform_admin`,
`super_admin`). A test that mutates persisted state on one of those accounts and fails partway
through leaves the account dirty for every later or parallel test.

**A12.1 🔴 Restore mutated shared state in `try/finally`, never only on the success path.** Real
finding (Greptile P1, held this PR at "not safe to merge" for multiple rounds): TC-US-101,
TC-US-102, TC-US-103 toggled persisted `chat_user` preferences (local-caching toggle, preferred
model, density) and restored them *after* the assertions. Any failing assertion skipped the
restore and contaminated subsequent tests.

❌
```ts
await toggle.click();                       // mutate shared account
await expect(banner).toBeVisible();         // if this fails, the toggle stays flipped
await toggle.click();                       // restore never runs
```
✅
```ts
await toggle.click();
try {
  await expect(banner).toBeVisible();
} finally {
  await toggle.click();                     // restore runs on pass AND on failure
}
```

**A12.2 🔴 Tag shared-account mutators and route them to a serial project.** A `try/finally` fixes
sequential contamination but not *parallel* contamination — two workers on the same account still
race. This repo's accepted pattern: tag the case `@serial-account`, add a dedicated Playwright
project (`user-settings-serial-account`) that runs them serially, and `grepInvert` the tag out of
the parallel browser projects so they run exactly once.

**A12.3 🟡 A shared `beforeEach` is not serialization.** Reviewers explicitly called out the
assumption that "the describe block uses serial execution implicitly (same `beforeEach`)" as false.
Only `test.describe.serial` or a dedicated serial project actually serializes.

---

## A13. Auth-role correctness

**A13.1 🔴 The authenticated identity must match the surface under test.** Real findings, three
separate cases: TC-US-195 and TC-US-241 navigated to `/admin` while authenticated as `chat_user`
(the route 403s — so the test asserted nothing about theme propagation), and TC-US-211 had the same
defect. Fix: authenticate as `platform_admin`, in its own `describe` block so the role change
doesn't leak into sibling cases.

**A13.2 🔴 Unauthenticated-state tests must not inherit an authenticating `beforeEach`.** Real
finding: TC-US-247 tested `/login` recovery controls, but the suite's `beforeEach` had already
authenticated as `chat_user` — so the test could never see the unauthenticated login page it
claimed to verify. Fix: move it to its own describe with no auth, or explicitly clear state.

**A13.3 🟡 A role change belongs in its own describe block, not mid-test.** Keeps the fixture's
identity unambiguous and prevents cross-test bleed.

---

## A14. Selector–implementation reconciliation

**A14.1 🔴 Every `data-testid` a spec targets must exist in the current implementation.** Real
finding (Kyle's review handoff — he declined to complete the review over it): active added cases
referenced `chat-notifications-toggle`, `knowledge-notifications-toggle`,
`product-updates-notifications-toggle`, `chat-frequency-selector`, and
`notification-preferences-knowledge-row`, none of which exist in
`src/components/user-profile/NotificationPreferencesTab.tsx`. The component instead exposes
`system-browser-channel-toggle`, `mentions-email-channel-toggle`, `quiet-hours-toggle`,
`notification-preferences-in-app-master-toggle`.

Grep the component for each testid before the spec is written. `playwright test --list` will **not**
catch this — the spec collects fine and fails only at runtime, or worse, silently passes a
`toHaveCount(0)`-style check.

**A14.2 🔴 Do not substitute a plausible-looking selector to make a test run.** The reviewer's exact
words: these "require product/QA intent mapping, not a speculative selector substitution." If the
control the test case describes no longer exists, that is a spec gap — re-scope or retire the case
(and tag it per the `@regression` / `@known-gap` split), don't silently retarget it at a different
control and claim the original coverage.

**A14.3 🟡 Link helpers to their source-of-truth component in a comment.** Called out as a positive
in review: the helpers module documented which component each locator group came from, so the next
reader can re-verify drift cheaply.

---

## A15. Interaction fidelity

**A15.1 🔴 The interaction performed must be the interaction the test name claims.** Real finding:
TC-US-214 was titled as a double-click/double-submit guard but performed a single `click()` and then
asserted the button was disabled — a proxy check that would pass even if double-submit were broken.
Fix: perform a real `dblclick()` and assert **exactly one** `PUT /api/user/profile` request fired.

❌
```ts
await save.click();
await expect(save).toBeDisabled();          // proves nothing about double-submit
```
✅
```ts
const reqs: string[] = [];
page.on('request', r => { if (r.method() === 'PUT' && r.url().includes('/api/user/profile')) reqs.push(r.url()); });
await save.dblclick();
await expect(banner).toBeVisible();
expect(reqs).toHaveLength(1);               // the actual invariant
```

**A15.2 🟡 Prefer asserting the observable side effect over the intermediate UI state.** Counting
the network calls is falsifiable; a disabled-attribute check is a proxy that can pass for the wrong
reason.

---

## A16. Test-created resource cleanup

**A16.1 🔴 A test deletes what it creates, in `finally`, itself.** Real finding: TC-US-227 created a
real conversation and left it for global teardown. Teardown ran as `super_admin` and only cleaned
conversations *visible to that identity*, so the probe conversation leaked permanently. Fix: call
`deleteConversationApi` in a `finally` block inside the test.

**A16.2 🟡 Never assume global teardown can see your resource.** Teardown runs under one identity
with one tenant scope; a resource created under a different identity may be invisible to it.

---

## A17. Discovery integrity

**A17.1 🔴 Run repo-wide `playwright test --list` before and after, not just a scoped `--grep`.**
Real finding, self-caught and flagged as the highest-impact bug in the PR (no review comment had
spotted it): this branch moved `automation/user-settings/notifications/helpers.ts` to
`automation/playwright-test/tests/user-settings/notifications/helpers.ts` but left
`automation/settings/notification-preferences.spec.ts` importing the old path. One broken import
aborts the **entire** discovery scan: `bun run test:automation -- --list` returned **0 tests instead
of 11,222 across 867 files**. A scoped `--grep "@App.UserSettings"` still looked healthy, which is
exactly why the scoped check is not sufficient.

Whenever a diff moves, renames, or deletes a shared helper: unscoped `--list` before, unscoped
`--list` after, and compare the totals.

**A17.2 🔴 New suites must be reachable by a CI grep, not just present on disk.** Real finding: the
whole 272-case suite was invisible to CI because the `settings-tests` job only grepped
`@automation.settings.account` / `@automation.settings.roadmap`, and `test:automation:fast` never ran
the new serial-account project. Reviewer's framing: added-but-never-run is "a real gap, not verified
coverage." Verify the tag you ship is actually in a CI matrix entry, and that any dedicated project
is in the scripts that CI calls. (Extends A11.3.)

**A17.3 🟡 Watch the first real CI run.** Local `--list` proves collection, not execution. On this PR
the CI matrix entry was the *first* execution against a live app; nothing before that point proved
the assertions held.

---

## PR-level review & closeout contract

From the repo's canonical `REVIEW.md` (+ `AGENTS.md` Artifacts/Validation, `docs/sdlc/PR_DOCUMENTATION.md`).
Apply when Aegis is used as a pre-merge gate on a PR rather than on loose files.

### Dispositions — exactly three, no others

Every actionable comment (human, bot, or AI — all are "evidence to investigate") gets:

- **Fixed**
- **Declined** — with a concrete technical reason
- **Tracked** — to a Linear ticket, and *only* when the fix is architecturally out of PR scope

**Forbidden:** bare acknowledgements ("noted", "will do", "thanks"), and "blocked — human needed"
as a per-comment disposition. A finding from Codex/Copilot/Greptile "is the agent's to resolve, not
to escalate — there is almost never a reason an agent cannot fix or defensibly decline a code
comment." Critical/high findings must be Fixed unless the fix is genuinely outside safe PR scope.

Human escalation is reserved for the off-limits set only: secrets, tenant-isolation / tenant-SQL
changes, protected-branch merge, migration merge, CI/workflow governance — and even then, fix or
decline everything else and name the specific residual rather than a blanket punt.

### Verification standard

**Re-verify prior "Fixed" claims against the current code, not the reply text.** This is the
practice David called out explicitly across rounds — 15 previously-"Fixed" threads were re-checked
against the merged tree (grepping testids, tracing route guards, confirming URL contracts, running
`--list` before/after) rather than trusted from the thread reply. Renames and consolidation between
rounds can silently undo an earlier fix.

### Hard lines

- Never weaken auth, tenant isolation, entitlement gates, AI Data Protection, i18n, CI, tests, or
  governance checks to make a PR pass.
- Keep repairs bounded: specific file staging only, **never `git add -A` or `git add .`**.
- A report may be linked as evidence but does not authorize implementation.
- Don't imply "done" without current code, checks, tracker, review/merge, and evidence state.

### Merge-readiness checks that bite QA/automation PRs

The full report runs C1–C26; these are the ones that actually flag test-only diffs:

| Check | What it wants |
|---|---|
| Review threads | All resolved, each with a real disposition |
| Codex review | `@codex review` posted after opening every agent PR; findings addressed |
| Copilot / Greptile | Present and addressed (Copilot is easy to forget — it was the round-2 gap here) |
| Branch freshness | Current with `develop` — verify via `git rev-list --count HEAD..origin/develop` |
| No skipped tests introduced | `test.fixme` is fine **when documented** with the app defect + sheet/ticket reference |
| No `any` types | Strict TS: avoid `any`, prefer `unknown` + type guards, `??` for nullish |
| No hardcoded secrets | Reuse secrets already bound to the job; new secrets need provisioning review |
| Tracking ticket | An accepted **Linear** ticket linked on every PR (Jira mirror when SOX/audit-relevant). Missing this was flagged as "a real policy gap, not a nit." |
| `.github/workflows/**` touched | PR body needs **Blast Radius / Rollback / Validation / Test Plan**; two human approvals for SOC2 two-reviewer paths (`docs/sdlc/high-risk-paths.yaml`) |
| Description ↔ diff | Every file in the diff accounted for by the stated scope; no undeclared production-code changes |

### Validation commands (`AGENTS.md`)

Run the smallest relevant set and **report what passed or could not run**:
`bun run type-check`, `bun run lint:fix:quiet`, `bun run test:run`, `bun run test:worker`,
`bun run drift:check`, `bun run ci-policy:check`, and `bun run test:automation:fast` for affected
browser flows.

Gotcha: bare `bun run test:changed` covers **STAGED files only** and exits 0 having run nothing
otherwise. For PR validation pass the branch diff explicitly:

```bash
bun run test:changed --files "$(git diff --name-only origin/develop...HEAD | jq -R . | jq -sc .)"
```

Never claim a gate passed that you could not actually run — say which ones and why.

### Recommendation

Return exactly one: `READY_FOR_HUMAN_MERGE` · `NOT_READY` · `BLOCKED`.

`BLOCKED` is a PR-level state (CI infrastructure down, or a genuine off-limits change) — it is never
a substitute for dispositioning individual comments. **Agents never approve or merge.** Human
reviewers own final approval and merge.

### Closeout output shape

Recommendation · blockers · CI/check summary · review-thread disposition · governance/security
result · validation evidence · residual risks and required human action.
