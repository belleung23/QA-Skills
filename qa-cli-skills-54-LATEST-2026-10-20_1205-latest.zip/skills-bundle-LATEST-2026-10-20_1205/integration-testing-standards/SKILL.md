---
name: "integration-testing-standards"
description: "Standards for integration tests — frontend↔backend, service↔service, service↔database/queue — in Playwright TypeScript: what to cover, how to verify data flow across layers, test doubles, environment setup and PR scope. Use whenever a ticket, feature or review involves more than one component working together, end-to-end data flow, or FE↔BE verification."
---

# Integration Testing Standards

Unit tests prove one piece works alone; API tests prove one endpoint honours its contract; integration tests prove the pieces work **together** — that what the UI sends is what the API receives, what the API writes is what the database holds, and what one service emits is what the next one consumes. Most production bugs live at these seams, which is why this layer deserves its own standards rather than being treated as "E2E but slower".

Use this skill when writing, generating or reviewing tests that cross a boundary. Pair it with `api-testing-standards` for the request/response rules; this skill is about the boundaries themselves.

## Step 1: Map the boundaries before writing a test

For the feature under test, draw (in a comment or the PR description) the chain of components and the data that crosses each hop. Example for "user updates their profile name":

```
UI form → PATCH /users/{id} → users table → profile-updated event → search index + audit log
```

Each arrow is a boundary and each boundary needs at least one test that checks the data on **both** sides. Ask for each hop:

- What exact payload crosses it? (field names, types, formats — the classic bug is `firstName` on one side and `first_name` on the other)
- Is it synchronous or asynchronous? (async hops need polling, not sleeps)
- What happens when the far side is slow, down, or returns an error?
- Who owns the data after the hop? (so cleanup goes to the right place)

If you cannot name what crosses a boundary, read the code until you can. Guessing here produces tests that pass against the wrong behaviour.

## Step 2: Choose the integration level deliberately

There are three levels and each has a job. State which one a spec is in its header.

**FE↔BE (UI-driven, real backend)** — drive the UI with Playwright, then verify the result through the API or database, and vice versa: create through the API, verify the UI reflects it. This catches mismatched field names, wrong IDs sent by the UI, stale caches, and optimistic updates that never persisted. Never verify a UI action only by what the UI shows — the UI may be showing its own local state.

**Service↔service (API-driven)** — call service A and verify the effect in service B (via B's API, its table, or its queue). Use real services in a test environment where possible; use a recorded or stubbed dependency only for third parties you do not control (payment providers, email, external AI APIs).

**Service↔infrastructure** — verify writes reach the database/cache/queue with the right shape, migrations apply, and jobs run. Use a direct DB/queue client in the test only when there is no API that exposes the effect, and read-only unless the test needs to seed.

Pick the lowest level that exercises the seam. Driving the whole UI to test a queue consumer is slow and flaky for no gain.

## Step 3: Coverage checklist per boundary

**Round trip** — write on one side, read on the other, compare field by field (not just "something exists"). Include every field the ticket touches, plus timestamps and IDs formats.

**Field mapping** — names, casing, enums, date/time zones, number precision, null vs missing. Assert a specific value that would be wrong if the mapping broke (e.g. a non-UTC date, a decimal with cents).

**Error propagation** — when the backend returns `400`/`403`/`500`, the UI shows the right message and does not pretend success; when a downstream service fails, the upstream returns an honest error, not `200` with empty data. Use Playwright `page.route()` to inject backend failures for FE↔BE tests — this is the one place mocking the backend is correct, because you are testing the frontend's handling, not the backend.

**Asynchronous completion** — for jobs, events and webhooks, poll until the expected state appears with a bounded timeout (`expect.poll`, `expect(async…).toPass()`), and also assert the *intermediate* state (pending/processing) when the UI shows one. A sleep followed by a check is not acceptable: it either wastes time or flakes.

**Consistency after failure** — if step 2 of 3 fails, is step 1 rolled back or clearly marked? Partial writes are a classic integration bug.

**Permissions across the seam** — a user allowed in the UI but denied by the API (or the reverse) is a security bug. Test with at least one unauthorised actor per feature.

**Concurrency where it matters** — two updates to the same record; a delete while an edit is open. Only for features where the ticket or the data model makes this plausible.

**Contract drift** — one test that validates the live response against the schema/types the frontend was built with (zod/TypeScript types generated from OpenAPI). This fails early when the backend changes shape.

## Step 4: Environment, data and doubles

- All connection details (base URLs, DB connection strings, queue names, credentials, tenant IDs) come from environment variables or a config file, never from the spec. Fail fast with a clear message if one is missing.
- Prefer a dedicated test tenant/org/workspace so cleanup is safe and cross-team data is never touched.
- Seed through APIs or the project's seed scripts; create data unique per run (`randomUUID()` suffix) and remove it in teardown. For data that cannot be deleted, mark it clearly (`qa-auto-` prefix) and document the retention.
- Test doubles: stub only what you do not own (third-party APIs) or what you are deliberately failing (`page.route()` for error handling). Everything else should be the real component, otherwise the test is no longer an integration test. Record in the spec header what is real and what is stubbed.
- Reuse an authenticated session via Playwright `storageState` rather than logging in per test; refresh it in a global setup when it expires.

## Playwright TypeScript pattern

Structure: `tests/integration/<feature>/<feature>.<boundary>.spec.ts`, with page objects in `src/pages/`, API clients in `src/api/`, and shared fixtures (`api`, `authedPage`, `db` if needed) in `fixtures/`. Tag with `@integration` plus the feature.

```ts
import { test, expect } from '../../fixtures/integration';

// Level: FE↔BE. Real backend. Boundary: profile form → PATCH /users/{id} → GET /users/{id}
test.describe('Profile name update', { tag: ['@integration', '@profile'] }, () => {
  test('name typed in the UI is persisted by the API with correct casing', async ({ authedPage, api, user }) => {
    const profile = new ProfilePage(authedPage);
    const newName = `QA Name ${Date.now()}`;

    await profile.goto();
    await profile.setDisplayName(newName);
    await profile.save();
    await expect(profile.toast).toHaveText(/saved/i);

    // Verify on the other side of the boundary — not just what the UI shows
    await expect.poll(async () => (await (await api.get(`/users/${user.id}`)).json()).displayName)
      .toBe(newName);
  });

  test('UI shows the backend validation error and keeps the form editable', async ({ authedPage }) => {
    await authedPage.route('**/users/*', route =>
      route.fulfill({ status: 400, json: { errors: [{ field: 'displayName', message: 'Too long' }] } }));
    const profile = new ProfilePage(authedPage);
    await profile.goto();
    await profile.setDisplayName('x'.repeat(300));
    await profile.save();
    await expect(profile.fieldError('displayName')).toHaveText('Too long');
    await expect(profile.saveButton).toBeEnabled();
  });
});
```

Notice the two directions: the first test trusts the UI to act and the API to verify; the second injects a backend failure and checks the UI. Both are needed for one boundary.

## Review checklist

1. Spec header states the integration level, the boundaries covered, and what is real vs stubbed.
2. Each boundary has a round-trip test asserting values on both sides.
3. At least one error-propagation test and one unauthorised-actor test per feature.
4. Async steps use `expect.poll`/`toPass` with bounded timeouts — no `waitForTimeout`.
5. No hardcoded URLs, credentials, IDs; data is unique per run and cleaned up.
6. Nothing owned by the team is mocked except deliberate failure injection.
7. One behaviour per test, sentence-style names, tags present, `tsc`/eslint clean, passes twice in a row and under `--workers=4`.

Report **PASS** or **BLOCKED** with severity-ordered findings, file:line, and a concrete fix each.

## Scope and delivery

One feature or one boundary per branch/PR, at most 10–15 tests, following the repo's branch naming convention. Write a detailed PR description: the boundary map, the level, real vs stubbed components, environment variables required, how to run, and any `fixme` items with their open question. Do not add Claude as author, co-author or in any "generated with" line on commits or PRs.

## Plain-language glossary

- **Boundary / seam**: the point where data passes from one component to another.
- **Round trip**: write through one side, read back through the other, compare.
- **Test double / stub**: a fake stand-in for a real component; fine for third parties, wrong for your own code in an integration test.
- **Polling**: checking repeatedly until a condition is true (with a time limit) instead of waiting a fixed number of seconds.
- **Contract drift**: backend response shape changed but the frontend still expects the old one.
- **Storage state**: Playwright's saved login (cookies/local storage) so tests start already signed in.