---
name: test-script-validator
description: >
  Validate and verify Playwright test scripts generated from First Recon AI QA test cases.
  Performs syntax checking, import validation, dry-run execution (--collect-only), and
  optionally runs scripts against the dev environment to confirm they pass.
  Use this skill whenever the user wants to verify a generated test script, check if scripts
  are valid before running them, do a dry run of Playwright tests, debug a failing script,
  or confirm scripts execute smoothly end to end.
  Triggers on: validate test script, verify script, check script, dry run, does this script work,
  run script validation, test the test, check playwright script, debug test script.
---

# Test Script Validator

Validate Playwright test scripts for correctness, syntax, and runability before full execution.

## Validation Levels

Run these checks in order — stop and report at the first blocking failure:

### Level 1: Syntax Check (fast, no browser needed)
```bash
python -m py_compile <script.py> && echo "Syntax OK"
```
Reports: any Python syntax errors with line numbers.

### Level 2: Import Check
```bash
python -c "import pytest; from playwright.sync_api import Page, expect; print('Imports OK')"
```
If imports fail, install missing packages:
```bash
pip install pytest playwright pytest-playwright --break-system-packages
playwright install chromium
```

### Level 3: Collection Dry-Run (no browser, discovers all tests)
```bash
pytest <script.py> --collect-only -q
```
This discovers all test functions without running them. Reports: missing fixtures, naming issues, import errors that only appear at collection time.

Expected output format:
```
<N> tests collected
  test_workspace_chat_sidebar.py::TestChatSidebar::test_tc_wc_chatsidebar_001
  test_workspace_chat_sidebar.py::TestChatSidebar::test_tc_wc_chatsidebar_002
  ...
```

### Level 4: Live Run (optional, requires network + auth)
```bash
pytest <script.py> -v --headed  # with browser visible
pytest <script.py> -v           # headless
```
Run only when the user explicitly asks to execute against the live environment.
Default environment: `https://app.dev.firstrecon.ai`

## Validation Report Format

After running checks, always produce a structured report:

```
=== Script Validation Report ===
File: test_workspace_chat_sidebar.py
Checks run: Syntax | Imports | Collection | Live Run (if applicable)

✅ Syntax check      PASSED
✅ Import check      PASSED
✅ Collection        PASSED — 12 tests discovered
⚠️  Live run         NOT RUN (pass --live to enable)

Issues found: None
TODOs in script (review before production use):
  - Line 24: # TODO: refine selector for "sidebar nav"
  - Line 67: # TODO: add specific assertion for count
```

## Common Issues and Fixes

### Missing `conftest.py` / fixture not found
**Symptom:** `fixture 'page' not found`
**Fix:** Ensure `pytest-playwright` is installed and `conftest.py` is in the same directory.

### Timeout on page.goto()
**Symptom:** `TimeoutError: page.goto: Timeout 30000ms exceeded`
**Fix:** The dev environment may be slow. Increase timeout in conftest:
```python
@pytest.fixture
def page(browser):
    page = browser.new_page()
    page.set_default_timeout(60000)
    yield page
```

### `expect()` locator not found
**Symptom:** `Error: locator.waitFor: Timeout exceeded`
**Fix:** Selector is wrong. Add a screenshot on failure to see state:
```python
page.screenshot(path="debug.png")
```

### Authentication redirect
**Symptom:** Test redirects to login page mid-run
**Fix:** Add login steps to `conftest.py` fixture, or set session storage via `page.context.storage_state()`.

## TODO Comment Analysis

Scan the script for `# TODO` comments and list them — these are spots where the generator
couldn't determine the exact selector and needs human review. Format:

```
TODOs requiring review (3 found):
  Line 24: refine selector for "Chat Actions nav"
  Line 45: add assertion for collapsed state
  Line 88: confirm button text exact match
```

This helps the user prioritize which parts of the generated script need manual tuning.

## Batch Validation

When validating multiple files at once:
```bash
pytest tests/ --collect-only -q
```
Report per-file pass/fail, then a summary:
```
Validation Summary:
  test_workspace_chat_sidebar.py   ✅ 12/12 collected, 0 errors, 2 TODOs
  test_platform_admin_sidebar.py   ✅  8/8 collected, 0 errors, 1 TODO
  test_operations_portal.py        ❌  SYNTAX ERROR at line 34
```

## Handoff

After successful validation:
> "All scripts validated. Use **excel-status-updater** to write results back to the Excel file after running."

After finding issues:
> "Found N issues. Fix the TODO/error items above, then revalidate."
