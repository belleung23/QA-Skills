---
name: "qa-ci-cd"
description: "Project-agnostic CI/CD for QA on GitHub Actions, GitLab CI or Jenkins: detect the platform and how the repo is set up, then create/change pipelines, wire automation tests in, run, schedule (cron) and manage them, with secrets kept out of the pipeline files. Triggers on: CI/CD, pipeline, GitHub Actions, GitLab CI, Jenkinsfile, workflow, cron, schedule tests, add suite to CI, run E2E in CI, secrets in CI."
---

# QA CI/CD (any project; GitHub Actions, GitLab CI, Jenkins)

Scope: creating, changing, running, scheduling and managing CI/CD pipelines that run QA
automation, in whatever repo the user points at. Phase 1 discovers the platform and the
repo's habits; every later step uses those answers. Not in scope: writing specs, triage,
reports — hand off to the matching QA skills.

Patterns were learned from a mature production repo (Persefoni `eng-guardrails-platform`,
GitHub Actions) and generalised. Never assume that repo's names (runner labels, secret names,
scripts, Bun) exist in the target — discover, then adapt. If the target repo has its own CI
standards doc, registry or policy script, those win wherever they differ from this skill.

## Phase 1 — Discover (always, before any YAML/Groovy)

### 1a. Detect the platform

| Repo has | Platform | Definition | Secret store |
|---|---|---|---|
| `.github/workflows/*.yml` | GitHub Actions | one YAML per workflow | Settings → Environments → Secrets (env-scoped) / Actions secrets (repo-wide) |
| `.gitlab-ci.yml` (+ `.gitlab/ci/` via `include:`) | GitLab CI | one root file, jobs in `stages:` | Settings → CI/CD → Variables, Masked + Protected, *Environment scope* |
| `Jenkinsfile*`, `*.groovy`, `jenkins/` | Jenkins | declarative `pipeline {}` per job | Manage Jenkins → Credentials (folder-scoped), `withCredentials` / `credentials('id')` |

Vocabulary map: job/job/stage; `runs-on`/`tags`/`agent{label}`; `workflow_dispatch`+`inputs` / *Run pipeline* `variables:` with `options:` / `parameters{}`; `schedule: cron` (UTC) / *Pipeline schedules* UI + `rules: $CI_PIPELINE_SOURCE == "schedule"` / `triggers{cron('H …')}` (controller TZ); `${{ secrets.X }}` / `$X` / `credentials('id')`; `upload-artifact` / `artifacts: when: on_failure` / `archiveArtifacts`+`junit`; lint with `actionlint` / `glab ci lint` / declarative-linter.

### 1b. Record {answers}

```bash
# any
ls .github/workflows .gitlab-ci.yml Jenkinsfile* 2>/dev/null; cat CODEOWNERS .github/CODEOWNERS 2>/dev/null | grep -iE "workflow|gitlab-ci|jenkins"
ls package-lock.json pnpm-lock.yaml yarn.lock bun.lock .nvmrc .tool-versions 2>/dev/null
grep -nE '"(test|e2e|playwright|cypress)[^"]*":' package.json | head -30; ls playwright.config.* cypress.config.* pytest.ini 2>/dev/null
grep -rhoE "process\.env\.[A-Z_]+" playwright.config.* 2>/dev/null | sort -u     # base-URL/env var names the config reads
ls .env.example .env.*.example 2>/dev/null; ls docs/ci* docs/devops* CONTRIBUTING.md .critical 2>/dev/null
git branch -r --sort=-committerdate | head -15                                      # branch naming convention
# GitHub
grep -h "cron:\|runs-on:" .github/workflows/*.yml | sort | uniq -c; grep -ho "secrets\.[A-Z0-9_]*" .github/workflows/*.yml | sort | uniq -c
ls .github/actions .github/workflows/_*.yml 2>/dev/null
# GitLab
grep -nE "^[a-zA-Z_.-]+:$|^  stage:|^  tags:|include:|extends:|schedule" .gitlab-ci.yml | head -60
grep -rhoE '\$[A-Z][A-Z0-9_]+' .gitlab-ci.yml .gitlab/ci 2>/dev/null | sort | uniq -c
# Jenkins
find . -name "Jenkinsfile*" -o -name "*.groovy" | grep -v node_modules
grep -rhoE "credentials\('[^']+'\)|withCredentials|cron\(|agent" --include=Jenkinsfile* . | sort | uniq -c
```

Record: platform; test runner + exact local command; package manager + runtime; runner/agent label; base-URL env var; auth mechanism (token-minted session / API token / stored password); existing secret names or credential ids; environments that exist; pipeline owner; registry/policy/PR-body requirements; branch convention. GitLab: also read the *Pipeline schedules* page (schedules are not in git). Jenkins: also read the job's folder for credentials and the controller timezone.

## Phase 2 — Decide the smallest change

| Ask | Do |
|---|---|
| Run an existing suite | Run workflow / Run pipeline / Build with Parameters. No code change. |
| Make a spec/tag runnable from CI | One option + one `case` line in the existing manual runner (GitHub inputs; GitLab `variables: options:`; Jenkins `choice`). |
| Run on a schedule | Add the suite key or a cron (GitHub file; GitLab schedules UI + `rules:`; Jenkins `triggers{}`). New file only for a different env/cadence/owner. |
| Nothing fits | New pipeline — Phase 3. |
| Change a merge gate, a reusable (`_*.yml`, `include:` template, shared library) or a required check | High risk: list callers, confirm with the owner first. |

## Phase 3 — Create or change a pipeline

1. Owner prerequisites ({answers}): ticket, `Why:` in PR/MR body, registry entry, policy script.
2. Branch from the default branch in their convention (`test/add-scheduled-qa-regression`, `ci/add-smoke-suite-option`). One pipeline change per PR/MR.
3. Name purpose-first, kebab-case. Reuse the repo's building blocks (composite actions / `extends:` templates / shared library) instead of re-implementing.
4. Build from the platform template (GitHub 3a, GitLab 3b, Jenkins 3c), substituting {answers}.
5. Shell safety: GitHub — every `${{ }}` into step `env:`, use `"$VAR"`; GitLab — quote `"$VAR"`, every QA job has `rules:` (no rules = runs on every push); Jenkins — single-quoted `sh '''…'''` so Groovy never interpolates secrets, `withCredentials` around the step that needs them.
6. Scheduled/post-merge runs are never cancelled by newer runs (`cancel-in-progress: false` / `interruptible: false` / `disableConcurrentBuilds()`); one concurrency group / `resource_group` / job per environment; pair every schedule with a manual trigger; environment chosen at run time, never one file per environment.
7. Artifacts on failure only, ~7-day retention; `fail-fast: false` / `failFast = false` on suite matrices; `--pass-with-no-tests` then check for 0 tests.
8. Lint: `actionlint` / `glab ci lint` / declarative-linter + Replay on a sandbox job; plus the repo's policy script; register the file if a registry exists.
9. PR/MR: detailed description, owner requested, secret-scan checks green, no AI attribution lines.
10. After merge: run once by hand before trusting the schedule (Jenkins registers a new cron only after the first run).

### 3a GitHub Actions template (Playwright; swap install/run lines for the repo's runner)

```yaml
name: Scheduled QA Regression
on:
  schedule: [{ cron: '30 1 * * *' }]              # UTC; avoid :00 and existing crons
  workflow_dispatch:
    inputs:
      environment: { type: choice, default: dev, options: [dev, staging] }
      suites:      { type: string, default: 'smoke,regression' }
      branch:      { type: string, default: develop }
      browser:     { type: choice, default: chromium, options: [chromium, firefox, webkit] }
concurrency: { group: "scheduled-qa-regression-${{ inputs.environment || 'dev' }}", cancel-in-progress: false }
permissions: { contents: read }
env: { DEV_URL: 'https://app.dev.example.com', STAGING_URL: 'https://app.staging.example.com' }
jobs:
  plan:
    runs-on: ubuntu-latest
    outputs: { suites: "${{ steps.plan.outputs.suites }}", environment: "${{ steps.plan.outputs.environment }}" }
    steps:
      - id: plan
        env: { INPUT_SUITES: "${{ inputs.suites || 'smoke,regression' }}", INPUT_ENVIRONMENT: "${{ inputs.environment || 'dev' }}" }
        run: |
          echo "suites=$(printf '%s' "$INPUT_SUITES" | tr -d ' ' | tr ',' '\n' | grep -v '^$' | jq -R . | jq -cs .)" >> "$GITHUB_OUTPUT"
          echo "environment=$INPUT_ENVIRONMENT" >> "$GITHUB_OUTPUT"
  run-suite:
    needs: plan
    runs-on: ubuntu-latest                          # {answers}
    timeout-minutes: 60
    environment: ${{ needs.plan.outputs.environment }}   # selects which secrets apply
    strategy: { fail-fast: false, matrix: { suite: "${{ fromJson(needs.plan.outputs.suites) }}" } }
    steps:
      - uses: actions/checkout@v4
        with: { ref: "${{ inputs.branch || 'develop' }}" }
      - uses: actions/setup-node@v4
        with: { node-version-file: '.nvmrc', cache: 'npm' }
      - run: npm ci                                 # {answers}
      - env: { BROWSER: "${{ inputs.browser || 'chromium' }}" }
        run: npx playwright install --with-deps "$BROWSER"
      - env: { ENVIRONMENT: "${{ needs.plan.outputs.environment }}" }
        run: |
          case "$ENVIRONMENT" in staging) echo "BASE_URL=${STAGING_URL}" >> "$GITHUB_ENV" ;; *) echo "BASE_URL=${DEV_URL}" >> "$GITHUB_ENV" ;; esac
      - id: suite
        env: { SUITE: "${{ matrix.suite }}" }
        run: |
          case "$SUITE" in smoke) ARGS="--grep @smoke" ;; regression) ARGS="--grep @regression" ;; *) echo "Unknown suite: $SUITE" >&2; exit 1 ;; esac
          echo "args=$ARGS" >> "$GITHUB_OUTPUT"
      - env:
          CI: true
          BROWSER: ${{ inputs.browser || 'chromium' }}
          TEST_ARGS: ${{ steps.suite.outputs.args }}
          AUTOMATION_TOKEN: ${{ secrets.AUTOMATION_TOKEN }}   # {answers}: existing secret name
        run: npx playwright test $TEST_ARGS --project="$BROWSER" --reporter=html,json,junit --pass-with-no-tests
      - uses: actions/upload-artifact@v4
        if: failure()
        with: { name: "qa-${{ matrix.suite }}-${{ needs.plan.outputs.environment }}-${{ github.run_id }}", path: test-results/, retention-days: 7 }
      - if: failure() && github.event_name == 'schedule'
        env: { SLACK_WEBHOOK_URL: "${{ secrets.SLACK_WEBHOOK_URL }}", TEXT: ":x: QA regression failed: ${{ matrix.suite }} on ${{ needs.plan.outputs.environment }} ${{ github.server_url }}/${{ github.repository }}/actions/runs/${{ github.run_id }}" }
        run: '[ -z "$SLACK_WEBHOOK_URL" ] || curl -sS -X POST -H "Content-type: application/json" --data "$(jq -n --arg t "$TEXT" "{text:\$t}")" "$SLACK_WEBHOOK_URL"'
```

### 3b GitLab CI template

```yaml
variables:
  ENVIRONMENT: { value: "dev", options: ["dev", "staging"], description: "Target environment" }
  SUITES:      { value: "smoke,regression", description: "Comma-separated suite keys" }
  BROWSER:     { value: "chromium", options: ["chromium", "firefox", "webkit"], description: "Browser" }
  DEV_URL: "https://app.dev.example.com"
  STAGING_URL: "https://app.staging.example.com"
qa-regression:
  stage: test
  image: mcr.microsoft.com/playwright:v1.47.0-jammy   # {answers}: pin to repo's Playwright version
  tags: [docker]                                       # {answers}
  timeout: 60 minutes
  interruptible: false
  resource_group: qa-regression-$ENVIRONMENT
  environment: { name: $ENVIRONMENT, action: verify }  # env-scoped variables (AUTOMATION_TOKEN) apply
  rules:
    - if: $CI_PIPELINE_SOURCE == "schedule"
    - if: $CI_PIPELINE_SOURCE == "web"
    - when: never
  parallel: { matrix: [{ SUITE: [smoke, regression] }] }
  before_script: [npm ci]
  script:
    - |
      case "$ENVIRONMENT" in staging) export BASE_URL="$STAGING_URL" ;; *) export BASE_URL="$DEV_URL" ;; esac
      case "$SUITE" in smoke) ARGS="--grep @smoke" ;; regression) ARGS="--grep @regression" ;; *) echo "Unknown suite: $SUITE" >&2; exit 1 ;; esac
      [ -n "$AUTOMATION_TOKEN" ] || { echo "AUTOMATION_TOKEN missing for $ENVIRONMENT" >&2; exit 1; }
      CI=true npx playwright test $ARGS --project="$BROWSER" --reporter=html,json,junit --pass-with-no-tests
  artifacts:
    when: on_failure
    expire_in: 7 days
    paths: [test-results/, playwright-report/]
    reports: { junit: test-results/junit.xml }
  after_script:
    - '[ "$CI_JOB_STATUS" = failed ] && [ "$CI_PIPELINE_SOURCE" = schedule ] && [ -n "$SLACK_WEBHOOK_URL" ] && curl -sS -X POST -H "Content-type: application/json" --data "$(jq -n --arg t ":x: QA regression failed: $SUITE on $ENVIRONMENT $CI_JOB_URL" "{text:\$t}")" "$SLACK_WEBHOOK_URL" || true'
```

Then create the schedule in *Build → Pipeline schedules* (cron, timezone, branch, variables). Schedules have an owner; note who.

### 3c Jenkins declarative template

```groovy
pipeline {
  agent { label 'linux && docker' }                 // {answers}
  options { timeout(time: 60, unit: 'MINUTES'); disableConcurrentBuilds(); timestamps(); buildDiscarder(logRotator(numToKeepStr: '30')) }
  triggers { cron('TZ=Asia/Ho_Chi_Minh\nH 8 * * *') }   // H spreads load; TZ line overrides controller timezone
  parameters {
    choice(name: 'ENVIRONMENT', choices: ['dev', 'staging'], description: 'Target environment')
    string(name: 'SUITES', defaultValue: 'smoke,regression', description: 'Comma-separated suite keys')
    string(name: 'BRANCH', defaultValue: 'develop', description: 'Branch to test')
    choice(name: 'BROWSER', choices: ['chromium', 'firefox', 'webkit'], description: 'Browser')
  }
  environment { DEV_URL = 'https://app.dev.example.com'; STAGING_URL = 'https://app.staging.example.com'; CI = 'true' }
  stages {
    stage('Checkout') { steps { git branch: params.BRANCH, url: '<repo url>', credentialsId: 'git-readonly' } }   // {answers}
    stage('Install')  { steps { sh 'npm ci && npx playwright install --with-deps "$BROWSER"' } }
    stage('Run suites') {
      steps {
        script {
          def branches = [:]
          params.SUITES.split(',').collect { it.trim() }.findAll { it }.each { suite ->
            branches[suite] = {
              withCredentials([string(credentialsId: "automation-token-${params.ENVIRONMENT}", variable: 'AUTOMATION_TOKEN')]) {   // one credential id per environment
                withEnv(["SUITE=${suite}", "BASE_URL=${params.ENVIRONMENT == 'staging' ? env.STAGING_URL : env.DEV_URL}", "BROWSER=${params.BROWSER}", "PLAYWRIGHT_JUNIT_OUTPUT_NAME=test-results/junit-${suite}.xml"]) {
                  sh '''
                    set -euo pipefail
                    case "$SUITE" in smoke) ARGS="--grep @smoke" ;; regression) ARGS="--grep @regression" ;; *) echo "Unknown suite: $SUITE" >&2; exit 1 ;; esac
                    npx playwright test $ARGS --project="$BROWSER" --reporter=html,json,junit --pass-with-no-tests
                  '''
                }
              }
            }
          }
          branches.failFast = false
          parallel branches
        }
      }
    }
  }
  post {
    always  { junit allowEmptyResults: true, testResults: 'test-results/**/junit*.xml' }
    failure {
      archiveArtifacts artifacts: 'test-results/**', allowEmptyArchive: true
      script {
        if (currentBuild.getBuildCauses('hudson.triggers.TimerTrigger$TimerTriggerCause')) {
          withCredentials([string(credentialsId: 'slack-webhook-qa', variable: 'SLACK_WEBHOOK_URL')]) {
            sh '''curl -sS -X POST -H 'Content-type: application/json' --data "$(jq -n --arg t ":x: QA regression failed: $JOB_NAME #$BUILD_NUMBER $BUILD_URL" '{text:$t}')" "$SLACK_WEBHOOK_URL"'''
          }
        }
      }
    }
  }
}
```

## Secrets — non-negotiable on every platform

- No secret values in pipeline files, specs, fixtures, `.env.example`, comments, PR/MR text, reports, Slack. References only: `${{ secrets.X }}` / masked `$X` / `credentials('id')`.
- Reuse the repo's existing secret names or credential ids ({answers}). A new one needs the owner and an allowlist/manifest entry if the repo keeps one; propose one if not.
- Scope by the platform's mechanism, not by copying: GitHub one name per Environment (never `_DEV/_STAGING/_PROD` suffixes); GitLab one variable with *Environment scope*, Masked + Protected, and verify masking actually applied; Jenkins one credential id per environment in the narrowest folder (the only place a suffix is correct).
- Never let PR/MR builds see real environment secrets (GitHub `environment:` on `pull_request`; GitLab Protected vars on unprotected MR pipelines; Jenkins prod credential ids in multibranch PR jobs).
- Never echo a secret; print presence booleans. Jenkins: never put a secret in a double-quoted Groovy string.
- When the user can choose a branch, read secrets from the pinned pipeline revision first (GitHub `ref: ${{ github.workflow_sha }}`; GitLab/Jenkins keep the definition on a protected branch and check the test branch into a sub-directory).
- `.env*`, `.auth/`, storage-state JSON stay git-ignored. Seeded test users in an isolated tenant only. Prefer a token-gated test-session endpoint (off in production) over stored passwords; if only a password exists, it is one environment-scoped secret used once in global setup.
- Leak: report the *name/id* and *location* to the owner, rotate first, delete second.

## Running, reading, managing

- Manual: Run workflow / Run pipeline / Build with Parameters. Failures attach `test-results/`; `npx playwright show-trace`.
- Classify before acting: product bug / flaky / environment (401, 429, 500 from auth) / bad test. Only the first becomes a ticket.
- Reproduce locally with the exact CI command and `.env.local` values from the password manager.
- Disable with the registry/docs entry: `# DEPRECATED: <reason> | <ticket>` header, remove automatic triggers; GitLab also deactivate the schedule in the UI; Jenkins disable the job and drop `triggers{}`.
- `if: always()` / `after_script` / `post { always }` teardown; a weekly cleanup job for timeout-killed runs; honest timeouts; caching; no schedule more frequent than its signal.
- QA validation of a CI change: run each affected lane, confirm the right scope ran, failures are visible, record a baseline.

## Output of this skill

For a create/change request: Phase-1 answers (short table incl. platform), the pipeline file for that platform, any registry/docs entry, the branch name, the PR/MR title + detailed body (owner's required fields, no AI attribution lines), the lint command, and for GitLab the schedule settings to enter in the UI. For an explain request: plain language, pointing at the matching section of the companion guide `ci-cd-qa-guide.md` when the user has it.