---
name: "playwright-media-capture"
description: "Capture screenshots (snapshots) and GIF recordings for QA test cases. PASS gets a green-badged screenshot, FAIL gets an outlined, labelled screenshot + GIF reproduction. Attach evidence to Linear via the Linear connector (prepare → PUT → finalize). Triggers on: screenshot, snapshot, screen recording, test passed, test failed, ✅ pass, ❌ fail, capture evidence, record bug, save evidence, highlight failing element, bug reproduction, attach to Linear."
---

# Playwright Media Capture

Runs for **every test case** — PASS and FAIL both get screenshots. GIF recordings are for FAIL only.

**Badge placement rule: ALWAYS bottom-right. NEVER top-left.** Top-left overlaps modals, dialogs, and confirmation boxes that appear in the center/top of the viewport. Bottom-right stays clear.

> Files are saved using **absolute paths** in the repo workspace — never relative paths, never a temp folder.
>
> **Workspace (persistent):** `/Users/belleung/Documents/guardrails/eng-guardrails-platform/` — survives sessions. In the Mac sandbox shell it is `$HOME/mnt/eng-guardrails-platform/`; Playwright on the Mac uses the `/Users/belleung/...` path directly.

> **Fixed 2026-10-16 (verified on FRAI-8354 — Part 1 PASS and FAIL, Part 3 upload):**
> - `mcp__playwright__browser_take_screenshot` hangs ("waiting for fonts"). Screenshot with `browser_run_code_unsafe` on a **fresh page** instead (Part 1).
> - `upload_linear_file.py` is not in the repo, needs an API key that is not configured, and the cloud sandbox cannot reach Linear's storage host. Upload through the **Linear connector** + a PUT from the Mac's Playwright process instead (Part 3).
> - The release state is named **`Ready for Release`** (not "Ready To Release").
> - A sibling skill, `qa-evidence-capture`, does the same chain with Jira support too; both now use the same capture code.
> - **2026-10-17:** Part 1 capture code replaced and re-tested (see the end of Part 1). The old in-page badge script saved login pages as PASS, shot loading placeholders, could not replay clicks, outlined one element only, and its badge blurred inside real modals.

---

## When to Capture

| Situation | Snapshot | Recording |
|-----------|----------|-----------|
| ✅ Pass (UI) | ✅ Green badge bottom-right | Never |
| 🔍 BE-only | ✅ Green badge if UI visible | Never |
| ❌ Fail (UI) | ✅ Numbered red/purple outlines + full-sentence labels + red badge bottom-right | ✅ GIF repro steps |

---

## Part 0 — Paths (once per ticket)

```bash
REPO_ROOT="$HOME/mnt/eng-guardrails-platform"      # device_bash on the Mac
mkdir -p "$REPO_ROOT/manual-testing/evidences/$TICKET_KEY"
mkdir -p "$REPO_ROOT/manual-testing/test-results/done"
```

Create the evidence folder **before** the first screenshot — `page.screenshot` hangs on a missing folder.

Naming: `{TICKET_KEY}-TC{n}-PASS-{description}.png`, `{TICKET_KEY}-TC{n}-FAIL-{description}.png`, `{TICKET_KEY}-TC{n}-FAIL-{description}.gif`.

---

## Part 1 — Screenshot (PASS and FAIL)

Claude in Chrome drives the testing; Playwright MCP captures evidence.

**Step 1.** Open the page under test in the Playwright browser (`browser_navigate`) and leave `URL` blank in the CFG block, or paste its full URL into `URL`. The code reloads it in a fresh tab, so put any clicks that make the bug visible in `STEPS`.

**Step 2.** If a modal is open that is NOT the evidence, close it first (Escape, or its close button). If the modal IS the evidence, keep it.

**Step 3.** One `browser_run_code_unsafe` call on a **fresh page** (the code opens its own; never the shared `page`). Fill in **only the CFG block** at the top. `MARKS` selectors must be plain CSS (prefer `[data-testid="…"]`; no `text=`, `:has-text`, `>>`); `STEPS` may use Playwright syntax.

What it does: refuses a login/SSO page, waits for the landmark, loaders, dialog animations and the marked elements, replays `STEPS`, takes a clean screenshot (viewport for a FAIL or open dialog, full page otherwise), then draws outlines, labels, badge and a footer strip **on a copy of the image** — never into the app, so nothing is blurred by a modal backdrop. Labels are placed together so none covers another label or outlined element.

```javascript
async (page) => {
  const CFG = /*CFG*/{
    URL: '',                         // leave blank = the page already open in the Playwright browser (browser_navigate first);
                                     //   or paste the full URL of the page under test
    OUT: '/Users/belleung/Documents/guardrails/eng-guardrails-platform/manual-testing/evidences/{TICKET_KEY}/{TICKET_KEY}-TC{n}-{PASS|FAIL}-{desc}.png',
    RESULT: 'PASS',                  // or 'FAIL'
    READY: '{landmark selector}',    // REQUIRED, e.g. 'main h1', '[data-testid="table"]', 'dialog[open]'
    STEPS: [],                       // FAIL only: [{click:'text=Settings'}, {fill:'#name', value:'x'}, {press:'Enter'}] (Playwright syntax OK)
    MARKS: [],                       // [{n:1, selector:'{plain CSS}', label:'{one full sentence}', color:'red'}]
                                     //   FAIL: #1 red = the wrong thing; #2+ color:'purple' = the element that proves it.
                                     //   PASS (optional): marks default to green = what was verified. Optional place:'below' etc.
    FOOTER: '{env} · {role}',        // host+path, window size and date are added automatically
    VP: { width: 1440, height: 900 },
    FULL_PAGE: 'auto',               // auto: viewport for a FAIL with marks or an open dialog, otherwise full page
                                     //   (and full page when the marks are too far apart for one window)
    ZOOM: false,                     // true: also write <OUT>-zoom.png (close-up of mark #1 + its label)
    SIGNIN: /login|signin|sign-in|authorize|oauth|\/realms\/|okta\.com|auth0\.com|accounts\.google\.com/i,
  }/*END*/;

  const problems = [];
  const PW_ONLY = /:has-text\(|:text(-is|-matches)?\(|:visible|:nth-match\(|>>|^\s*(text|xpath|css|id|internal:[\w-]+)=|^\s*\/\//;
  for (const m of CFG.MARKS) if (PW_ONLY.test(m.selector || '')) problems.push(`mark #${m.n}: "${m.selector}" is Playwright-only syntax — use plain CSS`);

  // Blank URL: capture the page that is already open in the Playwright browser, so the skill works on any project.
  if (!CFG.URL) { // let a page that is still loading or redirecting (e.g. to a login page) finish first
    await page.waitForLoadState('load', { timeout: 15000 }).catch(() => {});
    await page.waitForLoadState('networkidle', { timeout: 5000 }).catch(() => {});
  }
  const target = CFG.URL || page.url();
  if (!/^https?:/i.test(target || '')) return { ok: false, problem: `no page to capture (got "${target || ''}") — open the page first with browser_navigate, or put its URL in CFG.URL` };

  const p = await page.context().newPage();
  try {
    await p.setViewportSize(CFG.VP);
    await p.emulateMedia({ reducedMotion: 'reduce' }).catch(() => {});
    await p.goto(target, { waitUntil: 'domcontentloaded', timeout: 45000 });

    // 1. Signed out? A shot of the login page is not evidence.
    await p.waitForLoadState('networkidle', { timeout: 8000 }).catch(() => {}); // apps that poll never go idle
    const want = new URL(target), at = new URL(p.url());
    if ((at.host !== want.host || CFG.SIGNIN.test(at.pathname + at.search)) && !CFG.SIGNIN.test(want.pathname)) {
      return { ok: false, problem: `signed out — the app sent the browser to ${at.host}${at.pathname}. Sign in again, then retake.` };
    }

    // 2. Settle: positive landmark first (fails loudly), then loaders gone, dialog animations done, fonts.
    try { await p.waitForSelector(CFG.READY, { state: 'visible', timeout: 20000 }); }
    catch { return { ok: false, problem: `landmark "${CFG.READY}" never appeared at ${p.url()} — wrong READY selector or the page did not render` }; }
    const settle = async () => {
      await p.waitForFunction(() => !document.querySelector('[aria-busy="true"], [data-loading="true"], [data-testid*="loader" i], [data-testid*="skeleton" i], [class*="skeleton" i], .animate-spin'), null, { timeout: 15000 }).catch(() => problems.push('a loader/skeleton was still showing after 15s'));
      await p.evaluate(async () => {
        const open = [...document.querySelectorAll('dialog[open], [role="dialog"], [role="alertdialog"]')];
        await Promise.all(open.flatMap((d) => d.getAnimations({ subtree: true }).map((a) => a.finished.catch(() => {}))));
        await document.fonts.ready;
      }).catch(() => {});
      await p.waitForTimeout(400);
    };
    await settle();

    // 3. Replay the steps that make the bug visible (opening the URL alone often shows a bare screen).
    for (const st of CFG.STEPS) {
      try {
        if (st.click) await p.locator(st.click).first().click({ timeout: 8000 });
        else if (st.fill) await p.locator(st.fill).first().fill(String(st.value ?? ''), { timeout: 8000 });
        else if (st.press) await p.keyboard.press(st.press);
        await p.waitForTimeout(Math.min(15000, Number(st.wait) || 900));
      } catch (e) { problems.push(`step ${JSON.stringify(st)} failed: ${String(e).split('\n')[0]}`); }
    }
    if (CFG.STEPS.length) await settle();

    // 3b. The things to outline must be on screen. Data that arrives late (no skeleton marker) is waited
    //     for here, up to 10 s; a mark still missing after that is reported below, never drawn as bare.
    const deadline = Date.now() + 10000;
    for (const m of CFG.MARKS) {
      if (PW_ONLY.test(m.selector || '')) continue;
      await p.waitForFunction((sel) => { let f = []; try { f = [...document.querySelectorAll(sel)]; } catch { return true; }
        return f.some((e) => { const r = e.getBoundingClientRect(); return r.width >= 2 && r.height >= 2; }); }, m.selector, { timeout: Math.max(500, deadline - Date.now()) }).catch(() => {});
    }

    // 4. Viewport or full page? Full page drags fixed elements (modals, sticky bars) into odd places.
    const dialogOpen = await p.evaluate(() => [...document.querySelectorAll('dialog[open], [role="dialog"], [role="alertdialog"]')]
      .some((d) => { const r = d.getBoundingClientRect(); return r.width > 2 && r.height > 2; }));
    // auto also switches to full page when the marks are too far apart to fit in one window.
    const span = await p.evaluate((sels) => { const ys = [];
      for (const sel of sels) { let f = []; try { f = [...document.querySelectorAll(sel)]; } catch { continue; }
        const el = f.find((e) => { const r = e.getBoundingClientRect(); return r.width >= 2 && r.height >= 2; });
        if (el) { const r = el.getBoundingClientRect(); ys.push(r.top + scrollY, r.bottom + scrollY); } }
      return ys.length ? Math.max(...ys) - Math.min(...ys) : 0; }, CFG.MARKS.map((m) => m.selector));
    const tooFarApart = span > CFG.VP.height - 220;
    const full = CFG.FULL_PAGE === 'auto' ? (tooFarApart || !(dialogOpen || (CFG.RESULT === 'FAIL' && CFG.MARKS.length))) : !!CFG.FULL_PAGE;

    // 5. Scroll the first mark into view, then measure every mark in capture coordinates.
    //    No string-to-code tricks in page code: an app with a strict CSP would block them. First VISIBLE
    //    match only — a hidden element measures 0x0 at the top-left and would put a label in the corner.
    if (CFG.MARKS[0] && !full) {
      const y = await p.evaluate((sel) => { let f = []; try { f = [...document.querySelectorAll(sel)]; } catch { return null; }
        const el = f.find((e) => { const r = e.getBoundingClientRect(); return r.width >= 2 && r.height >= 2 && getComputedStyle(e).visibility !== 'hidden'; });
        return el ? el.getBoundingClientRect().top + scrollY : null; }, CFG.MARKS[0].selector);
      if (y !== null) { await p.evaluate((y) => scrollTo(0, Math.max(0, y - 180)), y); await p.waitForTimeout(350); }
    }
    const defColor = CFG.RESULT === 'PASS' ? 'green' : 'red';
    const measured = await p.evaluate(({ marks, full, defColor }) => {
      return marks.map((m) => {
        let f = []; try { f = [...document.querySelectorAll(m.selector)]; } catch { return { n: m.n, missing: true }; }
        const el = f.find((e) => { const r = e.getBoundingClientRect(); return r.width >= 2 && r.height >= 2 && getComputedStyle(e).visibility !== 'hidden'; });
        if (!el) return { n: m.n, missing: true };
        const r = el.getBoundingClientRect();
        return { ...m, color: m.color || defColor, box: { x: r.x + (full ? scrollX : 0), y: r.y + (full ? scrollY : 0), w: r.width, h: r.height } };
      });
    }, { marks: CFG.MARKS, full, defColor });
    // Controls and headings a label should not hide if it can help it (tried first, dropped if no clean spot).
    const soft = await p.evaluate(({ full }) => [...document.querySelectorAll('button, a[href], input, select, textarea, [role="tab"], [role="button"], h1, h2, h3, th, label')]
      .map((e) => e.getBoundingClientRect()).filter((r) => r.width >= 2 && r.height >= 2 && (full || (r.bottom > 0 && r.top < innerHeight)))
      .slice(0, 400).map((r) => ({ x: r.x + (full ? scrollX : 0) - 2, y: r.y + (full ? scrollY : 0) - 2, w: r.width + 4, h: r.height + 4 })), { full });
    const missing = measured.filter((m) => m.missing).map((m) => m.n);
    if (missing.length) problems.push(`mark(s) #${missing.join(', #')} not found on the page — fix the selector or the STEPS, then retake`);
    // A viewport shot only holds what is on screen: a mark mostly outside it would be drawn off the image.
    if (!full) for (const m of measured) {
      if (m.missing) continue;
      const vis = Math.max(0, Math.min(m.box.y + m.box.h, CFG.VP.height) - Math.max(m.box.y, 0)) * Math.max(0, Math.min(m.box.x + m.box.w, CFG.VP.width) - Math.max(m.box.x, 0));
      if (vis < 0.5 * m.box.w * m.box.h) problems.push(`mark #${m.n} is mostly outside the screenshot — set FULL_PAGE: 'auto' or true, or a taller VP, then retake`);
    }

    const raw = await p.screenshot({ fullPage: full, timeout: 20000 });

    // 6. Draw on a BLANK page over the image — never into the app (a blurred modal backdrop blurs anything injected).
    // Footer address: host + path + short query params only. Long values (login state, tokens) are left out —
    // they overflow the strip and should not end up in a ticket image.
    const cur = new URL(p.url());
    const q = [...cur.searchParams].filter(([, v]) => v.length <= 40).map(([k, v]) => `${k}=${v}`).join('&');
    let path = cur.pathname + (q ? '?' + q : '');
    if (path.length > 90) path = path.slice(0, 89) + '…';
    const host = at.host;
    const footer = [host + path, CFG.FOOTER, `${CFG.VP.width}x${CFG.VP.height}`, new Date().toISOString().slice(0, 16).replace('T', ' ') + 'Z'].filter(Boolean).join(' · ');
    const canvas = await p.context().newPage();
    let report, annotated;
    try {
      await canvas.setViewportSize(CFG.VP);
      await canvas.setContent(`<!doctype html><html><body style="margin:0;background:#fff"><img id="shot" style="display:block" src="data:image/png;base64,${raw.toString('base64')}"></body></html>`);
      await canvas.waitForFunction(() => { const i = document.getElementById('shot'); return i && i.complete && i.naturalWidth > 0; });
      report = await canvas.evaluate(({ marks, result, footer, soft }) => {
        // placeLabels — copied from spydysense-ux hunt/scripts/lib/labelPlace.mjs.
        function placeLabels(labels, obstacles, bounds, gap = 10) {
          const area = (a, b) => { const w = Math.min(a.x + a.w, b.x + b.w) - Math.max(a.x, b.x); const h = Math.min(a.y + a.h, b.y + b.h) - Math.max(a.y, b.y); return w > 0 && h > 0 ? w * h : 0; };
          const clamp = (v, lo, hi) => Math.max(lo, Math.min(v, Math.max(lo, hi)));
          const placed = [], out = [], SIDES = ['right', 'left', 'below', 'above'];
          for (const l of labels) {
            const { box, bw, bh } = l;
            const sides = l.place ? [l.place, ...SIDES.filter((s) => s !== l.place)] : SIDES;
            const cands = [];
            for (const side of sides) {
              for (let k = 0; k <= 12; k += 1) {
                const step = Math.ceil(k / 2) * (k % 2 ? 1 : -1) * (bh / 2 + gap);
                let x, y;
                if (side === 'right') { x = box.x + box.w + gap + 4; y = box.y + box.h / 2 - bh / 2 + step; }
                else if (side === 'left') { x = box.x - bw - gap - 4; y = box.y + box.h / 2 - bh / 2 + step; }
                else if (side === 'below') { x = box.x + step * 2; y = box.y + box.h + gap + Math.abs(step); }
                else { x = box.x + step * 2; y = box.y - bh - gap - Math.abs(step); }
                x = clamp(x, bounds.minX, bounds.maxX - bw); y = clamp(y, bounds.minY, bounds.maxY - bh);
                const r = { x, y, w: bw, h: bh };
                let overlap = 0; for (const o of obstacles) overlap += area(r, o); for (const q of placed) overlap += area(r, q);
                const dist = Math.hypot(x + bw / 2 - (box.x + box.w / 2), y + bh / 2 - (box.y + box.h / 2));
                cands.push({ r, overlap, dist, order: cands.length });
                if (overlap === 0 && k === 0) break;
              }
              if (cands.some((c) => c.overlap === 0)) break;
            }
            cands.sort((a, b) => (a.overlap === 0) !== (b.overlap === 0) ? (a.overlap === 0 ? -1 : 1) : a.overlap === 0 ? a.order - b.order : a.overlap - b.overlap || a.dist - b.dist);
            placed.push(cands[0].r); out.push({ x: cands[0].r.x, y: cands[0].r.y, overlap: cands[0].overlap });
          }
          return out;
        }
        const COLOR = { red: '#C0392B', purple: '#6D3FA5', green: '#15803D' }, GREEN = '#16a34a', FOOT = 42;
        // Retina-safe: the PNG has devicePixelRatio x the CSS pixels the boxes were measured in. Show it at
        // CSS size (same DPR here), draw in CSS pixels, and the saved image keeps full resolution.
        const img = document.getElementById('shot'); const dpr = window.devicePixelRatio || 1;
        const W = Math.round(img.naturalWidth / dpr), H = Math.round(img.naturalHeight / dpr);
        img.style.width = W + 'px'; img.style.height = H + 'px';
        const layer = document.createElement('div');
        Object.assign(layer.style, { position: 'absolute', left: 0, top: 0, width: W + 'px', height: (H + FOOT) + 'px', pointerEvents: 'none' });
        document.body.style.paddingBottom = FOOT + 'px'; // footer goes BELOW the screenshot, never over page content
        document.body.appendChild(layer);
        const add = (styles, text) => { const d = document.createElement('div'); if (text != null) d.textContent = text; Object.assign(d.style, { position: 'absolute', boxSizing: 'border-box' }, styles); layer.appendChild(d); return d; };
        // Pass 1: every outline first, so label placement knows about all of them.
        const outlines = [], pending = [];
        for (const m of marks) {
          if (!m.box) continue; const c = COLOR[m.color || 'red'] || COLOR.red, b = m.box, pad = 3;
          add({ left: (b.x - pad) + 'px', top: (b.y - pad) + 'px', width: (b.w + pad * 2) + 'px', height: (b.h + pad * 2) + 'px', border: '3px solid ' + c, borderRadius: '6px' });
          outlines.push({ x: b.x - pad - 2, y: b.y - pad - 2, w: b.w + pad * 2 + 4, h: b.h + pad * 2 + 4 });
          if (!m.label) continue;
          // Full sentence, never cut with "…" — the cut part is usually what the reader needs.
          const l = add({ background: c, color: '#fff', borderRadius: '7px', font: '600 15px/1.3 -apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif', padding: '7px 13px', whiteSpace: 'normal', overflowWrap: 'anywhere', maxWidth: Math.min(520, W - 32) + 'px', boxShadow: '0 2px 8px rgba(0,0,0,.25)' });
          l.innerHTML = '<span style="opacity:.82">#' + m.n + ':</span> <span style="opacity:.45">│</span> ';
          l.appendChild(document.createTextNode(m.label));
          const r = l.getBoundingClientRect();
          pending.push({ el: l, box: b, bw: r.width, bh: r.height, place: m.place, n: m.n, color: m.color || 'red' });
        }
        // Badge sits bottom-right above the footer; it is an obstacle too.
        const badge = add({ background: result === 'PASS' ? GREEN : COLOR.red, color: '#fff', font: '700 13px -apple-system,Segoe UI,sans-serif', padding: '6px 12px', borderRadius: '6px', whiteSpace: 'nowrap', boxShadow: '0 2px 8px rgba(0,0,0,.4)' }, result === 'PASS' ? '✅ PASSED' : '❌ FAILED');
        const br = badge.getBoundingClientRect();
        const bx = W - 12 - br.width, by = H - 12 - br.height;
        badge.style.left = bx + 'px'; badge.style.top = by + 'px';
        // Pass 2: place all labels together.
        const footTop = H;
        const hard = [...outlines, { x: bx - 4, y: by - 4, w: br.width + 8, h: br.height + 8 }];
        const bounds = { minX: 8, maxX: W - 8, minY: 8, maxY: H - 8 };
        // Try to keep the app's own controls readable too; if that leaves no clean spot, ignore them.
        let spots = placeLabels(pending, [...hard, ...soft], bounds);
        if (spots.some((s) => s.overlap > 0)) spots = placeLabels(pending, hard, bounds);
        let overlaps = 0;
        spots.forEach((s, i) => {
          const q = pending[i]; q.el.style.left = s.x + 'px'; q.el.style.top = s.y + 'px'; if (s.overlap > 0) overlaps++;
          // A label pushed away from its element gets a thin leader line back to it.
          const cx = s.x + q.bw / 2, cy = s.y + q.bh / 2;
          const tx = Math.max(q.box.x - 3, Math.min(cx, q.box.x + q.box.w + 3)), ty = Math.max(q.box.y - 3, Math.min(cy, q.box.y + q.box.h + 3));
          const sx = Math.max(s.x, Math.min(tx, s.x + q.bw)), sy = Math.max(s.y, Math.min(ty, s.y + q.bh));
          const len = Math.hypot(tx - sx, ty - sy);
          if (len > 24) {
            const line = add({ left: sx + 'px', top: sy + 'px', width: len + 'px', height: '0', borderTop: '2px dashed ' + (COLOR[q.color] || COLOR.red), transformOrigin: '0 0', transform: `rotate(${Math.atan2(ty - sy, tx - sx)}rad)`, opacity: '.85' });
            layer.insertBefore(line, layer.firstChild);
          }
        });
        const placed = marks.filter((m) => m.box).map((m) => { const i = pending.findIndex((q) => q.n === m.n);
          return { n: m.n, color: m.color || 'red', box: m.box, label: i < 0 ? null : { x: spots[i].x, y: spots[i].y, w: pending[i].bw, h: pending[i].bh } }; });
        add({ left: 0, top: footTop + 'px', width: W + 'px', height: FOOT + 'px', background: '#111418', color: '#e9edf3', font: '400 15px/42px -apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif', paddingLeft: '22px', whiteSpace: 'nowrap', overflow: 'hidden' }, footer);
        return { drawn: outlines.length, labels: pending.length, overlaps, w: W, h: H, placed };
      }, { marks: measured.filter((m) => !m.missing), result: CFG.RESULT, footer, soft });
      await canvas.waitForTimeout(150);
      annotated = await canvas.screenshot({ path: CFG.OUT, fullPage: true, timeout: 20000 });
    } finally { await canvas.close().catch(() => {}); }

    // 7. Readability check (shotProblem): too narrow, or the wrong shape for the window.
    if (report.w < 1000) problems.push(`screenshot is ${report.w}px wide — too small to read; use a window at least 1000px wide`);
    if (!full && Math.abs(report.w / report.h - CFG.VP.width / CFG.VP.height) / (CFG.VP.width / CFG.VP.height) > 0.12) problems.push(`screenshot is ${report.w}x${report.h} but the window is ${CFG.VP.width}x${CFG.VP.height} — shape does not match, retake`);
    if (report.overlaps) problems.push(`${report.overlaps} label(s) found no free space and still cover something — shorten the label or set "place"`);
    if (CFG.RESULT === 'FAIL' && CFG.MARKS.length && report.drawn === 0) problems.push('FAIL shot has NO outlined element — it is a bare screen, not evidence');

    // 8. Zoom crop of the annotated image around the first red mark (any mark when ZOOM: true) AND its label, 120px margin —
    //    the small image a reader looks at first (idea from composeAttachment in spydysense-ux).
    let zoom = null;
    const red = report.placed.find((q) => q.color === 'red') ?? (CFG.ZOOM === true ? report.placed[0] : undefined);
    if ((CFG.ZOOM === true || (CFG.ZOOM === 'auto' && CFG.RESULT === 'FAIL')) && red) {
      zoom = CFG.OUT.replace(/\.png$/i, '') + '-zoom.png';
      const u = [red.box, red.label].filter(Boolean);
      const M = 120;
      const x0 = Math.max(0, Math.min(...u.map((r) => r.x)) - M), y0 = Math.max(0, Math.min(...u.map((r) => r.y)) - M);
      const x1 = Math.min(report.w, Math.max(...u.map((r) => r.x + r.w)) + M), y1 = Math.min(report.h, Math.max(...u.map((r) => r.y + r.h)) + M);
      const z = await p.context().newPage();
      try {
        await z.setViewportSize({ width: Math.max(200, Math.round(x1 - x0)), height: Math.max(200, Math.round(y1 - y0)) });
        await z.setContent(`<!doctype html><html><body style="margin:0;overflow:hidden"><img id="i" style="display:block;width:${report.w}px;margin-left:${-Math.round(x0)}px;margin-top:${-Math.round(y0)}px" src="data:image/png;base64,${annotated.toString('base64')}"></body></html>`);
        await z.waitForFunction(() => { const i = document.getElementById('i'); return i && i.complete && i.naturalWidth > 0; });
        await z.screenshot({ path: zoom, timeout: 20000 });
      } finally { await z.close().catch(() => {}); }
    }

    const { placed: _placed, ...rest } = report;
    return { ok: problems.length === 0, path: CFG.OUT, zoom, mode: full ? 'fullPage' : 'viewport', ...rest, expectedMarks: CFG.MARKS.length, missing, problems };
  } finally { await p.close().catch(() => {}); }
}
```

**Read the return value — every time.**

- `ok: true` and `problems: []` → good evidence. Note `path` (and `zoom` if you asked for it).
- `problem: "signed out …"` → the session expired; sign in again (the project's login step, e.g. `authenticator-authorizer`),
  then retake. Nothing was written.
- `problem: "landmark … never appeared"` → wrong `READY`, or the page really did not render (that may
  itself be the bug — retake with `READY: 'body'` and say so). Nothing was written.
- Anything in `problems` → fix and retake: a mark not found (`missing` lists its number — fix the
  selector or add `STEPS`), a Playwright-only selector, a mark outside the screenshot (only when you forced `FULL_PAGE: false` — use `'auto'`),
  labels still overlapping (shorten the sentence or set `place`), a FAIL with nothing outlined (a bare
  screen is not evidence), a capture too narrow or the wrong shape.

**Why this code (re-tested 2026-10-17).** The earlier capture code was run unchanged against 13
local pages, at normal and Retina (2x) pixel density. It saved the login page with a ✅ PASSED badge
when the session had expired, photographed loading placeholders instead of late data while reporting
no problem, let labels cover other marked elements, drew the badge blurred inside a real modal (the
in-page versions), and could not replay a click before the shot. The code above passes all 15 cases (incl. blank URL)
at both densities.

Verify on disk: `ls -l "$REPO_ROOT/manual-testing/evidences/$TICKET_KEY/"` — note the exact byte size, Part 3 needs it.

---

## Part 2 — GIF Recording (FAIL only)

One GIF per failed TC. `gif_creator` only adds a frame when you call `computer screenshot`; actions alone add nothing, and identical consecutive frames are collapsed. Run **strictly in order, one call at a time** — never batch start/stop with the screenshots.

1. `gif_creator(action="start_recording", tabId)`
2. `computer(action="screenshot", tabId)` — initial state
3. For each repro step: do the action (`left_click`, `navigate`, `type`…), then `computer(action="screenshot", tabId)`
4. `computer(action="screenshot", tabId)` — final failure state
5. `gif_creator(action="stop_recording", tabId)`
6. `gif_creator(action="export", tabId, filename="{TICKET_KEY}-TC{n}-FAIL-{description}.gif", download=true, options={"showClickIndicators": true, "showActionLabels": true, "showProgressBar": true, "showWatermark": false, "quality": 10})`
7. The GIF lands in `~/Downloads` on the Mac. **Copy** it (the sandbox cannot delete, so `mv` fails):

```bash
cp "$HOME/mnt/Downloads/{TICKET_KEY}-TC{n}-FAIL-{description}.gif" "$REPO_ROOT/manual-testing/evidences/$TICKET_KEY/"
```

(Needs `~/Downloads` connected as a folder; ask for it with `device_request_folder_access` if it is not.)

---

## Part 3 — Upload to Linear (one file at a time)

The signed upload URL expires in **60 seconds**: do prepare → PUT → finalize for one file before preparing the next. Never batch the prepare calls.

**3a. Prepare** (Linear connector):
`prepare_attachment_upload(issue="{TICKET_KEY}", filename, contentType, size)` — `size` is the exact byte count from `ls -l`; `contentType` is `image/png` or `image/gif`. Note `assetUrl`, `uploadRequest.url` and `uploadRequest.headers`.

**3b. PUT the bytes** from the Mac's Playwright process (it has normal network; the sandbox shells do not):

```javascript
async (page) => {
  const FILE = '/Users/belleung/Documents/guardrails/eng-guardrails-platform/manual-testing/evidences/{TICKET_KEY}/{file}';
  const URL = '{uploadRequest.url}';
  const HEADERS = { /* uploadRequest.headers verbatim, same key casing */ };
  const p = await page.context().newPage();
  await p.setContent('<input type="file" id="f">');
  await p.setInputFiles('#f', FILE);
  const b64 = await p.evaluate(() => new Promise((res) => { const f = document.getElementById('f').files[0]; const r = new FileReader(); r.onload = () => res(r.result.split(',')[1]); r.readAsDataURL(f); }));
  await p.close();
  const data = Buffer.from(b64, 'base64');
  const r = await page.request.put(URL, { data, headers: HEADERS, timeout: 30000 });
  return { status: r.status(), bytes: data.length };
}
```

Expect `status: 200` and `bytes` equal to the prepared `size`. Anything else → prepare again and retry.

**3c. Finalize**: `create_attachment_from_upload(issue="{TICKET_KEY}", assetUrl, title=filename)`.

Record `filename → assetUrl` for every file — Part 4/5 embed them with `![name](assetUrl)`.

> If a `.dev.vars` with `TESTING_LINEAR_API_KEY` exists in the repo, `linear-comment-writer/scripts/upload_linear_file.py` is an alternative — but only from a shell that can reach `storage.googleapis.com`, which neither sandbox can today.

---

## Part 4 — Result File

Save to: `$REPO_ROOT/manual-testing/test-results/{TICKET_KEY}_result_{passed|failed}.md`

| Outcome | Filename |
|---------|---------|
| All passed | `_result_passed.md` |
| > 50% failed | `_result_failed.md` |
| ≤ 50% failed | `_result_passed.md` |

```markdown
# Test Result: {TICKET_KEY}

**Date**: {YYYY-MM-DD}
**Tested by**: belle.ung@persefoni.com
**Environment**: {environment name} ({app URL})
**Overall**: PASSED | FAILED | PARTIAL

## Summary
[What was tested, what passed, what failed.]

## Test Cases

| # | Type | Description | Status | Screenshot | Recording |
|---|------|-------------|--------|------------|-----------|
| 1 | Happy Path | [desc] | ✅ Pass | ![{TICKET_KEY}-TC1-PASS-desc.png](ASSET_URL) | — |
| 2 | Negative | [desc] | ❌ Fail | ![{TICKET_KEY}-TC2-FAIL-desc.png](ASSET_URL) | ![{TICKET_KEY}-TC2-FAIL-desc.gif](ASSET_URL) |

## Failed Test Cases — Detail

### TC-{n}: [title]
**AC**: AC#{n} — [verbatim text]
**Steps to Reproduce**:
1. Navigate to [URL]
2. [action]
3. Observe: [what happened]
**Expected**: [per AC]
**Actual**: [exactly what appeared]
**Screenshot**: ![...](ASSET_URL)
**Recording**: ![...](ASSET_URL)

## Evidence Files
- Location: /Users/belleung/Documents/guardrails/eng-guardrails-platform/manual-testing/evidences/{TICKET_KEY}/
```

`ASSET_URL` is the real `assetUrl` recorded in Part 3.

---

## Part 5 — Post Linear Comment

Hand off to `linear-comment-writer`: it posts the result-file content with the Linear connector's `save_comment(issueId, body)` as plain Markdown. Then open the issue in Chrome and confirm the images render (reload once if the newest comment is not shown).

If all passed, hand off to `linear-ticket-transition` (connector `save_issue(id, state="Ready for Release")` — one call, no intermediate states).

Move the result file to done:
```bash
mv "$REPO_ROOT/manual-testing/test-results/${TICKET_KEY}_result_"*.md "$REPO_ROOT/manual-testing/test-results/done/"
```

---

## File Flow

```
Claude in Chrome → drives all UI testing
  ↓ each test case result
capture code via run_code (fresh page) → sign-in check → settle → replay steps → clean shot → outlines/labels/badge/footer drawn on a copy → PNG in evidences/

  ↓ FAIL only
gif_creator start → screenshot → [action + screenshot] × N → stop → export(download) → cp ~/Downloads → evidences/

  ↓ upload, one file at a time
prepare_attachment_upload → PUT (Playwright on the Mac) → create_attachment_from_upload → assetUrl

  ↓ comment
save_comment with ![name](assetUrl) inline → verify in Chrome
```

---

## Badge Placement — Why Bottom-Right

Modals and overlays appear center/top of viewport. Bottom-right stays clear. The badge is drawn on a copy of the screenshot, just above the footer strip, so nothing in the app (not even a modal's blurred backdrop) can cover or blur it, and labels are placed to avoid it.