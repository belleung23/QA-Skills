---
name: "database-testing"
description: "Test the database layer behind any API or feature in any project: verify what each request actually wrote (rows, defaults, bookkeeping, soft/hard delete, rollback, tenant isolation, DB-enforced rules), prepare test data, investigate bad data with a SQL playbook and write the report. Manual SQL checklist plus a tested Playwright TypeScript kit (PostgreSQL and SQLite; driver, CLI or admin-API access; bearer, cookie or API-key login) where only feature.config.ts changes per project."
---

# Database Testing

Use this skill whenever a ticket, feature, bug or migration needs proof that the **data** is right — not only that the API answered 200 — and whenever data looks wrong and you need to find out what happened, since when, and how many rows are affected. It is project-agnostic: it works for any relational database (PostgreSQL, MySQL, SQL Server, SQLite and serverless SQLite-compatible databases) and gives notes for document/KV stores. Every connection detail, URL, account, table name and environment comes from config or environment variables — **nothing in this skill is hardcoded, and nothing project-specific may be added to it**. Project facts (table names, which service owns a table, how to reach the DB) are discovered per project in Step 1 and recorded in the test plan and the per-feature config file, not in this skill.

Plain-language rule of thumb: **the API is the door, the database is the room.** Every test opens the door (sends a request or runs a job), walks into the room (queries the tables) and checks exactly what changed — and that nothing else did.

---

## 0. Safety rules (read first, never skip)

1. **Never touch production.** Only connect to local / dev / test databases. If the connection target looks like production (contains `prod`, `production`, `live`, or the production hostname from the project config), stop and ask.
2. **Prefer SELECT.** Manual UPDATE / DELETE is only for test setup or cleanup, and always:
   - inside a transaction (`BEGIN; ... ROLLBACK;` first to preview, `COMMIT` only when the affected row count is exactly what you expect),
   - with a `WHERE` clause that targets only rows this test created (by a unique run marker such as `qa_<runId>` in a name/email/code field),
   - never `DELETE FROM table;` or `TRUNCATE` on a shared database.
3. **Credentials** live in `.env` / CI secrets / a secrets manager. Never paste a connection string, password or token into a ticket, PR, comment, screenshot or chat.
4. **Use a read-only DB user** for verification queries when one exists; a separate writable user only for seed/teardown.
5. **Tests create their own data and clean it up.** Never rely on "user id 42" or a row somebody else made.
6. Sensitive columns (passwords, tokens, PII) are checked for *shape* (hashed, encrypted, masked, null) — never copied into reports.
7. **Never run a migration, purge or retention job yourself on a shared environment.** A migration file existing in the repo is not evidence it was applied — verify through the migration ledger (section 3.4). Ask the owner to run it, or run it only on a local/throwaway database.

---

## 1. Workflow: ticket → DB test plan → execution → report

### Step 1 — Discover the data model behind the feature (per project)

From the ticket, API docs, ORM models, migration files or code (`grep` for the endpoint handler → repository/model → table name), write down:

- **Which store(s)** hold the data. Many projects use more than one: a relational DB plus a document DB, a KV cache, an object store, a search index, a queue/outbox table. Each store the feature writes to needs its own check.
- **Primary table(s)** written or read by the endpoint, and **related tables** (foreign keys, join tables, audit/history tables, outbox/event tables, search/FTS shadow tables, counters).
- **Which service/component is the write owner** of each table (some projects keep a DB-ownership file; otherwise ask). This tells you where the business rule lives — in code or in the database.
- Columns that must change (`status`, `updated_at`), columns that must NOT change (`id`, `created_at`, `tenant_id`, `created_by`, identity/digest columns).
- Whether delete is **hard** (row removed) or **soft** (`deleted_at` / `is_deleted` / status set).
- **Database-enforced rules**: NOT NULL, UNIQUE, FOREIGN KEY, CHECK, defaults, enums, length limits, **triggers / fences** (rules that reject or stamp writes), **row-level security (RLS) policies**, and generated/computed columns. Query them (section 4) — do not trust the ticket alone.
- **How to reach the database** in each environment (section 8.1): direct driver, a CLI, or only through an admin/operations API.
- The **API body field names** for the same things (they often differ from the column names).

Everything found here goes into `tests/config/feature.config.ts` (section 8.3). If you cannot find it, ask the developer one precise question: "Which tables does `<endpoint>` write to, which service owns them, and is delete hard or soft?"

### Step 2 — Write the plan as before/after statements

Every DB test case follows one shape:

```
Given   <state in the DB before — seeded by the test>
When    <request, job or migration>
Then    <exact rows/columns after>  AND  <what must be unchanged>
```

Always include the **unchanged** part. Most real bugs are side effects: deleted too much, updated the wrong tenant, overwrote a column you did not send, a bookkeeping table that did not follow the main write.

### Step 3 — Execute (manual or automated)

Prepare data first (section 5), then:

1. Seed data with a unique run marker, e.g. `qa_${runId}` inside a name/email/code field.
2. Snapshot the rows you care about (`SELECT ... WHERE marker = ...`) → **before**.
3. Send the request / run the job.
4. Query again → **after** (in every store the feature touches).
5. Assert the diff is exactly what you expected (section 2 has the assertions per request type).
6. Teardown everything with the marker.

### Step 4 — Investigate anything that failed

Use the SQL playbook (section 6): scope (how many rows, which tenants, since when), first bad row, which writer, cause in the deployed code, smallest repro. Turn a recurring investigation query into an integrity check.

### Step 5 — Report

For each test case record: store and table(s) queried, the SELECT used (with the marker value), before row(s), after row(s), expected vs actual, pass/fail. Use the report template in section 7 (the kit's `tools/qa-report.mjs` writes the first draft). Failures go through the project's root-cause flow before a ticket is written; the ticket includes the exact query and the row evidence (sensitive columns masked).

---

## 2. Manual checklist by request type

Tick every line that applies. "Row" means the row(s) your test created.

### GET (read)

- [ ] Returned fields match the DB row value-for-value (ids, names, numbers, booleans, dates in the right timezone/format).
- [ ] Computed/derived fields (totals, counts, statuses) match a SQL aggregate you ran yourself.
- [ ] Soft-deleted rows are NOT returned (unless the endpoint is explicitly "include deleted").
- [ ] Rows from another tenant / organization / user are NOT returned.
- [ ] Filters, sorting and pagination match an equivalent `WHERE` / `ORDER BY` / `LIMIT OFFSET` query (check total count too).
- [ ] A GET does not write anything (no `updated_at` change, no new audit row unless "viewed" auditing is a feature).
- [ ] Sensitive columns never appear in the response.

### POST (create)

- [ ] Exactly **one** new row in the primary table (not 0, not 2 — check with `COUNT(*)` on the marker).
- [ ] Every sent field is stored correctly (exact string, trimmed?, case preserved?, numbers not rounded, decimals precise, unicode intact).
- [ ] Fields you did not send get the right **default** (`status`, `is_active`, `currency`, etc.).
- [ ] System columns are filled: `id` generated, `created_at` ≈ now, `updated_at` ≈ `created_at`, `created_by` / `tenant_id` set from the auth context — not from the request body (send a fake `tenant_id` in the body and confirm it is ignored).
- [ ] **Bookkeeping rows** are written in the same transaction/batch: child rows, audit/history row, outbox/event row, search-index entry, counters/aggregates. If the main write succeeds and the bookkeeping is missing, that is a failure.
- [ ] Response id matches the DB id.
- [ ] Duplicate request (same unique field) → rejected with 4xx and **no** new row.
- [ ] Invalid body (missing required, wrong type, too long, bad enum, negative where not allowed) → 4xx and **no** new row, no partial related rows.
- [ ] Double submit / retry → still one row (idempotency), when the feature promises it.

### PUT / PATCH (update)

- [ ] Only the sent fields changed; every other column equals the **before** snapshot.
- [ ] `updated_at` moved forward; `created_at`, `id`, `tenant_id`, `created_by` unchanged.
- [ ] Setting a field to `null` / empty behaves as specified (cleared vs ignored).
- [ ] Updating a row that belongs to another tenant/user → 403/404 and the row is unchanged.
- [ ] Updating a non-existent or soft-deleted row → 404, nothing created.
- [ ] Unique constraint on update (change email to one already used) → 4xx, unchanged.
- [ ] **State transitions** follow the allowed graph (e.g. `draft → submitted → approved`; `approved → draft` rejected) and the DB status matches. Where the code uses a guarded update (`UPDATE ... WHERE id = ? AND status = ?`), a stale transition must affect 0 rows and the API must report it, not silently succeed.
- [ ] Immutable columns (identity, generation, digest, write-once fields) cannot be changed through any endpoint — attempt it and confirm the DB value is untouched.
- [ ] Concurrent updates (two PATCHes at once, or a stale version) behave as designed (last-write-wins, optimistic-lock error, etc.).

### DELETE

- [ ] **Hard delete:** row gone (`COUNT = 0`). **Soft delete:** row still exists with `deleted_at` / `is_deleted` set, and a subsequent GET no longer returns it.
- [ ] Child rows behave as designed: cascade-deleted, blocked (409/400 with parent unchanged), or detached (FK set null). Check each child table.
- [ ] Bookkeeping follows: search-index entry removed, counters decremented, audit row written, outbox event emitted — whichever the design says.
- [ ] Only the targeted row is affected — count other rows with the same marker before and after.
- [ ] Deleting another tenant's row → 403/404, row untouched.
- [ ] Deleting twice → second call 404 (or idempotent 204 per spec), no error row.
- [ ] Unique fields of a soft-deleted row: can a new row reuse the same email/code? Verify against the spec.

### Bulk / import / background jobs

- [ ] Row counts before/after equal input count (minus rejected rows, which are reported).
- [ ] One bad row does not corrupt the batch: either all-or-nothing (transaction) or per-row error reporting — whichever the spec says.
- [ ] Jobs are idempotent: running twice does not duplicate data.
- [ ] Progress/status table (if any) reaches a terminal state; failed jobs leave a readable error, not a half-written row.

---

## 3. Deeper test areas

### 3.1 Constraints and data integrity

For every constraint found in Step 1, write one negative test:

- NOT NULL → omit the field → 4xx, no row.
- UNIQUE → send duplicate → 4xx, no row (and check case-sensitivity: `Belle@x.com` vs `belle@x.com`).
- FOREIGN KEY → point to a non-existent parent → 4xx, no row.
- CHECK / enum / range → out-of-range value → 4xx.
- Length → max length passes, max+1 fails; emoji / multibyte characters count correctly.
- Precision → `19.999` into a 2-decimal money column: rounded, truncated, or rejected? Must match spec.
- Dates → timezone handling (stored as UTC?), leap day, far past/future.

The API must return a clean 4xx (never a 500 with a raw SQL error), and the DB must be unchanged.

### 3.2 Database-enforced rules: triggers, fences, RLS

Some rules live *inside* the database rather than in code, so they apply to every writer. Test them directly, not only through one endpoint:

- **Blocking trigger / fence** (e.g. "no writes to a record whose parent is being deleted", "this column can never change"): attempt the forbidden write → it is rejected with the documented error, and the row is unchanged. Then attempt the **allowed** write on the same table → it succeeds. A fence that is too wide and blocks legitimate writes is a critical bug (it surfaces as generic 5xx errors on unrelated features), so always test the allow path too.
- **Stamping trigger / bookkeeping** (`updated_at`, history row, counter, search index): after the write, the stamped value exists and is correct; after a failed write, nothing was stamped.
- **Row-level security (RLS)**: with the tenant/user context set, reads and writes see only that tenant's rows; with the context **missing**, the policy fails closed (no rows, or write rejected) — never "all rows". Test both.
- **Hot tables** (high write volume: messages, events, receipts, ledgers): any new trigger or constraint there needs a timing check (section 3.6) because every writer pays its cost.

### 3.3 Transactions and rollback

A transaction means "all steps succeed or none do". Force a failure in the middle of a multi-table write (invalid child item, unique violation on the second insert, simulated downstream error) and assert that **no** rows from the first step remain — including bookkeeping rows. Also check nothing is left locked (follow-up requests still work).

### 3.4 Migrations, rollbacks and schema changes

When a ticket changes the schema (run these on a **local or throwaway** database, never a shared one):

- **Fresh vs existing**: apply the migration to (a) an empty database built from scratch and (b) a database that already has the old shape *and data*. Both must succeed. Some engines (SQLite-based ones in particular) have no `ADD COLUMN IF NOT EXISTS`, so a migration that passes on one and fails on the other is a real bug.
- **Idempotent / re-runnable**: applying the same migration twice must not fail or duplicate anything, when the project's migration tool expects that.
- **Data preservation**: `COUNT(*)` and a checksum/sample of key columns before = after; backfilled values for new columns are correct; renamed/moved data is intact.
- **Structure**: new columns, indexes, constraints, triggers and policies actually exist afterwards (query `information_schema` / catalog tables; do not trust the file).
- **Ledger**: the migration tracking table records the migration as applied in the target environment. A file in the repo is not proof.
- **Rollback**: the down/rollback script exists, its stated preconditions are checked (e.g. "fails if any NULLs — backfill first"), it restores the previous shape, and data survives it.
- **Expand–contract (phased) changes**: when a change ships in two steps (add the new column/path first, remove the old one later), verify each phase separately: after phase 1 old and new code both work; after phase 2 the old path is gone and nothing still depends on it.
- **Rolling deploys**: if the database migrates before the application, old application code must still work against the new schema during the gap.

### 3.5 Tenant / user isolation (multi-tenant systems)

Seed data for tenant A and tenant B. With A's credentials run every GET/PUT/PATCH/DELETE against B's ids. Expect 403/404 and B's rows byte-for-byte unchanged. Also check list endpoints never leak B's rows via filters, search, sorting or pagination tricks (`?tenantId=B`, large page sizes, id guessing). Where RLS exists, repeat with the DB context missing (section 3.2).

### 3.6 Performance basics

- List endpoints paginate and never return the whole table.
- With realistic volume (seed thousands to hundreds of thousands of rows in a perf environment) key queries stay within the project's budget; run `EXPLAIN` / `EXPLAIN ANALYZE` on the slow query and confirm an index is used (no full table scan for filtered lookups).
- No N+1: one list request should not fire one query per row (check query logs or ORM debug output).
- New triggers, constraints or indexes on hot tables: measure write latency before vs after.

### 3.7 Security

- SQL injection strings in every text input (`' OR 1=1 --`, `"; DROP TABLE users; --`, `1; SELECT pg_sleep(5)`) are stored as plain text and never change other rows or delay the response.
- Passwords are hashed (prefix like `$2b$` / `$argon2`), tokens/secrets encrypted or hashed, PII masked where the spec says.
- Audit tables record who/when for sensitive actions and cannot be edited through the API.
- The DB user used by the application has only the permissions it needs (no superuser; writer roles limited to their tables) — ask if unsure.

### 3.8 Concurrency and race conditions

- Two parallel POSTs with the same unique value → exactly one row.
- Parallel increments/decrements (stock, balance, counters) → final value equals the arithmetic result (no lost updates).
- Parallel delete + update on the same row → consistent end state, no 500.

### 3.9 Data-lifecycle jobs: purge, retention, erasure, archiving

Jobs that delete or move data in bulk (account deletion, GDPR erasure, retention windows, archiving) deserve their own pass:

- **Dry run / plan first**: the job (or script) can produce a plan listing what it will delete, per store and table, with **before counts**, without deleting anything. Verify the plan against your own `COUNT` queries.
- **Classification**: tables marked "purge" lose only the target's rows; tables marked "retain" (audit, billing, legal) keep theirs; anything ambiguous is a blocker to raise, not to guess.
- **Execute** only on a test/demo target, after the confirmation step the job requires. Then **after counts**: target rows are 0 in purge tables, unchanged in retain tables, and **other tenants'/users' counts are identical** to before.
- Every store is covered (relational rows, document records, KV keys, object-storage files, search-index entries) — a job that cleans the main DB but leaves files behind has failed.
- Running the job twice is safe (second run finds nothing).

---

## 4. SQL query templates

Replace `<...>`. PostgreSQL syntax; dialect notes below.

```sql
-- Snapshot rows created by this test run
SELECT * FROM <table> WHERE <marker_column> LIKE 'qa_<runId>%' ORDER BY id;

-- Count (expect exact number)
SELECT COUNT(*) FROM <table> WHERE <marker_column> LIKE 'qa_<runId>%';

-- Verify one row and its system columns
SELECT id, <fields>, created_at, updated_at, created_by, tenant_id, deleted_at
FROM <table> WHERE id = <id>;

-- Children / bookkeeping of a parent (cascade, block, detach, outbox, history)
SELECT COUNT(*) FROM <child_table> WHERE <parent_fk> = <parent_id>;

-- Soft-delete check
SELECT id, deleted_at, is_deleted FROM <table> WHERE id = <id>;

-- Cross-tenant leak check (should be 0 for ids the API returned to tenant A)
SELECT COUNT(*) FROM <table> WHERE tenant_id <> '<tenantA>' AND id IN (<ids returned by API>);

-- Discover constraints, indexes, triggers and RLS policies (PostgreSQL)
SELECT conname, contype, pg_get_constraintdef(oid) FROM pg_constraint WHERE conrelid = '<table>'::regclass;
SELECT indexname, indexdef FROM pg_indexes WHERE tablename = '<table>';
SELECT tgname, pg_get_triggerdef(oid) FROM pg_trigger WHERE tgrelid = '<table>'::regclass AND NOT tgisinternal;
SELECT polname, polcmd, pg_get_expr(polqual, polrelid) FROM pg_policy WHERE polrelid = '<table>'::regclass;
SELECT relrowsecurity, relforcerowsecurity FROM pg_class WHERE oid = '<table>'::regclass;

-- Column definitions (any SQL DB with information_schema)
SELECT column_name, data_type, is_nullable, column_default, character_maximum_length
FROM information_schema.columns WHERE table_name = '<table>' ORDER BY ordinal_position;

-- Migration ledger (name varies by tool: schema_migrations, flyway_schema_history, _migrations, d1_migrations ...)
SELECT * FROM <migration_table> ORDER BY 1 DESC LIMIT 10;

-- RLS fail-closed check (PostgreSQL): with no tenant context, expect 0 rows / rejected write
RESET app.tenant_id;  SELECT COUNT(*) FROM <table>;
SET app.tenant_id = '<tenantA>';  SELECT COUNT(*) FROM <table>;

-- Query plan for a slow endpoint query
EXPLAIN ANALYZE <the query the endpoint runs>;

-- Safe cleanup (preview, then commit)
BEGIN;
DELETE FROM <child_table> WHERE <marker_column> LIKE 'qa_<runId>%';
DELETE FROM <table>       WHERE <marker_column> LIKE 'qa_<runId>%';
-- check the row counts printed above; then:
COMMIT;   -- or ROLLBACK;
```

Dialect notes:

- **MySQL**: backticks; `SHOW CREATE TABLE <table>;`, `SHOW INDEX FROM <table>;`, `SHOW TRIGGERS LIKE '<table>';`.
- **SQL Server**: `TOP n` instead of `LIMIT`, `GETDATE()`, `sp_help '<table>'`, `sys.triggers`.
- **SQLite and serverless SQLite-compatible DBs**: `PRAGMA table_info(<table>)`, `PRAGMA foreign_key_list(<table>)`, `SELECT name, sql FROM sqlite_master WHERE tbl_name = '<table>'` (shows indexes and triggers), `datetime('now')`; no `ADD COLUMN IF NOT EXISTS`; migrations often recreate the table — verify data copied across. Often reachable only through the vendor CLI (`--local` vs remote flags) rather than a driver.
- **Document / KV / object stores**: same ideas — `countDocuments`, `findOne`, `getIndexes()`, list keys by prefix, list objects by prefix; verify each store the feature writes to.

---

## 5. Test data preparation

Good data makes a test readable and repeatable. Bad data (shared rows, "user 42", leftovers from yesterday) is the main cause of flaky DB tests.

1. **Prefer the API for seeding.** Data created through the real endpoint passes the same validation and bookkeeping a user's data does. Use direct SQL only when the API cannot produce the state, for example a DB-rule test, a legacy shape before a migration, or volume for performance.
2. **Mark everything you create** with this test's run marker (`qa_<timestamp>_<random>`) in a unique text column (name, email, reference, code). Cleanup and assertions then target only your rows: `WHERE marker LIKE 'qa_…%'`.
3. **Fill every optional column** when seeding a row you will update. A bug that overwrites a column you did not send is invisible if that column was already `NULL`.
4. **Satisfy the real constraints** when inserting directly: NOT NULL, foreign keys, CHECKs, unique keys. Read them first (section 4: discovery queries). In the kit, `dbRule.seed(runId)` returns the **full** column set.
5. **Bulk / volume data**, on local or throwaway databases only:

```sql
-- PostgreSQL: 1,000 rows in one statement
INSERT INTO <table> (<marker_col>, <col2>, created_at)
SELECT format('qa_<runId>_%s', g), <expression>, now() FROM generate_series(1, 1000) AS g;

-- SQLite: recursive CTE instead of generate_series
WITH RECURSIVE n(i) AS (SELECT 1 UNION ALL SELECT i + 1 FROM n WHERE i < 1000)
INSERT INTO <table> (<marker_col>, <col2>, created_at)
SELECT 'qa_<runId>_' || i, <expression>, datetime('now') FROM n;

-- MySQL 8: recursive CTE (raise cte_max_recursion_depth for > 1000)
INSERT INTO <table> (<marker_col>, <col2>, created_at)
WITH RECURSIVE n(i) AS (SELECT 1 UNION ALL SELECT i + 1 FROM n WHERE i < 1000)
SELECT CONCAT('qa_<runId>_', i), <expression>, NOW() FROM n;
```

6. **Two tenants, always.** Isolation tests need a real second tenant with its own login, not just a different id in a query string.
7. **Clean up in the right order.** Delete children before parents (unless FKs cascade). Remember that **data-health checks may be running at the same moment**: never leave a parent in a "broken" state between two cleanup statements.
   - PostgreSQL: delete the parent and its bookkeeping in one statement: `WITH gone AS (DELETE … RETURNING id) DELETE FROM audit … WHERE entity_id IN (SELECT id FROM gone)`.
   - SQLite has no data-modifying CTE. Either order the steps so every invariant holds after each one (e.g. delete the parent first when the audit check only looks at existing parents), or run data-health checks in a separate step after the functional tests (`--grep-invert @data-health`, then `--grep @data-health`).
   - Some rows can't carry your marker: audit/event rows written by an API delete, and the sessions/tokens your logins create. Clean them by the ids you collected, set `logout` in the config so actors log out after each test, and include those tables in your "no leftovers" check.
8. **Columns that can't hold the marker** (e.g. "2–10 uppercase letters"): derive the value from the marker with `markerToCode(marker, length, alphabet)` (deterministic, so the duplicate test still collides on purpose), and keep the full marker in another text column, or in a child row, for cleanup.
9. Never `TRUNCATE` or delete without the marker on a shared database.

## 6. Investigating results (SQL playbook)

When a test fails, or a bug report says "the data looks wrong", the database tells you **what** happened, **since when** and **how many** rows are affected. Each query below answers one investigation question. Replace `<...>` and keep the marker filter when you only want your own test's rows.

```sql
-- 1. Orphans: children whose parent is gone (FK missing or a delete skipped the cascade)
SELECT c.* FROM <child> c LEFT JOIN <parent> p ON p.id = c.<parent_fk> WHERE p.id IS NULL;

-- 2. Duplicates the business forbids (case-insensitive, live rows only)
SELECT <tenant_col>, lower(<col>) AS value, COUNT(*) FROM <table>
WHERE <deleted_col> IS NULL GROUP BY <tenant_col>, lower(<col>) HAVING COUNT(*) > 1;

-- 3. Missing bookkeeping: rows without their audit/history/outbox row
SELECT t.id FROM <table> t
WHERE NOT EXISTS (SELECT 1 FROM <audit> a WHERE a.entity_id = t.id AND a.action = 'create');

-- 4. Totals that don't add up (header vs lines, invoice vs payments)
SELECT h.id, h.total, SUM(l.amount) AS lines_total FROM <header> h JOIN <lines> l ON l.<fk> = h.id
GROUP BY h.id, h.total HAVING h.total <> SUM(l.amount);

-- 5. Money taken twice (one business action → more than one effect)
SELECT <ref_col>, COUNT(*) FROM <payments> GROUP BY <ref_col> HAVING COUNT(*) > 1;

-- 6. Impossible states (state machine broken)
SELECT id, status FROM <table> WHERE status = 'paid' AND paid_at IS NULL;

-- 7. Cross-tenant leak: rows linked to a parent of ANOTHER tenant
SELECT c.id FROM <child> c JOIN <parent> p ON p.id = c.<parent_fk> WHERE c.<tenant_col> <> p.<tenant_col>;

-- 8. When did it start? First and last bad row, and how many per day
SELECT MIN(created_at) AS first_bad, MAX(created_at) AS last_bad, COUNT(*) FROM <table> WHERE <bad condition>;
SELECT date_trunc('day', created_at) AS day, COUNT(*) FROM <table> WHERE <bad condition> GROUP BY 1 ORDER BY 1;  -- PostgreSQL
SELECT date(created_at) AS day, COUNT(*) FROM <table> WHERE <bad condition> GROUP BY 1 ORDER BY 1;                -- SQLite

-- 9. Who/what wrote it? Join to the audit trail around the first bad row
SELECT * FROM <audit> WHERE entity_id = '<id>' ORDER BY created_at;

-- 10. Latest version per entity (window function) — compare with the "current" table
SELECT * FROM (SELECT a.*, ROW_NUMBER() OVER (PARTITION BY entity_id ORDER BY created_at DESC) AS rn FROM <audit> a) x WHERE rn = 1;

-- 11. Stuck work: jobs/outbox rows that never finished
SELECT id, status, created_at FROM <jobs> WHERE status IN ('pending','processing') AND created_at < now() - interval '15 minutes';                         -- PostgreSQL
SELECT id, status, created_at FROM <jobs> WHERE status IN ('pending','processing') AND created_at < strftime('%Y-%m-%dT%H:%M:%fZ', 'now', '-15 minutes'); -- SQLite (ISO text timestamps)
```

How to read the result, in this order:

1. **Scope.** How many rows, which tenants, which time window? One row from your test is a bug. Ten thousand rows since Tuesday is an incident.
2. **First bad row.** Match its timestamp to a deploy, a migration or a job run.
3. **Writer.** Which endpoint/service/job wrote it? Use the audit trail, correlation ids and the write-owner of the table (Step 1).
4. **Cause in code.** Find the handler or SQL that produces this shape. Read it at the commit that is **deployed** in that environment, not your local branch.
5. **Repro.** Write the smallest API call that produces one new bad row, then turn it into a test (the kit's spec, or a new `integrity` check).

Turn every recurring investigation query into an **integrity check** (section 8, `integrity: [...]`). The next time the same corruption appears, a test goes red instead of a customer noticing.

## 7. Reporting

One report per test pass. If the kit ran, start from `node tools/qa-report.mjs test-results/results.json --name "<feature>" --kind DB`, then add the evidence below. Name the file `<feature or ticket>_<PASSED|FAILED>_DB-Test-Report_<date>.md`.

```markdown
# <Feature> — DB test report
**Verdict:** PASSED | FAILED · <date> · env: <dev/test> · DB: <engine> (<driver|cli|api>)

## Scope
Stores and tables: <table (owner service)>, <child>, <audit>. Delete mode: soft (<column>) / hard.

## Results
| TC | What was checked | Result |
|---|---|---|
| TC-DB-001 | create writes one row, defaults, tenant from auth, audit row | ✅ |
| TC-DB-004 | update changes only sent columns | ❌ notes NULL after PATCH {total} |

## Failure evidence (one block per failure)
- Request: `PATCH /orgs/<A>/invoices/<id> {"total":20}` → 200
- Query: `SELECT id, total, notes FROM invoices WHERE reference = 'qa_…_update'`
- Before: `{ total: 1234.56, notes: "keep-me" }` · After: `{ total: 20, notes: null }`
- Expected: notes unchanged · Root cause: <file:line @ deployed commit> (or "RCA pending")

## Data health
<integrity check> — 0 rows ✅ / N rows ❌ (first bad row <timestamp>, sample ids …, sensitive columns masked)

## Not covered
<skipped checks and why>
```

Rules: mask sensitive columns (`mask()` in the kit does this). Never paste credentials or connection strings. Every ❌ gets a root-cause verdict before a ticket is written.

---

## 8. Automation kit (Playwright TypeScript)

The kit turns sections 2–3 into tests that run in any project. You copy the files **unchanged**, and only `tests/config/feature.config.ts` is written per feature (from Step 1). The API is called as a **real logged-in user** (bearer token, cookie session or API key), because almost every real API requires authentication.

### 8.1 Environment

```bash
DB_ACCESS_MODE=driver        # driver | cli | api
DB_ENGINE=postgres           # postgres | sqlite
DB_URL=postgres://user:pass@host:5432/db           # driver/cli on PostgreSQL (dev/test only)
DB_FILE=./data/app.db                              # driver on SQLite
DB_CLI_COMMAND="tools/psql-json.sh"                # cli: or "node --no-warnings tools/sqlite-json.mjs ./data/app.db"
DB_ADMIN_API_URL=https://<dev-api>/admin/query     # api: an ops/test endpoint that runs SQL and returns { rows }
DB_ADMIN_API_TOKEN=…                               # from secrets
DB_ADMIN_API_AUTH_HEADER=Authorization             # or the header your endpoint expects, e.g. X-Admin-Token
API_BASE_URL=https://<dev-api>
QA_TENANT_A_ID=…  QA_TENANT_B_ID=…                 # plus the logins your feature.config.ts reads
QA_MARKER_PREFIX=qa_
```

Why three modes: locally the database is reachable with a driver or a CLI. In shared dev/staging it often sits behind a private network and only an admin/ops API can run queries. The tests don't care which mode is used, because they call the adapter.

- `driver`: `pg` for PostgreSQL (`npm i -D pg @types/pg`). For SQLite, Node's built-in `node:sqlite` (Node ≥ 22.5, zero install), falling back to `better-sqlite3`.
- `cli`: the two wrappers in `tools/` print JSON and exit non-zero on SQL errors. The PostgreSQL wrapper needs only `psql`; the SQLite wrapper needs only Node. A vendor CLI that prints JSON works too. CLI mode cannot bind parameters, so the adapter inlines **only values the test generated**.
- `api`: posts `{ sql, params }`. For SQLite endpoints the adapter converts `$n` to `?` with the parameters in order of appearance.
- Tests always write PostgreSQL-style `$1, $2`. The adapter converts them: SQLite binds a positional array to `?NNN` but **not** to `$1` (that fails with "column index out of range").

### 8.2 Files

```
playwright.config.ts
tools/
  qa-report.mjs           # results → Markdown report (shared with the API testing skill)
  psql-json.sh            # cli wrapper, PostgreSQL
  sqlite-json.mjs         # cli wrapper, SQLite
tests/
  db/
    db.adapter.ts  db.helpers.ts  api-actors.ts  types.ts  db.fixture.ts
  config/
    feature.config.ts     # ← the ONLY per-feature file
  api/
    feature.db.spec.ts    # generic, identical in every project
```

#### `playwright.config.ts`

````ts
// playwright.config.ts — API / DB test runner settings. No browser is needed for these specs.
import { defineConfig } from '@playwright/test';

// Load .env without any dependency (Node >= 21.7). Real CI secrets always win over the file.
try { process.loadEnvFile(process.env.QA_ENV_FILE ?? '.env'); } catch { /* no .env file: rely on the environment */ }

export default defineConfig({
  testDir: './tests',
  testMatch: /.*\.spec\.ts$/,
  fullyParallel: true,
  workers: process.env.QA_WORKERS ? Number(process.env.QA_WORKERS) : 4,
  retries: 0, // a retry hides flakiness; fix the cause instead
  timeout: 60_000,
  // test-results/ is wiped at the start of every run: set QA_RESULTS_FILE to keep results of several runs.
  reporter: [['list'], ['json', { outputFile: process.env.QA_RESULTS_FILE ?? 'test-results/results.json' }]],
});
````

#### `tools/qa-report.mjs` — same file as in the API testing skill

````js
#!/usr/bin/env node
// qa-report.mjs — turn Playwright's JSON results into a plain-language Markdown test report. No dependencies.
// Usage: node tools/qa-report.mjs [results.json] [--name "Orders API"] [--kind API|DB] [--out reports/]
import { mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';

const args = process.argv.slice(2);
const opt = (k, d) => { const i = args.indexOf(`--${k}`); return i >= 0 ? args[i + 1] : d; };
const file = args.find((a) => a.endsWith('.json')) ?? 'test-results/results.json';
const name = opt('name', 'API');
const kind = opt('kind', 'API');
const outDir = opt('out', 'reports');

const PILLARS = {
  '@authn': ['Authentication', 'The API accepted a missing, broken, expired or revoked credential — anyone could get in.'],
  '@authz': ['Authorization', 'A role or another tenant could do something the contract forbids — an access-control defect.'],
  '@payload': ['Payload & schema', 'Bad input was accepted, good input was rejected, or the response shape/values are wrong or leak data.'],
  '@idempotency': ['Idempotency', 'A retry created a second effect (duplicate row, second charge) or did not replay the first result.'],
  '@status': ['Status codes & errors', 'Wrong status code or an error outside the agreed error envelope.'],
  '@lists': ['Lists & pagination', 'Paging limits are not enforced, or another tenant\'s items appear in a list.'],
  '@transitions': ['State transitions', 'A forbidden state change was allowed (or an allowed one refused).'],
  '@data-health': ['Data health', 'Rows in the database break a rule that must always hold.'],
  '@db': ['Database effects', 'The request did not write exactly what it should (extra/missing rows, wrong columns, no rollback, wrong tenant).'],
};

const json = JSON.parse(readFileSync(file, 'utf8'));
const tests = [];
(function walk(suite, titles, fileName) {
  for (const s of suite.suites ?? []) walk(s, [...titles, s.title], s.file ?? fileName);
  for (const spec of suite.specs ?? []) for (const t of spec.tests) {
    const r = t.results.at(-1) ?? {};
    const tags = [...new Set([...(spec.tags ?? []).map((x) => (x.startsWith('@') ? x : `@${x}`)), ...((spec.title.match(/@[\w-]+/g)) ?? [])])];
    tests.push({
      title: [...titles.slice(1), spec.title].filter(Boolean).join(' › '),
      file: spec.file ?? fileName, line: spec.line, tags,
      status: t.status === 'skipped' ? 'skipped' : r.status === 'passed' ? 'passed' : 'failed',
      error: (r.error?.message ?? '').replace(/\u001b\[[0-9;]*m/g, '').split('\n').filter(Boolean).slice(0, 4).join(' ').slice(0, 500),
      skip: (t.annotations ?? []).find((a) => a.type === 'skip')?.description ?? '',
      ms: r.duration ?? 0,
    });
  }
})(json, [], '');

const pillarOf = (t) => Object.keys(PILLARS).find((p) => t.tags.includes(p) && p !== '@db') ?? (t.tags.includes('@db') ? '@db' : 'other');
const failed = tests.filter((t) => t.status === 'failed');
const skipped = tests.filter((t) => t.status === 'skipped');
const verdict = failed.length ? 'FAILED' : 'PASSED';
const date = new Date().toISOString().slice(0, 10);
const host = (() => { try { return new URL(process.env.API_BASE_URL ?? '').host || 'n/a'; } catch { return 'n/a'; } })();
const esc = (s) => String(s).replace(/\|/g, '\\|');

const rows = Object.entries(PILLARS).map(([p, [label]]) => {
  const g = tests.filter((t) => pillarOf(t) === p);
  return g.length ? `| ${label} | ${g.length} | ${g.filter((t) => t.status === 'passed').length} | ${g.filter((t) => t.status === 'failed').length} | ${g.filter((t) => t.status === 'skipped').length} |` : null;
}).filter(Boolean);

const md = [
  `# ${name} — ${kind} test report`,
  '',
  `**Verdict: ${verdict}** · ${date} · target host: \`${host}\`${process.env.DB_ENGINE ? ` · DB: ${process.env.DB_ENGINE} (${process.env.DB_ACCESS_MODE ?? 'driver'})` : ''}`,
  '',
  `${tests.length} tests: ${tests.length - failed.length - skipped.length} passed, ${failed.length} failed, ${skipped.length} not run (see "Not covered").`,
  '',
  '## Summary by area',
  '',
  '| Area | Tests | Passed | Failed | Not run |',
  '|---|---:|---:|---:|---:|',
  ...rows,
  '',
  '## Failures',
  '',
  ...(failed.length ? Object.keys(PILLARS).concat('other').flatMap((p) => {
    const g = failed.filter((t) => pillarOf(t) === p);
    if (!g.length) return [];
    const [label, meaning] = PILLARS[p] ?? ['Other', ''];
    return [`### ${label} (${g.length})`, '', meaning ? `What this usually means: ${meaning}` : '', '',
      ...g.map((t) => `- **${esc(t.title)}** — \`${t.file}:${t.line}\`\n  - Result: ${esc(t.error || 'failed')}\n  - Re-run alone: \`npx playwright test ${t.file} -g "${t.title.split(' › ').pop().replace(/[\\^$.*+?()[\]{}|"]/g, '\\$&').slice(0, 80)}"\``), ''];
  }) : ['None.', '']),
  '## Not covered',
  '',
  ...(skipped.length ? skipped.map((t) => `- ${esc(t.title)} — ${esc(t.skip || 'skipped')}`) : ['Everything in scope ran.']),
  '',
  '## Next steps',
  '',
  failed.length
    ? '1. Re-run each failure alone (command below) to rule out flakiness.\n2. Do a root-cause analysis (file, line, commit) before filing a ticket; environment or spec-gap results are not product bugs.\n3. File one ticket per root cause with the request, response and (for DB tests) the exact query and masked rows.'
    : 'No defects found in scope. Review "Not covered" — each line is a gap a human should accept or close.',
  '',
  '## How to reproduce',
  '',
  '```bash',
  'npx playwright test --grep "<part of the test title>"',
  '```',
  '',
  `Raw results: \`${file}\``,
  '',
].join('\n');

mkdirSync(outDir, { recursive: true });
const slug = name.replace(/[^A-Za-z0-9]+/g, '-').replace(/^-|-$/g, '');
const out = join(outDir, `${slug}_${verdict}_${kind}-Test-Report_${date}.md`);
writeFileSync(out, md);
console.log(out);
process.exitCode = failed.length ? 1 : 0;
````

#### `tools/psql-json.sh`

````bash
#!/usr/bin/env bash
# psql-json.sh — CLI wrapper for DB_ACCESS_MODE=cli on PostgreSQL. Needs only the psql client.
# Usage: psql-json.sh "<one SQL statement>" [--json]   (connection from DB_URL, or the standard PG* variables)
# Prints ONLY a JSON array of row objects. Exits non-zero (psql error on stderr) when the SQL fails.
#   SELECT / read-only WITH          → rows as JSON (types kept: numbers, booleans, ISO timestamps)
#   INSERT/UPDATE/DELETE … RETURNING → returned rows as JSON
#   anything else (DDL, plain DML, data-modifying WITH) → executed, prints []
set -euo pipefail
SQL="$1"
stmt="$(printf '%s' "$SQL" | sed -e 's/^[[:space:]]*//' -e 's/;[[:space:]]*$//')"
lower="$(printf '%s' "$stmt" | tr '[:upper:]' '[:lower:]' | tr '\n' ' ')"
run() { psql "${DB_URL:-}" -X -q -A -t -v ON_ERROR_STOP=1 -c "$1"; }
if [[ "$lower" =~ ^select[[:space:]] ]] || { [[ "$lower" =~ ^with[[:space:]] ]] && ! [[ "$lower" =~ (^|[^a-z_])(insert|update|delete|merge)[[:space:]] ]]; }; then
  run "SELECT coalesce(json_agg(q), '[]'::json) FROM ($stmt) q"
elif [[ "$lower" =~ ^(insert|update|delete)[[:space:]] ]] && [[ "$lower" =~ [[:space:]]returning[[:space:]] ]]; then
  run "WITH qa_rows AS ($stmt) SELECT coalesce(json_agg(qa_rows), '[]'::json) FROM qa_rows"
else
  run "$stmt" > /dev/null
  echo '[]'
fi
````

#### `tools/sqlite-json.mjs`

````js
#!/usr/bin/env node
// sqlite-json.mjs — CLI wrapper for DB_ACCESS_MODE=cli on SQLite. Zero install (Node >= 22.5 built-in node:sqlite).
// Usage: node sqlite-json.mjs <db-file> "<one SQL statement>" [--json]
// Prints ONLY a JSON array of row objects on stdout. Exits 1 with the SQLite message on stderr on any error.
import { DatabaseSync } from 'node:sqlite';
const [file, sql] = process.argv.slice(2).filter((a) => a !== '--json');
if (!file || !sql) { process.stderr.write('usage: sqlite-json.mjs <db-file> "<sql>"\n'); process.exit(2); }
try {
  const db = new DatabaseSync(file);
  db.exec('PRAGMA foreign_keys = ON; PRAGMA busy_timeout = 5000'); // wait for the app's write lock instead of failing
  const rows = db.prepare(sql).all();          // all() also executes INSERT/UPDATE/DELETE (returns [] without RETURNING)
  process.stdout.write(JSON.stringify(rows.map((r) => ({ ...r }))));
  db.close();
} catch (e) {
  process.stderr.write(String(e?.message ?? e) + '\n');
  process.exit(1);
}
````

#### `tests/db/db.adapter.ts`

````ts
// db.adapter.ts — ONE query interface, three ways to reach the database, two engines verified.
//   DB_ACCESS_MODE = driver | cli | api      DB_ENGINE = postgres | sqlite
// Tests always write PostgreSQL-style placeholders ($1, $2 …); the adapter converts them for the engine.
import { createRequire } from 'node:module';

export interface DbAdapter {
  engine: 'postgres' | 'sqlite';
  query<T = Record<string, any>>(sql: string, params?: unknown[]): Promise<T[]>;
  close(): Promise<void>;
}

const req = createRequire(`${process.cwd()}/package.json`); // resolve drivers from the project root

function need(name: string): string {
  const v = process.env[name];
  if (!v) throw new Error(`${name} is not set (see the DB testing skill, section "Environment")`);
  return v;
}

export function assertNotProduction(target: string): void {
  const extra = (process.env.QA_PRODUCTION_HOSTS ?? '').split(',').map((s) => s.trim()).filter(Boolean);
  if (/(^|[^a-z])(prod|production|live)([^a-z]|$)/i.test(target) || extra.some((h) => target.includes(h))) {
    throw new Error(`Refusing to run DB tests against a production-looking target: ${target}`);
  }
}

/** $1..$n → engine placeholders. SQLite binds positional arrays to ?NNN, NOT to $1 ("column index out of range"). */
export function toEngineSql(sql: string, engine: 'postgres' | 'sqlite'): string {
  return engine === 'sqlite' ? sql.replace(/\$(\d+)/g, '?$1') : sql;
}

/** Inline values for CLI mode (no parameter binding there). Only ever pass values the test generated itself. */
export function inlineParams(sql: string, params: unknown[], engine: 'postgres' | 'sqlite'): string {
  const quote = (v: unknown): string => {
    if (v === null || v === undefined) return 'NULL';
    if (typeof v === 'number') return String(v);
    if (typeof v === 'boolean') return engine === 'sqlite' ? (v ? '1' : '0') : (v ? 'TRUE' : 'FALSE');
    const s = v instanceof Date ? v.toISOString() : String(v);
    return `'${s.replace(/'/g, "''")}'`;
  };
  return sql.replace(/\$(\d+)/g, (_, n) => quote(params[Number(n) - 1]));
}

const plain = <T>(rows: unknown[]): T[] => rows.map((r) => ({ ...(r as object) }) as T); // node:sqlite returns null-prototype rows

async function driverAdapter(engine: 'postgres' | 'sqlite'): Promise<DbAdapter> {
  if (engine === 'postgres') {
    const url = need('DB_URL'); assertNotProduction(url);
    const { Pool } = req('pg');                       // npm i -D pg @types/pg
    const pool = new Pool({ connectionString: url, max: 5 });
    return { engine, query: async (sql, params = []) => (await pool.query(sql, params)).rows, close: () => pool.end() };
  }
  const file = need('DB_FILE'); assertNotProduction(file);
  let db: { prepare(sql: string): { all(...p: unknown[]): unknown[] }; exec(sql: string): void; close(): void };
  try { const { DatabaseSync } = req('node:sqlite'); db = new DatabaseSync(file); }          // Node >= 22.5, zero install
  catch { const Better = req('better-sqlite3'); db = new Better(file); }                       // fallback: npm i -D better-sqlite3
  db.exec('PRAGMA foreign_keys = ON; PRAGMA busy_timeout = 5000'); // SQLite has one writer: wait for the app's lock instead of failing
  return {
    engine,
    query: async (sql, params = []) => {
      const stmt = db.prepare(toEngineSql(sql, engine)) as { all(...p: unknown[]): unknown[]; run?(...p: unknown[]): unknown; reader?: boolean };
      // better-sqlite3 refuses all() on statements that return no rows; node:sqlite allows it.
      if (stmt.reader === false && stmt.run) { stmt.run(...params); return []; }
      return plain(stmt.all(...params));
    },
    close: async () => db.close(),
  };
}

async function cliAdapter(engine: 'postgres' | 'sqlite'): Promise<DbAdapter> {
  const cmd = need('DB_CLI_COMMAND'); assertNotProduction(cmd);
  const { execFile } = await import('node:child_process');
  const { promisify } = await import('node:util');
  const run = promisify(execFile);
  return {
    engine,
    query: async (sql, params = []) => {
      // Wrapper contract (tools/psql-json.sh, tools/sqlite-json.mjs): print ONLY a JSON array of rows; exit non-zero on SQL error.
      const [bin, ...args] = cmd.split(' ').filter(Boolean);
      try {
        const { stdout } = await run(bin, [...args, inlineParams(sql, params, engine), '--json'], { maxBuffer: 64 * 1024 * 1024 });
        const parsed = JSON.parse(stdout.trim() || '[]');
        return plain(Array.isArray(parsed) ? parsed : parsed[0]?.results ?? parsed.results ?? []);
      } catch (e: any) {
        throw new Error(String(e?.stderr || e?.message || e).trim());
      }
    },
    close: async () => {},
  };
}

async function apiAdapter(engine: 'postgres' | 'sqlite'): Promise<DbAdapter> {
  const url = need('DB_ADMIN_API_URL'); assertNotProduction(url);
  const header = process.env.DB_ADMIN_API_AUTH_HEADER ?? 'Authorization';
  const token = need('DB_ADMIN_API_TOKEN');
  const rowsKey = process.env.DB_ADMIN_API_ROWS_KEY ?? 'rows';
  return {
    engine,
    query: async (sql, params = []) => {
      const res = await fetch(url, {
        method: 'POST',
        headers: { 'content-type': 'application/json', [header]: header.toLowerCase() === 'authorization' ? `Bearer ${token}` : token },
        body: JSON.stringify({ sql: engine === 'sqlite' ? sql.replace(/\$(\d+)/g, '?') : sql, params: engine === 'sqlite' ? orderedParams(sql, params) : params }),
      });
      const text = await res.text();
      if (!res.ok) throw new Error(`Admin query failed (${res.status}): ${text}`);
      return plain(JSON.parse(text)[rowsKey] ?? []);
    },
    close: async () => {},
  };
}

/** For endpoints that only take plain `?`: expand $n into one value per occurrence, in order. */
function orderedParams(sql: string, params: unknown[]): unknown[] {
  return [...sql.matchAll(/\$(\d+)/g)].map((m) => params[Number(m[1]) - 1]);
}

export async function createDb(): Promise<DbAdapter> {
  const engine = (process.env.DB_ENGINE ?? 'postgres') as 'postgres' | 'sqlite';
  if (engine !== 'postgres' && engine !== 'sqlite') throw new Error(`DB_ENGINE must be postgres or sqlite, got ${engine}`);
  switch (process.env.DB_ACCESS_MODE ?? 'driver') {
    case 'driver': return driverAdapter(engine);
    case 'cli': return cliAdapter(engine);
    case 'api': return apiAdapter(engine);
    default: throw new Error(`Unknown DB_ACCESS_MODE ${process.env.DB_ACCESS_MODE} (driver | cli | api)`);
  }
}
````

#### `tests/db/db.helpers.ts`

````ts
// db.helpers.ts — typed helpers for before/after checks. Identifiers (table/column names) come from config, never from input.
import { createHash } from 'node:crypto';
import type { DbAdapter } from './db.adapter';

/** Drivers return Date objects and numeric strings; CLIs/APIs return strings. Normalise before comparing. */
export function norm(v: unknown): unknown {
  if (v instanceof Date) return v.toISOString();
  if (typeof v === 'bigint') return v.toString();
  if (v && typeof v === 'object' && 'type' in (v as any) && (v as any).type === 'Buffer') return JSON.stringify(v);
  return v;
}
export const tsOf = (v: unknown): number => (v instanceof Date ? v : new Date(String(v))).getTime();
export const num = (v: unknown): number => Number(v);

export async function getRow<T = Record<string, any>>(db: DbAdapter, table: string, idCol: string, id: unknown): Promise<T | undefined> {
  return (await db.query<T>(`SELECT * FROM ${table} WHERE ${idCol} = $1`, [id]))[0];
}

export async function countRows(db: DbAdapter, table: string, where: string, params: unknown[]): Promise<number> {
  const rows = await db.query<{ n: string | number }>(`SELECT COUNT(*) AS n FROM ${table} WHERE ${where}`, params);
  return Number(rows[0].n);
}

/** Every column must be equal before/after except the listed ones. Reports ALL differences at once. */
export function expectUnchangedExcept(before: Record<string, unknown>, after: Record<string, unknown>, changed: string[]): void {
  const diffs = Object.keys(before)
    .filter((k) => !changed.includes(k) && JSON.stringify(norm(before[k])) !== JSON.stringify(norm(after?.[k])))
    .map((k) => `${k}: ${JSON.stringify(norm(before[k]))} → ${JSON.stringify(norm(after?.[k]))}`);
  if (diffs.length) throw new Error(`Columns changed that should not have:\n  ${diffs.join('\n  ')}`);
}

/** The database itself (constraint, trigger, fence, RLS) must reject this write. */
export async function expectDbRejects(db: DbAdapter, sql: string, params: unknown[], message?: RegExp): Promise<void> {
  let error: unknown;
  try { await db.query(sql, params); } catch (e) { error = e; }
  if (!error) throw new Error(`Expected the database to reject this write, but it succeeded:\n  ${sql}`);
  if (message && !message.test(String(error))) throw new Error(`Rejected with an unexpected message: ${String(error)}`);
}

/** Mask sensitive columns before rows go into a report or an error message. */
export function mask(rows: Record<string, unknown>[], sensitive: string[] = []): Record<string, unknown>[] {
  const hidden = ['password', 'password_hash', 'token', 'token_hash', 'secret', 'key_hash', ...sensitive].map((s) => s.toLowerCase());
  return rows.map((r) => Object.fromEntries(Object.entries(r).map(([k, v]) => [k, hidden.includes(k.toLowerCase()) ? '***' : norm(v)])));
}

/** INSERT a row from a column → value map (direct seeding for DB-rule tests). Returns the inserted row. */
export async function insertRow(db: DbAdapter, table: string, values: Record<string, unknown>): Promise<Record<string, any>> {
  const cols = Object.keys(values);
  const rows = await db.query(`INSERT INTO ${table} (${cols.join(', ')}) VALUES (${cols.map((_, i) => `$${i + 1}`).join(', ')}) RETURNING *`, Object.values(values));
  return rows[0];
}

/**
 * Turn the run marker into a value for a column that cannot hold it (e.g. "2-10 uppercase letters").
 * Deterministic: the same marker always gives the same code, so duplicate tests still collide on purpose.
 */
export function markerToCode(marker: string, length = 10, alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'): string {
  const bytes = createHash('sha256').update(marker).digest();
  return Array.from(bytes.subarray(0, length), (b) => alphabet[b % alphabet.length]).join('');
}
````

#### `tests/db/api-actors.ts`

````ts
// api-actors.ts — how the DB tests call the API as a real, logged-in user. Pick the factory that matches the project.
import { request as pwRequest, type APIRequestContext } from '@playwright/test';
import { assertNotProduction } from './db.adapter';

export type ActorAuth =
  | { kind: 'bearer-login'; path: string; body: () => Record<string, unknown>; tokenPath: string; scheme?: string }
  | { kind: 'bearer-env'; token: () => string; scheme?: string }
  | { kind: 'cookie-login'; path: string; body: () => Record<string, unknown> }
  | { kind: 'header'; header: string; value: () => string }
  | { kind: 'none' };

export const bearerLogin = (path: string, body: () => Record<string, unknown>, tokenPath = 'accessToken'): ActorAuth => ({ kind: 'bearer-login', path, body, tokenPath });
export const cookieLogin = (path: string, body: () => Record<string, unknown>): ActorAuth => ({ kind: 'cookie-login', path, body });
export const apiKeyHeader = (header: string, value: () => string): ActorAuth => ({ kind: 'header', header, value });
export const bearerToken = (token: () => string): ActorAuth => ({ kind: 'bearer-env', token });
export const noAuth = (): ActorAuth => ({ kind: 'none' });

export function apiBaseUrl(): string {
  const url = process.env.API_BASE_URL;
  if (!url) throw new Error('API_BASE_URL is not set');
  assertNotProduction(url);
  return url;
}

export async function actorContext(auth: ActorAuth): Promise<APIRequestContext> {
  const baseURL = apiBaseUrl();
  const headers = { Accept: 'application/json' };
  switch (auth.kind) {
    case 'none': return pwRequest.newContext({ baseURL, extraHTTPHeaders: headers });
    case 'header': return pwRequest.newContext({ baseURL, extraHTTPHeaders: { ...headers, [auth.header]: auth.value() } });
    case 'bearer-env': return pwRequest.newContext({ baseURL, extraHTTPHeaders: { ...headers, Authorization: `${auth.scheme ?? 'Bearer'} ${auth.token()}` } });
    case 'cookie-login': {
      const ctx = await pwRequest.newContext({ baseURL, extraHTTPHeaders: headers });
      const res = await ctx.post(auth.path, { data: auth.body() });
      if (!res.ok()) throw new Error(`cookie login failed: ${res.status()} ${await res.text()}`);
      return ctx; // the context keeps the session cookie
    }
    case 'bearer-login': {
      const login = await pwRequest.newContext({ baseURL });
      const res = await login.post(auth.path, { data: auth.body() });
      if (!res.ok()) throw new Error(`login failed: ${res.status()} ${await res.text()}`);
      const token = auth.tokenPath.split('.').reduce<any>((o, k) => o?.[k], await res.json());
      await login.dispose();
      if (typeof token !== 'string') throw new Error(`no token at "${auth.tokenPath}" in the login response`);
      return pwRequest.newContext({ baseURL, extraHTTPHeaders: { ...headers, Authorization: `${auth.scheme ?? 'Bearer'} ${token}` } });
    }
  }
}
````

#### `tests/db/types.ts`

````ts
// types.ts — the shape of tests/config/feature.config.ts (the only per-project file).
import type { ActorAuth } from './api-actors';

export interface FeatureConfig {
  name: string;
  /** Two logged-in API callers: the owner (tenant A) and a user of another tenant (tenant B). */
  actors: { owner: ActorAuth; otherTenant: ActorAuth };
  /** Optional: log each actor out after the test so sessions/tokens don't pile up in the database. */
  logout?: { method: 'POST' | 'DELETE'; path: string };
  api: {
    collectionPath: string;                                   // e.g. /orgs/<tenantA>/invoices
    /** Path of one row. `tenant` = whose tenant goes in the path ('B' = the other tenant using ITS OWN path with tenant A's id — the IDOR attempt). */
    itemPath: (id: string | number, tenant?: 'A' | 'B') => string;
    idOf: (createResponseBody: any) => string | number;
    create: { status: number; body: (marker: string) => Record<string, unknown> };
    /** A request that must be rejected and leave NO row (e.g. a required field missing). */
    invalidCreate: { status: number[]; body: (marker: string) => Record<string, unknown> };
    duplicateStatus: number[];
    /**
     * body / expectColumns may be functions of the marker — needed for PUT (full replace), where the body must
     * repeat the marker column or the update would overwrite it.
     * derived: columns the server recalculates from the sent ones (e.g. a margin from an amount).
     */
    update: { method: 'PATCH' | 'PUT'; status: number; body: Record<string, unknown> | ((marker: string) => Record<string, unknown>);
      expectColumns: Record<string, unknown> | ((marker: string) => Record<string, unknown>); derived?: string[] };
    delete: { status: number };
    notFoundStatus: number;
    /** What the other tenant gets for tenant A's row (403 or 404 — follow the contract). */
    deniedStatus: number[];
    /** Body field naming the tenant, sent by a client that should not control it. null = skip the check. */
    tenantInBody: { field: string; value: () => unknown; rejectedWith: number[] | null } | null;
    /** Retry header that must not create a second row. null = the API has none. */
    idempotency: { header: string; replayStatus: number } | null;
  };
  table: string;
  col: { id: string; marker: string; tenant: string; createdAt: string; updatedAt: string };
  /** Expected tenant column value for rows the owner creates. */
  ownerTenant: () => unknown;
  /** Body field → column, for the "stored exactly as sent" check. */
  sentColumns: Record<string, string>;
  /** Column → value expected right after create when the client did not send it. */
  defaults: Record<string, unknown>;
  /** null = hard delete (row removed). */
  softDelete: { column: string; isDeleted: (row: any) => boolean } | null;
  child: null | { table: string; fk: string; marker: string; bodyField: string; valid: (m: string) => Record<string, unknown>; invalid: (m: string) => Record<string, unknown> };
  /** Rows that must be written in the same transaction (audit / history / outbox). */
  bookkeeping: null | { table: string; where: string; expected: number };   // `where` uses $1 = the new row id
  /** A rule enforced INSIDE the database (trigger / constraint / fence). */
  dbRule: null | {
    name: string;
    seed: (runId: string) => Record<string, unknown>;          // full column set for a direct INSERT
    forbidden: Record<string, unknown>;                          // UPDATE ... SET these → must be rejected
    error: RegExp;
    allowed: Record<string, unknown>;                            // UPDATE ... SET these → must succeed
  };
  /** Data-health invariants: each query must return 0 rows. They run in parallel with other tests, so use invariants that hold at every instant. */
  integrity: Array<{ name: string; sql: string; params?: unknown[] }>;
  /** Teardown, children first. Each statement gets $1 = `${runId}%`. */
  cleanup: string[];
  sensitiveColumns?: string[];
}
````

#### `tests/db/db.fixture.ts`

````ts
// db.fixture.ts — `db`, a unique `runId` per test, logged-in API `actor`s, and automatic teardown of this test's rows.
import { test as base, expect, type APIRequestContext } from '@playwright/test';
import { createDb, type DbAdapter } from './db.adapter';
import { actorContext } from './api-actors';
import { feature } from '../config/feature.config';

type Fixtures = { db: DbAdapter; runId: string; actor: (who: 'owner' | 'otherTenant') => Promise<APIRequestContext> };

export const test = base.extend<Fixtures>({
  db: async ({}, use) => {
    const db = await createDb();
    await use(db);
    await db.close();
  },
  runId: async ({ db }, use) => {
    // Letters, digits and underscores only, so it fits most "reference/code" columns as a marker.
    const runId = `${process.env.QA_MARKER_PREFIX ?? 'qa_'}${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
    await use(runId);
    for (const sql of feature.cleanup) await db.query(sql, [`${runId}%`]); // children first, only this test's rows
  },
  actor: async ({}, use) => {
    const opened: APIRequestContext[] = [];
    await use(async (who) => { const ctx = await actorContext(feature.actors[who]); opened.push(ctx); return ctx; });
    for (const c of opened) {
      if (feature.logout) await c.fetch(feature.logout.path, { method: feature.logout.method }).catch(() => undefined);
      await c.dispose();
    }
  },
});

export { expect, feature };
````

#### `tests/api/feature.db.spec.ts`

````ts
// feature.db.spec.ts — identical in every project. It reads names from tests/config/feature.config.ts.
// The API is the door, the database is the room: every test opens the door and checks exactly what changed in the room.
import type { APIRequestContext } from '@playwright/test';
import { test, expect, feature as F } from '../db/db.fixture';
import { countRows, expectDbRejects, expectUnchangedExcept, getRow, insertRow, mask, norm, tsOf } from '../db/db.helpers';

const T = F.table;
const C = F.col;
const byMarker = `${C.marker} = $1`;

async function createViaApi(actor: APIRequestContext, marker: string, extra: Record<string, unknown> = {}): Promise<string | number> {
  const res = await actor.post(F.api.collectionPath, { data: { ...F.api.create.body(marker), ...extra } });
  const text = await res.text();
  expect(res.status(), `create ${marker} → ${res.status()} ${text.slice(0, 300)}`).toBe(F.api.create.status);
  return F.api.idOf(JSON.parse(text));
}

test.describe(`${F.name} — database effects`, { tag: ['@db'] }, () => {
  test('TC-DB-001 create writes exactly one row: sent values, defaults, system columns, tenant from auth, bookkeeping', async ({ db, runId, actor }) => {
    const marker = `${runId}_create`;
    const id = await createViaApi(await actor('owner'), marker);
    expect(await countRows(db, T, byMarker, [marker]), 'exactly one row for one create').toBe(1);
    const row = (await getRow(db, T, C.id, id))!;
    expect(row, 'response id must match the stored row').toBeDefined();
    const sent = F.api.create.body(marker);
    for (const [field, column] of Object.entries(F.sentColumns)) {
      const expected = sent[field];
      const actual = typeof expected === 'number' ? Number(row[column]) : norm(row[column]);
      expect(actual, `column ${column} must store body field ${field} exactly`).toEqual(expected);
    }
    for (const [column, value] of Object.entries(F.defaults)) expect(norm(row[column]), `default of ${column}`).toEqual(value);
    expect(norm(row[C.tenant]), 'tenant must come from the auth context, not the body').toEqual(F.ownerTenant());
    expect(Math.abs(tsOf(row[C.createdAt]) - Date.now()), 'created_at ≈ now').toBeLessThan(5 * 60_000);
    expect(tsOf(row[C.updatedAt])).toBeGreaterThanOrEqual(tsOf(row[C.createdAt]));
    if (F.softDelete) expect(F.softDelete.isDeleted(row), 'a new row is not deleted').toBe(false);
    if (F.child) expect(await countRows(db, F.child.table, `${F.child.fk} = $1`, [id]), 'child rows match the items sent').toBe(Array.isArray(sent[F.child.bodyField]) ? (sent[F.child.bodyField] as unknown[]).length : 0);
    if (F.bookkeeping) expect(await countRows(db, F.bookkeeping.table, F.bookkeeping.where, [id]), `bookkeeping rows in ${F.bookkeeping.table}`).toBe(F.bookkeeping.expected);
  });

  test('TC-DB-002 duplicate create is rejected and leaves one row', async ({ db, runId, actor }) => {
    const owner = await actor('owner');
    const marker = `${runId}_dup`;
    await createViaApi(owner, marker);
    const second = await owner.post(F.api.collectionPath, { data: F.api.create.body(marker) });
    expect(F.api.duplicateStatus, `duplicate → ${second.status()} ${await second.text()}`).toContain(second.status());
    expect(await countRows(db, T, byMarker, [marker])).toBe(1);
  });

  test('TC-DB-003 an invalid create is rejected and writes nothing', async ({ db, runId, actor }) => {
    const marker = `${runId}_invalid`;
    const res = await (await actor('owner')).post(F.api.collectionPath, { data: F.api.invalidCreate.body(marker) });
    expect(F.api.invalidCreate.status, `invalid create → ${res.status()} ${await res.text()}`).toContain(res.status());
    expect(await countRows(db, T, `${C.marker} LIKE $1`, [`${runId}%`]), 'no row may be written by a rejected request').toBe(0);
  });

  test('TC-DB-004 update changes only the sent columns and moves updated_at forward', async ({ db, runId, actor }) => {
    const owner = await actor('owner');
    const id = await createViaApi(owner, `${runId}_update`);
    const before = (await getRow(db, T, C.id, id))!;
    await new Promise((r) => setTimeout(r, 15)); // make an updated_at change measurable even with ms precision
    const marker = `${runId}_update`;
    const updateBody = typeof F.api.update.body === 'function' ? F.api.update.body(marker) : F.api.update.body;
    const expectColumns = typeof F.api.update.expectColumns === 'function' ? F.api.update.expectColumns(marker) : F.api.update.expectColumns;
    const res = await owner.fetch(F.api.itemPath(id), { method: F.api.update.method, data: updateBody });
    expect(res.status(), `update → ${await res.text()}`).toBe(F.api.update.status);
    const after = (await getRow(db, T, C.id, id))!;
    for (const [column, value] of Object.entries(expectColumns)) {
      expect(typeof value === 'number' ? Number(after[column]) : norm(after[column]), `column ${column} after update`).toEqual(value);
    }
    expect(tsOf(after[C.updatedAt]), 'updated_at must move forward').toBeGreaterThan(tsOf(before[C.updatedAt]));
    expectUnchangedExcept(before, after, [...Object.keys(expectColumns), ...(F.api.update.derived ?? []), C.updatedAt]);
  });

  test('TC-DB-005 delete is soft or hard as designed, and the API no longer returns the row', async ({ db, runId, actor }) => {
    const owner = await actor('owner');
    const id = await createViaApi(owner, `${runId}_delete`);
    const res = await owner.delete(F.api.itemPath(id));
    expect(res.status(), `delete → ${await res.text()}`).toBe(F.api.delete.status);
    const row = await getRow(db, T, C.id, id);
    if (F.softDelete) {
      expect(row, 'soft delete keeps the row').toBeDefined();
      expect(F.softDelete.isDeleted(row), `${F.softDelete.column} must mark the row deleted`).toBe(true);
    } else {
      expect(row, 'hard delete removes the row').toBeUndefined();
    }
    expect((await owner.get(F.api.itemPath(id))).status()).toBe(F.api.notFoundStatus);
  });

  test('TC-DB-006 transaction: an invalid child item rolls back the parent and its children', async ({ db, runId, actor }) => {
    test.skip(!F.child, 'feature has no child rows (config.child = null)');
    const child = F.child!;
    const marker = `${runId}_tx`;
    const res = await (await actor('owner')).post(F.api.collectionPath, {
      data: { ...F.api.create.body(marker), [child.bodyField]: [child.valid(`${runId}_ok`), child.invalid(`${runId}_bad`)] },
    });
    expect(F.api.invalidCreate.status, `invalid child → ${res.status()} ${await res.text()}`).toContain(res.status());
    expect(await countRows(db, T, byMarker, [marker]), 'parent must be rolled back').toBe(0);
    expect(await countRows(db, child.table, `${child.marker} LIKE $1`, [`${runId}%`]), 'children must be rolled back').toBe(0);
  });

  test('TC-DB-007 database rule blocks the forbidden write and allows the normal one', async ({ db, runId }) => {
    test.skip(!F.dbRule, 'feature has no database-enforced rule (config.dbRule = null)');
    const rule = F.dbRule!;
    const seeded = await insertRow(db, T, rule.seed(runId));
    const set = (vals: Record<string, unknown>, start: number) => Object.keys(vals).map((k, i) => `${k} = $${i + start}`).join(', ');
    const forbidden = Object.values(rule.forbidden);
    await expectDbRejects(db, `UPDATE ${T} SET ${set(rule.forbidden, 1)} WHERE ${C.id} = $${forbidden.length + 1}`, [...forbidden, seeded[C.id]], rule.error);
    const afterBlock = (await getRow(db, T, C.id, seeded[C.id]))!;
    expectUnchangedExcept(seeded, afterBlock, []);
    const allowed = Object.values(rule.allowed);
    await db.query(`UPDATE ${T} SET ${set(rule.allowed, 1)} WHERE ${C.id} = $${allowed.length + 1}`, [...allowed, seeded[C.id]]); // a fence that is too wide breaks other features
    const afterAllow = (await getRow(db, T, C.id, seeded[C.id]))!;
    for (const [k, v] of Object.entries(rule.allowed)) expect(norm(afterAllow[k])).toEqual(v);
  });

  test("TC-DB-008 another tenant cannot read, update or delete this tenant's row — and the row is byte-for-byte unchanged", async ({ db, runId, actor }) => {
    const id = await createViaApi(await actor('owner'), `${runId}_tenant`);
    const before = (await getRow(db, T, C.id, id))!;
    const other = await actor('otherTenant');
    // Try tenant A's path AND the other tenant's own path with tenant A's id (object-level check / IDOR).
    const paths = [...new Set([F.api.itemPath(id, 'A'), F.api.itemPath(id, 'B')])];
    for (const path of paths) {
      const attempts = [
        ['read', await other.get(path)],
        ['update', await other.fetch(path, { method: F.api.update.method, data: typeof F.api.update.body === 'function' ? F.api.update.body(`${runId}_tenant`) : F.api.update.body })],
        ['delete', await other.delete(path)],
      ] as const;
      for (const [what, res] of attempts) expect(F.api.deniedStatus, `other tenant ${what} ${path} → ${res.status()}`).toContain(res.status());
    }
    expectUnchangedExcept(before, (await getRow(db, T, C.id, id))!, []);
  });

  test('TC-DB-009 a tenant field sent in the body is never applied', async ({ db, runId, actor }) => {
    const t = F.api.tenantInBody;
    test.skip(!t, 'no tenant field to try (config.api.tenantInBody = null)');
    const marker = `${runId}_mass`;
    const res = await (await actor('owner')).post(F.api.collectionPath, { data: { ...F.api.create.body(marker), [t!.field]: t!.value() } });
    if (t!.rejectedWith) {
      expect(t!.rejectedWith, `tenant field in body → ${res.status()} ${await res.text()}`).toContain(res.status());
      expect(await countRows(db, T, byMarker, [marker])).toBe(0);
    } else {
      expect(res.status(), await res.text()).toBe(F.api.create.status);
      const rows = await db.query(`SELECT ${C.tenant} AS tenant FROM ${T} WHERE ${byMarker}`, [marker]);
      expect(rows.map((r) => norm(r.tenant)), 'row must belong to the caller, not to the tenant in the body').toEqual([F.ownerTenant()]);
    }
  });

  test('TC-DB-010 a retried create with the same idempotency key stores one row', async ({ db, runId, actor }) => {
    const k = F.api.idempotency;
    test.skip(!k, 'API has no idempotency header (config.api.idempotency = null)');
    const owner = await actor('owner');
    const marker = `${runId}_idem`;
    const headers = { [k!.header]: `${runId}-key` };
    const first = await owner.post(F.api.collectionPath, { data: F.api.create.body(marker), headers });
    expect(first.status(), await first.text()).toBe(F.api.create.status);
    const replay = await owner.post(F.api.collectionPath, { data: F.api.create.body(marker), headers });
    expect(replay.status(), `replay → ${await replay.text()}`).toBe(k!.replayStatus);
    expect(await countRows(db, T, byMarker, [marker]), 'two requests, one row').toBe(1);
  });
});

test.describe(`${F.name} — data health`, { tag: ['@db', '@data-health'] }, () => {
  for (const check of F.integrity) {
    test(`integrity: ${check.name}`, async ({ db }) => {
      const rows = await db.query(check.sql, check.params ?? []);
      expect(rows.length, `${rows.length} row(s) break "${check.name}":\n${JSON.stringify(mask(rows.slice(0, 10), F.sensitiveColumns), null, 1)}`).toBe(0);
    });
  }
});
````


### 8.3 `feature.config.ts` — complete example (PostgreSQL, bearer login, soft delete, audit table)

This example is a fictional "invoices" feature. Replace every name with what Step 1 found in your project.

````ts
// feature.config.ts — THE ONLY FILE THAT CHANGES PER PROJECT (filled from Step 1: data model discovery).
// Project: Orgs & Billing API — feature: invoices (PostgreSQL, soft delete via deleted_at, org_id tenant, audit_logs).
import { randomUUID } from 'node:crypto';
import { bearerLogin } from '../db/api-actors';
import type { FeatureConfig } from '../db/types';

const env = (n: string): string => { const v = process.env[n]; if (!v) throw new Error(`${n} is not set`); return v; };
const login = (emailEnv: string) => bearerLogin('/auth/login', () => ({ email: env(emailEnv), password: env('QA_PASSWORD') }), 'accessToken');
const A = () => env('QA_TENANT_A_ID');

export const feature: FeatureConfig = {
  name: 'Invoices',
  actors: { owner: login('QA_ADMIN_EMAIL'), otherTenant: login('QA_OTHER_TENANT_ADMIN_EMAIL') },
  api: {
    collectionPath: `/orgs/${A()}/invoices`,
    itemPath: (id, tenant = 'A') => `/orgs/${tenant === 'A' ? A() : env('QA_TENANT_B_ID')}/invoices/${id}`,
    idOf: (b) => b.id,
    create: { status: 201, body: (m) => ({ reference: m, total: 1234.56, notes: 'keep-me', lines: [{ label: `${m}_line`, qty: 2 }] }) },
    invalidCreate: { status: [400], body: (m) => ({ reference: m }) },            // total is required
    duplicateStatus: [409],
    update: { method: 'PATCH', status: 200, body: { total: 20 }, expectColumns: { total: 20 } },
    delete: { status: 204 },
    notFoundStatus: 404,
    deniedStatus: [404],                                                         // contract: other orgs get 404
    tenantInBody: { field: 'orgId', value: () => env('QA_TENANT_B_ID'), rejectedWith: null }, // ignored by contract
    idempotency: null,
  },
  table: 'invoices',
  col: { id: 'id', marker: 'reference', tenant: 'org_id', createdAt: 'created_at', updatedAt: 'updated_at' },
  ownerTenant: A,
  sentColumns: { reference: 'reference', total: 'total', notes: 'notes' },
  defaults: { status: 'draft', deleted_at: null },
  softDelete: { column: 'deleted_at', isDeleted: (r) => r.deleted_at !== null },
  child: { table: 'invoice_lines', fk: 'invoice_id', marker: 'label', bodyField: 'lines', valid: (m) => ({ label: m, qty: 1 }), invalid: (m) => ({ label: m, qty: 0 }) },
  bookkeeping: { table: 'audit_logs', where: "entity = 'invoice' AND entity_id = $1 AND action = 'create'", expected: 1 },
  dbRule: {
    name: 'invoice number is immutable (trigger)',
    seed: (runId) => ({ id: randomUUID(), org_id: A(), reference: `${runId}_dbrule`, number: `QA-${runId}`, total: 1, status: 'draft', notes: 'seeded', created_at: new Date().toISOString(), updated_at: new Date().toISOString() }),
    forbidden: { number: 'QA-CHANGED' },
    error: /invoice number is immutable/,
    allowed: { notes: 'allowed change' },
  },
  integrity: [
    { name: 'every API-created invoice has exactly one create audit row', sql: "SELECT i.id, i.reference FROM invoices i WHERE i.reference NOT LIKE '%dbrule' AND (SELECT COUNT(*) FROM audit_logs a WHERE a.entity = 'invoice' AND a.entity_id = i.id AND a.action = 'create') <> 1" },
    { name: 'no invoice has more than one payment', sql: 'SELECT invoice_id, COUNT(*) AS payments FROM payments GROUP BY invoice_id HAVING COUNT(*) > 1' },
    { name: 'no two active users share an email in one org', sql: 'SELECT org_id, lower(email) AS email FROM users WHERE deleted_at IS NULL GROUP BY org_id, lower(email) HAVING COUNT(*) > 1' },
    { name: 'invoice lines always have a positive quantity', sql: 'SELECT id, qty FROM invoice_lines WHERE qty < 1' },
  ],
  // Order matters twice: foreign keys (payments before invoices; lines cascade) AND the data-health invariants, which run
  // in parallel — deleting the audit row before its invoice would show a "broken" invoice for a moment. So the invoice
  // and its audit rows go in ONE statement.
  cleanup: [
    'DELETE FROM payments WHERE invoice_id IN (SELECT id FROM invoices WHERE reference LIKE $1)',
    "WITH gone AS (DELETE FROM invoices WHERE reference LIKE $1 RETURNING id) DELETE FROM audit_logs WHERE entity = 'invoice' AND entity_id IN (SELECT id FROM gone)",
  ],
};
````

### 8.4 What changes for another project (SQLite, cookie sessions, `is_deleted` flag, strict bodies)

````ts
// feature.config.ts — THE ONLY FILE THAT CHANGES PER PROJECT (filled from Step 1: data model discovery).
// Project: Orders API v2 — feature: orders (SQLite, soft delete via is_deleted, org_id tenant, order_history).
import { cookieLogin } from '../db/api-actors';
import type { FeatureConfig } from '../db/types';

const env = (n: string): string => { const v = process.env[n]; if (!v) throw new Error(`${n} is not set`); return v; };
const session = (userEnv: string) => cookieLogin('/api/v2/session', () => ({ username: env(userEnv), password: env('QA_PASSWORD') }));
const now = () => new Date().toISOString();

export const feature: FeatureConfig = {
  name: 'Orders',
  actors: { owner: session('QA_MANAGER_USER'), otherTenant: session('QA_OTHER_TENANT_MANAGER_USER') },
  api: {
    collectionPath: '/api/v2/orders',
    itemPath: (id) => `/api/v2/orders/${id}`,
    idOf: (b) => b.data.id,
    create: { status: 201, body: (m) => ({ orderRef: m, customerEmail: 'buyer@example.test', amount: 1234.56, note: 'keep-me', lines: [{ sku: 'QA-SKU', quantity: 2 }] }) },
    invalidCreate: { status: [400], body: (m) => ({ orderRef: m }) },             // customerEmail and amount are required
    duplicateStatus: [409],
    update: { method: 'PATCH', status: 200, body: { amount: 20 }, expectColumns: { amount: 20 }, derived: ['internal_margin'] }, // margin = 18% of amount
    delete: { status: 200 },
    notFoundStatus: 404,
    deniedStatus: [403],                                                         // contract: other orgs get 403
    tenantInBody: { field: 'orgId', value: () => env('QA_TENANT_B_ID'), rejectedWith: [400] }, // strict bodies
    idempotency: { header: 'X-Idempotency-Key', replayStatus: 200 },
  },
  table: 'orders',
  col: { id: 'id', marker: 'order_ref', tenant: 'org_id', createdAt: 'created_at', updatedAt: 'updated_at' },
  ownerTenant: () => env('QA_TENANT_A_ID'),
  sentColumns: { orderRef: 'order_ref', customerEmail: 'customer_email', amount: 'amount', note: 'note' },
  defaults: { status: 'open', is_deleted: 0 },
  softDelete: { column: 'is_deleted', isDeleted: (r) => Number(r.is_deleted) === 1 },
  child: { table: 'order_lines', fk: 'order_id', marker: 'sku', bodyField: 'lines', valid: (m) => ({ sku: m, quantity: 1 }), invalid: (m) => ({ sku: m, quantity: 0 }) },
  bookkeeping: { table: 'order_history', where: "order_id = $1 AND event = 'created'", expected: 1 },
  dbRule: {
    name: 'order_ref is immutable (trigger)',
    seed: (runId) => ({ org_id: env('QA_TENANT_A_ID'), order_ref: `${runId}_dbrule`, customer_email: 'seed@example.test', amount: 1, note: 'seeded', status: 'open', internal_margin: 0.18, created_at: now(), updated_at: now(), is_deleted: 0 }),
    forbidden: { order_ref: 'QA_CHANGED' },
    error: /order_ref is immutable/,
    allowed: { note: 'allowed change' },
  },
  integrity: [
    { name: 'every API-created order has exactly one created history row', sql: "SELECT o.id, o.order_ref FROM orders o WHERE o.order_ref NOT LIKE '%dbrule' AND (SELECT COUNT(*) FROM order_history h WHERE h.order_id = o.id AND h.event = 'created') <> 1" },
    { name: 'internal margin is 18% of the amount', sql: 'SELECT id, amount, internal_margin FROM orders WHERE abs(internal_margin - amount * 0.18) > 0.01' },
    { name: 'order lines always have a positive quantity', sql: 'SELECT id, quantity FROM order_lines WHERE quantity < 1' },
  ],
  cleanup: [
    'DELETE FROM idempotency WHERE key LIKE $1',
    'DELETE FROM orders WHERE order_ref LIKE $1',                                // lines and history cascade
  ],
  sensitiveColumns: ['internal_margin'],
};
````

### 8.5 Rules for the automation

- Every test seeds its own data with `runId`, never depends on another test, and is cleaned up by `cleanup` (children first, marker-scoped).
- Assertions compare with values the test sent or computed, never with "whatever is in the DB now". "It equals itself" is not a test.
- `TC-DB-004` snapshots the **whole row** and allows only the expected columns, `updated_at` and declared `derived` columns to change. A column the server recalculates (like a margin from an amount) must be listed in `update.derived`, otherwise the test reports it. For a **PUT** (full replace), make `update.body` a function of the marker so the body keeps the marker column, e.g. `body: (m) => ({ name: m, budget: 20 })`.
- `TC-DB-006` checks that the parent and its children are rolled back. A bookkeeping row from a rolled-back create has no parent id to look up, so cover it with an integrity check (e.g. "no audit row without its parent").
- `TC-DB-008` tries the other tenant on tenant A's path **and** on its own path with tenant A's id. The second is the object-level (IDOR) check that path checks miss.
- Not applicable? Set that part of the config to `null`. The test is then **skipped with a reason** in the report. It never silently passes.
- **SQLite allows one writer at a time.** The kit sets `busy_timeout` so tests wait for the app's lock. If the app itself reports "database is locked", run DB tests with `QA_WORKERS=1`.
- **Data-health checks** (`integrity`) run in parallel with the other tests, so they must be invariants that hold **at every instant**: rows written in one transaction, and cleanup that never leaves a half-deleted parent. They must also ignore rows the DB-rule test inserts directly (e.g. `NOT LIKE '%dbrule'`). For a final sweep after all writes, run them on their own: `npx playwright test --grep @data-health`.
- Numbers often come back as strings (`numeric`, `bigint`) and timestamps as `Date` or strings. Compare through `Number()` / `norm()` / `tsOf()`, never raw.
- SQLite: the app should store millisecond ISO timestamps, otherwise `updated_at` may not move within one second. `RETURNING *` needs SQLite ≥ 3.35.
- Never leave a test as a comment-only stub: it passes green while checking nothing. Implement it or mark it `test.fixme('reason')`.
- Tag `@db` for CI selection. Run in a job that has the test DB (service container, ephemeral DB, or `api` mode against dev).
- Keep PRs small: one feature per branch, at most 10–15 hand-written tests, the repo's branch convention. No AI co-author / "generated with" lines on commits or PRs.

### 8.6 Beyond the kit — hand-written DB checks

The kit covers what every create/update/delete feature has. Rules that only some features have are written by hand, in their own spec file next to `feature.db.spec.ts`. They use the same fixture (`db`, `runId`, `actor`), the same helpers and the same config, so they run in all three access modes and appear in the same report. Write one for each rule from sections 2–3 that the feature has:

- **State transitions:** the DB status after each allowed step; a refused step changes nothing; a guarded update with a stale state affects 0 rows.
- **Money and counters:** one business action makes exactly one effect (payment, ledger row); the amount equals what was sent; totals add up.
- **Concurrency:** two simultaneous writes with the same unique value leave one row; parallel increments end at the arithmetic result.
- **Bookkeeping on update and delete** (audit, history, outbox), and child-row behaviour on delete (cascade, block or detach) for each child table.
- **Bulk imports and background jobs:** rows in = rows out (minus reported rejects); a second run adds nothing.
- **RLS fail-closed** (PostgreSQL): set and reset the tenant context in the same session.
- **Migrations and data-lifecycle jobs** (sections 3.4 and 3.9): on a local or throwaway database only.

Rules: expected values come from the request the test sent; rows the marker cannot reach (idempotency keys, sessions, events) are deleted by id in a `finally` block; tag `@db`; hand-written tests count toward the 10–15 per PR.

Example for an invoice feature with an idempotent "pay" action. It was verified in all three access modes: green on the clean sample API, and red for each of three planted bugs (a retry charging twice, the invoice not marked paid, the pay audit row missing):

```ts
// invoices-pay.db.spec.ts — HAND-WRITTEN, project-specific DB checks on top of the kit (same fixture: db, runId, actor).
// Table, column and status names come from THIS project's data model (Step 1). The kit's cleanup still removes the invoice.
import { test, expect, feature as F } from '../db/db.fixture';
import { countRows, getRow } from '../db/db.helpers';

test.describe(`${F.name} — payment effects`, { tag: ['@db'] }, () => {
  test('pay writes one payment for the invoice total, marks the invoice paid, and a retry adds nothing', async ({ db, runId, actor }) => {
    const owner = await actor('owner');
    const sent = F.api.create.body(`${runId}_pay`);
    const created = await owner.post(F.api.collectionPath, { data: sent });
    expect(created.status(), await created.text()).toBe(F.api.create.status);
    const id = F.api.idOf(await created.json());
    expect((await owner.patch(F.api.itemPath(id), { data: { status: 'issued' } })).status(), 'issue the invoice').toBe(200);
    const key = `${runId}-pay`;
    try {
      const pay = () => owner.post(`${F.api.itemPath(id)}/pay`, { headers: { 'Idempotency-Key': key } });
      expect((await pay()).status(), 'first payment').toBe(201);
      expect((await pay()).status(), 'retry with the same key').toBe(200);
      const payments = await db.query<{ amount: string | number }>('SELECT amount FROM payments WHERE invoice_id = $1', [id]);
      expect(payments.map((p) => Number(p.amount)), 'exactly one payment, for the full invoice total').toEqual([Number(sent.total)]);
      const invoice = (await getRow(db, F.table, F.col.id, id))!;
      expect(invoice.status, 'the invoice is marked paid in the same transaction').toBe('paid');
      expect(await countRows(db, 'audit_logs', "entity_id = $1 AND action = 'pay'", [id]), 'one pay audit row').toBe(1);
    } finally {
      await db.query('DELETE FROM idempotency_keys WHERE key = $1', [key]); // a row the marker-based cleanup cannot see
    }
  });
});
```

---

## 9. Test-case template (manual sheet / Linear / Jira)

| TC ID | Title | Store / Table(s) | Precondition (seed) | Steps | SQL to verify | Expected in DB | Expected API | Priority |
|---|---|---|---|---|---|---|---|---|
| TC-DB-001 | POST creates one row with defaults | `<table>` | none | 1. POST `/<resource>` {name} 2. query | `SELECT * FROM <table> WHERE <marker>='qa_<run>_create'` | 1 row, status=default, created_at≈now, bookkeeping row present | 201, id = DB id | High |

Minimum coverage per endpoint: happy path, one negative per constraint, unchanged-columns check, bookkeeping check, tenant isolation, and (for delete) child-row behaviour. Per migration: fresh + existing + data-preservation + rollback. Per DB rule (trigger/fence/RLS): block path + allow path.

---

## 10. Definition of done for a DB test pass

- [ ] Stores, tables, write owners and delete mode (hard/soft) identified and written in the report (and in `tests/config/feature.config.ts` when automating).
- [ ] Before/after evidence for every create/update/delete case, including bookkeeping tables.
- [ ] At least one negative test per constraint; all return 4xx with DB unchanged.
- [ ] Every DB-enforced rule tested on both the block path and the allow path.
- [ ] Tenant/user isolation verified for every write endpoint (and RLS fail-closed where it exists).
- [ ] Transaction rollback verified for every multi-table write.
- [ ] Migrations verified on fresh and existing data, ledger checked, rollback exercised (local only).
- [ ] No test data left in the shared DB (`SELECT COUNT(*) ... LIKE 'qa_%'` returns 0 for this run).
- [ ] Sensitive columns never shown in evidence; no credentials in any artifact.
- [ ] Data-health (integrity) checks for the feature's invariants run and return 0 rows — or the offending rows are in the report.
- [ ] Feature rules outside the kit (state, money, concurrency, jobs) have hand-written checks (section 8.6) or a visible gap in the report.
- [ ] The automated suite was seen to FAIL at least once on purpose (e.g. set `bookkeeping.expected` to 2, or point `softDelete` at the wrong column) — a suite that never failed proves nothing.
- [ ] Failures went through root-cause analysis before a ticket was filed, and the ticket includes the exact query + masked rows.
- [ ] Report written (section 7) with verdict, evidence per failure and a "Not covered" list.

---

## 11. How this kit was verified

Verified on 19 Oct 2026 by **mutation testing** against three independent sample APIs with planted database bugs, switched on one at a time.

**The previous version was re-tested first, as published.** Its templates were copied verbatim and only the config file was filled. Result: **0 of 7 tests passed on both projects**, for three reasons:

- The generic spec called the API without logging in, so every real endpoint answered `401`.
- The direct-insert seed filled only 4 columns, which violated NOT NULL constraints.
- SQLite does not bind a positional array to `$1`.

**This version:**

| Sample project | Engine and access | Tests | Clean run | DB bugs caught |
|---|---|---:|---|---|
| Invoices (Orgs & Billing) | PostgreSQL · driver (`pg`), CLI (`psql-json.sh`), admin API · bearer login | 14 | 13 passed + 1 skipped (no idempotency header) in all 3 modes | **5 / 5** |
| Orders | SQLite · driver (`node:sqlite`), CLI (`sqlite-json.mjs`), admin API · cookie login | 13 | 13 passed in all 3 modes | **7 / 7** |
| Projects (unseen Workbench) | SQLite, all 3 modes · **configured blind** by a separate agent using only this skill + README, **no kit change needed** | 21 | 21 passed in all 3 modes | **5 / 5** DB-level (`archived_editable` is an API rule, caught by the API skill) |

- **Bugs caught:**
  - PATCH wiping an unsent column
  - a missing audit/history/event row (caught twice: by TC-DB-001 and by a data-health check)
  - a hard delete instead of a soft delete, and a soft delete instead of a hard delete
  - no transaction (half-written rows left behind)
  - another tenant deleting or updating through its own path (IDOR)
  - the tenant id in the body being applied
  - an idempotent retry writing a second row
- **Also run:**
  - On Belle's machine (Playwright 1.61.1, Node 22.23): 13 / 13.
  - The hand-written example in section 8.6, next to the full kit on Invoices, in all 3 modes: green on the clean API, red for each of 3 more planted bugs. No rows were left behind.
  - Every playbook query (section 6) on PostgreSQL and SQLite.
  - The PostgreSQL and SQLite bulk-data snippets. The MySQL snippet was **not** run (no MySQL server was available), so check it before relying on it.
- **Defects found and fixed during this testing** (now built in):
  - The psql wrapper broke on a data-modifying `WITH` statement.
  - SQLite "database is locked" errors under parallel tests → `busy_timeout`.
  - A teardown order that briefly broke a data-health invariant → one-statement parent+audit delete.
  - Recalculated columns reported as unexpected changes → `update.derived`.
  - PUT full replace overwriting the marker → `update.body` can take the marker.
  - The IDOR variant was missing from the tenant test.


---

## Glossary (plain language)

- **Constraint** — a rule the database enforces on data (required, unique, must point to a real parent).
- **Foreign key (FK)** — a column that must match an id in another table.
- **Cascade** — deleting a parent automatically deletes its children.
- **Soft delete** — the row stays but is marked deleted; **hard delete** — the row is removed.
- **Transaction** — a group of writes that all succeed or all roll back.
- **Trigger / fence** — code inside the database that runs on insert/update/delete; a *fence* rejects writes that break a rule, a *stamping* trigger fills columns like `updated_at` or writes history rows.
- **Row-level security (RLS)** — a database policy that filters every query by tenant/user automatically; "fail closed" means no context → no rows.
- **Bookkeeping** — side tables that must follow the main write: audit/history, outbox events, search index, counters.
- **Idempotent** — doing the same thing twice leaves the same result as doing it once.
- **Seed / teardown** — create test data before, remove it after.
- **Index** — a lookup structure that makes filtered queries fast; missing ones cause slow endpoints.
- **N+1** — one query for a list plus one extra query per item; a common performance bug.
- **Migration** — a scripted change to the database structure; **rollback** — the script that undoes it; **ledger** — the table that records which migrations were applied.
- **Expand–contract** — shipping a schema change in two phases (add new, then remove old) so old and new code can run together during deploy.
- **Write owner** — the one service/component allowed to write a table; rules for that table usually live there.
- **Hot table** — a table with very high write volume where every extra rule costs performance.
- **Run marker** — a unique value (`qa_<time>_<random>`) put in every row a test creates, so assertions and cleanup touch only that test's rows.
- **Data-health / integrity check** — a query that must always return 0 rows (no orphans, no duplicates, no missing audit rows); any row it returns is a data defect.
- **Access mode** — how tests reach the database: a driver (direct connection), a CLI wrapper, or an admin API endpoint.
- **Derived column** — a column the server recalculates from others (e.g. a margin from an amount); it legitimately changes when its source changes.