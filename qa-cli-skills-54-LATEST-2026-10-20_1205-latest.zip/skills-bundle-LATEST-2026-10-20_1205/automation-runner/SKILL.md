---
name: "automation-runner"
description: "Generate automated test suites from Linear issues, markdown reports, Excel QA test cases, or the live QA Google Sheet. Use when the user says 'Automation [TICKET-ID]' (Linear flow), 'Auto [TC-ID / Feature / sheet]' (Excel pipeline), or asks to generate automation from the Google Sheet test suite for a range of TC IDs. Triggers on: automation, Auto TC-, Auto [feature], generate automated tests, create E2E tests, playwright tests, regression tests, automate test cases, write test files, run full pipeline."
---

# Automation Runner

Three trigger modes — read the user's prompt and pick the right one. **Mode C is the one used for `eng-guardrails-platform` in practice** (manual re-test of a Google Sheet range, then generate scripts for the real TS codebase) — read it first if the repo is `eng-guardrails-platform`.

---

## ⚠️ Repo-reality gate — READ THIS BEFORE GENERATING ANYTHING

Modes A and B below describe a generic pipeline (Python/pytest-flavored in places, ad hoc POM-per-test in others). **`eng-guardrails-platform`'s real `automation/` directory does not match that generic pipeline.** Before writing a single file, confirm the target repo and, if it is `eng-guardrails-platform`, follow this section instead of Mode A/B's generic templates:

- **Language: TypeScript + Playwright only.** Never emit `.py`/pytest — `test-script-generator`'s Python template does not apply to this repo.
- **Location — two coexisting patterns, use the right one:**
  - Most feature areas are flat under `automation/playwright-test/tests/admin/<feature-slug>/*.spec.ts` (e.g. `admin/ai-gateway/`, `admin/audit-logs/`, `admin/data-protection/`, `admin/company-knowledge/`) — one folder per feature, no further nesting. Default to this pattern for anything outside the Security workspace.
  - The **Security workspace specifically** uses a three-level, folder-per-sub-feature layout — deeper than anywhere else in `tests/`:

    ```
    automation/playwright-test/tests/security/<navigator-slug>/<sub-feature>/<sub-feature>.spec.ts
    ```

    Level 1 (`security/`) is the workspace. Level 2 (`<navigator-slug>`) is the left-nav item shown inside that workspace. Level 3 (`<sub-feature>`) is one folder per spec subject, and **the filename drops the area prefix** — the path already carries the context, so `security-logs-events.report-queue.spec.ts` would be triply redundant. When a sub-feature has exactly one spec the filename repeats the folder (`report-queue/report-queue.spec.ts`); when it has several, the folder stays the sub-feature and each file is named for its aspect (`all-events/export.spec.ts`, `smart-routing/smart-routing-layout.spec.ts`).

    The five Security navigators and their current state (migrated 2026-08-20):

    | Navigator | Route | Folder | Specs |
    |---|---|---|---|
    | Overview | `/ai-data-protection/overview` | — | incidental only, no dedicated suite |
    | Security Graph | `/admin/security-graph` | — | **no coverage** (page is live — real gap) |
    | AI Gateway | `/ai-data-protection/gateway` | `security/ai-gateway/` | 8 |
    | Logs & Events | `/ai-data-protection/logs` | `security/logs-events/` | 9 |
    | Endpoint AI Security | `/admin/security/shadow-ai/*` | `security/endpoint-ai-security/` | 7 |

    ```
    tests/security/ai-gateway/{caching,integrations-siem,navigation,pages-validation,provisioning,rate-limits}/<same>.spec.ts
    tests/security/ai-gateway/smart-routing/{smart-routing,smart-routing-layout}.spec.ts
    tests/security/endpoint-ai-security/{coverage,dashboard,degraded-cross-cutting,destinations,navigation,settings,tools}/<same>.spec.ts
    tests/security/logs-events/all-events/{all-events,export,siem-timerange,user-filter}.spec.ts
    tests/security/logs-events/{ai-sessions,configuration-audit,dashboards,navigation,report-queue}/<same>.spec.ts
    ```

    Two non-obvious groupings, both deliberate — don't "correct" them:
    - **AI Sessions lives under `logs-events/`** because the QA Security sheet's own TC-SS numbering ties it to Logs & Events, even though the live page now renders under Data Management (its POM is `pages/admin/company-knowledge/companyKnowledgePage.ts`).
    - **Endpoint AI Security is the product name for Shadow AI.** The old folder was `tests/admin/shadow-ai/` and the POM is still `pages/admin/shadow-ai/shadowAiPage.ts`, whose header reads "Platform Admin › Security › Shadow AI (Endpoint AI Security)". Search for *both* names before concluding a navigator has no coverage.
    - **`audit-logs` was also Logs & Events.** `tests/admin/audit-logs/` targeted the same `/ai-data-protection/logs` route and the same `ActivityLogsView` DOM under a second POM (`auditLogsPage.ts`), so it folded into `logs-events/all-events/`. When migrating a navigator, grep by **route**, not just by folder name, or you leave half the coverage behind.

    **Import depth is one level deeper than the rest of `tests/`** — that extra folder breaks every relative import if you copy a spec in from a two-level folder. Note `fixtures/` sits at `automation/fixtures/`, one level *above* `playwright-test/`, while `pages/` and `utils/` are inside it — which is why the two counts differ. From `tests/security/<nav>/<sub>/`:

    ```ts
    import { test, expect } from '../../../../../fixtures/auth';   // automation/fixtures
    import { ... } from '../../../../pages/<area>/<feature>Page';  // playwright-test/pages
    import { ... } from '../../../../utils/validators';            // playwright-test/utils
    ```

    Migration mechanics that bit on the real move:
    - **Rewrite longest-pattern-first and anchor on the quote.** Fix `'../../../../fixtures/` → `'../../../../../fixtures/` **before** touching `'../../../` prefixes; a naive global replace of `../../../` mangles the fixtures path into `../../../..././fixtures`. Anchoring each pattern on the opening quote also makes the sed idempotent, so re-running it over already-correct files is a no-op.
    - **Verify, don't trust the sed.** Walk every import and assert the target file actually exists on disk — 89 imports across 24 specs, 0 missing, is a check that takes seconds and catches what `--list` won't.
    - **Re-run prettier after the rewrite, not just before.** Adding `../` lengthens import lines; one crossed the print width and had to be reflowed into a multi-line import. Formatting drift caused by your own path edit is easy to miss.
    - **Empty source directories can't be deleted from the device sandbox** (`rmdir` → `Operation not permitted`). `mv` them into `_to_delete/` and tell the user, rather than leaving stale empty folders in place.

    This layout was introduced 2026-08-20, migrating the old flat `admin/security-logs-events/` folder. If you find specs still under `admin/security-logs-events/`, that's stale: move the whole folder, not just the files you're touching, so Logs & Events coverage never sits in two places at once.
  - Either way: mirror the existing `automation/playwright-test/pages/<feature-area>/<sub-feature>/` Page Object layout, and find the closest existing feature-area folder before inventing a new one.
  - A test can live in a different tests/ folder than the Page Object that powers it, when the QA sheet's own taxonomy and the page's actual current location disagree (e.g. AI Sessions tests sit in `tests/security/logs-events/` but import from `pages/admin/company-knowledge/companyKnowledgePage.ts`, because that's where the real locators/helpers are defined) — reuse the real POM, never fork a duplicate one just to keep imports folder-local. Say so explicitly in a file-top comment so the next reader isn't confused by the cross-import.
- **Shared auth fixture, not ad hoc login code:** `import { test, expect } from '../../../../fixtures/auth'` (path depth varies by nesting), then `await authenticatedAs('platform_admin' | 'chat_user' | 'super_admin' | ...)` in `test.beforeEach`. Never hand-roll a login flow inside a spec.
- **Page Objects are centralized, not one class per spec.** Add new `goto*`/locator helpers to the existing `pages/<area>/<feature>Page.ts` file for that feature area rather than generating a new `.page.ts` per spec file (Mode B's POM template is aspirational for greenfield repos; this repo already has the pattern, just extend it).

## Branch naming (MANDATORY for every automation-generation task in this repo)

Create the work on a dedicated branch named:

```
test/<feature-slug>-automation-coverage
```

- `<feature-slug>` is a short kebab-case name for the feature area being automated (e.g. `security-logs-events`, `costs-and-budgets`, `user-settings-security`) — match the folder name under `automation/playwright-test/tests/` where possible.
- Real examples already in this repo's branch list: `test/costs-and-budgets-automation-coverage`, `test/security-logs-events-automation-coverage`, `test/user-settings-playwright-coverage` (older, less-preferred naming — prefer the `-automation-coverage` suffix going forward for consistency), `test/user-settings-test-coverage`.
- Never generate automation directly on `develop`/`main`, and never use a vague name like `automation-fix` or `belle/tests`, and never leave a `-v2`/abandoned-attempt branch behind — delete it once you've moved to the real branch name.

## Tag convention (MANDATORY — replaces Mode A's `{ tag: '@{TC-ID}' }`-only template)

Every generated `test(...)` / `test.fixme(...)` call must carry **all four** of the following in its `tag` array, in this order:

```typescript
test(
  'TC-SS-031: Security Events shows a Degraded delivery banner with Configure',
  { tag: ['@TC-SS-031', '@App.PlatformAdmin.Security.LogsEvents', '@P3', '@regression', '@dev'] },
  async ({ page, authenticatedAs }) => { /* ... */ }
);
```

1. **Test case ID** — `@TC-<ID>`, exactly as it appears in the sheet/ticket (e.g. `@TC-SS-028`, `@TC-PA-345`). If a test already carries other TC-IDs (e.g. it was written for `@TC-PA-333` and the Security sheet's `TC-SS-028` covers the same case), add the new ID alongside the old ones rather than replacing — don't lose the cross-reference.
2. **App/feature path** — `@App.<Area>.<SubArea>...` dot-path, matching (or extending) the `@App.*` tags already used as `test.describe` labels elsewhere in the same feature folder.
3. **Priority** — `@P1` / `@P2` / `@P3`, taken from the sheet's Priority column (or `@critical` only where the existing file already uses that convention instead of `@P1`).
4. **Status/taxonomy tag — `@regression` vs `@known-gap` (not interchangeable):**
   - **`@regression`** — the test is blocked (if at all) by a real, filed, *fixable* defect — the sheet's/ticket's described behavior is still the correct target, and this test will go green once someone fixes the bug. This is the default for a passing test, and for `test.fixme` blocks with a real Linear/Jira key in the FIXME comment.
   - **`@known-gap`** — the test's *premise* no longer matches the live product (a redesign, a removed feature, stale sheet wording) — there is no bug to fix, the test case itself needs re-scoping or retiring. Confirmed convention: `user-settings-profile.fields.spec.ts`, `user-settings-profile.avatar.spec.ts` (×2), `notifications.rendering.spec.ts` — all `test.fixme` + `@known-gap`, **never** `@regression` on the same test. Use this whenever your own FIXME comment says "spec gap" / "no longer exists" / "was redesigned" rather than "blocked by bug X".
   - These two tags are mutually exclusive on one test — pick the one that matches what you actually wrote in the FIXME comment above it. (Do not confuse with `@known-bug`, which appears in the generic Aegis rubric but is **not** this repo's real tag — this repo uses `@known-gap`.)
5. **Environment tag(s)** — at least one of `@dev` / `@staging` / `@prod`, reflecting where the test actually runs/was verified. Default to `@dev` for anything verified only on Dev (the primary QA environment per `shared-qa-base`); add `@staging`/`@prod` only once the test is confirmed to also run cleanly there.

**Why this matters:** the pre-existing `automation/playwright-test/tests/user-settings/security/*.spec.ts` files only tag `[App, TC-ID, Priority, @regression]` — no environment tag — which is the exact gap Belle flagged on 2026-08-20 ("the tags are not correct, the tags must have regression, env, and priority... including the test case id"). Going forward, every new spec gets all four (five, counting the regression/known-gap split); when touching an existing spec for another reason, backfill the missing env tag rather than leaving it.

## Handling a currently-failing feature (test.fixme, not a fabricated pass)

When the manual test that preceded automation generation found the feature broken, do **not** write assertions that pretend it works — but *why* it's broken decides the tag (see Tag convention #4 above), not just whether to use `test.fixme`:

- **Blocked by a real, fixable defect** (backend error, page never loads, etc.): use `test.fixme(...)` with the four-part tag array using `@regression`, plus a one-line `FIXME:` comment naming the blocking bug (Linear/Jira key if filed). It's already written and starts passing the moment the bug is fixed.
- **The test case itself is stale** (the described UI/flow doesn't exist anymore, was redesigned, or never matched the current implementation): use `test.fixme(...)` with `@known-gap` instead of `@regression`, and a FIXME comment that says what you actually found missing (grep the component source before concluding this — don't assume, confirm) plus a recommendation to re-scope or retire the TC. Write the body as navigation + `// TODO:` comments describing what a real assertion would need once re-scoped — never a fabricated `expect()` against UI that isn't there.

Follow the existing repo convention either way (see `user-settings-security-01.spec.ts` for the `@regression` case, `user-settings-profile.avatar.spec.ts` for the `@known-gap` case).

## Write-it-right checklist (the findings that sink QA PRs in review)

These come from the multi-round review of PR #11493 (User Settings, 272 cases — reviewed by David, Kyle, Greptile and Codex). Every one passed eslint, `tsc`, and `playwright test --list` and still had to be fixed. Check each **while writing**, not after:

1. **Mutating a shared account? Restore in `try/finally`.** `chat_user` / `platform_admin` / `super_admin` are shared real accounts. A display-name, locale, model or density change restored *after* the assertions leaks on any failure. Then tag `@serial-account` and route it to the dedicated serial Playwright project (`grepInvert`-ed out of the parallel projects) — a shared `beforeEach` does not serialize anything.
2. **Authenticate as the role the surface requires.** An `/admin` assertion under `chat_user` just 403s, so the test verifies nothing. Put the role change in its own `describe`. A test of unauthenticated behavior must not inherit an authenticating `beforeEach`.
3. **Grep the component for every testid before you use it.** `--list` collects specs that reference testids which don't exist — the failure only shows at runtime, or hides behind a trivially-passing check. If the control the test case describes is gone, that's a spec gap (`@known-gap`, re-scope or retire) — never retarget at a similar-looking control and claim the original coverage.
4. **Perform the interaction the test name claims.** A double-submit guard does a real `dblclick()` and asserts exactly one request fired; a single click plus a disabled-attribute check is a proxy that passes even when the behavior is broken. Assert the observable side effect (request count, persisted value) over intermediate UI state.
5. **Delete what the test creates, in `finally`, in the test.** Global teardown runs under one identity and silently misses resources created under another.
6. **Moved or renamed a shared helper? Run unscoped `playwright test --list` before and after.** One stale import aborts the entire scan — on #11493 a moved `helpers.ts` took repo-wide discovery from 11,222 tests to 0 while the scoped `--grep` still looked fine.
7. **Confirm the tag you shipped is actually in a CI matrix entry.** A suite no CI job greps is source, not coverage — "added-but-never-run is a real gap, not verified coverage." In this repo CI selects automation two ways, and **neither is path-based** (so folder moves are CI-safe, but folder *presence* proves nothing): explicit spec paths under `automation/<area>/…`, or `--grep` on a domain tag. The greps that exist are `@automation.*`, `@suite.browser.*`, `@translation.platform`, `@App.UserSettings`, and one hardcoded `@api-test.*@chat` matrix value. Only 8 of ~391 specs under `playwright-test/tests/` carry an `@automation.*` domain tag, so most of that tree — including all of `tests/security/**` — is not reachable by any CI job. `@App.*` tags alone do **not** route a suite; `@App.UserSettings` works only because PR #11493 explicitly added it to the `settings-tests` matrix. Adding a suite means adding a domain tag *and* a matrix entry. `scripts/check-e2e-domain-collection.ts` fails CI when a `--grep` domain collects 0 specs, which catches a typo'd pattern but never catches an untagged suite.
8. **Strict TypeScript.** No `any`; prefer `unknown` + type guards, `??` for nullish, and real union types for things like tab/subpage names. Keep helper modules under ~200 lines and specs roughly 100–300.
9. **Anchor every server-backed step on the network call, not on the clock or on UI alone.** If a click/fill/submit sends a request the test's outcome depends on (create, update, delete, save, search, filter, sort, paginate, export, toggle a persisted setting), wait for that request/response with `page.waitForResponse` / `page.waitForRequest` — registered **before** the action — and assert on it. See the next section for the exact patterns.

## Network-anchored assertions — `waitForResponse` / `waitForRequest` (MANDATORY)

**Why:** most flaky failures in this repo come from the test reading the screen before the server has answered — the UI still shows the old value, a toast hasn't appeared yet, or a list hasn't refreshed. A fixed sleep only hides this (and breaks under CI load); `networkidle` never settles on pages that poll. Waiting on the *specific* API call the step triggers removes the race, and asserting on that call proves the server actually did the work — not just that the UI changed.

**Plain-language rule:** "start listening → do the action → wait for what you were listening for → check it → then check the screen."

### Rule N1 — Register the wait BEFORE the action (the #1 cause of the flake)

```typescript
// ❌ RACE — the response can arrive before waitForResponse starts listening → random timeout
await budgetsPage.saveButton.click();
await page.waitForResponse((r) => r.url().includes('/api/v1/budgets'));

// ❌ DEADLOCK — awaiting the wait first means the click never happens
await page.waitForResponse((r) => r.url().includes('/api/v1/budgets'));
await budgetsPage.saveButton.click();

// ✅ store the promise, act, then await it
const saveResponse = page.waitForResponse(
  (r) => new URL(r.url()).pathname === BUDGETS_API && r.request().method() === 'POST',
);
await budgetsPage.saveButton.click();
const response = await saveResponse;
```

`Promise.all([page.waitForResponse(...), locator.click()])` is also correct; the stored-promise form above is preferred because it reads top-to-bottom and the variable can be reused for assertions.

### Rule N2 — Match precisely: path + method (+ body when needed)

A loose `url().includes('/api/')` matcher can resolve on a *different* call (a background poll, a prefetch, a CORS `OPTIONS` preflight) and the test continues too early — a flake that looks like a pass.

- Compare `new URL(r.url()).pathname` against a **named constant** (`BUDGETS_API`), never an inline full URL (A4: no hardcoded hosts).
- Always check the HTTP method: `r.request().method() === 'POST'`.
- When one endpoint serves several operations (e.g. a GraphQL or batch endpoint), also match on the request body: `r.request().postDataJSON()` (type it `unknown`, narrow it).
- **Find the real endpoint before writing the matcher** — grep the frontend API client/hooks for the path, or watch the Network tab during the manual test. Never guess the URL (same principle as checklist item 3 for testids).

### Rule N3 — Assert on the network result, then on the UI

Two separate checks, both required for a mutation test:

```typescript
const response = await saveResponse;
// 1. the server accepted it — exact status from the API contract, not just "ok"
expect(response.status()).toBe(201);

// 2. read what the server returned (typed unknown → narrowed, no `any`)
const created = readBudget(await response.json()); // throws if the shape is wrong

// 3. the UI shows what the SERVER returned (web-first, auto-retrying)
await expect(budgetsPage.rowByName(created.name)).toBeVisible();
```

- `readBudget` is a small named reader that takes `unknown`, checks the fields exist with type guards, and returns a typed object — `response.json()` is `any`, so never use it untyped (A10).
- Use the response payload as the **independent source** for the UI expectation (A18 anti-vacuity) — don't read the expected value off the same screen you're asserting.
- **Negative tests:** assert the error status (`expect(response.status()).toBe(422)`) **and** the visible error message. A UI error toast with a 200 response is a bug; a 4xx with no message is a bug.
- `waitForResponse` does **not** replace the UI assertion. The network check proves "the server did it"; the web-first `expect` proves "the user can see it". Keep both.

### Rule N4 — Use `waitForRequest` to assert what the UI SENT

For filters, search, sorting, pagination, and form submissions, the bug is often in the outgoing request (wrong param, missing field). Assert it directly:

```typescript
const filterRequest = page.waitForRequest(
  (r) => new URL(r.url()).pathname === LOGS_API && r.method() === 'GET',
);
await logsPage.applyUserFilter(email);
const request = await filterRequest;

const params = new URL(request.url()).searchParams;
expect(params.get('user')).toBe(email);
expect(params.get('page')).toBe('1'); // filter change resets pagination
```

For POST/PUT bodies: `readSettingsPayload(request.postDataJSON())` → assert the exact fields the form should send.

### Rule N5 — Double-submit / "exactly one call" tests

Count requests with a listener, perform the real interaction, wait for the response, then assert the count:

```typescript
let saveCalls = 0;
page.on('request', (r) => {
  if (new URL(r.url()).pathname === BUDGETS_API && r.method() === 'POST') saveCalls += 1;
});
const saveResponse = page.waitForResponse(
  (r) => new URL(r.url()).pathname === BUDGETS_API && r.request().method() === 'POST',
);
await budgetsPage.saveButton.dblclick();
await saveResponse;
await expect(budgetsPage.successToast).toBeVisible(); // UI settled — no sleep
expect(saveCalls).toBe(1);
```

### Rule N6 — Use the response for cleanup

Capture the created resource's id from the response and delete it via the API helper in `finally` (checklist item 5). This is more reliable than finding it again in the UI.

```typescript
const created = readBudget(await (await saveResponse).json());
try {
  // ...assertions...
} finally {
  await deleteBudgetViaApi(request, created.id); // `request` = Playwright's APIRequestContext fixture
}
```

### Rule N7 — Put matchers in the Page Object, not in every spec

Add an action helper to the existing centralized POM so the endpoint + method live in one place:

```typescript
// pages/<area>/<feature>Page.ts
async saveAndWaitForResponse(): Promise<Response> {
  const response = this.page.waitForResponse(
    (r) => new URL(r.url()).pathname === BUDGETS_API && r.request().method() === 'POST',
  );
  await this.saveButton.click();
  return response;
}
```

(`import type { Response } from '@playwright/test';`.) Specs then assert on the returned `Response`. Keep API path constants next to the POM (or in the existing `utils/` constants module if one already exists — check siblings first).

### When NOT to use it

- **Pure client-side UI** (expand/collapse, tooltip, tab switch with no fetch, client-side validation) → a web-first `expect(...)` alone is correct. Don't invent a network wait.
- **Navigation** → `await expect(page).toHaveURL(...)` / `page.waitForURL(...)`, plus `waitForResponse` only for the data call the page needs.
- **Cached data** (SWR/React Query cache hit) may not fire a request at all — confirm in the Network tab that the call really happens every time, or the wait will time out intermittently.
- **Never** use `waitForLoadState('networkidle')` as the main wait on this app — several pages poll, so it either never settles or settles at a random moment.
- **No per-call `{ timeout: N }` magic numbers** on these waits; rely on the config's timeouts. If a slow endpoint genuinely needs more, use a named constant with a comment explaining why.

## Quality gate — run automation-aegis before calling the task done

Before treating generated/edited specs as finished (and before committing), run the **automation-aegis** skill against exactly the files you touched. Two things matter beyond what Aegis's generic rubric says on its own:

1. **Calibrate against sibling files in the same folder first**, not just the generic rubric — grep for the pattern you're about to use (tag combos, `test.describe` title format, import style) across 3-5 sibling specs before scoring your own file. The generic rubric can be wrong for this repo in specifics (e.g. it says `@known-bug`; this repo's real tag is `@known-gap` — see Tag convention #4). A finding grounded in "6 sibling files do X, this file does Y" is worth more than a finding grounded only in the abstract rubric.
2. **Fix what Aegis finds before presenting the result**, don't just report it — the 2026-08-20 TC-SS-028..032 pass caught a real `@known-gap` vs `@regression` mismatch and a `test.describe` title format inconsistency this way; both were one-line fixes, applied immediately, then re-verified with prettier + `playwright test --list`.

---

## Mode A — `Auto [TC-ID | Feature | Sheet]` → Excel Pipeline

(Unchanged from before — still valid for the Excel-workbook-based repos/flows. **Do not use this mode's Python/pytest template or its generic `generated_tests/` folder structure for `eng-guardrails-platform`** — use the repo-reality gate above instead.)

[... existing Stage 1–4 content retained as before ...]

---

## Mode B — `Automation [TICKET-ID]` → Linear Issue Flow

(Unchanged from before for the general POM/output-structure guidance. **For `eng-guardrails-platform` specifically**, adapt: reuse the existing centralized Page Object per feature area instead of generating a fresh `.page.ts` per spec, and apply the Branch naming + Tag convention sections above instead of Mode B's untagged `test.describe('[GR-{ticketID}] ...')` example.)

---

## Mode C — Google Sheet manual-retest → automation (used for `eng-guardrails-platform`)

Trigger: a request to manually re-test a range of TC IDs from the live QA Google Sheet and then generate automation for them (e.g. "do the manual test of the Security sheet from SS-028 to SS-32, and then generate the automation scripts").

1. Read the sheet range via `mcp__Google_Drive__read_file_content` (natural-language export) or the gviz/tq CSV endpoint (see `linear-ticket-writer`'s Step 1 fetch method) — do not assume the sheet's last-recorded Status/Actual Result still reflects reality; re-verify live.
2. Execute each TC live on Dev per `manual-test-executor` (Layer 2 code check → Layer 1 UI → Layer 3 integration), running `root-cause-forensics` on every ❌ Fail before moving to the next TC. **While testing manually, note in the browser Network tab the exact API path + method each action calls** — you need it for the `waitForResponse` / `waitForRequest` matchers (Rule N2).
3. Update the sheet itself via `google-sheets-status-updater` with today's Actual Result/Status — the sheet is the source of truth for the next person, not just this session's memory.
4. Create the branch (see Branch naming above), then generate `.spec.ts` files per the repo-reality gate above — full assertions for passing TCs (network-anchored per Rules N1–N7 for any server-backed step), `test.fixme` with the correct `@regression`/`@known-gap` split (see Tag convention #4) for TCs that aren't a clean pass.
5. Validate with the working device_bash gates from `reference_automation-codebase-conventions.md`: `npx prettier --write`, `npx tsc --noEmit -p tsconfig.eslint.json`, `npx eslint ... --cache-location /tmp/xyz --max-warnings=0`, `npx playwright test --list --grep "@App.X"`, **plus an unscoped `npx playwright test --list` whenever the diff moved/renamed/deleted a shared helper** (see checklist item 6 — the scoped grep will not reveal a zeroed-out repo-wide scan). If the sandbox's memory/time ceiling can't complete `tsc`/`eslint` (a real, recurring limitation in the device_bash VM — 3.8GB RAM, ~45s per command), say so plainly rather than claiming a pass; prettier + `playwright test --list` passing is still real signal, just not the whole gate. Per `AGENTS.md`, always report what passed **and what could not run** — never imply a gate you didn't execute.
6. **Run `automation-aegis`** against exactly the files you touched (see Quality gate section above) and fix what it finds before presenting the work as done.
7. If a manual test failed for a real product reason (not env/spec-gap), file it via `root-cause-forensics` → `linear-ticket-writer` **before** or alongside writing the automation, so the `test.fixme` FIXME comment can cite the real ticket key.