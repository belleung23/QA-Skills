---
name: "pr-closeout"
description: "Final merge-readiness check for any pull request — returns exactly one verdict (READY_FOR_HUMAN_MERGE / NOT_READY / BLOCKED) with blockers, CI summary, thread dispositions, governance result, evidence and residual risk. Also checks the PR title and body against a standard shape. Triggers: pre-merge, closeout, is this PR ready to merge, merge readiness, check the PR body."
---

# PR Closeout

A read-mostly synthesis of a pull request's current state, ending in exactly one verdict. It
may make tiny PR-body or doc fixes when the user explicitly asks; its job is to say whether the
PR is ready for a **human** to approve and merge. You never approve or merge, and you never post
the verdict to the PR unless the user asks.

The checklist is a generalisation of a real team's pre-merge contract. Where this repo has its
own version, the repo wins.

## Step 0 — Learn the project's rules

Read, if present: `REVIEW.md`, `CONTRIBUTING.md`, `AGENTS.md`, `CLAUDE.md`, the PR template,
`CODEOWNERS`, any `docs/sdlc/`, `docs/governance/` or "high-risk paths" list, and the branch
protection / required-checks configuration you can see on the PR. Note: required ticket link,
required bot review (e.g. a `@codex review` comment), reviewer-count rules for sensitive paths,
size guidance, forbidden actions (no `--no-verify`, no `git add -A`, no attribution lines, etc.).

## Step 1 — Gather current state (not a stale handoff)

Use live sources: `gh pr view <n> --json ...`, `gh pr checks <n>`, REST fallbacks, or the
browser if the CLI is not authorised. Collect:

- head SHA, base branch, how far behind base, mergeability and merge-conflict state
- required checks: passing / failing / pending / skipped, and which are required vs advisory
- all review threads (inline, formal reviews, issue-level bot comments — expand resolved ones)
- the PR body as it stands now
- the diff file list, so you can see which governed/sensitive paths it touches
- advisory signals: size advisory, security scans, coverage analysis, lint/quality scores

## Step 2 — Run the checklist

Mark each item pass / fail / not applicable, with one line of evidence.

**Freshness and CI**
- Branch is current enough that CI and review are meaningful (not many commits behind base;
  no conflicts). Don't rebase just to be tidy — only if the project requires base freshness, a
  reviewer asked, or review comments were just addressed.
- Every required check passes, or a failing one has a documented baseline reason the project
  accepts. Pending required checks mean NOT_READY, not ready.
- Evidence posted earlier is for the **current** head. Green results on an older commit are not
  proof for this one.

**Review threads**
- Every actionable comment has a real disposition: Fixed, Declined with a technical reason, or
  Tracked to a linked ticket. Zero unresolved threads. Issue-level bot findings count too, even
  though the thread view hides them.
- Reviewer availability stated per bot: reviewed this head with N findings, or did not run.
- Required bot review was summoned (if the project requires a comment to trigger it) or a
  visible note explains why it could not be.
- Human reviewer assignment follows the project: usually exactly one owner for the touched paths;
  a second human only when the diff touches paths the project marks as two-reviewer (CI
  workflows, auth, billing, secrets, infra). Bots never count as approvals.

**PR body versus reality**
- The body matches the actual diff and the validation that was actually run. Test counts, file
  counts and "all passed" claims are re-checkable against the head.
- A tracking ticket/issue is linked if the project requires one (many require it even for tests
  and docs). If it is missing and the team tolerates that for this PR type, it must be written as
  an unmet deviation, not implied as satisfied.
- "Done" is not implied anywhere without current code, checks, tracker, review and evidence state.

**Governed and sensitive paths** (adapt to the repo's list)
- CI/workflow files, auth, tenant isolation, data protection, secrets/config names, infra,
  database ownership, shared packages: the project's governing doc was read and its required
  checks and source references are present in the PR.
- Database/SQL/migration changes carry proof from the real runtime the project cares about (a
  local emulator run, a migration preflight), not just "it worked against remote".
- New secret / env var / binding names are classified (is it a flag? config? needed at all?) per
  the project's rule, and land together with their consumer.
- Dependency, security and CI changes have the reviewers those changes require.

**User-facing changes**
- Browser proof (screenshots or a recorded run) and accessibility proof are current for this head.
- Design-system / UI section of the body is filled in when UI files changed; "N/A — no UI change"
  is valid only when no UI files changed.
- New interactive elements carry stable test ids; user-visible strings go through the i18n layer.

**Fixture-pinned and generated files**
- If the diff touches config, workflow, SQL, shell, governance docs or generated code, grep the
  test tree for each changed basename and confirm the matching suites were run — changed-file test
  selection usually does not pick them up, and they are what dequeue PRs in merge queues.

**Hygiene**
- No secrets, tokens, credentials or private data in the diff, body or comments.
- Commits and PR text follow the project's and user's conventions (including any rule about AI
  attribution lines).
- Size within the project's guidance, or the body justifies why it must ship together.

## Step 3 — Check the title and body shape

Title states the outcome for a user, operator, maintainer or auditor — not the code action.
`fix bug`, `update`, `add tests`, `follow-up` are not titles. Good: `Remove two smoke tests that
re-check the health endpoint` or `Keep the receipt reference on evaluate refusals`.

Body — the minimum sections that make the PR a durable record a cold reader can follow:

```md
## Outcome
What meaningful product, user, operational, security, compliance or maintainer outcome this creates.

## Source / Evidence
Links to the report, incident, screenshots, logs or design that motivate or prove the work.

## Tracking
Ticket/issue, owner, branch, base, review state, related PRs.

## Scope
What changes (files, behavior, counts).

## Boundaries
What does not change: explicit non-goals, things deliberately left for follow-up.

## Acceptance / Proof
How success is judged and the validation that proves it — commands run, counts, results,
and what was NOT run (left to CI, no browser run).
```

Add only when they add value: `Risk / Rollback` (blast radius, how to revert, how to validate),
`Reuse` (what you searched for before adding a new helper/hook/component and what you found),
`Architecture / ADR`, `Validation Commands`, `Follow-ups`.

Quality bar — flag the body if: the title is vague; it omits why the work matters; tracking or
proof is missing; scope boundaries are unclear; it contains stale generated residue, placeholders,
broken links, boilerplate, or mocked behavior presented as production-ready; or it describes a
mid-review snapshot rather than the current state.

## Step 4 — Return exactly one verdict

- `READY_FOR_HUMAN_MERGE` — everything above passes or is N/A; only human approval/merge remains.
- `NOT_READY` — something the author can still fix: failing or pending required checks, an open
  thread, stale evidence, a body that doesn't match the diff, missing proof.
- `BLOCKED` — a PR-level condition outside the author's hands: CI infrastructure down, a change
  that genuinely needs a human-only action (setting a secret value, applying a migration,
  dispatching a privileged workflow). BLOCKED is never a way to avoid dispositioning individual
  review comments — each still needs Fixed / Declined / Tracked.

## Output shape

```
Recommendation: READY_FOR_HUMAN_MERGE | NOT_READY | BLOCKED
Head: <sha> · base <branch>, <n> behind · mergeable: yes/no

Blockers: <numbered, each with the fix or the human action needed — or "none">
CI / checks: <required: x passed, y failing (names), z pending> · <advisory notes>
Review threads: <N total, N resolved; Fixed a / Declined b / Tracked c> · reviewer availability per bot
Governance / security: <governed paths touched and whether their requirements are met; scans>
Validation evidence: <what was run on this head, with counts; what was not run>
PR body: <matches diff: yes/no; title ok: yes/no; missing sections>
Residual risks and required human action: <plain language, for the approver>
```

Explain each blocker in plain language — what it is, why it matters, what to do. The approver
may not have read the diff.