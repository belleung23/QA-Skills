#!/usr/bin/env python3
"""
Post a Markdown comment to a Linear issue, and/or transition its workflow state.

Successor to post_jira_comment.py. No markdown-to-wiki-markup conversion is needed —
Linear comments are Markdown natively, so the comment file is posted verbatim.

Usage:
    python3 .claude/skills/linear-comment-writer/scripts/post_linear_comment.py GR-1234 \
      --comment-file test-reports/linear-comments/GR-1234_2026-04-23_comment.md

    # Transition to Ready To Release after a passing QA run
    python3 .claude/skills/linear-comment-writer/scripts/post_linear_comment.py GR-1234 \
      --comment-file test-reports/linear-comments/GR-1234_2026-04-23_comment.md \
      --transition "qa passed"

    # Transition only (no comment), e.g. move to In QA at test start
    python3 .claude/skills/linear-comment-writer/scripts/post_linear_comment.py GR-1234 \
      --transition "start qa" --transition-only
"""

from __future__ import annotations

import argparse
import json
import os
import sys
import urllib.error
import urllib.request
from pathlib import Path

LINEAR_API_URL = "https://api.linear.app/graphql"
TEAM_KEY = "GR"

# Named "transitions" mapped to the Linear workflow state they land on.
# Keep these names in sync with the actual state names configured on the Linear team.
TRANSITION_TO_STATE = {
    "start qa": "In QA",
    "qa passed": "Ready To Release",
}


def load_api_key(env_path: Path) -> str:
    if env_path.exists():
        for line in env_path.read_text(encoding="utf-8").splitlines():
            stripped = line.strip()
            if stripped.startswith("TESTING_LINEAR_API_KEY="):
                return stripped.split("=", 1)[1].strip().strip("'\"")
    return os.environ.get("LINEAR_API_KEY", "")


def gql(query: str, variables: dict, api_key: str) -> dict:
    body = json.dumps({"query": query, "variables": variables}).encode("utf-8")
    req = urllib.request.Request(
        LINEAR_API_URL, data=body, method="POST",
        headers={"Content-Type": "application/json", "Authorization": api_key},
    )
    try:
        with urllib.request.urlopen(req) as resp:
            result = json.loads(resp.read())
    except urllib.error.HTTPError as exc:
        raise RuntimeError(f"HTTP {exc.code}: {exc.read().decode()}") from exc
    if "errors" in result:
        raise RuntimeError(f"Linear API error: {result['errors']}")
    return result["data"]


def get_issue(identifier: str, api_key: str) -> dict:
    data = gql(
        """query($id: String!) {
          issue(id: $id) { id identifier state { id name } }
        }""",
        {"id": identifier},
        api_key,
    )
    return data["issue"]


def get_team_states(api_key: str) -> list[dict]:
    data = gql(
        """query($key: String!) {
          teams(filter: { key: { eq: $key } }) { nodes { states(first: 50) { nodes { id name type } } } }
        }""",
        {"key": TEAM_KEY},
        api_key,
    )
    return data["teams"]["nodes"][0]["states"]["nodes"]


def resolve_state_id(state_name: str, states: list[dict]) -> str | None:
    for s in states:
        if s["name"].lower() == state_name.lower():
            return s["id"]
    return None


def post_comment(issue_id: str, body: str, api_key: str) -> str:
    data = gql(
        """mutation($issueId: String!, $body: String!) {
          commentCreate(input: { issueId: $issueId, body: $body }) { success comment { id url } }
        }""",
        {"issueId": issue_id, "body": body},
        api_key,
    )
    return data["commentCreate"]["comment"]["url"]


def set_state(issue_id: str, state_id: str, api_key: str) -> None:
    gql(
        """mutation($id: String!, $input: IssueUpdateInput!) {
          issueUpdate(id: $id, input: $input) { success issue { identifier state { name } } }
        }""",
        {"id": issue_id, "input": {"stateId": state_id}},
        api_key,
    )


def apply_transition(identifier: str, transition: str, api_key: str) -> bool:
    issue = get_issue(identifier, api_key)
    states = get_team_states(api_key)

    if transition.lower() == "qa passed" and issue["state"]["name"].lower() == "qa review":
        print("[INFO] Current state is 'QA Review' — stepping through 'In QA' first…")
        in_qa_id = resolve_state_id("In QA", states)
        if not in_qa_id:
            print("[WARN] 'In QA' state not found on team — check LINEAR_CHEATSHEET.md §7", file=sys.stderr)
            return False
        set_state(issue["id"], in_qa_id, api_key)
        print("[OK] -> In QA")

    target_name = TRANSITION_TO_STATE.get(transition.lower(), transition)
    target_id = resolve_state_id(target_name, states)
    if not target_id:
        available = [s["name"] for s in states]
        print(f"[WARN] State '{target_name}' not found. Available: {available}", file=sys.stderr)
        return False
    set_state(issue["id"], target_id, api_key)
    print(f"[OK] {identifier} -> {target_name}")
    return True


def main() -> int:
    parser = argparse.ArgumentParser(description="Post a Markdown comment to Linear and/or transition its state.")
    parser.add_argument("issue_key", help="Linear issue identifier, e.g. GR-1234")
    parser.add_argument("--comment-file", default="", help="Markdown comment file")
    parser.add_argument("--transition", default="", help="Transition name to apply (e.g. 'start qa', 'qa passed')")
    parser.add_argument("--transition-only", action="store_true", help="Apply transition without posting a comment")
    parser.add_argument("--env-file", default=".dev.vars", help="Env file with TESTING_LINEAR_API_KEY")
    args = parser.parse_args()

    identifier = args.issue_key.upper()
    api_key = load_api_key(Path(args.env_file))

    if not args.transition_only:
        if not args.comment_file:
            print("[ERROR] --comment-file is required unless --transition-only is set", file=sys.stderr)
            return 1
        comment_path = Path(args.comment_file)
        if not comment_path.exists():
            print(f"[ERROR] Comment file not found: {comment_path}", file=sys.stderr)
            return 1

        body = comment_path.read_text(encoding="utf-8")
        issue = get_issue(identifier, api_key)
        print(f"[INFO] Posting comment to {identifier}…")
        url = post_comment(issue["id"], body, api_key)
        print(f"[OK] Comment posted — {url}")

    if args.transition:
        apply_transition(identifier, args.transition, api_key)

    return 0


if __name__ == "__main__":
    sys.exit(main())
