#!/usr/bin/env python3
"""
Upload one or more files to Linear's asset storage and print the resulting assetUrl(s).

Successor to the old "upload via Playwright setInputFiles + scrape Media UUID from img src"
dance. Linear's fileUpload mutation returns a signed uploadUrl (PUT the raw bytes there) and
a permanent assetUrl (reference that anywhere — comment body, description, attachmentCreate).

Usage:
    python3 .claude/skills/linear-comment-writer/scripts/upload_linear_file.py file1.png file2.webm
"""

from __future__ import annotations

import json
import mimetypes
import os
import sys
import urllib.error
import urllib.request
from pathlib import Path

LINEAR_API_URL = "https://api.linear.app/graphql"


def load_api_key(env_path: Path) -> str:
    if env_path.exists():
        for line in env_path.read_text(encoding="utf-8").splitlines():
            stripped = line.strip()
            if stripped.startswith("TESTING_LINEAR_API_KEY="):
                return stripped.split("=", 1)[1].strip().strip("'\"")
    return os.environ.get("LINEAR_API_KEY", "")


def gql(query: str, variables: dict, api_key: str) -> dict:
    body = json.dumps({"query": query, "variables": variables}).encode("utf-8")
    req = urllib.request.Request(
        LINEAR_API_URL, data=body, method="POST",
        headers={"Content-Type": "application/json", "Authorization": api_key},
    )
    try:
        with urllib.request.urlopen(req) as resp:
            result = json.loads(resp.read())
    except urllib.error.HTTPError as exc:
        raise RuntimeError(f"HTTP {exc.code}: {exc.read().decode()}") from exc
    if "errors" in result:
        raise RuntimeError(f"Linear API error: {result['errors']}")
    return result["data"]


def upload_file(path: Path, api_key: str) -> str:
    content_type = mimetypes.guess_type(path.name)[0] or "application/octet-stream"
    size = path.stat().st_size
    data = gql(
        """mutation($contentType: String!, $filename: String!, $size: Int!) {
          fileUpload(contentType: $contentType, filename: $filename, size: $size) {
            success
            uploadFile { uploadUrl assetUrl headers { key value } }
          }
        }""",
        {"contentType": content_type, "filename": path.name, "size": size},
        api_key,
    )
    upload = data["fileUpload"]["uploadFile"]
    headers = {h["key"]: h["value"] for h in upload["headers"]}
    headers["Content-Type"] = content_type
    put_req = urllib.request.Request(upload["uploadUrl"], data=path.read_bytes(), method="PUT", headers=headers)
    with urllib.request.urlopen(put_req):
        pass
    return upload["assetUrl"]


def main() -> int:
    if len(sys.argv) < 2:
        print("Usage: upload_linear_file.py <file1> [file2 ...]", file=sys.stderr)
        return 1

    api_key = load_api_key(Path(".dev.vars"))
    exit_code = 0
    for arg in sys.argv[1:]:
        p = Path(arg)
        if not p.exists():
            print(f"[WARN] Not found, skipping: {p}", file=sys.stderr)
            exit_code = 1
            continue
        try:
            asset_url = upload_file(p, api_key)
            print(f"{p.name} -> {asset_url}")
        except RuntimeError as exc:
            print(f"[ERROR] {p.name}: {exc}", file=sys.stderr)
            exit_code = 1
    return exit_code


if __name__ == "__main__":
    sys.exit(main())
