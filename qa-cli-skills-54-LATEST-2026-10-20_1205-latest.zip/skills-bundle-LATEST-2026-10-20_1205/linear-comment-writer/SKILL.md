---
name: "linear-comment-writer"
description: "Write and post the Linear QA comment. Picks comment type automatically — PASS ✅, FAIL ❌ with root-cause, or clarification. Posts as plain Markdown via the Linear connector with inline screenshots via ![alt](assetUrl). Upload files first (connector prepare → PUT → finalize), then reference the assetUrl in the comment body. 7-column table, Execution Summary bullets, h2 headings. Use whenever: write comment, post comment, QA comment, post results, comment on Linear issue, verification comment, tag for review."
---

# Linear Comment Writer

Final step after QA execution. Posts the Linear comment as **plain Markdown** with inline screenshot evidence, uploads artifacts, and transitions the issue's workflow state.

> Linear comments are Markdown, not ADF. `![alt](url)` embeds an image inline — including inside
> table cells — as long as `url` is a real `assetUrl` from a Linear upload.

> **Upload first, comment second.** The comment body needs the real `assetUrl` for each image,
> which only exists after the upload is finalized.

> **Fixed 2026-10-16 (verified on FRAI-8354):** the Python scripts (`upload_linear_file.py`,
> `post_linear_comment.py`) need `TESTING_LINEAR_API_KEY` in `.dev.vars`, which is not configured,
> and the cloud sandbox cannot reach Linear's storage host. Everything below uses the **Linear
> connector tools** instead: `prepare_attachment_upload`, `create_attachment_from_upload`,
> `save_comment`, `save_issue`. The scripts remain an alternative only if an API key is added.
> The release state is named **`Ready for Release`** (not "Ready To Release"); there are no
> `In QA` / `QA Review` states.

---

## Pick Comment Type

| Situation | Type |
|-----------|------|
| Every TC passed | ✅ All Passed |
| Failures with clear root cause | ❌ Bug Report → auto-trigger `linear-ticket-writer` |
| Failures with ambiguous behaviour | ⚠️ Clarification |

Prefer Bug Report over Clarification whenever root cause is identifiable without hedging. A ❌ Bug Report requires `root-cause-forensics` to have run first.

---

## Images: upload once, reference everywhere

1. Upload each file (Step 2 below) and record its `assetUrl`.
2. Use that `assetUrl` directly as `![TC-01 screenshot](assetUrl)` inside the Markdown table cell or paragraph where the screenshot belongs.
3. `create_attachment_from_upload` also lists the file under the issue's Resources — same `assetUrl`.

For a test case with no screenshot (BE-only, Layer 2), put `—` in that table cell.

---

## Comment Format

The canonical reference stays Lan's GR-5146-style comment, in Markdown:
- **7 columns:** `(empty) | Test Case | Status | Expected Result | Actual Result | Reproduction Steps | Screenshot`
- **Leading empty column** holds the TC number (TC-01, TC-02, etc.)
- **Reproduction Steps column** — numbered steps so developers can reproduce without guessing:
  - **PASS cases:** concise happy-path steps ("1. Navigate to the feature → 2. Perform the action → 3. Verify result")
  - **FAIL cases:** detailed and precise — exact inputs, UI state at the failure point, API payload if relevant, and the exact step where it fails. A developer must be able to reproduce from this column alone.
- **Execution Summary** is a bullet list (not a table)
- **Headings** use `##` (h2): "Execution Summary" and "Test Cases"
- **Technical values** use backtick code spans

### Markdown Comment Skeleton

```markdown
QA Verification PASS ✅

- Date: `YYYY-MM-DD`
- Issue: `FRAI-XXXX`
- Environment: `Dev — https://app.dev.firstrecon.ai`
- Tester: `belle.ung@persefoni.com`
- Scope: `Frontend + Backend`

## Execution Summary

- Total: `N`
- Passed: `N`
- Failed: `0`
- Skipped: `0`
- Blocked: `0`

## Test Cases

|  | Test Case | Status | Expected Result | Actual Result | Reproduction Steps | Screenshot |
|---|---|---|---|---|---|---|
| TC-01 | Test case description | ✅ Pass | Expected outcome | Actual outcome matched | 1. Navigate to feature URL → 2. Perform the tested action → 3. Observe result | ![TC-01](ASSET_URL_FROM_UPLOAD) |

Summary narrative here.
```

For a ❌ Bug Report add a `## Failed Test Cases — Detail` section per failed TC (AC verbatim, steps, expected, actual, RCA summary).

---

## Posting Workflow

### 1. Capture screenshots

Use `qa-evidence-capture` (preferred — outlines and labels the failing element) or `playwright-media-capture`. Both save into
`/Users/belleung/Documents/guardrails/eng-guardrails-platform/manual-testing/evidences/{TICKET_KEY}/`
and both screenshot on a **fresh Playwright page** via `browser_run_code_unsafe` (`browser_take_screenshot` hangs).

### 2. Upload every evidence file (BEFORE posting) — one file at a time

The signed URL expires in 60 seconds: prepare → PUT → finalize one file before preparing the next.

1. `prepare_attachment_upload(issue="{TICKET_KEY}", filename, contentType, size)` — `size` = exact bytes (`ls -l`); `contentType` `image/png`, `image/gif`, or `text/markdown` for report files.
2. PUT the bytes from the Mac's Playwright process (`browser_run_code_unsafe`):

```javascript
async (page) => {
  const FILE = '/Users/belleung/Documents/guardrails/eng-guardrails-platform/manual-testing/evidences/{TICKET_KEY}/{file}';
  const URL = '{uploadRequest.url}';
  const HEADERS = { /* uploadRequest.headers verbatim, same casing */ };
  const p = await page.context().newPage();
  await p.setContent('<input type="file" id="f">');
  await p.setInputFiles('#f', FILE);
  const b64 = await p.evaluate(() => new Promise((res) => { const f = document.getElementById('f').files[0]; const r = new FileReader(); r.onload = () => res(r.result.split(',')[1]); r.readAsDataURL(f); }));
  await p.close();
  const data = Buffer.from(b64, 'base64');
  const r = await page.request.put(URL, { data, headers: HEADERS, timeout: 30000 });
  return { status: r.status(), bytes: data.length };
}
```

   Expect `status: 200` and `bytes` equal to `size`; otherwise prepare again and retry.
3. `create_attachment_from_upload(issue="{TICKET_KEY}", assetUrl, title=filename)`.

Record each `assetUrl` by filename — that is what goes into the Screenshot column.

### 3. Post the comment

`save_comment(issueId="{TICKET_KEY}", body=<the filled-in Markdown skeleton>)` — plain Markdown, literal newlines, no escaping. Also save the same Markdown to
`$REPO_ROOT/test-reports/linear-comments/{TICKET_KEY}_{date}_comment.md` for the record.

Then open the issue in Chrome and confirm every image renders in the table (`![…]` that shows as text means a bad URL). Reload the page once if the newest comment is not shown.

### 4. Transition if all passed

`save_issue(id="{TICKET_KEY}", state="Ready for Release")` — one call, no intermediate states. Confirm the name with `list_issue_statuses(team)` first if unsure; the SpydySense AI team has no release-ready state, so stop and ask there. See `linear-ticket-transition`.

### 5. Auto-trigger linear-ticket-writer (Bug Report only — MANDATORY)

If comment type is Bug Report, immediately invoke `linear-ticket-writer` for every failed TC. Do not wait for user confirmation.

---

## Status Transitions

| Outcome | Transition | Status |
|---------|-----------|--------|
| All passed | `qa passed` | → Ready for Release |
| Any failure | none | unchanged |
| Clarification | none | unchanged |

---

## Final Report

Output after completion:
- Issue ID + URL
- Comment type (Pass / Bug Report / Clarification)
- Artifacts uploaded (filenames + count)
- TC count: passed / failed / skipped / blocked
- Bug issues filed (if any, with links)
- Transition applied (if any)

---

## Alternative: API-key scripts

If `.dev.vars` in the repo root contains `TESTING_LINEAR_API_KEY`, the bundled scripts work from any shell that can reach `api.linear.app` **and** `storage.googleapis.com`:

```bash
python3 scripts/upload_linear_file.py <files…>                       # prints filename -> assetUrl
python3 scripts/post_linear_comment.py {TICKET_KEY} --comment-file <md>
python3 scripts/post_linear_comment.py {TICKET_KEY} --transition "qa passed"
```

Neither the cloud sandbox nor the Mac sandbox shell can reach the storage host today, so prefer the connector path above.

---

## Fallback (if Linear is unreachable)

1. Note the evidence path: `/Users/belleung/Documents/guardrails/eng-guardrails-platform/manual-testing/evidences/{TICKET_KEY}/`
2. Tell the user the comment could not be posted and give them the Markdown file path so they can paste it manually into the Linear issue and drag the images in.