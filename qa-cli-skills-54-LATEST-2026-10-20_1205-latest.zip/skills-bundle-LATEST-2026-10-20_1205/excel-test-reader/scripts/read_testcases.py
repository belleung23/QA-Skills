#!/usr/bin/env python3
"""
read_testcases.py — Reader/utility for the First Recon AI QA test-suite workbook.

The workbook (default: First-Recon-AI-Full-QA-Test-Suite.xlsx) has:
  - A "Summary" sheet (per-workspace totals + grand total + legends).
  - One sheet per workspace: Workspace-Chat, Platform-Admin, Operations-Portal,
    Prompt-Security, User-Settings, AI-Security-Runtime, Integration-Workflows.
  - An "ID-Map" sheet (old ID -> new ID traceability).

Each workspace sheet is a table with these columns (row 1 = header):
  A Test Case ID   - e.g. TC-WC-Chat-001  =  TC-<WorkspaceCode>-<Feature>-<NNN>
  B Description
  C Test Steps      (numbered, multi-line)
  D Expected Result
  E Actual Result
  F Status          - PASSED | FAILED | BLOCKED | N/A
  G Comments
  H Screenshots
  I Failure Type    - only on FAILED rows: Product Defect | Reference/Spec Mismatch
                      | Negative-test (by-design) | Needs relook
  J Automation      - To Do | In Progress | Done

Interspersed "section banner" rows start with "▼" in column A and mark a
feature group (Chat, Cowork, Context, Recall, ...). They are NOT test cases;
this reader skips them but uses them to tag each case with its `section`.

Usage (CLI):
  python read_testcases.py                         # overview of the whole workbook
  python read_testcases.py --summary               # per-sheet status + automation counts
  python read_testcases.py --sheet Workspace-Chat  # list cases in one sheet
  python read_testcases.py --status FAILED          # all FAILED cases (every sheet)
  python read_testcases.py --automation "To Do"    # cases not yet automated
  python read_testcases.py --failtype "Product Defect"
  python read_testcases.py --feature Context        # cases in a feature group
  python read_testcases.py --id TC-WC-Context-001   # full detail of one case
  python read_testcases.py --search "model selector"
  python read_testcases.py --export-csv out.csv     # flatten all cases to one CSV

Programmatic:
  from read_testcases import TestSuite
  ts = TestSuite("First-Recon-AI-Full-QA-Test-Suite.xlsx")
  ts.sheets                       # list of workspace sheet names
  ts.all_cases()                  # list[dict] across every sheet
  ts.cases(sheet="Prompt-Security", status="FAILED")
  ts.get("TC-PA-People-003")      # one case dict, or None
  ts.counts()                     # nested status/automation/failtype tallies
"""

from __future__ import annotations
import argparse
import csv
import os
import sys

try:
    from openpyxl import load_workbook
except ImportError:
    sys.exit("openpyxl is required:  pip install openpyxl --break-system-packages")

DEFAULT_FILE = "First-Recon-AI-Full-QA-Test-Suite.xlsx"
NON_WORKSPACE_SHEETS = {"Summary", "ID-Map"}

# Column layout (1-based) on every workspace sheet
COLUMNS = {
    "id": 1, "description": 2, "steps": 3, "expected": 4, "actual": 5,
    "status": 6, "comments": 7, "screenshots": 8, "failure_type": 9, "automation": 10,
}
# Section banner rows start with one of these markers in column A:
#   ▼ = feature section,  ◆ = cross-cutting type section (Accessibility/Responsive/etc.)
BANNER_PREFIXES = ("▼", "◆")


class TestSuite:
    """Loads the workbook and exposes structured access to the test cases."""

    def __init__(self, path: str = DEFAULT_FILE):
        if not os.path.exists(path):
            raise FileNotFoundError(f"Workbook not found: {path}")
        self.path = path
        # data_only=True so we read computed values (e.g. Summary totals), not formulas
        self._wb = load_workbook(path, data_only=True, read_only=True)
        self.sheets = [s for s in self._wb.sheetnames if s not in NON_WORKSPACE_SHEETS]

    # ---- core reading -------------------------------------------------
    def _read_sheet(self, sheet: str) -> list[dict]:
        ws = self._wb[sheet]
        cases, current_section = [], None
        for i, row in enumerate(ws.iter_rows(values_only=True)):
            if i == 0:
                continue  # header
            if not row or row[0] is None or str(row[0]).strip() == "":
                continue
            first = str(row[0])
            if first.startswith(BANNER_PREFIXES):
                current_section = first.lstrip("▼◆").strip()
                continue

            def col(key):
                idx = COLUMNS[key] - 1
                return row[idx] if idx < len(row) and row[idx] is not None else ""

            cid = first
            # Feature segment = 3rd token of TC-<WS>-<Feature>-<NNN>
            parts = cid.split("-")
            feature = parts[2] if len(parts) >= 4 else ""
            ws_code = parts[1] if len(parts) >= 2 else ""
            cases.append({
                "sheet": sheet,
                "workspace_code": ws_code,
                "feature": feature,
                "section": current_section or "",
                "id": cid,
                "description": str(col("description")),
                "steps": str(col("steps")),
                "expected": str(col("expected")),
                "actual": str(col("actual")),
                "status": str(col("status")).strip().upper(),
                "comments": str(col("comments")),
                "screenshots": str(col("screenshots")),
                "failure_type": str(col("failure_type")),
                "automation": str(col("automation")).strip(),
            })
        return cases

    def all_cases(self) -> list[dict]:
        out = []
        for s in self.sheets:
            out.extend(self._read_sheet(s))
        return out

    def cases(self, sheet=None, status=None, automation=None,
              failure_type=None, feature=None, search=None) -> list[dict]:
        rows = self._read_sheet(sheet) if sheet else self.all_cases()
        def keep(c):
            if status and c["status"] != status.strip().upper():
                return False
            if automation and c["automation"].lower() != automation.strip().lower():
                return False
            if failure_type and failure_type.lower() not in c["failure_type"].lower():
                return False
            if feature and feature.lower() != c["feature"].lower():
                return False
            if search:
                blob = " ".join(str(v) for v in c.values()).lower()
                if search.lower() not in blob:
                    return False
            return True
        return [c for c in rows if keep(c)]

    def get(self, case_id: str):
        for c in self.all_cases():
            if c["id"] == case_id:
                return c
        return None

    # ---- aggregates ---------------------------------------------------
    def counts(self) -> dict:
        result = {}
        grand = {"total": 0, "status": {}, "automation": {}, "failure_type": {}}
        for s in self.sheets:
            rows = self._read_sheet(s)
            st, au, ft = {}, {}, {}
            for c in rows:
                st[c["status"]] = st.get(c["status"], 0) + 1
                au[c["automation"] or "(blank)"] = au.get(c["automation"] or "(blank)", 0) + 1
                if c["status"] == "FAILED":
                    key = c["failure_type"] or "(unclassified)"
                    ft[key] = ft.get(key, 0) + 1
            result[s] = {"total": len(rows), "status": st, "automation": au, "failure_type": ft}
            grand["total"] += len(rows)
            for d, src in ((grand["status"], st), (grand["automation"], au), (grand["failure_type"], ft)):
                for k, v in src.items():
                    d[k] = d.get(k, 0) + v
        result["__GRAND_TOTAL__"] = grand
        return result

    def export_csv(self, out_path: str):
        rows = self.all_cases()
        cols = ["sheet", "section", "id", "feature", "description", "steps",
                "expected", "actual", "status", "failure_type", "automation",
                "comments", "screenshots"]
        with open(out_path, "w", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=cols, extrasaction="ignore")
            w.writeheader()
            w.writerows(rows)
        return len(rows)


# ---- CLI ------------------------------------------------------------------
def _print_case_short(c):
    auto = f"[{c['automation']}]" if c['automation'] else "[--]"
    ft = f" {{{c['failure_type']}}}" if c["failure_type"] else ""
    print(f"  {c['id']:<34} {c['status']:<8} {auto:<14} {c['description'][:60]}{ft}")


def _print_case_full(c):
    print("=" * 80)
    for label, key in [("ID", "id"), ("Sheet", "sheet"), ("Section", "section"),
                       ("Feature", "feature"), ("Status", "status"),
                       ("Failure Type", "failure_type"), ("Automation", "automation"),
                       ("Description", "description"), ("Test Steps", "steps"),
                       ("Expected", "expected"), ("Actual", "actual"),
                       ("Comments", "comments"), ("Screenshots", "screenshots")]:
        val = c.get(key, "")
        if val:
            print(f"{label}:")
            for line in str(val).split("\\n"):
                print(f"    {line}")


def main():
    ap = argparse.ArgumentParser(description="Read the First Recon AI QA test-suite workbook.")
    ap.add_argument("--file", default=DEFAULT_FILE, help="path to the .xlsx (default: %(default)s)")
    ap.add_argument("--summary", action="store_true", help="per-sheet + grand totals")
    ap.add_argument("--sheet", help="limit to one workspace sheet")
    ap.add_argument("--status", help="filter by Status (PASSED/FAILED/BLOCKED/N/A)")
    ap.add_argument("--automation", help="filter by Automation (To Do/In Progress/Done)")
    ap.add_argument("--failtype", help="filter by Failure Type (substring)")
    ap.add_argument("--feature", help="filter by feature segment (e.g. Context)")
    ap.add_argument("--search", help="free-text search across all fields")
    ap.add_argument("--id", help="show full detail of one Test Case ID")
    ap.add_argument("--export-csv", help="flatten every case into one CSV at this path")
    args = ap.parse_args()

    try:
        ts = TestSuite(args.file)
    except FileNotFoundError as e:
        sys.exit(str(e))

    if args.id:
        c = ts.get(args.id)
        if not c:
            sys.exit(f"No case with ID {args.id}")
        _print_case_full(c)
        return

    if args.export_csv:
        n = ts.export_csv(args.export_csv)
        print(f"Exported {n} cases -> {args.export_csv}")
        return

    if args.summary or not any([args.sheet, args.status, args.automation,
                                args.failtype, args.feature, args.search]):
        cc = ts.counts()
        g = cc["__GRAND_TOTAL__"]
        print(f"Workbook: {args.file}")
        print(f"Workspace sheets: {', '.join(ts.sheets)}")
        print(f"\nGRAND TOTAL: {g['total']} test cases")
        print("  Status:     " + ", ".join(f"{k}={v}" for k, v in sorted(g["status"].items())))
        print("  Automation: " + ", ".join(f"{k}={v}" for k, v in sorted(g["automation"].items())))
        print("  FAILED by type: " + ", ".join(f"{k}={v}" for k, v in sorted(g["failure_type"].items())))
        print("\nPer sheet:")
        for s in ts.sheets:
            d = cc[s]
            print(f"  {s:<22} total={d['total']:<4} "
                  f"{', '.join(f'{k}={v}' for k, v in sorted(d['status'].items()))}")
        if not args.summary:
            print("\n(Use --sheet / --status / --automation / --failtype / --feature / --search / --id / --export-csv)")
        return

    rows = ts.cases(sheet=args.sheet, status=args.status, automation=args.automation,
                    failure_type=args.failtype, feature=args.feature, search=args.search)
    print(f"{len(rows)} case(s) matched:")
    for c in rows:
        _print_case_short(c)


if __name__ == "__main__":
    try:
        main()
    except BrokenPipeError:
        # e.g. when piping into `head`; exit quietly
        try:
            sys.stdout.close()
        except Exception:
            pass
        os._exit(0)
