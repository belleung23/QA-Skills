---
name: excel-test-reader
description: >
  Read and filter QA test cases from the First Recon AI Excel test suite (.xlsx).
  Use whenever the user wants to load, list, search, or filter test cases from the
  spreadsheet — by sheet, status, feature, TC ID, or free-text — or export to CSV.
  Triggers on: read test cases, load excel, show me the tests, get test cases,
  filter tests, which tests are FAILED, search test suite, export csv.
---

# Excel Test Reader

Use the bundled script `scripts/read_testcases.py` for all operations.

## Setup
```bash
pip install openpyxl --break-system-packages
```

## Commands
```bash
# Overview / grand totals
python scripts/read_testcases.py --file <path.xlsx>

# Per-sheet breakdown
python scripts/read_testcases.py --file <path.xlsx> --summary

# Filter cases
python scripts/read_testcases.py --file <path.xlsx> --sheet Platform-Admin
python scripts/read_testcases.py --file <path.xlsx> --status FAILED
python scripts/read_testcases.py --file <path.xlsx> --failtype "Product Defect"
python scripts/read_testcases.py --file <path.xlsx> --feature Context
python scripts/read_testcases.py --file <path.xlsx> --search "model selector"

# Single test case detail
python scripts/read_testcases.py --file <path.xlsx> --id TC-WC-ChatSidebar-001

# Export all to CSV
python scripts/read_testcases.py --file <path.xlsx> --export-csv out.csv
```

## Programmatic use (for other skills)
```python
from scripts.read_testcases import TestSuite
ts = TestSuite("path/to/file.xlsx")
ts.all_cases()                          # list[dict] — all 1651 cases
ts.cases(sheet="Prompt-Security", status="FAILED")
ts.get("TC-PA-People-003")             # single case dict or None
ts.counts()                             # nested status/automation/failtype tallies
```

After loading, tell the user the match count and ask if they want to pipe into
**test-script-generator** or **excel-status-updater**.
