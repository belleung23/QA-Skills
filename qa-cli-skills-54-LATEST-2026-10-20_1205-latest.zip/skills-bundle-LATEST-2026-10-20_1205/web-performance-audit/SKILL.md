---
name: "web-performance-audit"
description: "Measure how fast web pages load and respond for one user in any web app, public or logged-in. Covers Core Web Vitals (LCP, INP, CLS), FCP, TTFB, blocking time, page weight and click-to-result times, using Playwright + Chromium with desktop and mobile network/CPU profiles, several cold-cache runs, screenshots, and Lighthouse when installed. Runs where Playwright is installed, or through a connected Playwright browser tool on the user's computer when only that computer can reach the app. Use whenever someone asks to test page speed, load time, web or front-end performance, Core Web Vitals, a Lighthouse score, whether a page or flow is slow, or to compare speed before and after a fix. Then hand the results to performance-report for the .md report. For many simultaneous users, use load-test-runner instead."
---

# Web Performance Audit (one user, page speed)

Playwright is not a performance tool by itself. Driven through Chromium's DevTools protocol, though, it gives reliable **lab** measurements for one user: Web Vitals, navigation timings, network and CPU throttling, per-file download sizes, and click-to-result timings. That is what this skill does.

What it cannot do:

- **Many users at once.** For load, stress or capacity, use **load-test-runner**.
- **Real-user (field) data.** Google's official Core Web Vitals come from real visitors (CrUX/RUM). Lab numbers are an early warning, not the official score. The report says so.

Run everything yourself, end to end, and finish with the report from **performance-report**. The reviewer looks at the report and screenshots. Only stop to ask for things you cannot know: which pages matter (when the request is vague), and credentials or a saved login for protected pages.

## Step 1 — Plan the pages

- **Pages:** the ones the user names. If they're vague, take 3–5 pages that matter most: entry/login, the main dashboard or home, the heaviest list or detail page, and any page they complained about.
- **`waitFor`:** for each page, a selector that proves the real content is shown (main heading, table rows, a `data-testid`), not a spinner. It defines "ready" and keeps the measurement honest. If you don't know what the page shows, run the preflight with `--out <run-dir>` first: it saves a screenshot of each loaded page in `<run-dir>/preflight/` and prints each page's headings, `data-testid`s, landmarks, visible buttons/links and inputs with a ready-to-use selector for each (`peek`), using the saved login when there is one. The outline is printed even when `waitFor` fails, so a wrong guess is easy to correct. Pick a selector of the main content from that; avoid selectors an error page or the login page would also match, like a bare `h1`.
- **Interactions:** add 1–2 typical clicks per page, each with an `expect` selector that appears when the action has finished. Without at least one, INP is reported as *not measured*. On shared or production environments use **read-only** interactions only (open a menu, switch a tab, filter a list). Never submit orders, send messages or delete things. On a local or throwaway environment a click that only changes test data (add to cart) is fine; list it in `assumptions`. If you don't know what appears after the click, add the interaction without `expect` first and run the preflight with `--out <run-dir>`: it saves a screenshot taken after the click, `<run-dir>/preflight/screens/<page>-none-after-<action>.png` (`<action>` = the interaction name in lowercase with dashes, e.g. `add-to-cart`). Pick a selector for what appeared there (a message, a dialog, a changed counter), add it as `expect`, and run the preflight again.
- **Profiles:** `desktop` and `mobile-4g` by default. Add `slow-3g` only for loading-state checks. Use `none` (no throttling) only for before/after comparisons on the same machine.
- **Runs:** 5 cold-cache runs per page and profile (minimum 3). The report rates the p75.
- **Environment:** label it honestly (`local`, `dev`, `staging`, `production`). Single-user page loads are safe on any environment.
- **A page the user says is broken or slow but that answers an error** (the preflight says `HTTP 4xx/5xx`): keep it in the run when the user named it, with the `waitFor` you would use for its real content (if that is unknown, use `main` or `body` and say so in `assumptions`). On an error answer the script does not wait for that content: it records one run and a screenshot as evidence and skips the rest, and the report rates it as an error page, not as fast or slow. Otherwise fix the path.

## Step 2 — Find a machine that can run it

The run needs Node 18+, Playwright with its Chromium build, and network access to the target. If you can work in more than one place (a local shell, a VM, a cloud workspace), run the preflight in each until one passes:

```bash
node .perf-kit/measure-page.mjs --preflight --config <run-dir>/web-config.json
```

The preflight checks the machine, then opens every page once without throttling and tries its `waitFor` and interactions, so a wrong selector or a login redirect shows up in seconds instead of after a long run. What to do when a line fails:

| Preflight line | Fix |
|---|---|
| `playwright: NOT FOUND` | Use the project's own install (`@playwright/test`), or `npm i -D playwright` in `.perf-kit/` |
| `chromium: MISSING` | `npx playwright install chromium` (needs network) |
| `target: UNREACHABLE` | Wrong URL, VPN or allowlist needed, or the app isn't running: start it, or run from a machine that can reach it |
| `storageState: MISSING` | Create the login state first (Step 3) |
| `pages.<name>: FAILED: … redirect …` | The page sent you elsewhere, usually to login: the session is missing or expired |
| `pages.<name>: FAILED: "<selector>" did not appear` | The `waitFor` selector is wrong, or the page needs longer: fix the selector or raise `waitForTimeoutMs` |
| `pages.<name>: FAILED: the page answered HTTP 4xx/5xx` | If the user named this page as broken or slow, keep it and carry on (Step 1): the run records it as an error page and the report rates it that way. Otherwise the path is wrong: fix it |
| `pages.<name>: FAILED interaction(s)` | A `click`/`fill`/`expect` selector is wrong or the element is hidden: fix it |
| `lighthouse: not installed` | Optional: don't install it yourself unless the user asked for Lighthouse scores (it needs network, Node 22+ and a global install: `npm i -g lighthouse`). Otherwise carry on. The report marks Lighthouse as not measured, and nothing else depends on it |

**No machine passes, but a Playwright browser tool is connected on the user's computer?** (A browser tool with a "run code" action, e.g. `browser_run_code_unsafe` from the Playwright MCP.) Use **browser-connector mode** (Step 5b): this machine writes a job file, the user's own browser runs the measurement in the background, and the results, screenshots and filmstrip land in the run folder as usual. It is the right choice when the app is only reachable from the user's computer (VPN, office network) or when this machine has no browser. Lighthouse is not available in that mode.

If no machine passes the machine lines (`node`, `playwright`, `chromium`, `target`) and no browser tool is connected, stop. Tell the user exactly which line failed and the one command that would fix it. Never estimate or invent numbers.

## Step 3 — Logged-in pages

Measure protected pages with a saved Playwright session (`storageState` JSON). Reuse the project's existing way of producing one (a Playwright global-setup, an auth fixture, or the team's login or auth skill), save it to a file, and set `storageState` in the config. Passwords and tokens never go into the config or the report. After the run, check that no page shows `redirectedTo` the login page.

For a plain username/password form with nothing to reuse, a small helper does it. Adjust the selectors, keep the credentials in environment variables, and keep the session file out of the report folder and out of git (it is a live login):

```js
// .perf-kit/login.mjs — usage: PERF_USER=… PERF_PASS=… node .perf-kit/login.mjs <login-url> <state-file>
import { createRequire } from 'node:module';
import { execSync } from 'node:child_process';
const req = createRequire(`${execSync('npm root -g').toString().trim()}/x.js`);
let pw; try { pw = createRequire(`${process.cwd()}/x.js`)('playwright'); } catch { pw = req('playwright'); }
const [url, out] = process.argv.slice(2);
const b = await pw.chromium.launch(); const p = await b.newPage();
await p.goto(url);
await p.fill('input[type=email], input[name=user], input[name=username], input[type=text]', process.env.PERF_USER);
await p.fill('input[type=password]', process.env.PERF_PASS);
await Promise.all([p.waitForURL((u) => !String(u).includes('/login')), p.click('button[type=submit], button')]);
await p.context().storageState({ path: out }); await b.close();
console.log(`saved ${out}`);
```

In browser-connector mode there is a simpler option for single sign-on or MFA logins: sign in once in the browser tool's own window (use the team's login skill, or ask the user to complete the MFA step there), then set `"useBrowserSession": true` instead of `storageState`. Each measured run copies that browser's cookies and storage into a fresh, cache-cold session. The copy stays in memory and is never written to disk.

## Step 4 — Write the tool and the config

- **Tool:** if `.perf-kit/measure-page.mjs` exists and its version line (`// perf-kit:measure-page v5`, line 2) matches the script at the bottom of this file, reuse it. Otherwise overwrite it with the script exactly as given. `.perf-kit/` sits at the project root, or in the working folder when you only have a URL.

  The script is long, so copy it out of this file with a command instead of retyping it (`<this SKILL.md>` is the path you read these instructions from), then check it:

  ```bash
  mkdir -p .perf-kit && awk '/^## measure-page[.]mjs$/{h=1;next} h&&/^````js$/{p=1;next} p&&/^````$/{exit} p' "<this SKILL.md>" > .perf-kit/measure-page.mjs
  node --check .perf-kit/measure-page.mjs && sed -n 2p .perf-kit/measure-page.mjs   # must print the version line
  ```
- **Run directory:** `perf-reports/<YYYY-MM-DD>_<app-slug>/` (`<app-slug>` = a short lowercase name for the app, such as `acme-shop`). If the project already has a reports folder (e.g. `test-reports/`), use `test-reports/performance/<YYYY-MM-DD>_<app-slug>/` instead. When a load test is part of the same request, use the **same** run directory so performance-report produces one combined report.
- **Config** (`<run-dir>/web-config.json`):

```json
{
  "label": "Acme Web — checkout pages",
  "environment": "staging",
  "baseUrl": "https://staging.acme.example",
  "storageState": "auth/qa-user.json",
  "runs": 5,
  "profiles": ["desktop", "mobile-4g"],
  "lighthouse": true,
  "pages": [
    { "name": "home", "path": "/", "waitFor": "[data-testid=hero-title]" },
    { "name": "product", "path": "/product/42", "waitFor": "[data-testid=product-title]",
      "interactions": [ { "name": "open size picker", "click": "[data-testid=size-picker]", "expect": "[role=listbox]" } ] }
  ]
}
```

Each page's `path` is added to the end of `baseUrl` (so `"baseUrl": "https://host/app"` with `"path": "/orders"` opens `https://host/app/orders`); a full `https://…` address in `path` is used as is. Page names must be unique: they name the screenshots and the report rows.

Add `"assumptions": ["…"]` for anything you decided without asking (which pages, which clicks, what counts as "loaded"); the report lists them right under the summary.

Interaction keys: `name` (unique on the page), `click`, `fill` + `value`, `press` (a key), and `expect` (a selector to wait for; on its own it times how long something takes to appear after the page is ready, such as a chart that loads later). A broken interaction never throws away the page-load numbers: it is recorded in `interactionErrors` and skipped in the remaining runs.

Optional top-level keys:

| Key | Default | Use |
|---|---|---|
| `waitForTimeoutMs` | 30000 (15000 in the preflight) | How long to wait for `waitFor`; when set, the preflight uses it too. After a redirect the wait stops after 5 s, so a lost login fails fast |
| `interactionTimeoutMs` | 10000 | How long a `click`/`fill` may wait for its element (`expect` waits at least 30 s) |
| `navTimeoutMs` | 60000 | Page navigation timeout |
| `ignoreRequests` | `[]` | Regular expressions for URLs that never finish (analytics beacons, custom live feeds) so they don't hold up "page settled". EventSource, WebSocket and any fetch/XHR open longer than 5 s are ignored automatically and listed as `longLivedRequests` |
| `ignoreHTTPSErrors` | `false` | Self-signed test certificates |
| `repeatView` | `true` | One extra repeat visit with a warm cache |
| `filmstrip` | `true` | One extra run that saves 8 frames of the page loading |
| `useBrowserSession` | `false` | Browser-connector mode only: reuse the browser tool's logged-in session (Step 3) |

## Step 5 — Run

```bash
node .perf-kit/measure-page.mjs --config <run-dir>/web-config.json --out <run-dir>
```

The script checks the config first. If something is missing or wrong (no pages, a page without a name, duplicate names, an interaction with nothing to do, no `baseUrl`), it stops with exit code `2` and a plain list of what to fix, before opening a browser.

- Duration is roughly pages × profiles × runs × 5–20 s (slow pages on `mobile-4g` take longest). If your shell has a time limit, start it in the background (`nohup … > <run-dir>/web.log 2>&1 &`) and poll the log.
- Keep the machine otherwise quiet while it runs. CPU contention inflates the numbers. The script samples the machine's load and the report says so when it was busy; then re-run borderline results when it is quiet. Compare before and after only on the same machine, profile and number of runs.
- Output in `<run-dir>`:
  - `web-results.json`
  - `screens/<page>-<profile>.png` (the loaded page)
  - `screens/<page>-<profile>-after-<action>.png` (the result of each scripted click)
  - `screens/film/` (filmstrip frames)
  - `lighthouse/*.html` when Lighthouse ran
- The reviewer sees the screenshots and filmstrip inside the report, so they're the visual proof of what the numbers say: the banner jump, the image appearing late, what the click showed.

## Step 5b — Browser-connector mode (the user's own browser runs it)

Use this when Step 2 pointed here. The run folder must be inside a folder that both this machine and the user's computer see (a connected or shared project folder). `--map` tells the script where that folder is on the user's computer: `--map "<folder here>=<same folder on the user's computer>"`, for example `--map "$HOME/mnt/my-repo=/Users/alex/code/my-repo"`. Leave `--map` out when both are the same machine.

```bash
# 1. Preflight, from the user's computer
node .perf-kit/measure-page.mjs --preflight --emit-mcp --config <run-dir>/web-config.json --out <run-dir> --map "<here>=<there>"
#    → run the printed "filename" once with the browser tool's run-code action, then poll until the exit code is not 5:
node .perf-kit/measure-page.mjs --preflight --collect-mcp --config <run-dir>/web-config.json --out <run-dir>
# 2. The measurement
node .perf-kit/measure-page.mjs --emit-mcp --config <run-dir>/web-config.json --out <run-dir> --map "<here>=<there>"
#    → run the printed "filename" once, then poll (every 30–60 s) until the exit code is not 5:
node .perf-kit/measure-page.mjs --collect-mcp --config <run-dir>/web-config.json --out <run-dir>
```

- The emitted `job-*.js` is a short loader for `job-*.core.js`; running it keeps the tool's echo small. It answers within seconds with `started: true` and keeps measuring in the background. If it answers `started: false` with `runInstead`, run that file instead; for any other `started: false`, fix what the `error` says.
- **Run each job file exactly once.** If the tool call times out, the job may well be running: poll `--collect-mcp` instead of starting it again. A second copy is refused while one runs, because two at once distort each other.
- `--collect-mcp` exit codes: `5` still running (it prints progress), `0` finished (it writes `web-results.json`, or prints the preflight checklist), `1` failed, stalled or never started (it says which), `2` nothing emitted yet.
- The connector preflight always keeps a screenshot of each page in `<run-dir>/preflight/` and prints the same `peek` outline as the local preflight, so you can check selectors before the long run.
- Browser windows may open and close on the user's computer while it runs; ask them not to close them. Measured on their computer, numbers include whatever else it is doing, so compare before and after from the same computer only. The report says so.
- Lighthouse cannot run in this mode; the report marks it as not measured.

## Step 6 — Check the results before reporting

Look at the console summary and `web-results.json`:

- Every page shows `n/n ok`. Read the errors of any failed runs.
- No `redirectedTo`. A redirect means the session is missing or expired.
- `status` is 2xx. The report flags an error page with ❌ and leaves it out of the "slowest page" summary.
- `interactionErrors` is empty. Otherwise the action time and INP for that click are missing: fix the selector and re-run.
- `settleTimedOut` is empty. If it lists URLs, the page kept loading them for 15 s: add them to `ignoreRequests` if they are live connections or beacons, or report them if they are real slow loads.
- The `lcpElement` is plausibly the page's main content. If it's a spinner or cookie bar, improve `waitFor` and re-run.
- `lcpFallbackRuns > 0` is fine. Headless Chromium sometimes drops the paint entry of a large image that is still streaming in; the script detects that and uses the image's load-finish time instead, and the report notes it.

If the run measured the wrong thing, fix the config and run again. A clean measurement of the wrong page is worse than no report.

## Step 7 — Report

Use **performance-report**: build the report from `<run-dir>/web-results.json` (plus `load-results.json` if a load test ran), write the analyst notes, and deliver.

## What each number means (for your own judgement)

| Metric | Plain meaning | Usual culprit when bad |
|---|---|---|
| TTFB | Server starts answering | Backend work, cold start, redirects |
| FCP | First thing appears | Slow TTFB, render-blocking CSS/JS |
| LCP | Main content appears | Large hero image or font, slow server, blocking scripts |
| CLS | Content jumps around | Late banners or ads, images without width/height |
| TBT | Page frozen by JavaScript after first paint | Long tasks: hydration, big bundles |
| INP | Delay from a click to the screen updating | Heavy click handlers on the main thread |
| Action time | Click until the expected result is visible | Slow API behind the action, heavy UI work |
| Page weight | Total download | Uncompressed images, large JS bundles |

The script also names culprits for the report:

- **Render-blocking files:** CSS/JS in `<head>` the browser had to wait for.
- **Heaviest scripts:** taken from Chrome's Long Animation Frames, split into "while loading" and "during clicks", e.g. `/blocking.js (250 ms)` or `BUTTON#add.onclick (600 ms)`.
- **Static files with weak cache headers** and **uncompressed text files.**
- **The repeat-visit download size.**

Lab quirks to know: TTFB is taken from the network layer. Chrome applies the simulated latency as a *minimum* per request, so a fast server shows about the latency and a slow server (1 s) hides it. The report states the exact throttling values. Scripts are split into *before first paint* (they delay FCP) and *after first paint* (they make up TBT), so don't add the two together. TBT is measured from first paint until the page settles, which approximates Lighthouse's window. Network and CPU throttling are simulated by Chromium and only approximate a real device. INP comes only from the interactions you scripted.

## measure-page.mjs

````js
#!/usr/bin/env node
// perf-kit:measure-page v5 — single-user page-speed measurement with Playwright + Chromium (CDP).
// Usage (this machine runs the browser):
//   node measure-page.mjs --preflight --config web-config.json
//   node measure-page.mjs --config web-config.json --out <run-dir>
// Usage (browser-connector mode: a Playwright browser tool on the user's computer runs the measurement):
//   node measure-page.mjs [--preflight] --emit-mcp --config web-config.json --out <run-dir> [--map <folder-here>=<same-folder-there>]
//   node measure-page.mjs [--preflight] --collect-mcp --config web-config.json --out <run-dir>   (exit 5 = still running)
// Writes <run-dir>/web-results.json (schema perf-results/1), screenshots in <run-dir>/screens/,
// and Lighthouse reports in <run-dir>/lighthouse/ when Lighthouse is available.
import { createRequire } from 'node:module';
import { execSync, spawnSync } from 'node:child_process';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

const args = process.argv.slice(2);
const arg = (k, d) => { const i = args.indexOf(`--${k}`); return i >= 0 ? args[i + 1] : d; };
const flag = (k) => args.includes(`--${k}`);

const PROFILES = {
  // Matches Lighthouse's desktop preset (40 ms RTT, 10 Mbps, no CPU slowdown).
  desktop: { viewport: { width: 1350, height: 940 }, dpr: 1, mobile: false, latency: 40, downKbps: 10240, upKbps: 5120, cpu: 1, lh: ['--preset=desktop'] },
  // Matches Lighthouse's default mobile profile ("Slow 4G": 150 ms RTT, 1.6 Mbps, 4x CPU slowdown).
  'mobile-4g': { viewport: { width: 412, height: 823 }, dpr: 1.75, mobile: true, latency: 150, downKbps: 1638, upKbps: 750, cpu: 4, lh: [] },
  // Worst-case check for loading states / skeletons.
  'slow-3g': { viewport: { width: 412, height: 823 }, dpr: 1.75, mobile: true, latency: 400, downKbps: 400, upKbps: 400, cpu: 4, lh: ['--throttling.rttMs=400', '--throttling.throughputKbps=400'] },
  // Raw machine speed, no throttling (useful for before/after comparisons on the same machine only).
  none: { viewport: { width: 1350, height: 940 }, dpr: 1, mobile: false, latency: 0, downKbps: -1, upKbps: -1, cpu: 1, lh: ['--preset=desktop', '--throttling-method=provided'] },
};

function loadPlaywright() {
  const bases = [path.join(process.cwd(), 'noop.js'), new URL(import.meta.url).pathname];
  try { bases.push(path.join(execSync('npm root -g', { stdio: ['ignore', 'pipe', 'ignore'] }).toString().trim(), 'noop.js')); } catch {}
  for (const b of bases) for (const n of ['playwright', '@playwright/test', 'playwright-core']) {
    try { const req = createRequire(b); const m = req(n); let v = '?'; try { v = req(`${n}/package.json`).version; } catch {} let where = path.dirname(b); try { where = path.dirname(req.resolve(`${n}/package.json`)); } catch {} if (m.chromium) return { pw: m, name: n, version: v, from: `${n}@${v} (${where})` }; } catch {}
  }
  return null;
}

function lighthouseAvailable() {
  const r = spawnSync('npx', ['--no-install', 'lighthouse', '--version'], { encoding: 'utf8', timeout: 30000 });
  return r.status === 0 ? r.stdout.trim() : null;
}

// A page's address: "path" is appended to baseUrl (so baseUrl may carry a prefix such as /app); a full http(s)://
// URL in "path" or "url" is used as is.
function pageUrl(cfg, page) { const p = page.path || page.url || '/'; return /^https?:\/\//i.test(p) ? p : `${String(cfg.baseUrl).replace(/\/+$/, '')}/${p.replace(/^\/+/, '')}`; }

// Mistakes in the config that would crash the run or measure the wrong thing.
function configProblems(cfg) {
  const p = []; const pages = cfg.pages || [];
  if (!pages.length) p.push('"pages" is empty: list at least one page ({ "name": "home", "path": "/", "waitFor": "main" }).');
  if (pages.some((pg) => !/^https?:\/\//i.test(pg.path || pg.url || '')) && !/^https?:\/\//i.test(cfg.baseUrl || '')) p.push('"baseUrl" must be a full http(s):// URL.');
  for (const [i, pg] of pages.entries()) {
    if (!pg.name) p.push(`pages[${i}] needs a "name".`);
    for (const [j, it] of (pg.interactions || []).entries()) { if (!it.name) p.push(`${pg.name || `pages[${i}]`}: interactions[${j}] needs a "name".`); if (!it.click && !it.fill && !it.press && !it.expect) p.push(`${pg.name || `pages[${i}]`}: interaction "${it.name || j}" needs "click", "fill", "press" or "expect".`); }
    const iNames = (pg.interactions || []).map((it) => it.name); if (new Set(iNames).size < iNames.length) p.push(`${pg.name || `pages[${i}]`}: interaction names must be unique.`);
  }
  const names = pages.map((pg) => pg.name); const dup = names.filter((n, i) => n && names.indexOf(n) !== i);
  if (dup.length) p.push(`Page names must be unique (they name the screenshots and report rows): ${[...new Set(dup)].join(', ')}.`);
  return p;
}

const pct = (vals, p) => { const v = vals.filter((x) => x != null).sort((a, b) => a - b); if (!v.length) return null; const i = (v.length - 1) * p; const lo = Math.floor(i); return v[lo] + (v[Math.ceil(i)] - v[lo]) * (i - lo); };

// Runs inside the page before any page script, so buffered observers catch everything.
function installObservers() {
  const s = (window.__perf = { lcp: null, lcpEl: null, lcpUrl: null, fcp: null, shifts: [], longTasks: [], events: [], loafs: [] });
  const desc = (el) => { if (!el || !el.tagName) return null; let d = el.tagName.toLowerCase(); if (el.id) return `${d}#${el.id}`; const c = typeof el.className === 'string' ? el.className.trim().split(/\s+/).filter(Boolean).slice(0, 2) : []; if (c.length) d += `.${c.join('.')}`; const t = el.getAttribute && el.getAttribute('data-testid'); return t ? `${d}[data-testid=${t}]` : d; };
  const po = (type, cb, extra = {}) => { try { new PerformanceObserver((l) => l.getEntries().forEach(cb)).observe({ type, buffered: true, ...extra }); } catch (e) { /* unsupported */ } };
  po('largest-contentful-paint', (e) => { s.lcp = e.startTime; s.lcpSize = e.size; s.lcpEl = desc(e.element); s.lcpUrl = e.url || null; });
  s.desc = desc;
  po('paint', (e) => { if (e.name === 'first-contentful-paint') s.fcp = e.startTime; });
  po('layout-shift', (e) => { if (!e.hadRecentInput) s.shifts.push({ t: e.startTime, v: e.value, src: desc(e.sources && e.sources[0] && e.sources[0].node) }); });
  po('longtask', (e) => s.longTasks.push({ start: e.startTime, dur: e.duration }));
  // Long Animation Frames name the scripts behind slow frames (Chrome 123+).
  po('long-animation-frame', (e) => s.loafs.push({ start: e.startTime, dur: e.duration, scripts: (e.scripts || []).map((x) => ({ src: x.sourceURL || '', invoker: x.invoker || '', type: x.invokerType || '', dur: x.duration })) }));
  po('event', (e) => { if (e.interactionId) s.events.push({ id: e.interactionId, dur: e.duration, name: e.name, target: desc(e.target) }); }, { durationThreshold: 16 });
  // 'event' entries only exist for interactions of 16 ms or more; 'first-input' always records the first one, so a
  // fast click is measured as fast instead of "not measured".
  po('first-input', (e) => s.events.push({ id: e.interactionId || 'first-input', dur: e.duration, name: e.name, target: desc(e.target) }));
}

// CLS = largest "session window" of shifts (gap < 1 s, window < 5 s) — the official definition.
function clsOf(shifts) {
  let max = 0, cur = 0, first = 0, prev = -1e9, top = null, curTop = null;
  for (const s of shifts) {
    if (s.t - prev < 1000 && s.t - first < 5000) { cur += s.v; } else { cur = s.v; first = s.t; curTop = null; }
    if (!curTop || s.v > curTop.v) curTop = s;
    prev = s.t;
    if (cur > max) { max = cur; top = curTop; }
  }
  return { value: max, topSource: top ? top.src : null };
}

const STATIC = new Set(['Script', 'Stylesheet', 'Image', 'Font', 'Media']);
const TEXTY = /html|javascript|ecmascript|css|json|xml|svg|text\/|font\/(ttf|otf|sfnt)|x-font-(ttf|otf)|font-sfnt|vnd\.ms-fontobject/; // compressible types (WOFF/WOFF2 are already compressed)

// mode: 'cold' (measured, fresh context), 'warm' (repeat visit: prime once, measure 2nd load), 'film' (evidence frames only)
// io = { join, writeBase64 }: file access is passed in, so the same code also runs inside a browser tool
// that has no file system (see the browser-connector job below).
async function measureOnce(browser, cfg, page, profileName, mode, runIdx, outDir, io, opts = {}) {
  const prof = PROFILES[profileName];
  const ctx = await browser.newContext({ viewport: prof.viewport, deviceScaleFactor: prof.dpr, isMobile: prof.mobile, hasTouch: prof.mobile, storageState: cfg.storageState || undefined, ignoreHTTPSErrors: !!cfg.ignoreHTTPSErrors });
  await ctx.addInitScript(installObservers);
  const p = await ctx.newPage();
  const cdp = await ctx.newCDPSession(p);
  await cdp.send('Network.enable');
  if (prof.latency || prof.downKbps > 0) await cdp.send('Network.emulateNetworkConditions', { offline: false, latency: prof.latency, downloadThroughput: prof.downKbps > 0 ? (prof.downKbps * 1024) / 8 : -1, uploadThroughput: prof.upKbps > 0 ? (prof.upKbps * 1024) / 8 : -1 });
  if (prof.cpu > 1) await cdp.send('Emulation.setCPUThrottlingRate', { rate: prof.cpu });

  let reqs = new Map(), lastNet = Date.now(), doc = {};
  const open = new Set(); const longLived = new Set(); const streams = new Set(); let settleTimedOut = null;
  const STREAMING = new Set(['WebSocket', 'EventSource']);
  const ignoreRe = (cfg.ignoreRequests || []).map((x) => new RegExp(x));
  cdp.on('Network.requestWillBeSent', (e) => {
    if (!/^(https?|wss?):/i.test(e.request.url)) return; // data:/blob: URLs are inline content, not downloads: no caching, size or timing to report
    if (e.type === 'Document' && !doc.id) { doc.id = e.requestId; doc.t0 = e.timestamp; }
    if (!reqs.has(e.requestId)) { reqs.set(e.requestId, { url: e.request.url, type: e.type || 'Other', start: e.timestamp, wall: Date.now() }); if (!STREAMING.has(e.type)) open.add(e.requestId); else streams.add(e.request.url.replace(/[?#].*$/, '')); }
    lastNet = Date.now();
  });
  cdp.on('Network.responseReceived', (e) => {
    const r = reqs.get(e.requestId); if (!r) return;
    const h = Object.fromEntries(Object.entries(e.response.headers || {}).map(([k, v]) => [k.toLowerCase(), v]));
    Object.assign(r, { status: e.response.status, type: e.type || r.type, mime: e.response.mimeType, cacheControl: h['cache-control'] || null, encoding: h['content-encoding'] || null, fromCache: !!(e.response.fromDiskCache || e.response.fromServiceWorker || e.response.fromPrefetchCache) });
    // TTFB from the network layer: unlike Navigation Timing, this includes the emulated network latency.
    if (e.requestId === doc.id && e.response.timing) doc.ttfb = (e.response.timing.requestTime - doc.t0) * 1000 + e.response.timing.receiveHeadersEnd;
  });
  const done = (e, failed) => { const r = reqs.get(e.requestId); if (r && r.end == null) { r.end = e.timestamp; r.bytes = e.encodedDataLength || 0; r.failed = failed; } open.delete(e.requestId); lastNet = Date.now(); };
  cdp.on('Network.loadingFinished', (e) => done(e, false));
  cdp.on('Network.loadingFailed', (e) => done(e, true));
  let consoleErrors = 0; p.on('console', (m) => { if (m.type() === 'error') consoleErrors++; }); p.on('pageerror', () => consoleErrors++);
  // "Settled" = no request started or finished for 1 s. Live connections never finish, so they are ignored:
  // EventSource/WebSocket always, fetch/XHR pending for over 5 s (long-poll), and URLs matching cfg.ignoreRequests.
  const pending = () => { const now = Date.now(); const out = []; for (const id of open) { const r = reqs.get(id); if (!r || ignoreRe.some((re) => re.test(r.url))) continue; if (['Fetch', 'XHR', 'Other', 'Ping'].includes(r.type) && now - r.wall > 5000) { longLived.add(r.url.replace(/[?#].*$/, '')); continue; } out.push(r); } return out; };
  const settle = async () => { const t0 = Date.now(); while (Date.now() - t0 < 15000) { if (!pending().length && Date.now() - lastNet > 1000) { await p.waitForTimeout(500); return; } await p.waitForTimeout(200); } settleTimedOut = pending().map((r) => r.url).slice(0, 5); };
  const waitReady = async () => {
    if (!page.waitFor) return;
    const redirected = new URL(p.url()).pathname !== new URL(url).pathname;
    const ms = redirected ? 5000 : cfg.waitForTimeoutMs || 30000;
    try { await p.locator(page.waitFor).first().waitFor({ state: 'visible', timeout: ms }); } catch (e) {
      throw new Error(redirected ? `ended on ${p.url()} instead of ${url} (a redirect — often a missing or expired login), and "${page.waitFor}" never appeared` : `"${page.waitFor}" did not appear within ${ms / 1000} s on ${p.url()} — check the selector or raise waitForTimeoutMs`);
    }
  };
  const shot = async (name) => { const f = `screens/${name}.png`; await p.screenshot({ path: io.join(outDir, f) }); return f; }; // Playwright creates the folder
  const slugify = (x) => String(x).toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
  // Preflight only: what the page offers for "ready" selectors and interactions.
  const peek = () => p.evaluate(() => {
    const t = (e) => (e.textContent || e.value || '').trim().replace(/\s+/g, ' ').slice(0, 50);
    const sel = (e) => { const tid = e.getAttribute('data-testid'); if (tid) return `[data-testid=${tid}]`; if (e.id) return `#${e.id}`; const n = e.getAttribute('name'); if (n) return `${e.tagName.toLowerCase()}[name=${n}]`; const al = e.getAttribute('aria-label'); if (al) return `${e.tagName.toLowerCase()}[aria-label="${al}"]`; return t(e) ? `${e.tagName.toLowerCase()}:has-text("${t(e).slice(0, 30)}")` : e.tagName.toLowerCase(); };
    const vis = (e) => { const r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0; };
    return { title: document.title, headings: [...document.querySelectorAll('h1, h2')].slice(0, 6).map((e) => `${e.tagName.toLowerCase()}: ${t(e)}`), testIds: [...new Set([...document.querySelectorAll('[data-testid]')].map((e) => e.getAttribute('data-testid')))].slice(0, 20), landmarks: ['main', 'table', 'form', 'nav', '[role=grid]', '[role=table]'].filter((s) => document.querySelector(s)),
      clickable: [...document.querySelectorAll('button, [role=button], a[href], summary, [role=tab]')].filter(vis).slice(0, 12).map((e) => `${sel(e)}${t(e) ? ` — "${t(e)}"` : ''}`), inputs: [...document.querySelectorAll('input:not([type=hidden]), textarea, select')].filter(vis).slice(0, 8).map((e) => `${sel(e)}${e.getAttribute('placeholder') ? ` — "${e.getAttribute('placeholder')}"` : ''}`) };
  }).catch(() => null);

  const url = pageUrl(cfg, page);
  const navTimeout = cfg.navTimeoutMs || 60000;
  const result = { run: runIdx + 1, mode, url };
  try {
    if (mode === 'warm') { // prime the cache like a first visit, then measure the repeat visit
      await p.goto(url, { waitUntil: 'load', timeout: navTimeout });
      await waitReady();
      await settle();
      reqs = new Map(); open.clear(); doc = {};
    }
    let frames = null;
    if (mode === 'film') {
      frames = [];
      cdp.on('Page.screencastFrame', (f) => { frames.push({ ts: f.metadata.timestamp, data: f.data }); cdp.send('Page.screencastFrameAck', { sessionId: f.sessionId }).catch(() => {}); });
      await cdp.send('Page.startScreencast', { format: 'jpeg', quality: 60, maxWidth: prof.mobile ? 300 : 480, maxHeight: 640 });
    }
    const navStart = Date.now() / 1000;
    const resp = await p.goto(url, { waitUntil: 'load', timeout: navTimeout });
    result.status = resp ? resp.status() : null;
    result.finalUrl = p.url();
    if (!(result.status >= 400)) await waitReady(); // an error page never shows the real content: don't wait for it
    await settle();
    if (mode === 'film') { // evidence only: up to 8 frames spread over the load, saved as small JPEGs
      await cdp.send('Page.stopScreencast');
      const end = Date.now() / 1000 - navStart; const out = [];
      const n = 8;
      for (let i = 1; i <= n; i++) {
        const t = end * (i / n) ** 2; const f = [...frames].reverse().find((x) => x.ts - navStart <= t); // denser early, where most visual change happens
        if (!f) { out.push({ ms: Math.round(t * 1000), file: null }); continue; }
        const file = `screens/film/${page.name}-${profileName}-${String(Math.round(t * 1000)).padStart(5, '0')}.jpg`;
        await io.writeBase64(io.join(outDir, file), f.data); out.push({ ms: Math.round(t * 1000), file });
      }
      result.film = out;
      return result;
    }
    if (mode === 'cold' && runIdx === 0) result.screenshot = await shot(`${page.name}-${profileName}`);
    if (opts.peek) result.peek = await peek();

    const snap = () => p.evaluate(() => {
      const n = performance.getEntriesByType('navigation')[0]; const s = window.__perf;
      // Headless Chromium sometimes drops the paint-timing entry of a large image that streams in under
      // network throttling. If a fully loaded, on-screen image is bigger than the reported LCP element,
      // the entry was missed: fall back to that image's load-finish time (when it can first paint).
      let lcp = s.lcp, lcpEl = s.lcpEl, lcpUrl = s.lcpUrl, lcpSource = lcp == null ? 'none' : 'observer';
      const vis = (r) => Math.max(0, Math.min(r.right, innerWidth) - Math.max(r.left, 0)) * Math.max(0, Math.min(r.bottom, innerHeight) - Math.max(r.top, 0));
      const imgs = [...document.images].filter((i) => i.complete && i.naturalWidth > 0).map((i) => ({ i, area: Math.min(vis(i.getBoundingClientRect()), i.naturalWidth * i.naturalHeight), src: i.currentSrc || i.src })).sort((a, b) => b.area - a.area);
      const big = imgs[0];
      if (big && big.area > (s.lcpSize || 0) && big.src !== s.lcpUrl) {
        const re = performance.getEntriesByName(big.src).find((e) => e.entryType === 'resource');
        if (re) { lcp = Math.max(re.responseEnd, s.fcp || 0); lcpEl = s.desc(big.i); lcpUrl = big.src; lcpSource = 'image-load-fallback'; }
      }
      const renderBlocking = performance.getEntriesByType('resource').filter((e) => e.renderBlockingStatus === 'blocking').map((e) => ({ url: e.name, ms: Math.round(e.responseEnd - e.startTime) }));
      return { nav: n ? { ttfb: n.responseStart, dcl: n.domContentLoadedEventEnd, load: n.loadEventEnd } : null, lcp, lcpEl, lcpUrl, lcpSource, fcp: s.fcp, shifts: s.shifts, longTasks: s.longTasks, loafs: s.loafs.slice(), renderBlocking };
    });
    const before = await snap();

    // scripted interactions (cold runs only) -> action time (click until expected element visible) + INP from Event Timing
    // A broken interaction must not throw away the page-load numbers: record its error and carry on.
    const actions = {}; const afterShots = {}; const interactionErrors = {};
    const itTimeout = cfg.interactionTimeoutMs || 10000;
    if (mode === 'cold') for (const it of page.interactions || []) {
      if (opts.skip?.has(it.name)) continue;
      const t = Date.now();
      try {
        if (it.fill) await p.locator(it.fill).first().fill(it.value ?? 'test', { timeout: itTimeout });
        if (it.click) await p.locator(it.click).first().click({ timeout: itTimeout });
        if (it.press) await p.keyboard.press(it.press);
        if (it.expect) await p.locator(it.expect).first().waitFor({ state: 'visible', timeout: Math.max(itTimeout, 30000) });
        actions[it.name] = Date.now() - t;
      } catch (e) { interactionErrors[it.name] = String(e.message || e).split('\n')[0]; actions[it.name] = null; continue; }
      await p.waitForTimeout(400);
      if (runIdx === 0) afterShots[it.name] = await shot(`${page.name}-${profileName}-after-${slugify(it.name)}`);
    }
    const after = await p.evaluate(() => ({ events: window.__perf.events, loafs: window.__perf.loafs }));
    const perInteraction = {};
    for (const e of after.events) if (!perInteraction[e.id] || e.dur > perInteraction[e.id].dur) perInteraction[e.id] = e;
    const ints = Object.values(perInteraction).sort((a, b) => b.dur - a.dur);
    // INP: worst interaction (with < 50 interactions, as in the spec); null when nothing was interacted with
    const inp = ints.length ? (ints.length < 50 ? ints[0].dur : pct(ints.map((i) => i.dur), 0.98)) : null;
    const topScripts = (loafs) => { const agg = {}; for (const f of loafs) for (const sc of f.scripts) { const src = sc.src ? sc.src.replace(/^https?:\/\/[^/]+/, '') : 'inline script'; const inv = sc.invoker && sc.invoker !== sc.src ? ` — ${sc.invoker}` : ''; const k = `${src}${inv}`; agg[k] = (agg[k] || 0) + sc.dur; } return Object.entries(agg).sort((a, b) => b[1] - a[1]).slice(0, 5).map(([script, ms]) => ({ script, ms: Math.round(ms) })); };

    const fcp = before.fcp;
    const lt = before.longTasks;
    const tbt = fcp == null ? null : lt.filter((x) => x.start + x.dur > fcp).reduce((a, x) => a + Math.max(0, x.dur - 50), 0);
    const cls = clsOf(before.shifts);
    const list = [...reqs.values()];
    const byType = {};
    for (const r of list) { const k = (r.type || 'Other').toLowerCase(); byType[k] = byType[k] || { bytes: 0, count: 0 }; byType[k].bytes += r.bytes || 0; byType[k].count++; }
    const weakCache = (cc) => !cc || /no-store|no-cache|private/.test(cc) || (!/immutable/.test(cc) && Number((/max-age=(\d+)/.exec(cc) || [])[1] || 0) < 86400);
    Object.assign(result, {
      metrics: { TTFB: doc.ttfb ?? before.nav?.ttfb ?? null, FCP: fcp, LCP: before.lcp, CLS: cls.value, TBT: tbt, INP: inp, DCL: before.nav?.dcl ?? null, Load: before.nav?.load ?? null },
      lcpElement: before.lcpEl, lcpUrl: before.lcpUrl, lcpSource: before.lcpSource, clsTopSource: cls.topSource,
      longTasks: { count: lt.length, totalMs: Math.round(lt.reduce((a, x) => a + x.dur, 0)), longestMs: Math.round(Math.max(0, ...lt.map((x) => x.dur))) },
      heavyScriptsBeforePaint: fcp == null ? [] : topScripts(before.loafs.filter((f) => f.start < fcp)), heavyScriptsLoad: topScripts(fcp == null ? before.loafs : before.loafs.filter((f) => f.start >= fcp)), heavyScriptsInteraction: topScripts(after.loafs.slice(before.loafs.length)),
      renderBlocking: before.renderBlocking,
      worstInteraction: ints[0] ? { durMs: ints[0].dur, event: ints[0].name, target: ints[0].target } : null,
      actions, afterShots, interactionErrors, longLived: [...longLived], streams: [...streams], settleTimedOut,
      resources: {
        requests: list.length, totalBytes: list.reduce((a, r) => a + (r.bytes || 0), 0), byType,
        failed: list.filter((r) => r.failed || (r.status || 0) >= 400).map((r) => ({ url: r.url, status: r.status || 'failed' })).slice(0, 10),
        largest: list.filter((r) => r.bytes).sort((a, b) => b.bytes - a.bytes).slice(0, 5).map((r) => ({ url: r.url, type: r.type, bytes: r.bytes, ms: r.end && r.start ? Math.round((r.end - r.start) * 1000) : null })),
        weakCaching: list.filter((r) => STATIC.has(r.type) && r.status === 200 && !r.fromCache && weakCache(r.cacheControl)).map((r) => ({ url: r.url, cacheControl: r.cacheControl })).slice(0, 10),
        uncompressed: list.filter((r) => (r.bytes || 0) > 2048 && !r.encoding && TEXTY.test(r.mime || '')).map((r) => ({ url: r.url, bytes: r.bytes })).slice(0, 10),
      },
      consoleErrors,
    });
  } catch (e) {
    result.error = String(e.message || e).split('\n')[0];
    try { result.finalUrl = result.finalUrl || p.url(); } catch {}
    if (opts.peek && !result.peek) { result.peek = await peek(); if (runIdx === 0 && !result.screenshot) result.screenshot = await shot(`${page.name}-${profileName}`).catch(() => undefined); } // show what loaded instead, so a wrong selector is easy to fix
  } finally {
    await ctx.close();
  }
  return result;
}

// All cold runs + one repeat visit + one filmstrip run for one page on one profile (raw results).
async function measurePageProfile(browser, cfg, page, pr, outDir, io, log = () => {}) {
  const runs = Number(cfg.runs || 5);
  const results = []; const skip = new Set();
  for (let i = 0; i < runs; i++) {
    const r = await measureOnce(browser, cfg, page, pr, 'cold', i, outDir, io, { skip });
    results.push(r); log(r.error ? '✗' : '·');
    if (i === 0 && r.error) { log(' first run failed, skipping the rest'); break; }
    if (i === 0 && r.status >= 400) { log(` error page (HTTP ${r.status}), skipping the rest`); return { page: page.name, profile: pr, runs, results, warm: null, film: null, stoppedEarly: `the page answered HTTP ${r.status} on the first run, so the remaining runs, the repeat visit and the filmstrip were skipped` }; }
    if (i === 0) for (const k of Object.keys(r.interactionErrors || {})) skip.add(k);
  }
  const anyOk = results.some((r) => !r.error);
  const warm = cfg.repeatView === false || !anyOk ? null : await measureOnce(browser, cfg, page, pr, 'warm', 0, outDir, io);
  const film = cfg.filmstrip === false || !anyOk ? null : await measureOnce(browser, cfg, page, pr, 'film', 0, outDir, io);
  log(`${warm ? (warm.error ? ' warm✗' : ' warm·') : ''}${film ? (film.error ? ' film✗' : ' film·') : ''}`);
  return { page: page.name, profile: pr, runs, results, warm, film };
}

// Raw runs -> one page entry of web-results.json (rated on the p75 by build-report).
function buildEntry(cfg, page, raw) {
  const { results, warm, film, profile: pr } = raw; const runs = raw.stoppedEarly ? results.length : raw.runs;
  const ok = results.filter((r) => !r.error);
  const series = (k) => ok.map((r) => r.metrics[k]);
  const mode = (xs) => { const c = {}; let best = null; for (const x of xs) if (x) { c[x] = (c[x] || 0) + 1; if (!best || c[x] > c[best]) best = x; } return best; };
  const entry = {
    name: page.name, url: pageUrl(cfg, page), profile: pr, runs, okRuns: ok.length,
    status: ok[0]?.status ?? results[0]?.status ?? null, finalUrl: ok[0]?.finalUrl ?? results[0]?.finalUrl ?? null,
    metrics: Object.fromEntries(['TTFB', 'FCP', 'LCP', 'CLS', 'TBT', 'INP', 'DCL', 'Load'].map((k) => [k, series(k)])),
    actions: Object.fromEntries((page.interactions || []).map((it) => [it.name, ok.map((r) => r.actions?.[it.name] ?? null)])),
    lcpElement: mode(ok.map((r) => r.lcpElement)), lcpUrl: mode(ok.map((r) => r.lcpUrl)), lcpFallbackRuns: ok.filter((r) => r.lcpSource === 'image-load-fallback').length, clsTopSource: mode(ok.map((r) => r.clsTopSource)),
    worstInteraction: ok.map((r) => r.worstInteraction).filter(Boolean).sort((a, b) => b.durMs - a.durMs)[0] || null,
    longTasks: ok[0]?.longTasks || null,
    heavyScriptsLoad: [...ok].sort((a, b) => (b.metrics.TBT || 0) - (a.metrics.TBT || 0))[0]?.heavyScriptsLoad || [],
    heavyScriptsBeforePaint: [...ok].sort((a, b) => (b.metrics.FCP || 0) - (a.metrics.FCP || 0))[0]?.heavyScriptsBeforePaint || [],
    heavyScriptsInteraction: ok.find((r) => r.heavyScriptsInteraction?.length)?.heavyScriptsInteraction || [],
    renderBlocking: ok[0]?.renderBlocking || [],
    afterShots: results[0]?.afterShots || {},
    interactionErrors: results[0]?.interactionErrors || {},
    longLivedRequests: [...new Set(ok.flatMap((r) => [...(r.streams || []), ...(r.longLived || [])]))],
    settleTimedOut: ok.find((r) => r.settleTimedOut)?.settleTimedOut || null,
    repeatView: warm && !warm.error ? { metrics: warm.metrics, transferredBytes: warm.resources.totalBytes, requests: warm.resources.requests } : warm ? { error: warm.error } : null,
    filmstrip: film && !film.error ? film.film : null,
    resources: ok.length ? { ...ok[0].resources, totalBytes: Math.round(pct(ok.map((r) => r.resources.totalBytes), 0.5)) } : null,
    consoleErrors: Math.max(0, ...ok.map((r) => r.consoleErrors)),
    screenshot: results[0]?.screenshot || null,
    errors: results.filter((r) => r.error).map((r) => `run ${r.run}: ${r.error}`),
    interactionsDefined: (page.interactions || []).length,
    lighthouse: null,
  };
  if (raw.stoppedEarly) { entry.stoppedEarly = raw.stoppedEarly; entry.plannedRuns = raw.runs; }
  if (entry.finalUrl && new URL(entry.finalUrl).pathname !== new URL(entry.url).pathname) entry.redirectedTo = entry.finalUrl;
  return entry;
}

// The reachability check sends no login, so a protected page answering 3xx/401/403 here is normal.
function statusNote(s) { return s >= 300 && s < 400 ? ' — a redirect; normal for a protected page checked without a session (the page checks below use the session)' : s === 401 || s === 403 ? ' — needs a login; normal for a protected page checked without a session' : ''; }

// Preflight verdict from the checklist lines only (the page outline in "peek" can contain any text).
function preflightFailed(chk) {
  return /TOO OLD/.test(chk.node || '') || [chk.playwright, chk.chromium, chk.target, chk.storageState].some((x) => /^(NOT FOUND|MISSING|UNREACHABLE)/.test(String(x || ''))) || Object.values(chk.pages || {}).some((v) => String(v).startsWith('FAILED'));
}

// One preflight dry-run result -> one plain-language line.
function pageCheck(r) {
  const redirected = r.finalUrl && new URL(r.finalUrl).pathname !== new URL(r.url).pathname;
  if (r.error) return `FAILED: ${r.error}`;
  if (r.status >= 400) return `FAILED: the page answered HTTP ${r.status} — it is an error page, not the page to measure`;
  if (Object.keys(r.interactionErrors || {}).length) return `FAILED interaction(s): ${Object.entries(r.interactionErrors).map(([k, v]) => `"${k}": ${v}`).join('; ')}`;
  const live = (r.longLived || []).length ? ` — keeps ${r.longLived.join(', ')} open; add ${r.longLived.length > 1 ? 'them' : 'it'} to "ignoreRequests" so each run doesn't wait 5 s for ${r.longLived.length > 1 ? 'them' : 'it'}` : '';
  return `ok (HTTP ${r.status}${redirected ? `, redirected to ${r.finalUrl} — check this is intended` : ''})${live}`;
}

// ---------- Browser-connector mode ----------
// When this machine has no browser or cannot reach the app, the measurement runs inside a Playwright browser tool
// on the user's computer (its "run code" action). That sandbox has no file system and must answer within about a
// minute, so the job starts in the background and saves its files through browser downloads. The functions below
// are copied into the job file as source text, so they may only use what that sandbox has.
function toB64(text) { return typeof Buffer !== 'undefined' ? Buffer.from(text, 'utf8').toString('base64') : btoa(unescape(encodeURIComponent(text))); }
function makeSaver(browser) {
  let ctx = null, pg = null, chain = Promise.resolve();
  const save = (abs, b64, mime) => (chain = chain.catch(() => {}).then(async () => {
    if (!pg) { ctx = await browser.newContext({ acceptDownloads: true }); pg = await ctx.newPage(); await pg.setContent('<a id="d" download="f">f</a>'); }
    await pg.evaluate(([d, m]) => { const bin = atob(d); const u = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i); const a = document.getElementById('d'); if (a.href) URL.revokeObjectURL(a.href); a.href = URL.createObjectURL(new Blob([u], { type: m })); }, [b64, mime || 'application/octet-stream']);
    const [dl] = await Promise.all([pg.waitForEvent('download'), pg.click('#d')]);
    await dl.saveAs(abs); await dl.delete().catch(() => {});
  }));
  return { save, saveJson: (abs, obj) => save(abs, toB64(JSON.stringify(obj, null, 2)), 'application/json'), close: async () => { await chain.catch(() => {}); if (ctx) await ctx.close().catch(() => {}); } };
}
async function runWebJob(page, J) {
  const browser = page.context().browser();
  if (!browser) return { started: false, error: 'This browser tool uses one persistent profile and cannot open clean, separate sessions. Start it in isolated mode (e.g. --isolated) or run the scripts on a machine with Playwright installed.' };
  const G = browser; // the browser object outlives each run-code call (a call's own globals do not)
  if (G.__perfKitJob && !G.__perfKitJob.done && Date.now() - G.__perfKitJob.at < 3 * 3600e3) return { started: false, alreadyRunning: G.__perfKitJob.id, note: 'Another perf-kit job is still running in this browser. Wait for it (poll --collect-mcp) instead of starting a second one: two at once distort each other.' };
  const job = (G.__perfKitJob = { id: J.id, at: Date.now(), done: false });
  const saver = makeSaver(browser);
  const io = { join: (...a) => a.join('/').replace(/\/{2,}/g, '/'), writeBase64: (abs, b64) => saver.save(abs, b64, 'image/jpeg') };
  const mcp = `${J.outDir}/mcp`;
  // Write the first file before answering, so a wrong folder mapping fails here, visibly, not silently later.
  try { await saver.saveJson(`${mcp}/${J.prefix}-started.json`, { jobId: J.id, startedAt: new Date().toISOString(), browser: `Chromium ${browser.version()}`, parts: J.total }); } catch (e) {
    await saver.close(); job.done = true;
    return { started: false, error: `Could not write into ${mcp} on this computer (${String(e.message || e).split('\n')[0]}). Check that --map points at the same folder on the user's computer.` };
  }
  (async () => {
    const cfg = { ...J.cfg };
    if (cfg.useBrowserSession) { const c = page.context(); cfg.storageState = await c.storageState({ indexedDB: true }).catch(() => c.storageState()); }
    if (J.preflight) {
      const out = { jobId: J.id, browser: `Chromium ${browser.version()}`, pages: {} };
      try { const r = await fetch(pageUrl(cfg, cfg.pages[0]), { redirect: 'manual', signal: AbortSignal.timeout(15000) }); out.target = `${cfg.baseUrl} reachable from the user's computer (HTTP ${r.status})${statusNote(r.status)}`; } catch (e) { out.target = `UNREACHABLE from the user's computer: ${(e.cause && e.cause.code) || e.message}`; }
      if (!/UNREACHABLE/.test(out.target)) for (const pg of cfg.pages) out.pages[pg.name] = await measureOnce(browser, { ...cfg, waitForTimeoutMs: cfg.waitForTimeoutMs || 15000 }, pg, 'none', 'cold', 0, `${J.outDir}/preflight`, io, { peek: true });
      await saver.saveJson(`${mcp}/${J.prefix}-done.json`, out);
      return;
    }
    let n = 0;
    for (const pg of cfg.pages) for (const pr of J.profiles) {
      const raw = await measurePageProfile(browser, cfg, pg, pr, J.outDir, io);
      await saver.saveJson(`${mcp}/${J.prefix}-part-${String(++n).padStart(2, '0')}.json`, { ...raw, jobId: J.id });
    }
    await saver.saveJson(`${mcp}/${J.prefix}-done.json`, { jobId: J.id, finishedAt: new Date().toISOString(), parts: n, browser: `Chromium ${browser.version()}` });
  })().catch((e) => saver.saveJson(`${mcp}/${J.prefix}-error.json`, { jobId: J.id, error: String((e && e.stack) || e) }).catch(() => {}))
    .finally(async () => { await saver.close(); job.done = true; });
  return { started: true, id: J.id, parts: J.total, poll: 'Do not run this file again. Poll with: node .perf-kit/measure-page.mjs --collect-mcp ... (exit 5 = still running)' };
}

// Writes the job and a tiny loader for it. Running the loader keeps the browser tool's echo of the call short
// (it prints the code it ran); the loader reads the job file through the browser and runs it. The job file is a
// complete job too: run it directly if the browser tool cannot open local files.
function writeJob(dir, prefix, core, host) {
  const ascii = (s) => s.replace(/[^\t\n\r -~]/g, (c) => `\\u${c.charCodeAt(0).toString(16).padStart(4, '0')}`);
  const coreFile = path.join(dir, `job-${prefix}.core.js`), loader = path.join(dir, `job-${prefix}.js`);
  fs.writeFileSync(coreFile, ascii(core), { mode: 0o600 });
  const hp = host(coreFile).split(/[\\/]/).map((s, i) => (i === 0 && /^[A-Za-z]:$/.test(s) ? s : encodeURIComponent(s))).join('/');
  const url = `file://${hp.startsWith('/') ? '' : '/'}${hp}`;
  fs.writeFileSync(loader, `async (page) => {
// perf-kit loader: reads job-${prefix}.core.js through the browser and starts it. Run this file ONCE.
const fallback = { started: false, runInstead: ${JSON.stringify(host(coreFile))} };
const b = page.context().browser(); if (!b) return { ...fallback, error: 'no separate browser sessions available' };
const ctx = await b.newContext(); let src;
try { const p = await ctx.newPage(); await p.goto(${JSON.stringify(url)}); src = await p.evaluate(() => { const pre = document.querySelector('pre'); return pre ? pre.textContent : document.body.textContent; }); }
catch (e) { return { ...fallback, error: 'could not read the job file: ' + String(e.message).split('\\n')[0] }; } finally { await ctx.close(); }
let job; try { job = (0, eval)('(' + src + ')'); } catch (e) { return { ...fallback, error: 'could not load the job: ' + e.message }; }
return job(page);
}
`);
  return { loader, coreFile };
}

// Maps a path on this machine to the same path on the user's computer (--map /here/project=/Users/me/project).
function hostPathFn(map) {
  if (!map) return (p) => path.resolve(p);
  const i = map.lastIndexOf('='); if (i < 1) throw new Error('--map needs <folder here>=<same folder on the user\'s computer>');
  const real = (p) => { try { return fs.realpathSync(p); } catch { return path.resolve(p); } };
  const from = real(map.slice(0, i)), to = map.slice(i + 1).replace(/[\\/]+$/, '');
  return (p) => { const abs = real(p); if (abs !== from && !abs.startsWith(from + path.sep)) throw new Error(`${abs} is not inside ${from}; keep the run folder inside the connected folder`); return to + abs.slice(from.length).split(path.sep).join('/'); };
}

// Status of a browser-connector job from the files it has written so far. Exit 5 = still running.
// Files are matched to the current job by jobId: old files are overwritten, never deleted (connected folders
// often forbid deleting).
function mcpStatus(dir, prefix, stallMin, alsoWatch = []) {
  const f = (n) => path.join(dir, n);
  const read = (n) => { try { return JSON.parse(fs.readFileSync(f(n), 'utf8')); } catch { return null; } };
  const cur = read(`${prefix}-current.json`)?.jobId;
  if (!cur) { console.error(`No job was emitted in ${dir}: run --emit-mcp first.`); process.exit(2); }
  const mine = (n) => { const j = read(n); return j && j.jobId === cur ? j : null; };
  const age = (t) => Math.round((Date.now() - t) / 1000);
  const err = mine(`${prefix}-error.json`);
  if (err) { console.error(`The job failed on the user's computer:\n${err.error}`); process.exit(1); }
  const partNames = fs.readdirSync(dir).filter((n) => n.startsWith(`${prefix}-part-`) && n.endsWith('.json')).sort();
  const parts = partNames.map((n) => mine(n)).filter(Boolean);
  const done = mine(`${prefix}-done.json`);
  if (done) return { done, parts };
  const started = mine(`${prefix}-started.json`);
  if (!started) {
    const jobT = fs.existsSync(f(`job-${prefix}.js`)) ? fs.statSync(f(`job-${prefix}.js`)).mtimeMs : null;
    console.log(jobT && age(jobT) > 120 ? `NOT STARTED: job-${prefix}.js was written ${age(jobT)} s ago and has not started. Run it once with the browser tool (run code, filename = the job file's path on the user's computer). If the tool answered started:false, fix what it says first.` : 'waiting for the job to start…');
    process.exit(jobT && age(jobT) > 600 ? 1 : 5);
  }
  const watched = alsoWatch.filter((d) => fs.existsSync(d)).flatMap((d) => fs.readdirSync(d).map((n) => fs.statSync(path.join(d, n)).mtimeMs)); // screenshots count as progress
  const last = Math.max(Date.parse(started.startedAt), ...[`${prefix}-started.json`, ...partNames].map((n) => fs.statSync(f(n)).mtimeMs), ...watched);
  if (age(last) > stallMin * 60) { console.error(`STALLED: no progress for ${Math.round(age(last) / 60)} min (${parts.length}/${started.parts} parts saved). The browser was probably closed or the computer slept. Re-emit and run the job again.`); process.exit(1); }
  console.log(`running: ${parts.length}/${started.parts} parts saved, last update ${age(last)} s ago (started ${started.startedAt})`);
  process.exit(5);
}

function emitWebJob(cfg, cfgPath, outDir, profiles, preflight, command) {
  const host = hostPathFn(arg('map'));
  fs.mkdirSync(path.join(outDir, 'mcp'), { recursive: true });
  const prefix = preflight ? 'web-preflight' : 'web';
  const jcfg = { ...cfg };
  if (cfg.storageState && !cfg.useBrowserSession) { if (!fs.existsSync(cfg.storageState)) throw new Error(`storageState file not found: ${cfg.storageState}`); jcfg.storageState = host(cfg.storageState); }
  const J = { id: `${prefix}-${Date.now().toString(36)}`, prefix, preflight, outDir: host(outDir), profiles, total: preflight ? 1 : cfg.pages.length * profiles.length, cfg: jcfg };
  const fns = [toB64, makeSaver, installObservers, clsOf, pageUrl, statusNote, measureOnce, measurePageProfile, runWebJob];
  const body = [
    `// perf-kit:measure-page browser-connector job (${prefix}), generated ${new Date().toISOString()} from ${path.relative(process.cwd(), cfgPath)}.`,
    '// Run it ONCE with the Playwright browser tool (run code, filename = this file). It answers at once and keeps working in the background.',
    `const PROFILES = ${JSON.stringify(PROFILES)};`, `const STATIC = new Set(${JSON.stringify([...STATIC])});`, `const TEXTY = ${TEXTY};`, `const pct = ${pct};`,
    ...fns.map((fn) => (/^(async\s+)?function\b/.test(String(fn)) ? String(fn) : `const ${fn.name} = ${fn};`)), `const J = ${JSON.stringify(J)};`, 'return runWebJob(page, J);'];
  let hostCwd = process.cwd(); try { hostCwd = host(process.cwd()); } catch {}
  fs.writeFileSync(path.join(outDir, 'mcp', `${prefix}-current.json`), JSON.stringify({ jobId: J.id, emittedAt: new Date().toISOString(), emitCommand: command, hostCwd }));
  const { loader, coreFile } = writeJob(path.join(outDir, 'mcp'), prefix, `async (page) => {\n${body.join('\n')}\n}\n`, host);
  const est = preflight ? cfg.pages.length * 15 : cfg.pages.length * profiles.length * (Number(cfg.runs || 5) + 2) * 12;
  console.log(JSON.stringify({ jobFile: path.relative(process.cwd(), loader), runWith: { tool: 'Playwright browser tool → run code (browser_run_code_unsafe)', filename: host(loader), ifItAnswersRunInstead: host(coreFile) }, expectedMinutes: Math.max(1, Math.round(est / 60)), then: `node ${path.relative(process.cwd(), process.argv[1])} ${preflight ? '--preflight ' : ''}--collect-mcp --config ${path.relative(process.cwd(), cfgPath)} --out ${path.relative(process.cwd(), outDir) || '.'}` }, null, 2));
}

function cookieHeaderFor(storageStatePath, url) {
  if (!storageStatePath) return null;
  try {
    const host = new URL(url).hostname;
    const st = JSON.parse(fs.readFileSync(storageStatePath, 'utf8'));
    const c = (st.cookies || []).filter((k) => host === k.domain.replace(/^\./, '') || host.endsWith(k.domain.startsWith('.') ? k.domain : `.${k.domain}`));
    return c.length ? c.map((k) => `${k.name}=${k.value}`).join('; ') : null;
  } catch { return null; }
}

function runLighthouse(url, profileName, outDir, name, cfg, chromePath) {
  const dir = path.join(outDir, 'lighthouse'); fs.mkdirSync(dir, { recursive: true });
  const base = path.join(dir, `${name}-${profileName}`);
  const a = ['--no-install', 'lighthouse', url, '--quiet', '--output=json', '--output=html', `--output-path=${base}`, '--chrome-flags=--headless=new --no-sandbox', '--only-categories=performance,accessibility,best-practices', ...PROFILES[profileName].lh];
  const cookie = cookieHeaderFor(cfg.storageState, url);
  if (cookie) a.push(`--extra-headers=${JSON.stringify({ Cookie: cookie })}`);
  const r = spawnSync('npx', a, { encoding: 'utf8', timeout: 240000, env: { ...process.env, CHROME_PATH: chromePath } });
  if (r.status !== 0 || !fs.existsSync(`${base}.report.json`)) return { error: `Lighthouse failed: ${(r.stderr || r.error || '').toString().trim().split('\n').slice(-2).join(' ').slice(0, 300)}` };
  const lhr = JSON.parse(fs.readFileSync(`${base}.report.json`, 'utf8'));
  const num = (id) => lhr.audits[id]?.numericValue ?? null;
  const score = (c) => (lhr.categories[c]?.score == null ? null : Math.round(lhr.categories[c].score * 100));
  return {
    version: lhr.lighthouseVersion,
    scores: { performance: score('performance'), accessibility: score('accessibility'), bestPractices: score('best-practices') },
    metrics: { LCP: num('largest-contentful-paint'), FCP: num('first-contentful-paint'), TBT: num('total-blocking-time'), CLS: num('cumulative-layout-shift'), SpeedIndex: num('speed-index') },
    html: path.relative(outDir, `${base}.report.html`),
  };
}

async function main() {
  const cfgPath = arg('config');
  if (!cfgPath) { console.error('Missing --config <web-config.json>'); process.exit(2); }
  const cfg = JSON.parse(fs.readFileSync(cfgPath, 'utf8'));
  const outDir = path.resolve(arg('out', cfg.outDir || '.'));
  const profiles = cfg.profiles || ['desktop', 'mobile-4g'];
  for (const pr of profiles) if (!PROFILES[pr]) { console.error(`Unknown profile ${pr}. Use: ${Object.keys(PROFILES).join(', ')}`); process.exit(2); }
  const cfgErr = flag('collect-mcp') ? [] : configProblems(cfg);
  if (cfgErr.length) { console.error(`Config problems (fix web-config.json):\n- ${cfgErr.join('\n- ')}`); process.exit(2); }
  const nodeIO = { join: path.join, writeBase64: async (f, b64) => { fs.mkdirSync(path.dirname(f), { recursive: true }); fs.writeFileSync(f, Buffer.from(b64, 'base64')); } };
  const command = `node ${path.relative(process.cwd(), process.argv[1])} ${args.map((a) => (/\s/.test(a) ? JSON.stringify(a) : a)).join(' ')}`;
  const profileInfo = Object.fromEntries(profiles.map((p) => [p, { latencyMs: PROFILES[p].latency, downKbps: PROFILES[p].downKbps, upKbps: PROFILES[p].upKbps, cpuSlowdown: PROFILES[p].cpu, viewport: `${PROFILES[p].viewport.width}x${PROFILES[p].viewport.height}` }]));
  const header = (tool) => ({ schema: 'perf-results/1', kind: 'web', label: cfg.label || cfg.baseUrl, target: cfg.baseUrl, environment: cfg.environment || 'unknown', startedAt: new Date().toISOString(), tool, cwd: process.cwd(), command, config: cfg, profiles: profileInfo, assumptions: cfg.assumptions || [], pages: [], notes: [] });

  // ----- browser-connector mode -----
  if (flag('emit-mcp')) { emitWebJob(cfg, cfgPath, outDir, profiles, flag('preflight'), command); return; }
  if (flag('collect-mcp')) {
    const dir = path.join(outDir, 'mcp');
    if (flag('preflight')) {
      const { done: r } = mcpStatus(dir, 'web-preflight', 5);
      const chk = { runner: `browser tool on the user's computer (${r.browser})`, target: r.target, storageState: cfg.useBrowserSession ? 'reusing the browser tool\'s logged-in session (useBrowserSession)' : cfg.storageState ? (fs.existsSync(cfg.storageState) ? 'found' : `MISSING: ${cfg.storageState}`) : 'none (unauthenticated)', lighthouse: 'not available in browser-connector mode (reported as not measured)', pages: Object.fromEntries(Object.entries(r.pages || {}).map(([k, v]) => [k, pageCheck(v)])), peek: Object.fromEntries(Object.entries(r.pages || {}).filter(([, v]) => v.peek).map(([k, v]) => [k, { ...v.peek, screenshot: v.screenshot ? path.relative(process.cwd(), path.join(outDir, 'preflight', v.screenshot)) : undefined }])) };
      console.log(JSON.stringify(chk, null, 2));
      process.exit(preflightFailed(chk) ? 1 : 0);
    }
    const { done, parts } = mcpStatus(dir, 'web', 15, [path.join(outDir, 'screens'), path.join(outDir, 'screens', 'film')]);
    const out = header(`Playwright browser tool on the user's computer + ${done.browser}`);
    const em = JSON.parse(fs.readFileSync(path.join(dir, 'web-current.json'), 'utf8'));
    Object.assign(out, { runner: 'browser-connector', cwd: em.hostCwd || process.cwd(), cwdLocal: process.cwd(), command: `${em.emitCommand.replace(/--map ("(?:[^"\\]|\\.)*"|\S+)/, (a, v) => { const x = v.startsWith('"') ? JSON.parse(v) : v; return `--map ${JSON.stringify(`<folder here>=${x.slice(x.lastIndexOf('=') + 1)}`)}`; })}\n# then run ${path.relative(process.cwd(), path.join(dir, 'job-web.js'))} once with the Playwright browser tool (run code), and collect:\n${command}` });
    if (cfg.lighthouse !== false) out.notes.push('Lighthouse scores were not measured: this run used the browser tool on the user\'s computer, which cannot start Lighthouse. Run the audit on a machine with Node 22+, Playwright and network access to add them.');
    for (const raw of parts) {
      const page = cfg.pages.find((p) => p.name === raw.page);
      const entry = buildEntry(cfg, page, raw); out.pages.push(entry);
      console.log(`▶ ${entry.name} [${entry.profile}] ${entry.status >= 400 ? `⚠ error page: HTTP ${entry.status}` : `${entry.okRuns}/${entry.runs} ok`}${Object.keys(entry.interactionErrors).length ? `  ⚠ interaction failed: ${Object.keys(entry.interactionErrors).join(', ')}` : ''}${entry.redirectedTo ? `  ⚠ redirected to ${entry.redirectedTo}` : ''}${entry.errors.length ? `  ⚠ ${entry.errors[0]}` : ''}`);
    }
    out.finishedAt = done.finishedAt;
    const file = path.join(outDir, 'web-results.json');
    fs.writeFileSync(file, JSON.stringify(out, null, 2));
    console.log(`\nSaved ${file}`);
    return;
  }
  if (cfg.useBrowserSession && !cfg.storageState) { console.error('"useBrowserSession" only works in browser-connector mode (--emit-mcp). Here, save a login with storageState instead.'); process.exit(2); }
  const loaded = loadPlaywright();

  if (flag('preflight')) {
    const major = Number(process.versions.node.split('.')[0]);
    const chk = { node: `${process.version}${major < 18 ? ' — TOO OLD (need 18+)' : major < 22 ? ' (fine; Lighthouse itself would need 22+)' : ''}`, playwright: loaded ? loaded.from : 'NOT FOUND — npm i -D playwright (or @playwright/test)' };
    if (loaded) { const exe = loaded.pw.chromium.executablePath(); chk.chromium = fs.existsSync(exe) ? exe : `MISSING at ${exe} — run: npx playwright install chromium`; }
    try { const r = await fetch(pageUrl(cfg, cfg.pages[0]), { redirect: 'manual', signal: AbortSignal.timeout(15000) }); chk.target = `${cfg.baseUrl} reachable (HTTP ${r.status})${statusNote(r.status)}`; } catch (e) { chk.target = `UNREACHABLE: ${e.cause?.code || e.message}`; }
    chk.lighthouse = cfg.lighthouse === false ? 'disabled in config' : lighthouseAvailable() || 'not installed (scores will be reported as not measured)';
    chk.storageState = cfg.storageState ? (fs.existsSync(cfg.storageState) ? 'found' : `MISSING: ${cfg.storageState}`) : 'none (unauthenticated)';
    // Dry run: open every page once (no throttling) and try its waitFor + interactions, so config mistakes
    // (wrong selector, login redirect, missing button) surface in seconds instead of after a long run.
    if (!preflightFailed(chk)) {
      const browser = await loaded.pw.chromium.launch({ headless: true });
      chk.pages = {};
      const keep = arg('out') ? path.join(outDir, 'preflight') : null; // with --out, keep a screenshot of each page
      const tmp = keep || fs.mkdtempSync(path.join(os.tmpdir(), 'perfkit-'));
      chk.peek = {};
      for (const page of cfg.pages) {
        const r = await measureOnce(browser, { ...cfg, waitForTimeoutMs: cfg.waitForTimeoutMs || 15000 }, page, 'none', 'cold', keep ? 0 : 1, tmp, nodeIO, { peek: true });
        chk.pages[page.name] = pageCheck(r);
        if (r.peek) chk.peek[page.name] = { ...r.peek, screenshot: r.screenshot ? path.relative(process.cwd(), path.join(tmp, r.screenshot)) : undefined };
      }
      await browser.close();
      if (!keep) fs.rmSync(tmp, { recursive: true, force: true });
    }
    console.log(JSON.stringify(chk, null, 2));
    process.exit(preflightFailed(chk) ? 1 : 0);
  }
  if (!loaded) { console.error('Playwright not found. Install it: npm i -D playwright && npx playwright install chromium'); process.exit(2); }

  const { pw } = loaded;
  const lhVersion = cfg.lighthouse === false ? null : lighthouseAvailable();
  const browser = await pw.chromium.launch({ headless: true });
  const out = header(`${loaded.name}@${loaded.version} + Chromium ${browser.version()}`);
  if (cfg.lighthouse !== false && !lhVersion) out.notes.push('Lighthouse is not installed on this machine, so Lighthouse scores were not measured. Install with `npm i -g lighthouse` (needs network) and re-run to add them.');

  // Other work on this machine slows the browser down: sample the load average so the report can say so.
  const cpus = os.cpus().length; let loadMax = os.loadavg()[0];
  const loadTimer = setInterval(() => { loadMax = Math.max(loadMax, os.loadavg()[0]); }, 5000);
  for (const page of cfg.pages) for (const pr of profiles) {
    process.stdout.write(`▶ ${page.name} [${pr}] `);
    const raw = await measurePageProfile(browser, cfg, page, pr, outDir, nodeIO, (s) => process.stdout.write(s));
    const entry = buildEntry(cfg, page, raw);
    if (lhVersion && entry.okRuns) entry.lighthouse = runLighthouse(entry.url, pr, outDir, page.name, cfg, pw.chromium.executablePath());
    out.pages.push(entry);
    console.log(` ${entry.status >= 400 ? `⚠ error page: HTTP ${entry.status}` : `${entry.okRuns}/${entry.runs} ok`}${Object.keys(entry.interactionErrors).length ? `  ⚠ interaction failed: ${Object.keys(entry.interactionErrors).join(', ')}` : ''}${entry.redirectedTo ? `  ⚠ redirected to ${entry.redirectedTo}` : ''}${entry.errors.length ? `  ⚠ ${entry.errors[0]}` : ''}`);
  }
  await browser.close();
  clearInterval(loadTimer);
  out.machine = { cpus, loadAvgMax: Math.round(loadMax * 10) / 10 };
  if (loadMax > cpus + 1) out.notes.push(`The test machine was busy during the run (1-minute load average up to ${out.machine.loadAvgMax} on ${cpus} CPU cores): other work competed with the browser, so times may be somewhat slower than they should be. Re-run on a quiet machine to confirm borderline results.`);
  out.finishedAt = new Date().toISOString();
  fs.mkdirSync(outDir, { recursive: true });
  const file = path.join(outDir, 'web-results.json');
  fs.writeFileSync(file, JSON.stringify(out, null, 2));
  console.log(`\nSaved ${file}`);
}
main().catch((e) => { console.error(String(e?.stack || e).split('\n').slice(0, 3).join('\n')); process.exit(1); });
````