---
name: test-script-generator
description: >
  Generate Playwright (Python) test scripts from First Recon AI QA test cases.
  Takes structured test case data (from excel-test-reader or raw TC IDs) and produces
  runnable pytest + Playwright scripts that mirror the manual test steps exactly.
  Use this skill whenever the user wants to automate test cases, generate E2E scripts,
  convert manual tests to Playwright, create automation for specific TC IDs, or build
  a test script file from Excel test cases.
  Triggers on: generate test script, automate test cases, create playwright test, write E2E test,
  convert to automation, generate script from TC, make test script, automate this test.
---

# Test Script Generator

Convert First Recon AI manual QA test cases into runnable Playwright (Python/pytest) scripts.

## What Good Scripts Look Like

Each generated script should:
1. Be runnable with `pytest` and `playwright` out of the box
2. Mirror the manual test steps faithfully — don't invent interactions not described in the steps
3. Assert on the **Expected Result** field exactly
4. Include the TC ID, description, and sheet as metadata in the docstring
5. Be grouped by test section/sheet into a single file (or split if the user prefers)

## Script Template

```python
"""
QA Test Script — {sheet}
Generated from: First Recon AI Full QA Test Suite
"""
import pytest
from playwright.sync_api import Page, expect


BASE_URL = "https://app.dev.firstrecon.ai"


@pytest.fixture(autouse=True)
def setup(page: Page):
    """Navigate and authenticate before each test."""
    page.goto(BASE_URL)
    # Authentication is handled by existing session or via env var credentials
    yield


class Test{SectionName}:

    def test_{tc_id_snake}(self, page: Page):
        """
        {tc_id}: {description}
        
        Steps:
        {steps}
        
        Expected: {expected}
        """
        # --- Steps ---
        {step_implementations}

        # --- Assertion ---
        {assertion}
```

## How to Translate Test Steps → Code

Use this mapping when converting human-readable steps:

| Step phrase | Playwright code |
|-------------|----------------|
| "Navigate to /path" | `page.goto(f"{BASE_URL}/path")` |
| "Click [element]" | `page.get_by_role("button", name="...").click()` or `page.locator("...").click()` |
| "Observe / Confirm / Verify [element] present" | `expect(page.get_by_text("...")).to_be_visible()` |
| "Confirm [text] shown" | `expect(page.get_by_text("...")).to_be_visible()` |
| "Type / Enter [value]" | `page.get_by_label("...").fill("value")` |
| "Wait for [element]" | `page.wait_for_selector("...")` |
| "Inspect / Check [element]" | `expect(page.locator("...")).to_have_attribute(...)` |
| "Expand / Collapse [element]" | `page.locator("...").click()` |

**When a step is ambiguous** (e.g., "Observe sidebar"), add a `# TODO: refine selector` comment so the user knows to review it rather than leaving broken code silently.

## Assertion Strategy

Derive assertions from the **Expected Result** field:
- Presence of text/element → `expect(locator).to_be_visible()`
- Count of items → `expect(locator).to_have_count(N)`
- Text content → `expect(locator).to_have_text("...")`
- URL → `expect(page).to_have_url(re.compile("..."))`
- Attribute → `expect(locator).to_have_attribute("attr", "value")`

If the expected result is vague, add a `# TODO: add specific assertion` comment.

## File Naming Convention

```
test_{sheet_slug}_{section_slug}.py
```
Examples:
- `test_workspace_chat_sidebar.py`
- `test_platform_admin_sidebar.py`
- `test_operations_portal_tenants.py`

## Full Example

**Input test case:**
```
ID: TC-WC-ChatSidebar-001
Description: Verify sidebar New Chat button (expanded)
Steps: 1. Observe left sidebar Chat Actions nav.\n2. Confirm New Chat button present.
Expected: New Chat button visible in sidebar.
```

**Output:**
```python
def test_tc_wc_chatsidebar_001(self, page: Page):
    """
    TC-WC-ChatSidebar-001: Verify sidebar New Chat button (expanded)
    
    Steps:
      1. Observe left sidebar Chat Actions nav.
      2. Confirm New Chat button present.
    
    Expected: New Chat button visible in sidebar.
    """
    # Step 1: Observe left sidebar Chat Actions nav
    page.goto(f"{BASE_URL}/workspace")
    
    # Step 2: Confirm New Chat button present
    new_chat_btn = page.get_by_role("button", name="New Chat")
    expect(new_chat_btn).to_be_visible()
```

## Batch Generation

When given multiple test cases:
1. Group by sheet → one file per sheet (or one file per section if the user prefers)
2. Output a `conftest.py` with shared fixtures (login, base URL, etc.)
3. Print a file manifest at the end:
   ```
   Generated files:
     conftest.py                          (shared fixtures)
     test_workspace_chat_sidebar.py       (12 test cases)
     test_platform_admin_sidebar.py       (8 test cases)
   ```

## Dependencies

Generated scripts require:
```
pytest
playwright
pytest-playwright
```

Install: `pip install pytest playwright pytest-playwright --break-system-packages && playwright install chromium`

## Handoff

After generating scripts, tell the user:
> "Scripts are ready. Run `pytest <file>.py -v` to execute, or use the **test-script-validator** skill to verify them first."
