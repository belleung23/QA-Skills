---
name: excel-status-updater
description: >
  Write test results back to the First Recon AI QA Excel test suite after tests complete.
  Updates the Status, Actual Result, Comments, and Failure Type columns for specific TC IDs
  in the correct sheet, then saves the file. Preserves all existing formatting and other rows.
  Use this skill whenever the user wants to mark tests as passed/failed in Excel, update test
  status after a run, write results back to the spreadsheet, record actual results, or bulk-update
  multiple test statuses at once.
  Triggers on: update status in excel, mark as passed, mark as failed, write results to excel,
  update excel after test, record test results, set status in spreadsheet, bulk update status.
---

# Excel Status Updater

Write test execution results back into the First Recon AI QA Excel spreadsheet.

## Valid Status Values

| Status | Meaning |
|--------|---------|
| `PASSED` | Behavior verified as expected |
| `FAILED` | Live defect or divergence from expected |
| `BLOCKED` | Could not execute (env/auth/dependency issue) |
| `N/A` | Test case written but not executed in this run |

## Valid Failure Types (only required when Status = FAILED)

- `Product Defect` — Reproduced on the correct route; actual behavior differs from expected
- `Reference/Spec Mismatch` — Build differs from original test spec but may be intentional
- `Negative-test (by-design)` — Intentionally uses invalid input/state; expected failure
- `Needs relook` — Ambiguous or possible test/environment issue; requires further investigation

## How to Update the File

Use `openpyxl` with `keep_vba=False` (no macros in this file). Load with `data_only=False` to preserve formulas in the Summary sheet:

```python
import openpyxl

# Column mapping
COL_STATUS        = 6
COL_ACTUAL_RESULT = 5
COL_COMMENTS      = 7
COL_FAILURE_TYPE  = 9

TEST_SHEETS = [
    'Workspace-Chat', 'Platform-Admin', 'Operations-Portal',
    'Prompt-Security', 'User-Settings', 'AI-Security-Runtime',
    'Integration-Workflows'
]

def update_test_results(xlsx_path, updates, output_path=None):
    """
    updates: list of dicts, e.g.:
      [
        {
          'id': 'TC-WC-ChatSidebar-001',
          'status': 'PASSED',
          'actual_result': 'New Chat button is visible.',
          'comments': '',
          'failure_type': ''
        },
        {
          'id': 'TC-PA-Sidebar-002',
          'status': 'FAILED',
          'actual_result': 'Toggle did not collapse submenus.',
          'comments': 'Intermittent — reproduced twice.',
          'failure_type': 'Product Defect'
        },
      ]
    output_path: save to a new file if provided; otherwise overwrite xlsx_path.
    """
    wb = openpyxl.load_workbook(xlsx_path)
    
    # Build a lookup: tc_id -> (sheet_name, row_number)
    id_to_location = {}
    for sheet_name in TEST_SHEETS:
        if sheet_name not in wb.sheetnames:
            continue
        ws = wb[sheet_name]
        for row in range(2, ws.max_row + 1):
            tc_id = ws.cell(row=row, column=1).value
            if tc_id and str(tc_id).startswith('TC-'):
                id_to_location[tc_id] = (sheet_name, row)
    
    results = []
    for update in updates:
        tc_id = update['id']
        if tc_id not in id_to_location:
            results.append({'id': tc_id, 'result': 'NOT FOUND'})
            continue
        
        sheet_name, row = id_to_location[tc_id]
        ws = wb[sheet_name]
        
        # Validate status
        valid_statuses = {'PASSED', 'FAILED', 'BLOCKED', 'N/A'}
        status = update.get('status', '').upper()
        if status not in valid_statuses:
            results.append({'id': tc_id, 'result': f'INVALID STATUS: {status}'})
            continue
        
        ws.cell(row=row, column=COL_STATUS).value = status
        if 'actual_result' in update:
            ws.cell(row=row, column=COL_ACTUAL_RESULT).value = update['actual_result']
        if 'comments' in update:
            ws.cell(row=row, column=COL_COMMENTS).value = update['comments']
        if 'failure_type' in update and status == 'FAILED':
            ws.cell(row=row, column=COL_FAILURE_TYPE).value = update['failure_type']
        elif status != 'FAILED':
            # Clear failure type if not failed
            ws.cell(row=row, column=COL_FAILURE_TYPE).value = None
        
        results.append({'id': tc_id, 'result': 'UPDATED', 'sheet': sheet_name, 'row': row})
    
    save_path = output_path or xlsx_path
    wb.save(save_path)
    return results, save_path
```

## Input Formats

Accept updates from the user in any of these forms:

**Natural language:**
> "Mark TC-WC-ChatSidebar-001 as passed"
> "TC-PA-Sidebar-002 failed — toggle didn't work"
> "Set TC-OP-Tenants-001 to BLOCKED, couldn't log in"

**From pytest output:** Parse `pytest -v` output to extract pass/fail per test function name, then map back to TC IDs via the function name convention `test_{tc_id_snake}`.

**Bulk from a results dict:** Accept a JSON/dict of `{tc_id: status}` pairs.

## Parsing Pytest Output

When the user pastes pytest output, extract results like this:

```python
import re

def parse_pytest_output(output: str) -> list[dict]:
    """Parse pytest -v output into TC ID → status mappings."""
    results = []
    # Match lines like: test_workspace_chat.py::TestChat::test_tc_wc_chatsidebar_001 PASSED
    pattern = r'test_\w+::Test\w+::(test_tc_[\w]+)\s+(PASSED|FAILED|ERROR|SKIPPED)'
    for match in re.finditer(pattern, output, re.MULTILINE):
        fn_name, outcome = match.groups()
        # Convert test_tc_wc_chatsidebar_001 → TC-WC-ChatSidebar-001
        # (reverse of the snake_case conversion done in script generator)
        tc_id = fn_name.replace('test_', '', 1).upper().replace('_', '-')
        status = 'PASSED' if outcome == 'PASSED' else 'FAILED'
        results.append({'id': tc_id, 'status': status})
    return results
```

## Safety Rules

1. **Never overwrite an already-PASSED test with a worse status** without explicit confirmation from the user. Ask: "TC-WC-001 is currently PASSED. Set it to FAILED?"
2. **Always save to a backup first** if overwriting the original file: copy `filename.xlsx` → `filename_backup_YYYYMMDD.xlsx` before writing.
3. **Validate TC IDs exist** before writing. Report missing IDs clearly.
4. **Failure Type is required for FAILED** — if the user doesn't provide one, ask before saving.

## Update Report

After saving, always print a summary:

```
=== Excel Status Update Report ===
File saved to: First-Recon-AI-Full-QA-Test-Suite_updated.xlsx

Updated: 8 test cases
  ✅ TC-WC-ChatSidebar-001  → PASSED   (Workspace-Chat, row 3)
  ✅ TC-WC-ChatSidebar-002  → PASSED   (Workspace-Chat, row 4)
  ❌ TC-PA-Sidebar-003      → FAILED   (Platform-Admin, row 7) [Product Defect]
  🚫 TC-OP-Tenants-001      → BLOCKED  (Operations-Portal, row 3)

Not found (1):
  ⚠️  TC-INVALID-999        → NOT FOUND in any sheet

Summary sheet totals will recalculate when you open the file in Excel.
```

## Handoff

After updating:
> "Results written to Excel. Open the file to verify, or share it with the team."

If the user has Linear integration:
> "Status updated in Excel. Want me to also file Linear issues for the FAILED cases?"
