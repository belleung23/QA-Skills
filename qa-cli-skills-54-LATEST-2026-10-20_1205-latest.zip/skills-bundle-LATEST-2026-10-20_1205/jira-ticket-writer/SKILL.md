---
name: "jira-ticket-writer"
description: "Create bug tickets directly in Jira via the Atlassian connector — sets title, priority, assignee, labels, attachments and the parent link. Requires a completed root-cause-forensics RCA before any ticket is created; the RCA block goes into the description and sets priority. Labels come from scope (Frontend/Backend/Both), priority and workspace. Records the environment per the routing policy — Dev for normal tickets, Production (with Dev fallback) for [Pro]/[Prod]. Use whenever the user says 'Jira' followed by AC numbers or test case references, or wants to auto-create a bug ticket. Triggers on: Jira, create Jira ticket, file bug in Jira, submit bug to Jira, auto-create ticket, push to Jira."
---

# Jira Ticket Writer

Creates bug tickets in Jira with evidence attached automatically.

> **Fixed 2026-10-16 (create, attach and comment verified on GR-11288).** The old version ran
> `create_jira_bug.py` with `TESTING_JIRA_API_TOKEN` from `.dev.vars` (not configured, and
> `persefoni.atlassian.net` is unreachable from both sandboxes) and wrote the description in Jira
> wiki markup. This version uses the **Atlassian connector** (`mcp__Atlassian_MCP__*`):
> `createJiraIssue` (Markdown description), `uploadAttachmentToJiraIssue` + a POST from the Mac's
> Playwright, `editJiraIssue` (HTML) to embed images, `createJiraIssueLink`, `addOrEditJiraIssueComment`.
> **Site:** `cloudId = dce2ce03-4355-4e26-8af2-06995df138ef`.

The description is the most important part of a bug ticket. A developer reading it must be able to understand the bug, reproduce it, and know exactly what "fixed" looks like — without needing to ask QA a single question. Every field below exists for a reason; don't skip or abbreviate them.

---

## Step 0a — RCA prerequisite (MANDATORY GATE)

> **No ticket is created without a completed `root-cause-forensics` RCA.** A bug report that describes only a symptom is not ready to file.

Before doing anything else, confirm you hold an RCA for every failure going into this ticket:

| Required from `root-cause-forensics` | Used for |
|---|---|
| Class — 🎨 Frontend / ⚙️ Backend / 🔗 Integration / 🗄️ Data / 🔧 Config | `## Root Cause Analysis` + the `scope` label in Step 4 |
| Location — `path/to/file.ts:142 — functionName()` | `## Root Cause Analysis` |
| Mechanism — one or two sentences | `## Root Cause Analysis` |
| Confidence — High / Medium / Low | `## Root Cause Analysis` (state it; never inflate it) |
| Type — Regression / Latent defect / Incomplete fix | Priority, and whether to file at all |
| Console log (verbatim, secrets redacted) | `### Console Errors` code block |
| Network log (verbatim, secrets redacted) | `### Network Failures` code block |
| RCA `.md` + `-console.log` + `-network.json` paths | attachments in Step 7 |

**If no RCA exists → stop and run `root-cause-forensics` first.** Do not file from the symptom alone.

**RCA verdicts that mean DO NOT FILE:**

| Verdict | Instead |
|---|---|
| 🔌 **Environment** | Not a bug. Report the env fault to the user; re-test once healthy. |
| 📋 **Spec gap** | Post a Clarification comment via `jira-comment-writer` and escalate the AC ambiguity. |
| ❓ **Not reproducible** | Attach evidence to the parent ticket via `jira-comment-writer`; assert no cause. |
| **Incomplete fix** on the ticket under test | Reopen that ticket with the full RCA — do not create a new bug. |

**Priority comes from the RCA class, not the visible symptom.** A 500 on a core write path is High/Critical even when the only thing the user sees is a missing toast. Conversely, a cosmetic 🎨 Frontend defect with no data impact stays Low regardless of how obvious it looks.

---

## Step 0b — Repo root

```bash
REPO_ROOT="$HOME/mnt/eng-guardrails-platform"        # device_bash on the Mac
[ -d "$REPO_ROOT/.git" ] || { echo "[ERROR] repo folder not connected"; exit 1; }
mkdir -p "$REPO_ROOT/bug-drafts"
```

Playwright on the Mac sees the same folder as `/Users/belleung/Documents/guardrails/eng-guardrails-platform`.

---

## Step 1 — Gather all TC data from the Google Sheet

When the command references TC IDs (e.g. TC-PA-443, TC-WC-458), fetch the full row for each TC from the QA test suite Google Sheet **before** writing the description. Do not paraphrase — copy the exact text from the sheet columns:

| Sheet column | Maps to description field |
|---|---|
| Test Case ID | TC identifier in heading |
| Nav | Navigation path |
| Priority | P1 / P2 / P3 label |
| Description | Short heading / summary |
| Test Steps | Numbered steps to reproduce |
| Expected Result | Expected section |
| Actual Result (or observed) | Actual section |
| Acceptance Criteria | AC list |

**Fetch method** — use the gviz/tq API from within the authenticated Google Sheets browser tab (tabId from Claude in Chrome):

```javascript
const sid = '1tOOMsej7yuwiahUEk0foR-6Mk4fWnzrjbhycTwnUAAM';
const ids = ['TC-PA-443', 'TC-WC-458']; // replace with actual IDs
const sheetName = 'Platform-Admin'; // match the correct sheet tab
const conditions = ids.map(id => `A = '${id}'`).join(' or ');
const tq = encodeURIComponent(`select * where ${conditions}`);
const url = `https://docs.google.com/spreadsheets/d/${sid}/gviz/tq?tqx=out:csv&sheet=${encodeURIComponent(sheetName)}&tq=${tq}`;
const resp = await fetch(url, { credentials: 'include' });
const csv = await resp.text();
return csv;
```

Run this for each sheet tab that contains TCs referenced in the command. Parse the CSV to extract the fields above for every TC.

If the TC data is already available in sessionStorage (stored as `tc_TC-PA-443`), read from there first to avoid redundant fetches.

---

## Step 2 — Identify failing items

For each TC, extract:
- TC ID, Nav, Priority, description/title
- Numbered test steps (verbatim from sheet)
- Expected result (verbatim)
- Actual result (verbatim — what was observed on screen, not a summary)
- Acceptance criteria (verbatim, each as a separate AC bullet)
- Existing media paths (screenshots / recordings already captured)
- **RCA verdict** (class, location, mechanism, confidence, type) and RCA artifact paths
- Parent Jira ticket ID (if applicable)

**Group by root cause, not by symptom.** If several TCs share one RCA location and mechanism, they belong in **one** ticket listing every affected TC — not one ticket each. Distinct root causes always get separate tickets even when the symptom looks identical.

---

## Step 3 — Capture fresh evidence (UI bugs only, if not already captured)

Use `qa-evidence-capture` Part 1 (FAIL, with the failing selector as a mark) and Part 2 (GIF). Files land in `$REPO_ROOT/manual-testing/evidences/{PARENT_KEY}/`. Skip for pure backend failures.

Console and network logs are **not** re-captured here — `root-cause-forensics` already saved them to `$REPO_ROOT/manual-testing/evidences/{PARENT_KEY}/rca/`. Re-capturing now would collect a clean page, not the failure.

---

## Step 4 — Label strategy

Final label array: `[scope, priority-label, workspace-label, "qa-found", "FRAI-Guardrails"]`

**Scope** (one): `frontend` / `backend` / `both` — take it from the RCA class:

| RCA class | Scope label |
|---|---|
| 🎨 Frontend | `frontend` |
| ⚙️ Backend | `backend` |
| 🔗 Integration / Contract | `both` |
| 🗄️ Data | `backend` |
| 🔧 Config / Flag | `backend` (or `both` if a UI guard is also missing) |

**Priority** (one): `priority-critical` / `priority-high` / `priority-medium` / `priority-low` — set from RCA severity and blast radius, not the surface symptom.

**Workspace** (one):

| Label | Routes |
|-------|--------|
| `ai-chat` | `/chat/*`, `chat-worker` |
| `prompt-security` | `/prompt-security/*`, `guardrails-worker` |
| `platform-admin` | `/admin/*`, `admin-worker` |
| `developer-tools` | `/developer/*`, `gateway-worker` |
| `operations` | `/dev-admin/*`, `/operations/*` |
| `qa-feedback` | DLP, `guardrails-worker`, `services/guardrails/*` |
| `wip-workspace` | `workers/*/`, `migrations/`, `.github/workflows/` |
| `product-intent` | `corpus-worker`, knowledge base |
| `test-policies` | Cross-cutting / unclear |

Prefer the workspace that owns the **RCA location file**, not the page where the symptom appeared — they differ when a shared worker is at fault.

---

## Step 5 — Duplicate check

```
searchJiraIssuesUsingJql(cloudId, jql='project = GR AND issuetype = Bug AND summary ~ "[feature] [what broke]"')
```

Run 2–3 keyword variants. If an open duplicate is found → do NOT create; report the existing ticket. If closed → create and link `Relates`.

Also search on the **RCA location** — `summary ~ "validator"` or the function name — since the same root cause often surfaced earlier under a different symptom and was filed with different wording.

---

## Step 6 — Write the description (Markdown)

Save a copy to `$REPO_ROOT/bug-drafts/{PARENT_KEY}_bug_description.md` for the record. The connector converts Markdown to ADF; **do not** use Jira wiki markup (`h2.`, `{code}`, `!file.png!`) — it renders as literal text.

### Summary line

```
[Area] Short plain-English statement of what is broken (≤ 80 chars)
```

Good: `[Platform Admin] Security Dashboard time-range selector does not apply to chart`
Bad: `Bug in admin`

### Description — full template

```markdown
## Summary
[2–3 sentences that tell the whole story: what feature is affected, what broke, and why it matters to the user. No jargon abbreviations — write it so a new developer on their first day can understand.]

## Environment
- Affected: Dev — https://app.dev.firstrecon.ai
- URL: https://app.dev.firstrecon.ai/[exact path where bug occurs]
- Browser: Chrome
- Tested by: belle.ung@persefoni.com
- Area: [workspace / feature area from Nav path]

---

## Failing Test Cases ({N})

### {TC-ID} — {verbatim description from sheet}
**Priority:** {P1 / P2 / P3}
**Nav:** {exact nav path from sheet, e.g. Platform Admin > Dashboards & Feeds > Security}

**Steps to Reproduce:**
1. {Step 1 — verbatim from sheet, written as a complete action: "Navigate to /admin > Security"}
2. {Step 2}
3. {Step 3}
4. {Step 4 — include "Observe [what]" as the last step so the reader knows where to look}

**Expected:** {Exact expected behaviour — what should happen, from the sheet. Complete sentence.}
**Actual:** {Exactly what happened — what appeared on screen or what failed. Complete sentence. Quote error messages verbatim if any.}

**Acceptance Criteria:**
- AC1: {First criterion — complete sentence}
- AC2: {Second criterion if present}

[Repeat the ### block for each additional TC]

---

## Root Cause Analysis

**Class:** {Frontend | Backend | Integration | Data | Config}
**Location:** `path/to/file.ts:142` — `functionName()`
**Mechanism:** {One or two sentences naming the exact faulty behaviour and why the bad input reaches it.}
**Confidence:** {High | Medium | Low}
**Type:** {Regression — PR #4821 (abc1234, @author, 2026-07-24) | Latent defect | Incomplete fix}

### Console Errors
```
[error] {verbatim console message, including source:line}
```

### Network Failures
```
{METHOD} {full URL}
  → {status} {statusText} ({duration}ms)
  Request:  {payload verbatim, secrets redacted}
  Response: {body verbatim, secrets redacted}
```

### Blast Radius
{Other flows that hit the same code path and are therefore also broken. State which are verified vs suspected.}

### Suggested Direction
{Mechanism-level suggestion — what a fix should address, not a patch.}

---

## Evidence
[Images are embedded in Step 7c; list the non-image files here]
- Recording: {PARENT_KEY}-TC{id}.gif (attached)
- RCA report: {PARENT_KEY}_RCA_{TC-ID}_{date}.md (attached)

## Impact
[One sentence: who is affected (which user roles), what workflow is blocked, and whether a workaround exists.]

## Source
QA Test Suite — {Sheet tab name}: {TC-ID list, comma-separated} (verified on Dev {date})
```

### Rules
- Never truncate steps — include every step from the sheet, numbered in order
- Never write "N/A" or leave a field blank — if data is missing, fetch it from the sheet before proceeding
- If multiple TCs are grouped in one ticket, each gets its own `###` block with all fields filled in
- AC bullets must be complete sentences

### Root Cause Analysis section rules
- **`## Root Cause Analysis` is mandatory.** A ticket without it is not ready to file.
- Console and network text goes inside fenced code blocks, **verbatim** — never reflowed, summarized, or paraphrased. Developers grep for exact strings.
- **Redact every secret** before it reaches Jira: bearer tokens, cookies, API keys, passwords → `<REDACTED>`. Keep the header name so its presence is still provable.
- If there was genuinely no console output, write `(no console output — see RCA report)`. If the action fired no request, write `(no network request fired — this is the finding)`. Absence is evidence; never leave the block empty.
- State the real confidence. `Low` with attached evidence is more useful than a fabricated `High`.
- Only write "Regression — PR #X" when the diff line is in hand. Otherwise: `Latent defect — not in linked PR; last modified {sha}`.
- Suggested Direction addresses the **mechanism**, not the symptom.

---

## Step 7 — Create the ticket, attach evidence, embed images

**7a. Resolve the assignee** (Kim Stroh):
```
executeRead(name="listJiraIssueAssignableUsers", cloudId, inputs={ project: "GR", query: "Kim Stroh" })   → accountId
```

**7b. Create:**
```
createJiraIssue(cloudId, projectKey="GR", issueType="Bug", summary=<summary line>, description=<Markdown from Step 6>, priority=<Critical|High|Medium|Low>, labels=[…], assignee=<accountId>)
```
Note the new key `{NEW_KEY}`. If the create is rejected, read the `repairHint` and fix the named field.

**7c. Upload every evidence file** (one at a time; token lives ~20 min):

1. `executeWrite(name="uploadAttachmentToJiraIssue", cloudId, inputs={ issueIdOrKey: "{NEW_KEY}", filePath: "/Users/belleung/…/{file}" })` → `uploadCommand`, `collection`.
2. POST the bytes from the Mac's Playwright process (the sandboxes cannot reach `api.media.atlassian.com`) — the snippet is in `jira-comment-writer` Step 2b; set `Content-Type` to the file's MIME type. Reply `201` with `data.id` = fileId.
3. **Images that go inline** (screenshots, GIFs): do NOT run phase 2. After the description is created, embed them:
   ```
   editJiraIssue(cloudId, issueIdOrKey="{NEW_KEY}", contentFormat="html", inlineFileId=[fileId…], inlineFileCollection=[collection…], inlineFileName=["{file}.png"…])
   ```
   This appends the images under the description and attaches the files automatically.
4. **Non-image files** (RCA `.md`, `-console.log`, `-network.json`): run phase 2 so they land in the attachment list:
   ```
   executeWrite(name="uploadAttachmentToJiraIssue", cloudId, inputs={ issueIdOrKey: "{NEW_KEY}", fileId: "<data.id>" })
   ```

**Always attach the RCA `.md` plus its raw console and network logs** — the code blocks in the description are the summary; the raw logs are the full record.

---

## Step 7d — Link to the parent ticket (MANDATORY)

> NEVER set the `parent` field — that creates a "Child work item" hierarchy (wrong).
> ALWAYS create an issue link ("Link work items", correct).

| Situation | linkType | inwardIssue | outwardIssue |
|-----------|----------|-------------|--------------|
| Bug caused by Epic / Story / Task | `Caused` | `{PARENT_KEY}` | `{NEW_KEY}` |
| Bug relates to another Bug | `Relates` | `{OTHER_BUG}` | `{NEW_KEY}` |
| Bug duplicates existing | `Duplicate` | `{EXISTING}` | `{NEW_KEY}` |

```
executeWrite(name="createJiraIssueLink", cloudId, inputs={ linkType: "Caused", inwardIssue: "{PARENT_KEY}", outwardIssue: "{NEW_KEY}" })
```

If `Caused` is rejected, `executeRead(name="listJiraIssueLinkTypes", cloudId)` and use the exact name listed. When the RCA identified a **Regression** introduced by a PR belonging to a *different* ticket, also link `Caused` from that ticket.

---

## Step 8 — Post cross-reference comment on the parent ticket

```
addOrEditJiraIssueComment(cloudId, issueIdOrKey="{PARENT_KEY}", commentBody="Bug ticket filed for QA failures: [{NEW_KEY}](https://persefoni.atlassian.net/browse/{NEW_KEY})\nFailing cases: {TC numbers}\nRoot cause: {class} — {file:line} — {one-line mechanism} ({confidence} confidence)\nType: {Regression (PR #n) | Latent defect}")
```

---

## Step 9 — Report

```
Bug ticket created: {NEW_KEY}
URL: https://persefoni.atlassian.net/browse/{NEW_KEY}
Title: {summary}
Priority: {priority}  (set from RCA class + blast radius)
Assignee: Kim Stroh
Labels: {label list}
Linked to: {PARENT_KEY} via "is caused by" (Link work items — Caused type)
Root cause: {class} — {file:line} — {confidence} confidence
Type: {Regression (PR #n) | Latent defect | Incomplete fix}
Attachments uploaded: {n} files
  - {screenshot(s), inline}
  - {RCA .md}
  - {console.log}
  - {network.json}
Covers: {TC-ID list}
```

---

## Alternative: API-key script

If `.dev.vars` in the repo root contains `TESTING_JIRA_API_TOKEN`, `create_jira_bug.py --payload … --attachment …` still works from a shell that can reach `persefoni.atlassian.net` (neither sandbox can today). It expects Jira wiki markup, not Markdown.