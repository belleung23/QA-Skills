#!/usr/bin/env python3
"""
post_jira_result.py — One-shot QA result poster.

Uploads evidence files, posts the QA comment, and optionally transitions the ticket.
This is the single entry-point script called by manual-test-executor and playwright-media-capture.

Usage:
    python3 .claude/skills/jira-comment-writer/scripts/post_jira_result.py GR-1234 \
      --result-dir manual-testing/test-results \
      --evidence-dir manual-testing/evidences/GR-1234 \
      --done-dir manual-testing/test-results/done

The script:
  1. Finds the result .md file in --result-dir matching GR-1234
  2. Uploads all files in --evidence-dir to Jira as attachments
  3. Posts the result .md as a comment (converts markdown → Jira wiki markup)
  4. If result file name contains "_passed", transitions ticket to Ready to Release
  5. Moves the result .md to --done-dir

NOTE: Requires TESTING_JIRA_API_TOKEN in .dev.vars at the repo root.
      This script makes direct HTTPS calls to persefoni.atlassian.net.
      From the sandbox, this is proxy-blocked. Run from the host machine or
      use the browser same-origin fetch fallback documented in the SKILL.md.
"""

from __future__ import annotations

import argparse
import base64
import glob
import json
import re
import shutil
import sys
import urllib.error
import urllib.request
from pathlib import Path


JIRA_EMAIL = "belle.ung@persefoni.com"
DEFAULT_JIRA_URL = "https://persefoni.atlassian.net"
ALLOWED_EXTS = {".md", ".png", ".jpg", ".jpeg", ".gif", ".webp", ".webm", ".mp4"}


# ---------------------------------------------------------------------------
# Auth / HTTP helpers
# ---------------------------------------------------------------------------

def load_token(repo_root: Path, env_file: str = ".dev.vars") -> str:
    env_path = (repo_root / env_file).resolve()
    if not env_path.exists():
        raise FileNotFoundError(f".dev.vars not found at {env_path}")
    for line in env_path.read_text(encoding="utf-8").splitlines():
        stripped = line.strip()
        if stripped.startswith("TESTING_JIRA_API_TOKEN="):
            return stripped.split("=", 1)[1].strip().strip("'\"")
    raise ValueError("TESTING_JIRA_API_TOKEN not found in .dev.vars")


def auth_header(token: str) -> str:
    return "Basic " + base64.b64encode(f"{JIRA_EMAIL}:{token}".encode()).decode()


def jira_get(url: str, auth: str) -> dict:
    req = urllib.request.Request(url, headers={"Authorization": auth, "Accept": "application/json"})
    with urllib.request.urlopen(req, timeout=30) as resp:
        return json.loads(resp.read())


def jira_post(url: str, body: dict, auth: str) -> dict:
    data = json.dumps(body).encode()
    req = urllib.request.Request(
        url, data=data, method="POST",
        headers={"Authorization": auth, "Content-Type": "application/json", "Accept": "application/json"},
    )
    with urllib.request.urlopen(req, timeout=30) as resp:
        raw = resp.read()
        return json.loads(raw) if raw else {}


# ---------------------------------------------------------------------------
# Upload
# ---------------------------------------------------------------------------

def upload_file(base_url: str, ticket: str, path: Path, auth: str) -> dict:
    url = f"{base_url}/rest/api/3/issue/{ticket}/attachments"
    boundary = "----PyFormBoundary7MA4YWxkTrZu0gW"
    body = (
        f"--{boundary}\r\n"
        f'Content-Disposition: form-data; name="file"; filename="{path.name}"\r\n'
        "Content-Type: application/octet-stream\r\n\r\n"
    ).encode() + path.read_bytes() + f"\r\n--{boundary}--\r\n".encode()

    req = urllib.request.Request(url, data=body, method="POST")
    req.add_header("Authorization", auth)
    req.add_header("X-Atlassian-Token", "no-check")
    req.add_header("Content-Type", f"multipart/form-data; boundary={boundary}")

    with urllib.request.urlopen(req, timeout=60) as resp:
        result = json.loads(resp.read())
        return result[0] if isinstance(result, list) else result


# ---------------------------------------------------------------------------
# Markdown → Jira wiki markup
# ---------------------------------------------------------------------------

def convert_inline(text: str) -> str:
    placeholders: list[str] = []
    def stash(m: re.Match) -> str:
        placeholders.append(m.group(0))
        return f"\x00IMG{len(placeholders)-1}\x00"
    text = re.sub(r"![^!\s][^!]*!", stash, text)
    text = re.sub(r"\*\*(.+?)\*\*", r"*\1*", text)
    text = re.sub(r"`([^`]+)`", r"{{\1}}", text)
    for i, img in enumerate(placeholders):
        text = text.replace(f"\x00IMG{i}\x00", img)
    return text


def markdown_to_wiki(markdown: str) -> str:
    lines = markdown.splitlines()
    result: list[str] = []
    in_table = False
    header_done = False

    for line in lines:
        s = line.strip()
        m = re.match(r"^(#{1,6})\s+(.*)", s)
        if m:
            in_table = header_done = False
            result.append(f"h{len(m.group(1))}. {convert_inline(m.group(2))}")
            continue
        if re.match(r"^-{3,}$", s):
            in_table = header_done = False
            result.append("----")
            continue
        if s.startswith("|") and "|" in s[1:]:
            if re.match(r"^\s*\|?[\s\-|:]+\|?\s*$", s):
                header_done = True
                continue
            cells = [c.strip() for c in s.strip().strip("|").split("|")]
            if not in_table or not header_done:
                result.append("|| " + " || ".join(convert_inline(c) for c in cells) + " ||")
                in_table = True
            else:
                result.append("| " + " | ".join(convert_inline(c) for c in cells) + " |")
            continue
        else:
            in_table = header_done = False
        bm = re.match(r"^[-*]\s+(.*)", s)
        if bm:
            result.append(f"* {convert_inline(bm.group(1))}")
            continue
        result.append("" if not s else convert_inline(s))

    return "\n".join(result)


# ---------------------------------------------------------------------------
# Transition
# ---------------------------------------------------------------------------

def transition_to_rtr(base_url: str, ticket: str, auth: str) -> None:
    status = jira_get(f"{base_url}/rest/api/3/issue/{ticket}?fields=status", auth)["fields"]["status"]["name"]
    print(f"[INFO] Current status: {status!r}")
    transitions = jira_get(f"{base_url}/rest/api/3/issue/{ticket}/transitions", auth)["transitions"]

    def apply(name: str) -> bool:
        match = next((t for t in transitions if t["name"].lower() == name.lower()), None)
        if not match:
            print(f"[WARN] Transition {name!r} not available. Available: {[t['name'] for t in transitions]}")
            return False
        jira_post(f"{base_url}/rest/api/3/issue/{ticket}/transitions", {"transition": {"id": match["id"]}}, auth)
        print(f"[OK] Transitioned → {name!r}")
        return True

    if status.lower() == "qa review":
        apply("start qa")
        transitions = jira_get(f"{base_url}/rest/api/3/issue/{ticket}/transitions", auth)["transitions"]
    apply("qa passed")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> int:
    parser = argparse.ArgumentParser(description="Upload evidence + post comment + transition Jira ticket")
    parser.add_argument("ticket_key")
    parser.add_argument("--result-dir", default="manual-testing/test-results")
    parser.add_argument("--evidence-dir", default=None)
    parser.add_argument("--done-dir", default="manual-testing/test-results/done")
    parser.add_argument("--env-file", default=".dev.vars")
    args = parser.parse_args()

    ticket = args.ticket_key.upper()
    repo_root = Path.cwd()

    try:
        token = load_token(repo_root, args.env_file)
    except (FileNotFoundError, ValueError) as e:
        print(f"[ERROR] {e}", file=sys.stderr)
        return 1

    auth = auth_header(token)
    base_url = DEFAULT_JIRA_URL

    # --- Find result file ---
    result_dir = (repo_root / args.result_dir).resolve()
    result_files = list(result_dir.glob(f"{ticket}_result_*.md"))
    if not result_files:
        print(f"[ERROR] No result file found for {ticket} in {result_dir}", file=sys.stderr)
        return 1
    result_file = result_files[0]
    print(f"[INFO] Result file: {result_file.name}")
    is_passed = "_passed" in result_file.name.lower()

    # --- Upload evidence files ---
    evidence_dir = Path(args.evidence_dir).resolve() if args.evidence_dir else None
    if evidence_dir and evidence_dir.exists():
        evidence_files = [f for f in sorted(evidence_dir.iterdir())
                         if f.is_file() and f.suffix.lower() in ALLOWED_EXTS]
        print(f"[INFO] Uploading {len(evidence_files)} evidence file(s)...")
        for f in evidence_files:
            try:
                r = upload_file(base_url, ticket, f, auth)
                print(f"[OK] Uploaded: {r.get('filename', f.name)} (id={r.get('id')})")
            except urllib.error.HTTPError as e:
                print(f"[ERROR] Upload failed for {f.name}: HTTP {e.code} — {e.read().decode()}", file=sys.stderr)
                return 1
            except urllib.error.URLError as e:
                print(f"[ERROR] Network error uploading {f.name}: {e.reason}", file=sys.stderr)
                return 1

    # --- Post comment ---
    wiki = markdown_to_wiki(result_file.read_text(encoding="utf-8"))
    print(f"[INFO] Posting comment to {ticket}...")
    try:
        r = jira_post(f"{base_url}/rest/api/2/issue/{ticket}/comment", {"body": wiki}, auth)
        print(f"[OK] Comment posted (id={r.get('id')})")
    except urllib.error.HTTPError as e:
        print(f"[ERROR] Comment failed: HTTP {e.code} — {e.read().decode()}", file=sys.stderr)
        return 1

    # --- Transition if passed ---
    if is_passed:
        print(f"[INFO] Result is PASSED — transitioning to Ready to Release...")
        try:
            transition_to_rtr(base_url, ticket, auth)
        except Exception as e:
            print(f"[WARN] Transition failed: {e}")

    # --- Move result to done ---
    done_dir = (repo_root / args.done_dir).resolve()
    done_dir.mkdir(parents=True, exist_ok=True)
    shutil.move(str(result_file), done_dir / result_file.name)
    print(f"[OK] Result file moved to done/")

    return 0


if __name__ == "__main__":
    sys.exit(main())
