#!/usr/bin/env python3
"""
annotate_screenshot.py — Add pass/fail annotation to a screenshot.

Usage:
  python3 annotate_screenshot.py <input.png> <output.png> pass|fail "<label text>"

Adds:
  - Colored border (green=pass, red=fail)
  - Status badge strip at top (icon + label text)
  - Corner badge (✅ PASS or ❌ FAIL)
"""

import sys
from PIL import Image, ImageDraw, ImageFont

def annotate(input_path, output_path, status, label):
    status = status.lower()
    if status not in ("pass", "fail"):
        print(f"ERROR: status must be 'pass' or 'fail', got '{status}'")
        sys.exit(1)

    is_pass = status == "pass"
    border_color = (34, 197, 94) if is_pass else (220, 38, 38)   # green-500 / red-600
    badge_bg     = (22, 163, 74) if is_pass else (185, 28, 28)    # green-600 / red-700
    icon         = "✅" if is_pass else "❌"
    status_text  = "PASS" if is_pass else "FAIL"

    img = Image.open(input_path).convert("RGB")
    w, h = img.size

    border = 6
    badge_h = 36

    # New canvas: border on all sides + badge strip on top
    new_w = w + border * 2
    new_h = h + border * 2 + badge_h

    canvas = Image.new("RGB", (new_w, new_h), border_color)
    draw = ImageDraw.Draw(canvas)

    # Badge strip background
    draw.rectangle([0, 0, new_w, badge_h + border], fill=badge_bg)

    # Try to load a font, fall back to default
    try:
        font_large = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 18)
        font_small = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 14)
    except Exception:
        font_large = ImageFont.load_default()
        font_small = font_large

    # Badge text: "❌ FAIL — <label>" or "✅ PASS — <label>"
    badge_text = f"{icon} {status_text}  —  {label}"
    draw.text((12, badge_h // 2 + border // 2 - 2), badge_text,
              fill=(255, 255, 255), font=font_large, anchor="lm")

    # Paste original image with border offset
    canvas.paste(img, (border, badge_h + border))

    # Corner label (bottom-right)
    corner_text = f"{icon} {status_text}"
    bbox = draw.textbbox((0, 0), corner_text, font=font_small)
    tw = bbox[2] - bbox[0]
    th = bbox[3] - bbox[1]
    pad = 6
    rx = new_w - tw - pad * 2 - border
    ry = new_h - th - pad * 2 - border
    draw.rectangle([rx - pad, ry - pad, rx + tw + pad, ry + th + pad], fill=badge_bg)
    draw.text((rx, ry), corner_text, fill=(255, 255, 255), font=font_small)

    canvas.save(output_path)
    print(f"Annotated screenshot saved: {output_path}")

if __name__ == "__main__":
    if len(sys.argv) < 5:
        print("Usage: annotate_screenshot.py <input.png> <output.png> pass|fail '<label>'")
        sys.exit(1)
    annotate(sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4])
