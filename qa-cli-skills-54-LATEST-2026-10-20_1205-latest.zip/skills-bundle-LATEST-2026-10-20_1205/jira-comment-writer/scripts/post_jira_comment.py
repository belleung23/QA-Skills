#!/usr/bin/env python3
"""
Post a Jira comment from a markdown draft file using Jira wiki markup formatting.

The script converts the markdown draft to Jira wiki markup so that:
- headings, tables, bullet lists, bold labels, and inline code render correctly
- !filename.png! references embed the attached screenshot directly in the comment

Optionally transitions the ticket status when --transition is provided.

Usage:
    python3 .claude/skills/jira-comment-writer/scripts/post_jira_comment.py GR-1234 \
      --comment-file test-reports/jira-comments/GR-1234_2026-04-23_comment.md

    # Transition to Ready to Release after a passing QA run
    python3 .claude/skills/jira-comment-writer/scripts/post_jira_comment.py GR-1234 \
      --comment-file test-reports/jira-comments/GR-1234_2026-04-23_comment.md \
      --transition "qa passed"

    # Transition only (no comment), e.g. move to In QA at test start
    python3 .claude/skills/jira-comment-writer/scripts/post_jira_comment.py GR-1234 \
      --transition "start qa" --transition-only
"""

from __future__ import annotations

import argparse
import base64
import json
import re
import sys
import urllib.error
import urllib.request
from pathlib import Path


JIRA_EMAIL = "belle.ung@persefoni.com"
DEFAULT_JIRA_URL = "https://persefoni.atlassian.net"


# ---------------------------------------------------------------------------
# Auth helpers
# ---------------------------------------------------------------------------

def load_token(env_path: Path) -> str:
    if not env_path.exists():
        raise FileNotFoundError(f"Env file not found: {env_path}")
    for line in env_path.read_text(encoding="utf-8").splitlines():
        stripped = line.strip()
        if stripped.startswith("TESTING_JIRA_API_TOKEN="):
            return stripped.split("=", 1)[1].strip().strip("'\"")
    raise ValueError("TESTING_JIRA_API_TOKEN not found in env file")


def auth_header(token: str) -> str:
    return "Basic " + base64.b64encode(f"{JIRA_EMAIL}:{token}".encode()).decode()


def jira_request(url: str, method: str, body: dict, auth: str) -> dict:
    data = json.dumps(body).encode("utf-8")
    req = urllib.request.Request(
        url, data=data, method=method,
        headers={"Authorization": auth, "Content-Type": "application/json", "Accept": "application/json"},
    )
    with urllib.request.urlopen(req) as resp:
        raw = resp.read()
        return json.loads(raw) if raw else {}


# ---------------------------------------------------------------------------
# Markdown → Jira wiki markup converter
# ---------------------------------------------------------------------------

def convert_inline(text: str) -> str:
    """Convert inline markdown spans to Jira wiki markup.

    - **bold** → *bold*
    - `code`   → {{code}}
    - !img.png! stays as-is (wiki markup image embed)
    """
    # Protect !image.png! references so they survive the bold substitution
    placeholders: list[str] = []

    def stash_image(m: re.Match) -> str:
        placeholders.append(m.group(0))
        return f"\x00IMG{len(placeholders) - 1}\x00"

    text = re.sub(r"![^!\s][^!]*!", stash_image, text)

    # **bold** → *bold*  (must come before single-star handling)
    text = re.sub(r"\*\*(.+?)\*\*", r"*\1*", text)

    # `inline code` → {{code}}
    text = re.sub(r"`([^`]+)`", r"{{\1}}", text)

    # Escape bare TC-N / TC-NN patterns so Jira does not auto-link them as issue keys.
    # Must run after the {{...}} substitution so already-wrapped tokens are not double-wrapped.
    # Negative lookbehind/lookahead avoids touching tokens already inside {{ }}.
    text = re.sub(r"(?<!\{)(?<!\{)\b(TC-\d+)\b(?!\})", r"{{\1}}", text)

    # Restore image placeholders
    for idx, img in enumerate(placeholders):
        text = text.replace(f"\x00IMG{idx}\x00", img)

    return text


def _is_separator_row(line: str) -> bool:
    return bool(re.match(r"^\s*\|?[\s\-|:]+\|?\s*$", line))


def _parse_table_cells(line: str) -> list[str]:
    line = line.strip().strip("|")
    return [cell.strip() for cell in line.split("|")]


def markdown_to_wiki(markdown: str) -> str:
    """Convert a QA comment markdown draft to Jira wiki markup.

    Jira wiki markup reference:
      h1. to h6.   — headings
      *bold*       — bold
      {{code}}     — inline code
      * item       — bullet list item
      || hdr ||    — table header row
      | cell |     — table body row
      ----         — horizontal rule
      !file.png!   — embedded image (must be attached to the ticket)
    """
    lines = markdown.splitlines()
    result: list[str] = []
    i = 0
    in_table = False
    table_header_done = False

    while i < len(lines):
        line = lines[i]
        stripped = line.strip()

        # --- Heading ---
        heading_match = re.match(r"^(#{1,6})\s+(.*)", stripped)
        if heading_match:
            if in_table:
                in_table = False
                table_header_done = False
            level = len(heading_match.group(1))
            text = convert_inline(heading_match.group(2).strip())
            result.append(f"h{level}. {text}")
            i += 1
            continue

        # --- Horizontal rule ---
        if re.match(r"^-{3,}$", stripped):
            if in_table:
                in_table = False
                table_header_done = False
            result.append("----")
            i += 1
            continue

        # --- Table row ---
        if stripped.startswith("|") and "|" in stripped[1:]:
            if _is_separator_row(stripped):
                # Separator row marks end of header
                table_header_done = True
                i += 1
                continue
            cells = _parse_table_cells(stripped)
            if not in_table or not table_header_done:
                # First non-separator table row → header row
                wiki_cells = " || ".join(convert_inline(c) for c in cells)
                result.append(f"|| {wiki_cells} ||")
                in_table = True
            else:
                wiki_cells = " | ".join(convert_inline(c) for c in cells)
                result.append(f"| {wiki_cells} |")
            i += 1
            continue
        else:
            if in_table:
                in_table = False
                table_header_done = False

        # --- Bullet list item ---
        bullet_match = re.match(r"^[-*]\s+(.*)", stripped)
        if bullet_match:
            result.append(f"* {convert_inline(bullet_match.group(1))}")
            i += 1
            continue

        # --- Empty line ---
        if not stripped:
            result.append("")
            i += 1
            continue

        # --- Regular paragraph ---
        result.append(convert_inline(stripped))
        i += 1

    return "\n".join(result)


# ---------------------------------------------------------------------------
# Jira transitions (v3 — format-agnostic)
# ---------------------------------------------------------------------------

def get_issue_status(base_url: str, ticket: str, auth: str) -> str:
    """Return the current status name of the issue (e.g. 'In QA', 'QA Review')."""
    req = urllib.request.Request(
        f"{base_url}/rest/api/3/issue/{ticket}?fields=status",
        headers={"Authorization": auth, "Accept": "application/json"},
    )
    with urllib.request.urlopen(req) as resp:
        return json.loads(resp.read())["fields"]["status"]["name"]


def get_transitions(base_url: str, ticket: str, auth: str) -> list[dict]:
    req = urllib.request.Request(
        f"{base_url}/rest/api/3/issue/{ticket}/transitions",
        headers={"Authorization": auth, "Accept": "application/json"},
    )
    with urllib.request.urlopen(req) as resp:
        return json.loads(resp.read())["transitions"]


def transition_issue(base_url: str, ticket: str, transition_name: str, auth: str) -> bool:
    """Apply a single named transition. Returns True on success."""
    transitions = get_transitions(base_url, ticket, auth)
    match = next((t for t in transitions if t["name"].lower() == transition_name.lower()), None)
    if not match:
        available = [t["name"] for t in transitions]
        print(f"[WARN] Transition '{transition_name}' not available for {ticket}.")
        print(f"[WARN] Available: {available}")
        return False
    jira_request(
        f"{base_url}/rest/api/3/issue/{ticket}/transitions",
        "POST",
        {"transition": {"id": match["id"]}},
        auth,
    )
    return True


def transition_to_ready(base_url: str, ticket: str, auth: str) -> bool:
    """Transition ticket to Ready to Release.

    If the current status is 'QA Review', first moves to 'In QA' via 'start qa',
    then applies 'qa passed' to reach Ready to Release.
    From any other status (e.g. already In QA), applies 'qa passed' directly.
    """
    status = get_issue_status(base_url, ticket, auth)
    print(f"[INFO] Current status: '{status}'")

    if status.lower() == "qa review":
        print(f"[INFO] Status is QA Review — stepping through In QA first…")
        ok = transition_issue(base_url, ticket, "start qa", auth)
        if not ok:
            print(f"[WARN] Could not move {ticket} from QA Review to In QA; aborting.")
            return False
        print(f"[OK] {ticket} → In QA")

    ok = transition_issue(base_url, ticket, "qa passed", auth)
    if ok:
        print(f"[OK] {ticket} → Ready to Release")
    return ok


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> int:
    parser = argparse.ArgumentParser(description="Post a markdown QA comment to Jira using wiki markup formatting.")
    parser.add_argument("ticket_key", help="Jira ticket key, e.g. GR-1234")
    parser.add_argument("--comment-file", default="", help="Markdown comment draft file")
    parser.add_argument("--transition", default="", help="Transition name to apply (e.g. 'start qa', 'qa passed')")
    parser.add_argument("--transition-only", action="store_true", help="Apply transition without posting a comment")
    parser.add_argument("--env-file", default=".dev.vars", help="Env file with TESTING_JIRA_API_TOKEN")
    args = parser.parse_args()

    ticket = args.ticket_key.upper()

    env_path = Path(args.env_file)
    try:
        token = load_token(env_path)
    except (FileNotFoundError, ValueError) as exc:
        print(f"[ERROR] {exc}", file=sys.stderr)
        return 1

    auth = auth_header(token)
    base_url = DEFAULT_JIRA_URL

    if not args.transition_only:
        if not args.comment_file:
            print("[ERROR] --comment-file is required unless --transition-only is set", file=sys.stderr)
            return 1
        comment_path = Path(args.comment_file)
        if not comment_path.exists():
            print(f"[ERROR] Comment file not found: {comment_path}", file=sys.stderr)
            return 1

        markdown = comment_path.read_text(encoding="utf-8")
        wiki_body = markdown_to_wiki(markdown)

        print(f"[INFO] Posting comment to {ticket}…")
        try:
            # Use REST API v2 — accepts Jira wiki markup; !file.png! embeds attached images
            result = jira_request(
                f"{base_url}/rest/api/2/issue/{ticket}/comment",
                "POST",
                {"body": wiki_body},
                auth,
            )
            print(f"[OK] Comment posted — id={result.get('id')}")
        except urllib.error.HTTPError as exc:
            body = exc.read().decode() if exc.fp else ""
            print(f"[ERROR] HTTP {exc.code}: {body}", file=sys.stderr)
            return 1

    if args.transition:
        if args.transition.lower() == "qa passed":
            # Smart path: check for QA Review and step through In QA if needed
            transition_to_ready(base_url, ticket, auth)
        else:
            print(f"[INFO] Transitioning {ticket} → '{args.transition}'…")
            ok = transition_issue(base_url, ticket, args.transition, auth)
            if ok:
                print(f"[OK] {ticket} transitioned to '{args.transition}'")
            else:
                print(f"[WARN] Transition skipped — see warning above.")

    return 0


if __name__ == "__main__":
    sys.exit(main())
