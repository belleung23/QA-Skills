#!/usr/bin/env python3
"""
Upload Jira QA artifacts for a single ticket.

This helper uploads only ticket-related files:
- QA report markdown
- test-cases markdown
- screenshot evidence

It does NOT post the Jira comment.

Usage:
    python3 .claude/skills/jira-comment-writer/scripts/post_jira_comment_with_evidence.py GR-1234 \
      --report-file test-reports/GR-1234_PASSED_QA-Report_2026-04-23.md \
      --test-cases-file test-cases/GR-1234_PASSED_Test-Cases_2026-04-23.md
"""

from __future__ import annotations

import argparse
import base64
import json
import sys
import urllib.error
import urllib.request
from pathlib import Path


JIRA_EMAIL = "belle.ung@persefoni.com"
DEFAULT_JIRA_URL = "https://persefoni.atlassian.net"
ALLOWED_EXTS = {".md", ".png", ".jpg", ".jpeg", ".gif", ".webp", ".webm", ".mp4"}


def load_env_file(env_path: Path) -> dict[str, str]:
    env_vars: dict[str, str] = {}
    if not env_path.exists():
        raise FileNotFoundError(f"Env file not found: {env_path}")

    for line in env_path.read_text(encoding="utf-8").splitlines():
        stripped = line.strip()
        if not stripped or stripped.startswith("#") or "=" not in stripped:
            continue
        key, _, value = stripped.partition("=")
        env_vars[key.strip()] = value.strip().strip("'").strip('"')
    return env_vars


def build_auth_header(email: str, token: str) -> str:
    encoded = base64.b64encode(f"{email}:{token}".encode("utf-8")).decode("utf-8")
    return f"Basic {encoded}"


def resolve_path(repo_root: Path, raw_path: str | None) -> Path | None:
    if not raw_path:
        return None
    path = Path(raw_path)
    if not path.is_absolute():
        path = (repo_root / path).resolve()
    return path if path.exists() else None


def discover_ticket_screenshots(repo_root: Path, ticket_key: str) -> list[Path]:
    screenshot_dir = repo_root / "test-reports" / "screenshots"
    if not screenshot_dir.exists():
        return []

    paths: list[Path] = []
    ticket_upper = ticket_key.upper()
    for path in sorted(screenshot_dir.iterdir()):
        if (
            path.is_file()
            and ticket_upper in path.name.upper()
            and path.suffix.lower() in ALLOWED_EXTS
        ):
            paths.append(path.resolve())
    return paths


def collect_upload_paths(
    repo_root: Path,
    ticket_key: str,
    report_file: Path | None,
    test_cases_file: Path | None,
    evidence_files: list[str],
) -> list[Path]:
    seen: dict[str, Path] = {}

    for path in [report_file, test_cases_file]:
        if path is not None:
            seen[str(path)] = path

    for raw_path in evidence_files:
        resolved = resolve_path(repo_root, raw_path)
        if resolved is not None and resolved.suffix.lower() in ALLOWED_EXTS:
            seen[str(resolved)] = resolved

    for path in discover_ticket_screenshots(repo_root, ticket_key):
        seen[str(path)] = path

    return sorted(seen.values())


def upload_attachment(base_url: str, ticket_key: str, file_path: Path, auth_header: str) -> dict:
    url = f"{base_url}/rest/api/3/issue/{ticket_key}/attachments"
    boundary = "----PythonFormBoundary7MA4YWxkTrZu0gW"
    body = (
        f"--{boundary}\r\n"
        f'Content-Disposition: form-data; name="file"; filename="{file_path.name}"\r\n'
        "Content-Type: application/octet-stream\r\n\r\n"
    ).encode("utf-8") + file_path.read_bytes() + f"\r\n--{boundary}--\r\n".encode("utf-8")

    req = urllib.request.Request(url, data=body, method="POST")
    req.add_header("Authorization", auth_header)
    req.add_header("X-Atlassian-Token", "no-check")
    req.add_header("Content-Type", f"multipart/form-data; boundary={boundary}")

    with urllib.request.urlopen(req, timeout=60) as resp:
        result = json.loads(resp.read().decode("utf-8"))
        if result and isinstance(result, list):
            return result[0]
        raise RuntimeError(f"Unexpected upload response for {file_path.name}: {result}")


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Upload ticket-related QA artifacts to Jira without posting the comment."
    )
    parser.add_argument("ticket_key", help="Jira ticket key, e.g. GR-1234")
    parser.add_argument("--report-file", help="QA report markdown file")
    parser.add_argument("--test-cases-file", help="Test-cases markdown file")
    parser.add_argument(
        "--env-file",
        default=".dev.vars",
        help="Environment file containing TESTING_JIRA_API_TOKEN and optional JIRA_URL",
    )
    parser.add_argument(
        "--evidence-file",
        action="append",
        default=[],
        help="Additional screenshot or evidence file path. Can be repeated.",
    )
    args = parser.parse_args()

    repo_root = Path.cwd()
    ticket_key = args.ticket_key.upper()
    report_file = resolve_path(repo_root, args.report_file)
    test_cases_file = resolve_path(repo_root, args.test_cases_file)
    env_file = (repo_root / args.env_file).resolve()

    if args.report_file and report_file is None:
        print(f"[ERROR] Report file not found: {args.report_file}", file=sys.stderr)
        return 1
    if args.test_cases_file and test_cases_file is None:
        print(f"[ERROR] Test-cases file not found: {args.test_cases_file}", file=sys.stderr)
        return 1

    if report_file is None and test_cases_file is None and not args.evidence_file:
        print(
            "[ERROR] Provide at least one of --report-file, --test-cases-file, or --evidence-file.",
            file=sys.stderr,
        )
        return 1

    try:
        env_vars = load_env_file(env_file)
    except FileNotFoundError as exc:
        print(f"[ERROR] {exc}", file=sys.stderr)
        return 1

    jira_token = env_vars.get("TESTING_JIRA_API_TOKEN")
    if not jira_token:
        print("[ERROR] TESTING_JIRA_API_TOKEN not found in .dev.vars", file=sys.stderr)
        return 1

    jira_base_url = env_vars.get("JIRA_URL", DEFAULT_JIRA_URL).rstrip("/")
    auth_header = build_auth_header(JIRA_EMAIL, jira_token)
    upload_paths = collect_upload_paths(
        repo_root=repo_root,
        ticket_key=ticket_key,
        report_file=report_file,
        test_cases_file=test_cases_file,
        evidence_files=args.evidence_file,
    )

    if not upload_paths:
        print(f"[ERROR] No ticket-related artifacts found for {ticket_key}", file=sys.stderr)
        return 1

    print(f"[INFO] Uploading {len(upload_paths)} ticket-related artifact(s) for {ticket_key}")
    for path in upload_paths:
        try:
            result = upload_attachment(jira_base_url, ticket_key, path, auth_header)
            print(f"[OK] Uploaded: {result.get('filename', path.name)} (id: {result.get('id', 'N/A')})")
        except urllib.error.HTTPError as exc:
            body_text = exc.read().decode("utf-8") if exc.fp else ""
            print(f"[ERROR] Jira upload failed for {path.name}: HTTP {exc.code} — {body_text}", file=sys.stderr)
            return 1
        except urllib.error.URLError as exc:
            print(f"[ERROR] Jira upload failed for {path.name}: {exc.reason}", file=sys.stderr)
            return 1

    print(f"[DONE] Uploaded artifacts only for {ticket_key}. Comment posting was intentionally skipped.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
