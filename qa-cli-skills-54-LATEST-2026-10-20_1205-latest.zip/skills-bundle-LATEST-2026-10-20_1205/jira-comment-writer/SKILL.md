---
name: "jira-comment-writer"
description: "Write and post the Jira QA comment via the Atlassian connector. Picks comment type automatically — PASS ✅, FAIL ❌ with root-cause, or clarification. Posts as HTML (contentFormat=html) with media nodes so screenshots render inside table cells; upload files first with uploadAttachmentToJiraIssue (phase 1) + a POST from the Mac's Playwright. 7-column table, Execution Summary bullets, h2 headings. Use whenever: write comment, post comment, QA comment, post results, comment on Jira ticket, verification comment, tag for review."
---

# Jira Comment Writer

Final step after QA execution. Posts the Jira comment as **HTML** (the connector converts it to ADF) with inline screenshot evidence, uploads artifacts, and transitions the ticket.

> **Fixed 2026-10-16 (verified on GR-11288 — upload, inline image in a table cell, transitions).**
> The old version referenced a previous Atlassian MCP (`mcp__5e7d7dc5…__addCommentToJiraIssue` with
> `contentFormat="adf"`), scraped media UUIDs from the ticket page with Playwright `setInputFiles`,
> and hand-built ADF JSON. The current **Atlassian connector** (`mcp__Atlassian_MCP__*`) replaces all
> of that: `uploadAttachmentToJiraIssue` mints an upload command, `addOrEditJiraIssueComment` takes
> HTML with `<figure data-type="media-single">` nodes, and `transitionJiraIssue` moves the ticket.
> No API key, no ADF, no UUID scraping.

> **Upload first, comment second.** The media node needs the `fileId` and `collection` that only
> exist after the upload.
> **Plain `!filename.png!` does NOT embed images in table cells.** Use the HTML media node below.

**Site:** `cloudId = dce2ce03-4355-4e26-8af2-06995df138ef` (https://persefoni.atlassian.net). Pass it on every connector call.

---

## Pick Comment Type

| Situation | Type |
|-----------|------|
| Every TC passed | ✅ All Passed |
| Failures with clear root cause | ❌ Bug Report → auto-trigger `jira-ticket-writer` |
| Failures with ambiguous behaviour | ⚠️ Clarification |

Prefer Bug Report over Clarification whenever root cause is identifiable without hedging. A ❌ Bug Report requires `root-cause-forensics` to have run first.

---

## Comment Format (Lan's GR-5146 style)

- **7 columns:** `(empty) | Test Case | Status | Expected Result | Actual Result | Reproduction Steps | Screenshot`
- **Leading empty column** holds the TC number (TC-01, TC-02, …)
- **Reproduction Steps column** — numbered steps so developers can reproduce without guessing:
  - **PASS cases:** concise happy-path steps ("1. Navigate to the feature → 2. Perform the action → 3. Verify result")
  - **FAIL cases:** detailed and precise — exact inputs, UI state at the failure point, API payload if relevant, and the exact step where it fails. A developer must be able to reproduce from this column alone.
- **Execution Summary** is a bullet list (not a table)
- **Headings** use `<h2>`: "Execution Summary" and "Test Cases"
- **Technical values** use `<code>`
- **Posted as HTML** via `contentFormat: "html"`

### HTML Comment Skeleton

```html
<p><strong>QA Verification PASS ✅</strong></p>
<ul>
<li>Date: <code>YYYY-MM-DD</code></li>
<li>Ticket: <code>GR-XXXX</code></li>
<li>Environment: <code>Dev — https://app.dev.firstrecon.ai</code></li>
<li>Tester: <code>belle.ung@persefoni.com</code></li>
<li>Scope: <code>Frontend + Backend</code></li>
</ul>
<h2>Execution Summary</h2>
<ul>
<li>Total: <code>N</code></li>
<li>Passed: <code>N</code></li>
<li>Failed: <code>0</code></li>
<li>Skipped: <code>0</code></li>
<li>Blocked: <code>0</code></li>
</ul>
<h2>Test Cases</h2>
<table>
<thead><tr><th></th><th>Test Case</th><th>Status</th><th>Expected Result</th><th>Actual Result</th><th>Reproduction Steps</th><th>Screenshot</th></tr></thead>
<tbody>
<tr>
<td><p>TC-01</p></td>
<td><p>Test case description</p></td>
<td><p>✅ Pass</p></td>
<td><p>Expected outcome</p></td>
<td><p>Actual outcome matched</p></td>
<td><p>1. Navigate to feature URL → 2. Perform the tested action → 3. Observe result</p></td>
<td><figure data-type="media-single" data-layout="center" data-width="100" data-width-type="percentage"><div data-type="media" data-media-type="file" data-id="{FILE_ID}" data-collection="{COLLECTION}" data-alt="{filename}.png"></div></figure></td>
</tr>
</tbody>
</table>
<p>Summary narrative here.</p>
```

- A FAIL row carries two media nodes in the Screenshot cell (PNG, then GIF).
- A TC with no screenshot (BE-only, Layer 2) gets `<td><p>—</p></td>`.
- Always include `data-width-type="percentage"` — without it Jira treats the width as pixels and renders a tiny image.
- No `<html>`/`<body>` wrapper, no Markdown code fences, no Confluence `<ac:…>` macros, no layout `<section>`s (Jira rejects them).

For a ❌ Bug Report add `<h2>Failed Test Cases — Detail</h2>` with one `<h3>` per failed TC (AC verbatim, steps, expected, actual, RCA summary).

---

## Posting Workflow

### 1. Capture screenshots

Use `qa-evidence-capture` (preferred — outlines and labels the failing element) or `playwright-media-capture`. Both save into
`/Users/belleung/Documents/guardrails/eng-guardrails-platform/manual-testing/evidences/{TICKET_KEY}/`
and screenshot on a **fresh Playwright page** via `browser_run_code_unsafe` (`browser_take_screenshot` hangs).

### 2. Upload every evidence file (BEFORE posting) — one file at a time

The upload token lives ~20 minutes; do phase 1 → POST for one file before preparing the next.

**2a. Phase 1** — mint the upload command:

```
executeWrite(name="uploadAttachmentToJiraIssue", cloudId, inputs={ issueIdOrKey: "{TICKET_KEY}", filePath: "/Users/belleung/…/evidences/{TICKET_KEY}/{file}" })
```

The reply holds `uploadCommand` (a curl to `https://api.media.atlassian.com/file/binary?collection=…&name=…` with `Authorization: Bearer …` and `X-Client-Id` headers), plus `collection` and `fileName`.

**2b. POST the bytes from the Mac's Playwright process.** The cloud sandbox cannot reach `api.media.atlassian.com` (proxy 403) and the Mac sandbox shell has no network, so do not run the curl literally — replay it from Playwright:

```javascript
// mcp__playwright__browser_run_code_unsafe
async (page) => {
  const FILE = '/Users/belleung/Documents/guardrails/eng-guardrails-platform/manual-testing/evidences/{TICKET_KEY}/{file}';
  const URL = '{the --location URL from uploadCommand, verbatim}';
  const HEADERS = { 'Accept': 'application/json', 'Authorization': '{Bearer … from uploadCommand}', 'X-Client-Id': '{from uploadCommand}', 'Content-Type': 'image/png' };  // image/gif for GIFs
  const p = await page.context().newPage();
  await p.setContent('<input type="file" id="f">');
  await p.setInputFiles('#f', FILE);
  const b64 = await p.evaluate(() => new Promise((res) => { const f = document.getElementById('f').files[0]; const r = new FileReader(); r.onload = () => res(r.result.split(',')[1]); r.readAsDataURL(f); }));
  await p.close();
  const data = Buffer.from(b64, 'base64');
  const r = await page.request.post(URL, { data, headers: HEADERS, timeout: 60000 });
  return { status: r.status(), bytes: data.length, body: (await r.text()).slice(0, 400) };
}
```

Expect `status: 201` and a body with `data.id` — that is the **fileId**. Record `filename → { fileId, collection }`.

**2c. Do NOT run phase 2** (`uploadAttachmentToJiraIssue` with `fileId`) for a file you will embed inline — embedding attaches it automatically; phase 2 would duplicate it. Run phase 2 only for files that go to the attachment list without appearing in the comment (e.g. raw logs).

### 3. Post the comment

```
addOrEditJiraIssueComment(cloudId, issueIdOrKey="{TICKET_KEY}", contentFormat="html", commentBody=<the HTML skeleton with real fileId/collection in each media node>)
```

The reply echoes the body; `data-collection` is dropped on read — that is expected, not data loss. Then open the ticket in Chrome and confirm each image renders inside its table cell (reload once if the comment is not shown).

### 4. Transition if all passed

See `jira-ticket-transition`. From **In QA** the transition is named **`qa passed`** and lands on **`Ready to Release`** (lowercase "to"):

```
executeRead(name="listJiraIssueTransitions", cloudId, inputs={ issueIdOrKey })      → confirm "qa passed" is available
transitionJiraIssue(cloudId, issueIdOrKey, transitionName="qa passed")
```

If the ticket is still in Backlog / To Do / In Progress, step through `QA Review` (transition "QA Review") → `In QA` (transition "start qa") first.

### 5. Auto-trigger jira-ticket-writer (Bug Report only — MANDATORY)

If comment type is Bug Report, immediately invoke `jira-ticket-writer` for every failed TC. Do not wait for user confirmation.

---

## Status Transitions

| Outcome | Transition | Status |
|---------|-----------|--------|
| All passed | `qa passed` | → Ready to Release |
| Any failure | none | unchanged |
| Clarification | none | unchanged |

---

## Final Report

Output after completion:
- Ticket ID + URL
- Comment type (Pass / Bug Report / Clarification)
- Artifacts uploaded (filenames + count)
- TC count: passed / failed / skipped / blocked
- Bug tickets filed (if any, with links)
- Transition applied (if any)

---

## Alternative: API-key script

If `.dev.vars` in the repo root contains `TESTING_JIRA_API_TOKEN`, `scripts/post_jira_comment_with_evidence.py {TICKET_KEY} <files…>` uploads and comments in one go — but only from a shell that can reach `persefoni.atlassian.net`, which neither sandbox can today. Prefer the connector path above.

## Fallback (if the upload POST fails)

1. Post the comment anyway with `<td><p>— (see attachments)</p></td>` in the Screenshot cells.
2. Note the evidence path: `/Users/belleung/Documents/guardrails/eng-guardrails-platform/manual-testing/evidences/{TICKET_KEY}/`
3. Tell the user the images need to be dragged onto the ticket by hand.