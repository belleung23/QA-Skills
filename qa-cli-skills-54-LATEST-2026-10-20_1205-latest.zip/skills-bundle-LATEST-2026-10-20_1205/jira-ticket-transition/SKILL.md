---
name: "jira-ticket-transition"
description: "Transition a verified Jira ticket to Ready to Release after QA passes, via the Atlassian connector. Posts a QA verification comment and moves the ticket through QA Review → In QA → 'qa passed'. Records which environment was used per the routing policy: Dev for normal tickets, or Production (with Dev fallback) for [Pro]/[Prod] tickets. Use whenever the user says 'Passed' followed by a ticket ID, wants to mark a ticket as QA verified, or confirm QA completion on a Jira ticket. Triggers on: Passed, QA verified, ready to release, mark as passed, QA complete, transition ticket, move to release."
---

# Jira Ticket Transition (Passed)

This skill handles the post-QA workflow: verifying a ticket passed, posting a QA comment, and transitioning the ticket to Ready to Release.

> **Verified 2026-10-16 on GR-11288** with the Atlassian connector (`mcp__Atlassian_MCP__*`).
> **Site:** `cloudId = dce2ce03-4355-4e26-8af2-06995df138ef`. Pass it on every call.

## Trigger

`Passed [TICKET-ID or bug ticket reference]`

## Shared References

Before proceeding, read:
- `shared-qa-base/references/environments.md` — environment URLs and routing rules

## GR workflow (as of 2026-10-16)

Statuses: Backlog, To Do, In Progress, Code Review, QA Review, In QA, Blocked, **Ready to Release**, Done, Will Not Implement.

Transitions are named differently from the status they lead to — always pass the **transition** name or id:

| From | Transition name | id | Lands on |
|---|---|---|---|
| Backlog / To Do / In Progress / Code Review | `QA Review` | 24 | QA Review |
| QA Review | `start qa` | 21 | In QA |
| In QA | `qa passed` | 8 | **Ready to Release** |
| In QA | `rework` | 22 | In Progress |
| Ready to Release | `deployed` | 9 | Done |

Ids can change; confirm with `listJiraIssueTransitions` before each move.

## Step 1 — Verify the Ticket

- `getJiraIssue(cloudId, issueIdOrKey)` — note the current status
- Confirm the referenced item is recorded as ✅ Pass in the most recent `.md` report for the environment used
- Inspect the ticket title — if it contains `[Pro]` or `[Prod]`, the expected primary test environment was Production
- If the ticket did NOT pass, stop and report — do not transition a failing ticket

## Step 2 — Post a Verification Comment

`addOrEditJiraIssueComment(cloudId, issueIdOrKey, commentBody=…)` — Markdown is fine here (no images). The "Tested on" line follows the routing convention:

**Normal ticket (no `[Pro]`/`[Prod]`):**
```
✅ QA Verified — [YYYY-MM-DD]

Tested on: Dev (https://app.dev.firstrecon.ai)
Tested by: belle.ung@persefoni.com

All acceptance criteria verified and passed.
No issues observed. This ticket is ready for release.
```

**`[Pro]` / `[Prod]` ticket, fully verified on Production:**
```
✅ QA Verified — [YYYY-MM-DD]

Tested on: Production (https://app.firstrecon.ai)
Tested by: belle.ung@persefoni.com

All acceptance criteria verified and passed.
No issues observed. This ticket is ready for release.
```

**`[Pro]` / `[Prod]` ticket, verified on Dev because Production has a deployment gap:**
```
✅ QA Verified — [YYYY-MM-DD]

Tested on: Dev (https://app.dev.firstrecon.ai) — Production fallback used due to deployment gap
Tested by: belle.ung@persefoni.com

All acceptance criteria verified and passed on Dev. The fix has not yet rolled out to
Production (https://app.firstrecon.ai). Release/deployment team to push to Prod for the fix
to be live for users.
```

- Include only the environment that was actually used for testing
- Keep it short and factual — no lengthy test case details
- Date format: YYYY-MM-DD

## Step 3 — Transition the Ticket

Move the ticket through the lane sequence, one transition at a time, re-listing between moves:

```
executeRead(name="listJiraIssueTransitions", cloudId, inputs={ issueIdOrKey })
transitionJiraIssue(cloudId, issueIdOrKey, transitionName="QA Review")   # only if not already in QA Review / In QA
executeRead(name="listJiraIssueTransitions", …)
transitionJiraIssue(cloudId, issueIdOrKey, transitionName="start qa")    # QA Review → In QA
executeRead(name="listJiraIssueTransitions", …)
transitionJiraIssue(cloudId, issueIdOrKey, transitionName="qa passed")   # In QA → Ready to Release
```

- Each `transitionJiraIssue` reply states the status it landed on — no read-back needed.
- If a transition is unavailable or blocked: **report the blocker and stop** — do not skip steps or pick a substitute.
- Do not pass a comment inside the transition call; it can be dropped silently. Step 2 posts it separately.

## Step 4 — Confirm and Report

Output a confirmation with:

- **Ticket ID** and its **new status** (Ready to Release)
- **Direct Jira link** to the ticket (`https://persefoni.atlassian.net/browse/{TICKET_KEY}`)
- **Comment posted**: confirmation that the QA verification comment was added
- **Environment used**: which environment was tested (and whether a Production → Dev fallback was used for `[Pro]`/`[Prod]` tickets)
- **Transition path**: the sequence of transitions executed
- Flag any transition steps that could not be completed, with the reason

## Important Notes

- This skill does NOT run any tests — it only processes tickets that have already been fully tested and passed
- No media capture is needed — the Passed flow is purely about status updates
- No `bun run` commands are executed — ignore any build/lint steps in the transition
- If the ticket is already in Ready to Release, note it and skip the transition
- For `[Pro]`/`[Prod]` tickets verified only on Dev (Prod deployment pending), the QA verification still moves the ticket forward — but the comment makes the deployment gap explicit so the release team knows action is needed