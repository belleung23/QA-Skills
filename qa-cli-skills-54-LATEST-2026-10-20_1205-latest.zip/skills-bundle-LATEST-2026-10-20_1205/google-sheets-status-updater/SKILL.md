---
name: google-sheets-status-updater
description: >
  Write test results and automation statuses back to a LIVE Google Sheet QA test suite (use
  excel-status-updater for a local .xlsx instead). Updates Status/Comments/Failure Type/Linear
  after manual testing (Passed, Failed with Linear issue ref + root-cause note, or Blocked with a
  reason), and drives Automation through To Do, In Progress, Done, or Fixme around an automated
  run. Edits the sheet in-browser, locating rows via Sheets' Find-all-sheets rather than pixel
  coordinates. Before filing a new Linear issue for a Failed result, re-verifies it's reproducible
  and checks for a duplicate first. Use whenever given a docs.google.com/spreadsheets link and
  asked to update test status, mark a TC ID passed/failed/blocked, set automation to in
  progress/done/fixme, or log results to a shared QA sheet.
  Triggers on: update google sheet, update sheet status, mark TC- passed/failed/blocked in the
  sheet, set automation in progress/done/fixme, update automation column, log result in sheet.
---

# Google Sheet Status Updater

Write test execution results and automation run status directly into a live First Recon AI QA
Google Sheet, via browser automation. This is the Google Sheets counterpart to
`excel-status-updater` — use this one whenever the user hands you a `docs.google.com/spreadsheets`
link instead of a local `.xlsx` file.

There is no Sheets write API connected in this environment, so every update happens through the
Sheets UI in the browser. That means the #1 failure mode is landing on the wrong cell. Don't
click by pixel coordinate — coordinates shift with scroll position, frozen panes, and whichever
side panel happens to be open. Use the two Sheets-native tools below instead.

## Locating a row reliably

1. **Read the header row first.** Open the sheet/tab, read row 1, and map header text → column
   letter (e.g. `Status` → `I`, `Automation` → `L`, `Linear` → `M`). Don't hardcode column letters
   across sheets — different tabs or different QA suites may order columns differently. The
   layout observed on `First-Recon-AI-Full-QA-Test-Suite` is:

   | Col | Header | Notes |
   |-----|--------|-------|
   | A | Test Case ID | e.g. `TC-WC-001` |
   | B | Nav | breadcrumb, e.g. `Workspace > Chat > Sidebar & Conversations` |
   | C | Priority | dropdown P1–P3 |
   | D | Description | |
   | E | Test Steps | |
   | F | Acceptance Criteria | |
   | G | Expected Result | |
   | H | Actual Result | |
   | I | Status | free text, conditional-formatted (`PASSED` green / `FAILED` red) |
   | J | Comments | free text — failure detail, notes, ticket references |
   | K | Failure Type | free text category, often blank |
   | L | Automation | **dropdown**: `To Do`, `In Progress`, `Fixme`, `Done` |
   | M | Linear | free text issue ref, e.g. `GR-7519 WONT FIX` |

   Treat this table as a reference example, not a guarantee — always confirm against row 1 of the
   actual sheet you're given.

2. **Find the row with Search all sheets**, don't scroll-hunt:
   - Open Find (`Cmd/Ctrl+F`), switch it to search **all sheets** (not just the active tab), type
     the exact Test Case ID, and press Enter. This jumps you to the correct tab and selects the
     matching cell in column A — no need to guess which tab (Workspace-Chat, Platform-Admin, etc.)
     a TC ID lives in.
   - Rows can be grouped under a collapsed dark-blue section banner (e.g. "▼ Chat — Sidebar &
     Conversations") that spans the full row. These banners don't contain a TC ID and Find will
     skip straight past them — you don't need to expand anything.
   - If Find reports no match, the TC ID doesn't exist in this sheet. Stop and tell the user —
     don't guess a nearby row.

3. **Jump to the exact cell with the Name Box**, not clicks:
   - Once you know the matching row number (read it off the Name Box after Find lands on it, or
     off the row header), click the Name Box (top-left of the toolbar, `Cmd/Ctrl+J`), type the
     target cell reference directly — e.g. `I42` for the Status cell in row 42 — and press Enter.
   - This is the reliable way to select a specific cell in Sheets. Clicking coordinates that
     "looked right" in a screenshot is exactly what goes wrong: column widths, frozen columns, and
     open side panels (like the Data Validation panel) all shift where a given cell actually
     renders on screen.

## Writing the Status, Comments, and Failure Type columns (after a manual test)

Valid Status values (type these exactly, matching existing case in the sheet):

| Status | Meaning |
|--------|---------|
| `PASSED` | Behavior verified as expected |
| `FAILED` | Live defect or divergence from expected — must be accompanied by a Comment and, once verified, a Linear reference |
| `BLOCKED` | Could not execute (env/auth/missing data/dependency issue) — put the reason in Comments |

1. Jump to the Status cell (Name Box, e.g. `I42`), type the value, press Enter.
2. **If Passed**: leave Comments/Failure Type as-is unless there's something worth noting.
3. **If Blocked**: jump to the Comments cell and write *why* it couldn't be tested (e.g. "Blocked
   — tenant seed data missing `advanced_dlp` flag; can't reach this screen"). Do not file a Linear
   issue for a Blocked result — it isn't a confirmed defect yet.
4. **If Failed**: see the gate below before you touch the Linear column.

Failure Type (column K here) is optional in this sheet, but if the user's process uses one, these
four categories are the ones used on the parallel Excel suite — reuse them for consistency:
`Product Defect`, `Reference/Spec Mismatch`, `Negative-test (by-design)`, `Needs relook`.

### The Failed-result gate: verify, then dedupe, before filing

A `FAILED` status plus a brand-new Linear issue number is a claim that a real, unique bug exists.
Belle asked specifically that this skill not skip either check — a spreadsheet full of false-alarm
issues is worse than no automation at all.

1. **Re-verify before trusting the failure.** Don't write `FAILED` off a single ambiguous
   observation. Re-run the step (or re-check the evidence) at least once more, ideally with
   fresh screenshot/console evidence, and confirm it's not an environment blip, stale session,
   or test-data issue that would actually make this a `BLOCKED` result instead.
2. **Check for a duplicate before creating an issue.** Search Linear via the GraphQL
   `issues(filter: {...})` query (see `LINEAR_CHEATSHEET.md` §3 — `title: { containsIgnoreCase: ... }`
   against the team's issues) for existing issues referencing this Test Case ID or matching
   symptoms/component before filing anything new.
   - **Duplicate found** → don't create a new issue. Write the existing issue's identifier into the
     Linear column and the Comments column, same as the sheet already does for `GR-7519 WONT FIX`
     style entries.
   - **No duplicate** → only now hand off to `linear-ticket-writer` (or `linear-draft-ticket-creator`
     if the user wants a draft instead of a live filing) to create the issue.
3. Once you have an issue identifier (new or existing), write it to the Linear column and reference
   it in Comments, e.g. `GR-8123 — Sidebar Library link routes to image gallery, not the Library page.`

Never skip step 1 or step 2 to save time — that's the entire point of this gate.

## Writing the Automation column (around an automated script run)

The Automation column is a **dropdown**, not free text. Click the cell, open its dropdown (click
the small arrow that appears on the selected cell, or `Alt+Down`), and click the matching option —
don't type over it, since the sheet enforces the value must come from the list.

Lifecycle for a given Test Case ID:

1. **Starting the automated run** → set Automation to `In Progress`. Do this right when you kick
   off the generated script for that TC ID, not after — the sheet should reflect that a run is
   underway.
2. **Run finishes, script passed** → set Automation to `Done`.
3. **Run finishes, script failed** → set Automation to `Fixme`. This is a distinct status from a
   manual `FAILED` — it flags the *automation script* as needing a fix (selector drift, timing,
   bad assertion), not necessarily that the product has a bug. If you also believe the product
   itself is broken (not just the script), separately update the Status/Comments/Linear columns per
   the manual-test flow above, including the verify-then-dedupe gate.

If you're updating automation status for a batch of TC IDs from a single run (e.g. output from
`automation-runner` or `test-script-validator`), process them one at a time using the Find →
Name Box procedure for each — don't try to multi-select rows across tabs.

## Update Report

After all edits, summarize what changed — don't assume the user is watching the screen live:

```
=== Google Sheet Status Update Report ===
Sheet: First-Recon-AI-Full-QA-Test-Suite

Manual results (3):
  ✅ TC-WC-001  → PASSED         (Workspace-Chat, row 3)
  ❌ TC-WC-009  → FAILED         (Workspace-Chat, row 11) — GR-8123 filed (verified, no duplicate found)
  🚫 TC-PA-004  → BLOCKED        (Platform-Admin, row 6) — tenant seed data missing flag

Automation (2):
  ⏳ TC-WC-001  → In Progress → Done   (Workspace-Chat, row 3)
  🔧 TC-OP-002  → In Progress → Fixme  (Operations-Portal, row 5) — script timed out on modal wait

Not found (1):
  ⚠️  TC-INVALID-999 → not found on any tab
```

## Safety rules

1. **Never downgrade an existing `PASSED`/`Done` to something worse without confirming with the
   user first.** Ask: "TC-WC-001 is currently PASSED — set it to FAILED?"
2. **Validate every Test Case ID exists** (via Find) before writing anything for it. Report
   misses clearly instead of silently skipping them.
3. **Comments are required for `FAILED` and `BLOCKED`** — if the user hasn't given you the detail,
   ask before writing the status.
4. **Never write a new Linear issue identifier without running the verify + duplicate-check gate above.**
5. This is a live, shared document — other people may have it open. Don't reformat, resize,
   reorder, or touch rows/columns you weren't asked to update. Google Sheets keeps version
   history automatically, so there's no need for a manual backup copy before editing.
