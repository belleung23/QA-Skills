---
name: "api-standards-gate"
description: "Advisory quality gate for API endpoints: reviews auth and tenancy, contract surface, validation, error envelope, pagination and rate limits, headers, worker boundaries, docs and tests against this repo's standards, with per-check applicability so inapplicable checks are never reported as findings. Runs after api-governance-gate on a PR, or standalone on any endpoint. Triggers on API standards, API quality check, is this endpoint up to standard, review this API, conformance audit."
---

# API Standards Gate

Is this API **built correctly**? `api-governance-gate` answers the other half - is it *allowed to exist*.

- **Chained** - runs after `api-governance-gate` on the same PR, over the same endpoint inventory, and appends to `docs/analysis/api-audit/<PR-or-branch>-<date>.candidates.md`.
- **Standalone** - given a path, file, or worker name, audits those endpoints and writes its own candidates file at the same location.

## Status: advisory, not blocking (as of 2026-09-21)

This gate emits **candidate findings**, not a merge decision. A 2026-09-21 review found two checks that misfire when applied literally - E1 against the external developer API, and an applicability table with no class for a bodyless read - and a later pass found a third, P3 against the documented fail-open rate-limit families. Blocking authority is withdrawn until the rollout conditions below are met.

Emit `STANDARDS ADVISORY - N candidate(s)`, never `STANDARDS BLOCKED`. Hand every candidate to `api-finding-verifier`; only `api-audit-reporter` writes the decision.

**Restore blocking authority only when** all three hold: two blinded paired trials on real PRs agree with human-confirmed findings; **both independent security verification passes have been re-run** (`api-finding-verifier` Rule 5); and a pilot on a small set of real PRs produced no false BLOCKER. Record the date and the evidence in the report that lifts it.

```
api-governance-gate  ->  api-standards-gate  ->  api-finding-verifier  ->  api-audit-reporter
   candidates              candidates              evidence + severity      the only decision
```

**Authority: report-only.** Never edit route source, contracts, specs, or governance files, and never mutate the dependency tree (`bun install`, `npm install`).

## Shared finding schema

Every candidate carries these fields, under the same names as the other three API skills. They are independent axes; do not let one collapse another.

| Field | Values |
|---|---|
| `evidence` | CONFIRMED / UNVERIFIABLE / UNVERIFIED |
| `severity` | BLOCKER / MAJOR / MINOR / INFO - never lowered because another check would also catch it |
| `novelty` | NEW / PRE-EXISTING at the merge-base |
| `rule` | file:line or ADR id, quoted, with its scope |
| `ci_status` | covered-red / covered-green / uncovered / unknown - corroboration, never a downgrade |
| `remediation` | PATCH READY / NEEDS OWNER INPUT |
| `gaps` | what could not be determined and what would settle it |

`evidence` has exactly three values, and **REFUTED is not one of them**:

- **CONFIRMED** - the verifier ran a falsification test and failed to kill the finding.
- **UNVERIFIABLE** - the verifier ran and could not determine the answer. Coverage gaps, never a blocker.
- **UNVERIFIED** - not through the verifier yet. **Every candidate this gate emits starts here.**

A check whose outcome is **NOT VERIFIED** (below) produces a candidate at `evidence: UNVERIFIED` with the reason in `gaps`; if the verifier then also cannot settle it, it becomes `UNVERIFIABLE`.

`severity` on a candidate is a **proposal**. Record it in the artifact, but withhold it from the verifier's claim-only prompt so the second pass is not anchored by it.

## Environment and execution tiers

Use whichever shell reaches the repo: `Bash` when local, `device_bash` with `cd $HOME/mnt/<repo>` for a Cowork-connected folder. Probe once:

```
which bun gh git python3 2>/dev/null
node -e 'require("esbuild")' 2>&1 | head -2
```

| Tier | Condition | Behaviour |
|---|---|---|
| **1 Full** | `bun` present, `node_modules` load cleanly | Run every gate |
| **2 Partial** | `bun` present, some gate fails on a dep or network | Run what works, label the rest |
| **3 Static** | no `bun`, or `esbuild`/`tsx` host mismatch | Gates recorded NOT RUN with their commands |

Tier 3 is normal in a Cowork desktop session and is not a fault to fix. Do not install into the user's `node_modules`.

**Every check below is a source read and runs at any tier** - only the `bun run` gates are tier-dependent. State the tier in the header.

## Step 1 - Classify the endpoint, then select the checks

**Do this first, for every endpoint. Most checks do not apply to most endpoints.** On a real internal monolith route, 13 of ~40 checks were inapplicable. **N/A is a first-class outcome: never a finding, never a coverage gap, counted in its own scorecard column.**

Classify on four axes - **Host** (monolith `worker/` vs microservice `workers/<w>/`), **Ingress**, **Shape** (single-resource / batch / collection), **Effect** (read / mutating), and record a fifth fact: **does the route accept a request body at all?**

### The six ingress classes - identify by the middleware, never by the path

Applying the wrong class's security checks produces a false BLOCKER on correctly-secured code.

| Ingress | Identified by | Security checks |
|---|---|---|
| **Internal service-binding** | `validateInternalRequest({...})` | S1-S6 all apply |
| **Human browser** | `authMiddleware` + `requireAuth` + `csrfOriginCheck` + `createUserRateLimit` | S1-S4, S6 **N/A**. Require instead: CSRF origin check, per-user rate limit, rejection of any `x-internal-*` header |
| **External API-key** | `developerExternalApiAuthMiddleware` + `requireLiveKey` + `externalApiRateLimitMiddleware` | S1-S4, S6 **N/A**. Require instead: live-key class enforced, rate limit behaviour per P3, D1 spec entry |
| **External signed callback (HMAC)** | an `X-*-Signature` header verified against a timestamp + raw body, explicitly no session | S1-S4, S6 **N/A**; D1 **N/A**. Require instead: signature bound to both the timestamp and the exact raw body, a replay window, constant-time comparison, a missing secret failing closed (503) |
| **Gateway-proxied** | the monolith or gateway forwards on (`proxyToService`, `proxyToChatWorkerFor*`) | judge the **receiving** worker's route; on the proxy hop only E/H/D apply |
| **Unauthenticated liveness** | `GET /health`-shaped, no identity read, no tenant data returned | **S, V, P, D, C2-C6, E1-E5 all N/A.** Applicable: C1, E6, H1 (inverse - see H1), B1-B5, T1 |

### Per-check applicability - the complete table

A check with no row here applies to every endpoint. A check whose row does not match is **N/A**, which is scope, not a gap.

**When this table and an ingress-class row disagree, the ingress-class row wins.** The liveness row is the one that matters in practice: a `/health` probe is exempt from C2-C6, E1-E5 and every S/V/P/D check even though some of those have rows below that would otherwise pull them back in.

| Check | Applies only when |
|---|---|
| S1-S4, S6 | ingress = internal service-binding |
| S5 | **the route accepts a body** |
| S7 | the handler **looks up a user or resource by a caller-supplied id** - not to comparing a body field against a signed claim |
| S8 | the handler touches workspace-scoped data |
| S9 | every ingress class |
| S10, C1 | host = microservice |
| C2-C4 | the endpoint has a service contract (all internal routes; most worker routes) |
| C5 | a contract file exists for this endpoint |
| C6 | host = microservice **and** the PR adds a route module to that worker |
| V1 | **the route accepts a body.** A bodyless GET has nothing to parse and V1 is N/A - not "not verified" |
| V2 | host = monolith **and** the route accepts a body |
| V3 | the handler reads a free-text identifier from the path, query or body |
| V4 | **shape = batch.** A single-resource or collection endpoint has no batch to cap |
| V5 | the route accepts a body |
| E1 | see the E1 scope note - **excludes `workers/developer-api-worker`** and the other ADR-048 non-goals |
| E2 | the endpoint returns tenant or user-scoped data |
| E3 | the target is a worker entrypoint with a catch-all |
| E4 | the file returns more than one error response |
| E5 | the endpoint returns at least one error response |
| P1-P2 | shape = collection |
| P3 | ingress = human browser or external |
| P4 | effect = mutating |
| H1 | the response carries user or tenant data. **Inverse for liveness**: a public probe must not be marked private-no-store without reason |
| H2 | the request carries `Authorization` or `Cookie` |
| H3 | the path is a deprecated alias |
| D1 | ingress = external API-key |
| D2 | host = monolith |
| D3 | the handler emits user-facing prose |
| T2 | the endpoint has an auth or tenant check to deny with |
| T3 | the PR is a bug fix |
| T4 | the worker is in `INTERNAL_AUTH_EXEMPT_WORKERS` |

Record the classification in the report so a reader can check the selection.

## Checks

Every finding cites file:line and quotes a line. Four outcomes: **PASS**, **FAIL** (a candidate), **N/A** (per the tables above), **NOT VERIFIED** (could not evaluate - a coverage gap, never a pass).

### S - Security and tenancy (BLOCKER unless noted)

- **S1** Covered by `validateInternalRequest` (`packages/worker-shared/src/middleware/validate-internal-request.ts`).
- **S2** `allowBodyFallback: false`. Identity comes from signed headers only.
- **S3** `destinationId` set, naming the **receiving** service. Without it a signature minted for A replays at B. A monolith-hosted route whose `destinationId` names a logical owner rather than the actual receiver is VERIFY, not an automatic pass.
- **S4** Receipt/admin-grade lanes also set `requireSignedClaims: true`, `requireCallerSecret: true`, `minSignatureVersion: 5`. Compare against `workers/detection-worker/src/app.ts`.
- **S5** `maxBodyBytes` on every route taking a body. Missing = MAJOR. Size the worst case.
- **S6** `rejectOnMismatch` left at its default. Disabling it without a cited ticket reopens the confused-deputy hole (GR-4878).
- **S7** A caller-supplied id lookup fails closed in the charter's explicit-null form (`docs/architecture/governance/MICROSERVICES_CHARTER.md`, "Security patterns (authorization checks)"):
  ```ts
  if (!targetUser?.tenant_id || targetUser.tenant_id !== currentUser.tenant_id) {
    return c.json({ error: 'User not found' }, 404);
  }
  ```
  The broken form `targetUser?.tenant_id !== currentUser.tenant_id` passes when both are `undefined`. Response is **404, not 403**. Do **not** apply this to `request.tenantId !== context.internalTenantId` on a signed internal route - that is an identity-mismatch guard and 403 is correct.
- **S8** `validateWorkspaceAccess(...)` returns `false` on DB error by design; the caller treats false as deny.
- **S9** No authorization decision reads `x-tenant-id` / `x-user-id` / `x-user-roles` off `c.req.header()`. Use `getSignedIdentity(c)` or `getInternalRequestContext(c)`.
- **S10** No public route on a domain worker; public ingress belongs to `gateway-worker` (`AGENTS.md` Forbidden).

### C - Contract surface

- **C1** `GET /health` exists on the worker.
- **C2** A contract file in `packages/worker-shared/src/contracts/`; for a worker, the name `openapi-check-workers.ts` expects (`<worker minus -worker>-service.ts`, or its override map).
- **C3** One schema or interface per method+path, a doc comment naming the endpoint, `correlationId` carried on the response.
- **C4** Wire limits are exported consts in the contract, not literals in the handler.
- **C5** Contracts carry wire shape only. **Zod schemas are expected and are not a finding**; domain behaviour is.
- **C6** A new route module in a worker listed in `WORKER_ROUTE_MODULES` (`scripts/openapi-check-workers.ts`) is added to that map. MAJOR.

### V - Validation and limits

- **V1** Body parsed through a zod schema with explicit bounds (`.max()`, `.min()`, `.int()`) and `.strict()`. Reference: `workers/detection-worker/src/routes/security-events-routes.ts`. **N/A when the route takes no body.**
- **V2** Monolith routes use `withValidation` / `validateBody` / `withErrorHandling` from `worker/utils/validation-helpers.ts`. A route that does `safeParse` inside `handleAsyncError` and returns a coded 400 satisfies the intent - MINOR consistency note.
- **V3** Free-text identifiers are charset-guarded (e.g. `/^[A-Za-z0-9_-]{1,64}$/`), not only length-capped.
- **V4** Batch endpoints cap batch size and reject an invalid batch **whole**. 422 is documented; a coded 400 that rejects the whole batch is a MINOR status-semantics note. **N/A for non-batch shapes.**
- **V5** Oversize body returns 413 with a stable code.

### E - Errors and response envelope

- **E1** **Scope first, then check.** ADR-048 (`docs/architecture/decisions/adr-048-api-error-localization-contract.md`) requires a stable `code` shaped `<DOMAIN>_<CONDITION>` in SCREAMING_SNAKE_CASE ("Code namespace convention", line 112). Three scope rules, all from the ADR's own "Non-goals" section (line 174):
  - **`workers/developer-api-worker` is explicitly out of scope** (line 176). It keeps its own documented `Error` schema in `docs/api/developer-api-openapi.yaml` - `message`, `type` enum, and lowercase snake_case `code` such as `invalid_api_key`. `code: 'missing_api_key'` at `workers/developer-api-worker/middleware/external-api-auth-middleware.ts:73` is **compliant with its own versioned public contract**; flagging that namespace is a false positive.
  - Server-rendered artifacts with no frontend renderer (emails, PDF/CSV exports) are out of scope and tracked as GR-10693.
  - Four named route files are excluded per the Platform Admin IA v2 brief: `operations-routes.ts`, `customer-operations-routes.ts`, `roadmap/features-routes.ts`, `roadmap/releases-routes.ts`.

  In scope, a **new** error string with no code is a BLOCKER. For **existing** handlers the obligation is conditional - the ADR is a burn-down, not a big-bang - so report the ratio and list the uncoded lines, and mark them `novelty: PRE-EXISTING` when they are. One live PR had 13 error responses and 2 codes, with all four auth rejections uncoded.
- **E2** `correlationId` in the body **and** `X-Correlation-Id` echoed as a header (plus `X-Request-Id` on the external API).
- **E3** The catch-all `app.all('*')` 404 propagates the correlation id.
- **E4** One envelope per handler, matching the surrounding worker. The repo runs four shapes in production; a fifth is the finding, and **mixing two shapes inside one file** is a finding on its own.
- **E5** Status semantics: 400 malformed; 401 missing or invalid credential; 403 wrong caller, key class or role; 404 tenant-scoped not-found; 409 conflict with a distinguishing code; 413 oversize; 422 whole-batch reject; 429 with `Retry-After`; 503 with `Retry-After` for dependency unavailability.
- **E6** No stack traces, internal paths, or upstream error text in a response body.

### P - Pagination, rate limits, idempotency

- **P1** Cursor/keyset pagination, not offset. The cursor is opaque and bound to tenant, subject, workspace and filters; a context change returns **409**.
- **P2** Page size clamped server-side from a contract const.
- **P3** **Scope first, then check.** The default is fail-**closed** when the limiter backend errors - 503, not a degraded fallback counter (GR-9046). But this repo declares the exception in code: `worker/middleware/rate-limit-middleware.ts` carries **8 families with `backendFailureMode: 'best_effort'` against 23 with `'fail_closed'`**, each best-effort one with a reasoned comment and a `fail_open_override` security event - `'auth-read'`, for instance, fails open deliberately because failing closed "would turn limiter degradation into a global app-boot outage". **A documented `best_effort` family with its comment and its security event is a declared exception, not a finding.** Read the comment before flagging; an undocumented one, or a new family added as `best_effort` with no reasoning, is the finding. Separately, allow and deny paths both set `X-RateLimit-Limit` / `-Remaining` / `-Reset`; 429 also sets `Retry-After`.
- **P4** Mutating endpoints are idempotent - an `Idempotency-Key` or a natural-key dedup. A POST that only reads and projects is idempotent by construction: PASS, not N/A.

### H - Headers and caching

- **H1** Responses carrying user or tenant data set `Cache-Control: private, no-store, max-age=0, must-revalidate` plus `Pragma`/`Expires`. Setting it as the handler's first line covers the handler's returns but **not** the 401/403 an auth middleware returns first - apply it in middleware or a `finally`. Check *where* it is set. **Inverse for an unauthenticated liveness probe**: private-no-store there is the thing to ask about, not the thing to require.
- **H2** `Vary: Authorization, Cookie` on authenticated responses.
- **H3** Deprecated paths set `Deprecation`, `Sunset`, `Link` (`rel="successor-version"`) and `Warning` **before** `await next()`. BLOCKER.

### B - Boundaries

- **B1** No cross-worker imports. BLOCKER (`AGENTS.md` Forbidden; `eslint.config.boundaries.js` RULE 2).
- **B2** No new monolith imports from `workers/*` beyond the frozen allowlist, and no `worker/` importing `workers/*`.
- **B3** No domain business logic added to `packages/worker-shared/`.
- **B4** No new name added to the per-file grandfather baselines in `eslint.config.boundaries.js`.
- **B5** DB writes only to tables this worker owns per `docs/architecture/governance/db-ownership.yaml`.

### D - Documentation

- **D1** External API-key endpoints appear in `docs/api/developer-api-openapi.yaml` with a unique `operationId`, request schema, and documented error responses. No CI workflow validates this file - only the vitest parity test `workers/developer-api-worker/__tests__/openapi-artifact-firewall-parity.test.ts` - so this check is the real gate, at any tier. **BLOCKER**, the same severity `api-governance-gate` proposes for the same defect. **N/A for HMAC callbacks.**
- **D2** Monolith routes reflected in `worker/routes/docs-routes.ts` or `worker/routes/docs/*.ts`, which is what `openapi:check` diffs against.
- **D3** User-facing strings route through `t()`. An English `error` string paired with a stable `code` is the ADR-048 contract, not a violation.

### T - Tests

- **T1** A test exercises the behaviour the diff adds, not merely that the route is registered. A test file for a *sibling* route is not coverage. Name the file you checked.
- **T2** Auth and tenant-isolation tests assert the **deny** path, with a case that fails if the check is removed. For an HMAC callback: a bad-signature and a stale-timestamp case.
- **T3** A bug fix starts from a focused regression test.
- **T4** An `INTERNAL_AUTH_EXEMPT_WORKERS` entry names the test enforcing its precondition.

## Gates

```
bun run type-check
bun run lint:boundaries
bun run i18n:check:api-responses
bun run openapi:check:all
bun run drift:check
```

**Tier 1/2** - run them, capture output verbatim, read with these caveats:

- `i18n:check:api-responses` is an **exact-count ratchet** against `scripts/api-response-i18n-baseline.json`: above baseline fails as new, below fails as stale and must be regenerated in the same PR. Pre-existing uncoded strings are recorded in that baseline, so an existing handler's uncoded rejections keep the check green - a green run is not evidence that a file is compliant. It scans error-shaped payloads including `{ success: false, error: '...' }` (`scripts/check-api-response-i18n.ts:74-78`), and skips only a *provable* success payload. It cannot see a body built as a variable (`const body = {...}; c.json(body)`), a literal passed through a local `ok`/`bad` helper, or a string relocated within one file - check those by hand at every tier. It does not run on `hotfix/*` to `staging` promotions, a known accepted gap.
- `lint:workers` runs with a large `--max-warnings` ceiling - **9394 as of 2026-09-21; read the current value out of `package.json` rather than quoting this one**, it moves. A ceiling is not a clean gate; never cite it as evidence of quality.

**Tier 3** - do not attempt them and do not imply they passed. Record each as `NOT RUN - <probe reason>` with the command, and note which candidates a gate would additionally have caught. A Tier 3 audit is legitimate, just narrower.

**A green gate that ran against the current checkout validates that checkout, not this skill's rules.** Never present passing repo gates as evidence that the audit itself is correct.

## Verdict and output

Proposed severity: **BLOCKER** (an applicable S check, in-scope E1, E2, H3, B1, D1, or a gate that ran and failed) / **MAJOR** (weakens a guarantee without opening a hole) / **MINOR** / **INFO**.

Three overall outcomes, and **an unfinished audit is not a pass**:

| Outcome | When |
|---|---|
| `STANDARDS ADVISORY - clean` | Every applicable check evaluated, no candidate above INFO |
| `STANDARDS ADVISORY - N candidate(s)` | At least one FAIL |
| `STANDARDS INCOMPLETE - N check(s) NOT VERIFIED` | Any applicable check could not be evaluated. Use this rather than letting an unresolved audit read as a pass |

Chat, first line: that outcome, then candidates most severe first, one line each. Do not paste the artifact into chat.

Append to the governance candidates file, or create it standalone. Use `## Standards audit` with `###` sub-headings so it never collides with the numbered sections governance owns:

```
## Standards audit
**Outcome:** ADVISORY clean | ADVISORY N candidate(s) | INCOMPLETE   **Gate:** api-standards-gate
**Environment:** Tier 1|2|3 (<probe result>)

### Endpoint classification
| Endpoint | Host | Ingress class | Shape | Effect | Body? | Checks selected | Checks N/A |

### Scorecard
| Group | Applicable | Pass | Fail | N/A | Not verified |
| S Security | | | | | |
| C Contract | | | | | |
| V Validation | | | | | |
| E Errors | | | | | |
| P Pagination/limits | | | | | |
| H Headers | | | | | |
| B Boundaries | | | | | |
| D Documentation | | | | | |
| T Tests | | | | | |

### Candidates
#### [STD-01] <check id> - <title>
- **Endpoint:** METHOD /path   (ingress class)
- **Schema:** evidence UNVERIFIED | severity (proposed) <x> | novelty <x> | ci_status <x> | remediation <x>
- **Evidence:** file:line + quoted source
- **rule:** the standard, quoted from its source file/ADR with a line ref and its scope
- **Root cause:** why it happened, and which gate does not catch it
- **Impact:** concretely what goes wrong in production
- **Remediation:** the corrected code block, or NEEDS OWNER INPUT with the open question
- **Verify with:** the exact command or test

Every candidate leaves this gate at `evidence: UNVERIFIED`; the proposed severity is withheld from the
verifier's claim-only prompt.

### Gate output
Per command: run / NOT RUN + reason, exit code, verbatim output, interpretation.

### Not verified
Each unevaluated applicable check and what blocked it - this is each candidate's `gaps` field.
N/A checks are NOT listed here.
```

## Discipline

- No finding without a quoted line of real source. Unread means NOT VERIFIED, not pass.
- **Classify by middleware before checking.** An inapplicable check reported as a finding is itself a defect in this audit.
- **Scope a rule before applying it.** A repo-wide convention with a documented exclusion list is not repo-wide; read the exclusions before flagging. E1 and P3 are the live examples - both have their exceptions written down in the repo, and both produced false positives before they were scoped.
- A green gate is never by itself evidence of quality - name what it does not cover.
- Do not soften a BLOCKER because nearby code does the same thing. Cite the precedent, keep the severity, mark `novelty: PRE-EXISTING`.
- Report only. Never edit the endpoint to make a check pass.