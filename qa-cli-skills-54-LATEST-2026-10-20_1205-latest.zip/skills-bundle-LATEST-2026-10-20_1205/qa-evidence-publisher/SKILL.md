---
name: "qa-evidence-publisher"
description: "Upload QA evidence screenshots, recordings and report files to a Linear issue via the Linear connector, then trigger linear-comment-writer to post the structured Markdown comment with the images inline. Triggers on: upload evidence, attach screenshots, publish evidence, upload test results, attach to Linear, evidence upload, post evidence, qa-evidence-publisher."
---

# Post Test Result — Upload Evidence & Comment to Linear

Uploads evidence and report files, posts a formatted comment, and transitions the issue if all tests passed.

> **Fixed 2026-10-16 (verified on FRAI-8354 — PNG and `.md` uploads, comment, transition).** The
> previous version called `linear-comment-writer/scripts/upload_linear_file.py`. That script is not
> in the repo, needs a `TESTING_LINEAR_API_KEY` that is not configured, and its PUT to
> `storage.googleapis.com` is blocked from the cloud sandbox; the Mac sandbox shell has no network at
> all. This version uses the **Linear connector** (`prepare_attachment_upload` → PUT from the Mac's
> Playwright process → `create_attachment_from_upload`) and `save_comment` / `save_issue`. No API
> key, no scripts. The release state is named **`Ready for Release`**.

> **Critical:** All paths must be **absolute**. In the Mac sandbox shell (`device_bash`) the repo is
> `$HOME/mnt/eng-guardrails-platform`; in Playwright on the Mac it is
> `/Users/belleung/Documents/guardrails/eng-guardrails-platform`.

---

## Step 0 — Repo Root

```bash
REPO_ROOT="$HOME/mnt/eng-guardrails-platform"
[ -d "$REPO_ROOT/.git" ] || { echo "[ERROR] repo folder not connected — ask for /Users/belleung/Documents/guardrails/eng-guardrails-platform"; exit 1; }
```

---

## Screenshot & Video — Scope Rules

| Scope | Upload screenshots | Upload recordings |
|-------|-------------------|-------------------|
| **FE** or **FE+BE** | ✅ Yes — all TCs (PASS + FAIL) | ✅ Yes — FAIL cases only |
| **BE** only | ❌ No | ❌ No |

Only attach evidence files when scope is FE or FE+BE. For BE-only tickets, upload only the report `.md` files.

---

## Step 1 — Build the File List (with exact sizes)

```bash
# Always (every ticket)
ls -l "$REPO_ROOT/test-reports/${TICKET_KEY}_"*.md 2>/dev/null
ls -l "$REPO_ROOT/test-cases/${TICKET_KEY}_"*.md 2>/dev/null
# FE / FE+BE only
ls -l "$REPO_ROOT/manual-testing/evidences/$TICKET_KEY/"*.png "$REPO_ROOT/manual-testing/evidences/$TICKET_KEY/"*.gif "$REPO_ROOT/manual-testing/evidences/$TICKET_KEY/"*.webm 2>/dev/null
```

Record each file's **exact byte size** — the upload is rejected if it differs.

Content types: `.png` → `image/png`, `.gif` → `image/gif`, `.webm` → `video/webm`, `.md` → `text/markdown`.

---

## Step 2 — Upload Every File (connector, one file at a time)

The signed URL expires in **60 seconds**. For each file, finish all three sub-steps before starting the next file. Never batch the prepare calls.

**2a.** `prepare_attachment_upload(issue="{TICKET_KEY}", filename, contentType, size)` → note `assetUrl`, `uploadRequest.url`, `uploadRequest.headers`.

**2b.** PUT the bytes from the Mac's Playwright process:

```javascript
// mcp__playwright__browser_run_code_unsafe
async (page) => {
  const FILE = '/Users/belleung/Documents/guardrails/eng-guardrails-platform/{relative path of the file}';
  const URL = '{uploadRequest.url}';
  const HEADERS = { /* uploadRequest.headers verbatim, same key casing */ };
  const p = await page.context().newPage();
  await p.setContent('<input type="file" id="f">');
  await p.setInputFiles('#f', FILE);
  const b64 = await p.evaluate(() => new Promise((res) => { const f = document.getElementById('f').files[0]; const r = new FileReader(); r.onload = () => res(r.result.split(',')[1]); r.readAsDataURL(f); }));
  await p.close();
  const data = Buffer.from(b64, 'base64');
  const r = await page.request.put(URL, { data, headers: HEADERS, timeout: 60000 });
  return { status: r.status(), bytes: data.length };
}
```

Expect `status: 200` and `bytes` equal to the prepared `size`. Otherwise prepare again and retry that file.

**2c.** `create_attachment_from_upload(issue="{TICKET_KEY}", assetUrl, title=filename)` — this also lists the file under the issue's Resources.

Keep a `filename → assetUrl` table. Verify the count equals the file list from Step 1 before going on.

---

## Step 3 — Build the Screenshots Lane (FE / FE+BE only)

**Skip entirely for BE-only tickets.**

For every screenshot, add a Markdown image reference using its `assetUrl`, in the Screenshot column of the Test Cases table (see `linear-comment-writer`'s skeleton):

```markdown
![TC1-PASS](https://uploads.linear.app/.../FRAI-1234-TC1-PASS-desc.png)
```

**Rules:**
- Include **all** screenshots — both PASS (green badge) and FAIL (red badge) — for FE/FE+BE scope.
- Order by TC number, matching the test case table.
- A FAIL row carries its PNG and its GIF/WebM, both inline.
- Screenshots must appear **visually** in the comment (a rendered `![alt](url)` image), not just as a filename or attachment link. Linear renders them inside table cells.

---

## Step 4 — Post Comment

Use `linear-comment-writer` to write the comment, then post it with the connector:

`save_comment(issueId="{TICKET_KEY}", body=<Markdown>)` — plain Markdown, literal newlines.

Also write the same Markdown to `$REPO_ROOT/test-reports/linear-comments/${TICKET_KEY}_${date}_comment.md` for the record. Then open the issue in Chrome and confirm every image renders (reload once if the newest comment is not shown).

---

## Step 5 — Transition if All Passed

If result is passed (`_result_passed.md` or all TCs ✅): `save_issue(id="{TICKET_KEY}", state="Ready for Release")` — one call, no intermediate states (see `linear-ticket-transition`; the SpydySense AI team has no release-ready state, stop and ask there).

| Result | Action |
|--------|--------|
| All passed | → Ready for Release |
| Any failure | No status change |

---

## Step 6 — Move Result File to Done

```bash
mv "$REPO_ROOT/manual-testing/test-results/${TICKET_KEY}_result_"*.md "$REPO_ROOT/manual-testing/test-results/done/" 2>/dev/null || true
```

---

## Expected File Layout

```
{REPO_ROOT}/
  test-reports/
    FRAI-1234_PASSED_QA-Report_2026-05-28.md
  test-cases/
    FRAI-1234_PASSED_Test-Cases_2026-05-28.md
  manual-testing/
    evidences/
      FRAI-1234/
        FRAI-1234-TC1-PASS-desc.png     ← FE/FE+BE only
        FRAI-1234-TC2-FAIL-desc.png     ← FE/FE+BE only
        FRAI-1234-TC2-FAIL-desc.gif     ← FE/FE+BE only
```

---

## Linear Teams

`FRAI` (First Recon AI) and `SSAI` (SpydySense AI). `GR-` keys are Jira, not Linear — use the Jira skills for those.

---

## Alternative: API-key script

If `.dev.vars` in the repo root contains `TESTING_LINEAR_API_KEY`, `linear-comment-writer/scripts/upload_linear_file.py <files…>` prints `filename -> assetUrl` per file — but only from a shell that can reach both `api.linear.app` and `storage.googleapis.com`, which neither sandbox can today. Prefer Step 2.