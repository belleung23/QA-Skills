---
name: "api-finding-verifier"
description: "Adversarial second pass that tries to disprove every candidate API audit finding before it reaches the report. Runs a fixed falsification checklist covering the known false-positive classes and gives each finding an evidence verdict and a severity as separate judgements - CI coverage is corroboration, never a downgrade. Triggers on verify the findings, double check the audit, are these findings real, confirm the blockers, falsify, second pass."
---

# API Finding Verifier

The gates produce **candidate findings**. This skill decides which ones are real. Nothing reaches `api-audit-reporter` as a BLOCKER or MAJOR until it has survived this pass.

**Your job is to destroy findings, not to confirm them.** A verifier that agrees with the gate adds nothing. Start from the assumption that each candidate is wrong and go looking for the evidence that proves it wrong. Only a finding you genuinely failed to kill is real.

This exists because an earlier run of the gates over three live PRs was reported as producing **11 genuine blockers and 11 false ones**. No artifact from that run was retained, so treat the ratio as the reason the checklist exists rather than as a measurement - it does not meet the evidence bar Rule 6 sets for any number this skill publishes. What is durable is that every false finding came from a fixed, recognisable class, and those classes are the checklist below.

```
api-governance-gate  ->  api-standards-gate  ->  api-finding-verifier  ->  api-audit-reporter
   candidates              candidates              evidence + severity      the only decision
```

## Status: this pass is not a certification (as of 2026-09-21)

A 2026-09-21 review found that the previous version of this skill **downgraded a real tenant-isolation defect to INFO** because CI would catch it, while an unaided baseline run kept it CONFIRMED / BLOCKER. That rule is removed, but the pipeline it sits in is running advisory until its rollout conditions are met, so this pass produces verdicts, not clearance.

**Treat this pass as complete only when** the security double-pass in Rule 5 actually ran for every security finding, and say so in the summary either way. Blocking authority for the pipeline is restored only when both gates' conditions are met: blinded paired trials on real PRs, **both independent security passes re-run**, and a pilot with no false BLOCKER.

## Shared finding schema

Every finding carries these fields, under the same names as the other three API skills. This skill sets `evidence` and `severity`; the rest it records as facts.

| Field | Values |
|---|---|
| `evidence` | CONFIRMED / UNVERIFIABLE / UNVERIFIED |
| `severity` | BLOCKER / MAJOR / MINOR / INFO |
| `novelty` | NEW / PRE-EXISTING at the merge-base |
| `rule` | file:line or ADR id, quoted, with its scope |
| `ci_status` | covered-red / covered-green / uncovered / unknown |
| `remediation` | PATCH READY / NEEDS OWNER INPUT |
| `gaps` | what could not be determined and what would settle it |

How this skill's verdicts map onto `evidence`:

| Verdict here | `evidence` value | Where it goes |
|---|---|---|
| **CONFIRMED** | `CONFIRMED` | Report, at its own severity |
| **REFUTED** | none - it stops being a finding | Verification summary only, with the checklist line that killed it |
| **UNVERIFIABLE** | `UNVERIFIABLE` | Coverage gaps, never a blocker. Say what would settle it |

A candidate that never reached this pass stays at `evidence: UNVERIFIED` and is reported as such, not as a finding.

There is **no DOWNGRADED verdict**. It conflated "the evidence is weaker" with "the consequence is smaller" and hid real defects. A finding is CONFIRMED with a severity, or it is not CONFIRMED.

## Rule 0 - Two judgements, never one

Every candidate gets **two separate answers**, and collapsing them is the single most damaging thing this skill can do:

1. **Is the defect real?** CONFIRMED / REFUTED / UNVERIFIABLE. A question about evidence only.
2. **How bad is it?** BLOCKER / MAJOR / MINOR / INFO. A question about consequence only.

Nothing about *who else would notice the defect* belongs in either answer. A 2026-09-21 trial showed why: a real tenant-isolation defect - both tenant identifiers could be `undefined` and bypass the guard - was correctly recognised, then filed as INFO because CI would catch it. The unaided baseline run kept it CONFIRMED / BLOCKER. The skill made the answer worse.

`novelty`, `ci_status`, `rule`, `remediation` and `gaps` are recorded as **facts, not adjustments**. None of them moves either answer.

## Rule 1 - Fresh eyes

Verify each finding **without the reasoning that produced it**. The dispatch payload is: the claim, the endpoint, the file:line, and the quoted source. Nothing else.

In particular, **withhold the gate's proposed severity**. The gates record one in the candidate artifact for the reader; handing it to this pass anchors the second opinion on the first. Set severity yourself, from the consequence, after the evidence question is settled.

When a subagent is available, dispatch each candidate to its own agent with that claim-only prompt. When running inline, force the same discipline: write down the falsification test **before** re-reading the code, then go look.

## Rule 2 - Name the falsification test first

For every candidate, write one sentence: *"This finding is wrong if I observe X."* Then go look for X. If you cannot state X, send it back as UNVERIFIABLE.

| Candidate | Falsification test |
|---|---|
| Route is unregistered | An ownership prefix covering the **resolved** path exists anywhere in the branch's yaml |
| Route is new | The same `(method, resolved path)` exists in the **merge-base** inventory, in any file |
| Handler has no auth | Any auth exists in the route file **or in the function it delegates to** |
| Error response has no code | The endpoint's own contract is satisfied - including a documented lowercase convention the ADR excludes from its rule |
| Endpoint is a duplicate | The two handlers return different payloads, or serve different owners/ingress |
| Missing body size cap | A byte check exists in the delegate, or the route takes no body |
| Rate limiter fails open | The family's `backendFailureMode: 'best_effort'` is documented in the config with a reason and a `fail_open_override` event |
| Path escapes its mount | The framework says otherwise - check the installed package, not the intuition |

## Rule 3 - The known false-positive checklist

Run every applicable line. Each one killed a real finding in a real run.

### Path and registration

1. **Mount-relative path.** Resolve the real absolute path before claiming it is unregistered. `/pending` was really `/api/security/confirmations/pending`.
2. **Mounts always compose.** Verified on hono 4.13.5: a child registering `/api/gamma/one` under `app.route('/api/mu', child)` is served at `/api/mu/api/gamma/one`; the bare path 404s. An "absolute path escapes its mount" claim is wrong for this repo's framework - refute it and say so.
3. **Modified, not created.** Does the same method+path already exist at the **merge-base** - in any file? A remove-and-re-add to change options is a modification; a route that moved files is a move. Neither is new. And check the merge-base, not the base tip: when both branches added the same path, the tip hides it.
4. **Wildcard normalization.** Does `/a/*/c` match an ownership entry written as `/a/:id/c`? Mid-path `*` is a path parameter; only a trailing `/*` is a prefix.
5. **Near-miss prefix family.** `/internal/x/*` does **not** cover `/api/internal/x/*`. Confirm segment by segment - but equally, confirm a real covering entry is absent before calling it unregistered.
6. **Documented exception.** Is there a `gateway_mismatch_exception`, a `db-ownership-baseline.yaml` entry, or an `INTERNAL_AUTH_EXEMPT_WORKERS` line covering this?

### Handler behaviour

7. **Delegation.** Does the route file only forward (`serve*`, `handle*`, a service import)? Auth, size caps, error codes and cache headers routinely live one level down. Audit the file where the behaviour is, and say which file you read.
8. **Wrong ingress class.** Which middleware authenticates this? `validateInternalRequest`, a signed-envelope `verify*Message`, an `X-*-Signature` HMAC, `authMiddleware`+`requireAuth`+`csrfOriginCheck`, `developerExternalApiAuthMiddleware`, a gateway proxy hop, or an unauthenticated liveness probe. Internal-auth checks applied to any of the others produce a false BLOCKER on correctly-secured code.
9. **Out-of-scope rule.** Does the rule's own source exclude this surface? Two live examples: ADR-048's "Non-goals" (line 174) excludes `workers/developer-api-worker`, which keeps lowercase snake_case codes such as `missing_api_key` by its own versioned public contract; and `worker/middleware/rate-limit-middleware.ts` declares 8 deliberate `backendFailureMode: 'best_effort'` families against 23 `fail_closed`, each with a reason and a `fail_open_override` security event. A rule applied outside its stated scope is a false positive, not a strict reading.
10. **Error-value shape.** Judge the value, not the presence of a `code` key. `{ error: 'domain_condition_token' }` is machine-identifiable. Only English prose with no stable token is the violation.
11. **Identity guard vs tenant lookup.** `request.tenantId !== context.internalTenantId` on a signed route is an identity-mismatch guard and 403 is correct. The 404 existence-hiding rule applies only to lookups by a caller-supplied id.
12. **Applicability.** Was this check selected for this endpoint's class, or applied blindly? An N/A check reported as a finding is a defect in the audit. A bodyless read has no body to validate and no batch to cap; a liveness probe has no contract, no tenancy and no error envelope to grade.
13. **Convention, not rule.** Can you quote a rule from `AGENTS.md`, `docs/architecture/governance/MICROSERVICES_CHARTER.md`, an ADR, or a script's source? If the only support is "most files do it this way", it is MINOR at most.

### Scope and novelty - facts, not discounts

14. **Pre-existing on develop.** Does the same defect already exist unchanged at the merge-base? Record `novelty: PRE-EXISTING`. This changes **attribution**, not severity: the finding is still real and still reported, it is simply not this PR's doing. It may still block a PR that makes it worse or that ships in the same file.
15. **CI coverage.** Would `ownership:check`, `openapi:check:workers`, `lint:boundaries` or `i18n:check:api-responses` fail on this? **Record which check and its current colour. Do not change the severity.** A required check that is red is corroborating evidence and is itself a merge stop; deduplicate the *presentation* so the reader sees one finding, not two, and link the failing run. A check that is green while the defect is real tells you the check has a blind spot - name it; the `i18n:check:api-responses` baseline ratchet is the common one, since baselined pre-existing occurrences keep it green.

## Rule 4 - Recording the verdict

Use the verdict-to-`evidence` mapping in the schema section above. Two habits make the pass auditable:

**Never delete a REFUTED finding silently.** The verification summary lists what was raised and killed, so a reader can see the audit was adversarial rather than thin. It is also how you notice the gate regressing.

**Say which file you read.** A CONFIRMED verdict quotes the file that actually holds the behaviour, not the file the candidate pointed at, when those differ.

## Rule 5 - Second opinion on security

Any finding in the S group, or any finding whose remediation touches auth, tenancy, signatures or rate limiting, gets verified **twice by two independent passes**. If the two disagree, the verdict is UNVERIFIABLE and a human decides.

**The second pass is a claim, so it must be recorded as a fact.** State per security finding whether the independent pass **ran** or **did not run**, and who or what ran it. A run that skipped it is a partial verification and says so in its output - it must never be presented as a completed verifier certification. A 2026-09-21 controlled run skipped it and reported that limitation; that is the required behaviour, not an excuse.

## Rule 6 - Report the numbers

Every audit carries a verification summary:

```
### Verification pass
Candidates raised:      N
CONFIRMED:              N   (severity breakdown)
REFUTED:                N   (checklist line that killed each)
UNVERIFIABLE:           N   (what would settle it)
Of CONFIRMED, PRE-EXISTING: N
Of CONFIRMED, CI-covered:   N red / N green (corroboration only)
Security second pass:   ran | NOT RUN (reason)
Precision this run:     CONFIRMED / (CONFIRMED + REFUTED)   [UNVERIFIABLE excluded from both]

| # | Candidate | Falsification test | Verdict | Severity | Killed by |
```

**The precision formula counts every CONFIRMED finding, whatever its severity, novelty or CI status.** The earlier formula excluded true findings that had been downgraded and returned **0% on a run that had correctly identified a real tenant-isolation defect** - a number that would have condemned a working gate. If a run reports 0% precision, check the formula before checking the gate.

Track precision across runs. A falling number means the gate is drifting and its checks need scoping - fix the gate, not the report. **One run is not a benchmark: every number this skill publishes says how many runs it rests on, and an unretained run is not evidence.**

## What this cannot promise

This catches the **known** false-positive classes and catches new ones early. It does not drive them to zero, and no trial so far supports that claim: the classes above were derived from a handful of runs, and a new framework pattern, auth mechanism or contract convention will produce a class nobody has seen. The protection is Rule 2 - every finding states what would prove it wrong - and the discipline of adding each newly discovered class to the checklist above rather than fixing one instance quietly.

The cost is real and worth naming: some genuine findings land as UNVERIFIABLE rather than as blockers. That is the correct trade. What is **not** an acceptable trade is a real defect landing as INFO because something else might also catch it.