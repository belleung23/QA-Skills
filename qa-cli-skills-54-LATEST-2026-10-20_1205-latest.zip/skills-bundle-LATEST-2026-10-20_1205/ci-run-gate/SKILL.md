---
name: "ci-run-gate"
description: "Get a branch or PR running in CI and drive it to a verdict (CI_GREEN / CI_RED / CI_PENDING / CI_BLOCKED): push and open the PR, add the label or dispatch the workflow that starts CI, watch the checks on the head commit, separate required from advisory, read failing logs and test reports and classify each failure. Use it for any request about a PR's or branch's CI: is PR #N green, why is a check failing or stuck on 'Expected — waiting for status', watch my checks, push and open the PR with a label, kick off or dispatch a workflow or smoke suite in GitHub Actions or GitLab, did my tests really run in CI. Use it even when one quick gh command looks enough: a green tick can be stale, skipped or advisory."
---

# CI Run Gate

Second of three gates:

```
ci-precheck-gate  ──►  ci-run-gate  ──►  ci-postcheck-gate
```

Job: get the change **running** in CI, make sure the right checks ran **on the right commit**, and
turn the result into a verdict a person can act on. A green tick only means something if it is for
the current head SHA, from a job that really executed tests, on a required check. Much of this skill
is about not being fooled by green.

Not this skill: fixing the failing tests (`failure-triage` → `flake-surgeon`), CI-check repair in a
repo that ships its own `ci-debug` skill (use it), answering reviewer threads (`pr-review-response`),
merge readiness (`pr-closeout`), post-merge verification (`ci-postcheck-gate`).

The agent runs everything; the user approves shared actions once and reads the report.

## Ground rules

- **One approval for shared actions.** Before any of these, list them all in one message and wait
  for a yes: `git push`, opening a PR, editing title/body, marking ready / back to draft, adding or
  removing labels, posting PR comments (including bot commands like `@codex review`), `gh workflow
  run`, `gh run rerun`, `gh run cancel`. Reading is always fine.
- **Finished-runs-only mode.** When the user says to read existing runs only, do exactly that: no
  push, no PR, no label, no dispatch, no re-run, no comment — report from runs that already finished.
- **Never:** merge, approve, enable auto-merge, force-push a branch you didn't create, push to a
  protected branch, add bypass/override labels, edit CI files to get green, or dispatch a workflow
  that deploys to staging/production.
- **Nothing lands on the user's computer without asking.** Before downloading an artifact or report
  to their machine, name the exact file (name, source run, size) and wait for a yes. Touch only that
  file; never read, move or delete anything else in their Downloads folder.
- **No AI attribution** in commits, PR bodies or comments unless the user asks.
- **Re-run discipline.** At most one re-run of a failed job, only when evidence says FLAKY or ENV,
  and it goes in the report. Re-running until green hides real bugs.
- **Same commit or it doesn't count.** Every check result is matched to the PR's current
  `headRefOid`; results for older SHAs are stale.
- **Plain language first** in the report.

## Step 0 — Access, setup, kit

1. **Find a working path to GitHub**, in this order, and say which one you used:
   1. `gh` CLI: `gh auth status && gh repo view --json nameWithOwner` (in the shell that has network;
      the shell on the user's own machine may have none — then try the other shell).
   2. A GitHub connector/MCP tool in the session, if present.
   3. The browser (the user's logged-in Chrome or the built-in browser), read-only: PR page →
      **Checks** tab and the merge box (it shows **Required** badges and non-check requirements like
      reviews and the merge queue), each run page (jobs, job summaries, annotations) and job logs;
      read with page-text tools, open your own tab and close it after. Useful URLs:
      `/<owner>/<repo>/pull/<N>/checks`, `/<owner>/<repo>/actions/runs/<id>`, and run lists filtered
      with `/<owner>/<repo>/actions/workflows/<file>?query=branch:<b>+event:push`. Unauthenticated
      `api.github.com` calls from the browser page also work for public data (60 per hour).
      - A page that shows **"There was an error while loading"** or an empty checks list is not
        evidence of "no checks": reload once, then use the Checks tab, the run page or the API.
      - A shared browser can return a stale page: confirm the URL/title in the page text before using
        a read. A run page lists every job twice (sidebar and graph): count unique job IDs.
   4. Ask the user to paste the checks list / failing log. (Last resort.)
   Never work around a blocked domain with other HTTP tools.
2. **Work dir**: `<repo>/tmp/ci-gate/<pr-or-branch>/` if that path is git-ignored, else
   `${TMPDIR:-/tmp}/ci-gate/<pr-or-branch>/`.
3. **Project notes.** If `<repo>/.qa-kit/ci-notes.md` exists, read it. It holds what earlier runs
   learned about this repo (required checks, opt-in labels, dispatch inputs, known traps). Treat every
   line as a **lead to re-verify**, never as evidence: re-check it in this run, or label it "(from
   project notes, not re-checked)" in the report. The file is git-ignored with the rest of `.qa-kit/`.

### Install the kit

Two kits: **ci-gates** gives `ci-map.py` (what CI will run for a change); **ci-guard** gives
`post-ci-check.mjs` (what a run's Playwright report really says), with its reader `pw-report.mjs` and
`secret-scan.mjs` (masked secret scan of downloaded artifacts).

The scripts are not in this file. They are published, byte for byte, in the **Shift-Left QA Kit**
artifact: https://claude.ai/artifact/A6uQ18siDLrTWJdMEGdVWv (kit version 2026.10.20-1). This skill pins the files it needs, and installs them
into `<repo>/.qa-kit/ci-gates/`:

| File (published path) | Bytes | Fingerprint |
|---|---|---|
| `ci-gates/ci-map.py` | 35,935 | `9f675d2a7e7332e3` |
| `ci-gates/gate-run.py` | 14,416 | `8a08f42c56b1a9d6` |

The fingerprint is the first 16 hex characters of the file's sha256.

1. **Already installed?** Run
   `cd <repo> && node -e 'const c=require("crypto"),fs=require("fs");for(const f of process.argv.slice(1))console.log(c.createHash("sha256").update(fs.readFileSync(f)).digest("hex").slice(0,16),f)' .qa-kit/ci-gates/ci-map.py .qa-kit/ci-gates/gate-run.py`.
   If every file matches the table, the kit is installed: skip steps 2 and 3.
2. **Fetch.** Use the Artifact tool: `action: "read"`, `url: "https://claude.ai/artifact/A6uQ18siDLrTWJdMEGdVWv"`,
   `paths: ["ci-gates/ci-map.py", "ci-gates/gate-run.py"]`. It saves each file locally and prints its sha256. Compare the first 16
   characters with the table. **On any mismatch, stop**: don't run the file, and tell the user that
   the kit and this skill are out of sync.
3. **Install.** Copy the files into `<repo>/.qa-kit/ci-gates/`. Make sure `<repo>/.qa-kit/.gitignore`
   contains `*`, so nothing is ever committed. Then check the syntax (`python3 -c "import ast,sys; ast.parse(open(sys.argv[1]).read())" <file>` for each `.py`) and re-check the
   fingerprints in the repo — a copy can silently land an older version.
   - **Repo on the user's computer, files in the cloud:** copy them with the device file-copy tool.
     Stage them into a **new, timestamped folder every time**, because the copy tool caches by path
     and will otherwise write an old version; then re-check the fingerprints on the computer.
   - **No Artifact tool in this session, or the read is refused:** look on the same machine for
     another repo whose `.qa-kit/ci-gates/` matches the table, and copy from there. Otherwise tell the
     user what is missing. The artifact is private, so a teammate needs it shared with them. Never
     retype a script by hand.
4. **Python.** `ci-map.py` needs Python 3.8+ and PyYAML (`python3 -c "import yaml"`). If PyYAML is missing: `python3 -m pip install --user pyyaml`, or run ci-map on a machine that has it.

The scripts are not in this file. They are published, byte for byte, in the **Shift-Left QA Kit**
artifact: https://claude.ai/artifact/A6uQ18siDLrTWJdMEGdVWv (kit version 2026.10.20-1). This skill pins the files it needs, and installs them
into `<repo>/.qa-kit/ci-guard/`:

| File (published path) | Bytes | Fingerprint |
|---|---|---|
| `ci-guard/secret-scan.mjs` | 38,058 | `19daccd32b08fdf2` |
| `ci-guard/prepush-check.mjs` | 23,254 | `3db85cd35bbe579f` |
| `ci-guard/ci-audit.mjs` | 55,234 | `58f2fbb4d014acfc` |
| `ci-guard/post-ci-check.mjs` | 28,831 | `b31d2cdec77f3732` |
| `ci-guard/pw-report.mjs` | 13,015 | `89e86c27420deedd` |

The fingerprint is the first 16 hex characters of the file's sha256.

1. **Already installed?** Run
   `cd <repo> && node -e 'const c=require("crypto"),fs=require("fs");for(const f of process.argv.slice(1))console.log(c.createHash("sha256").update(fs.readFileSync(f)).digest("hex").slice(0,16),f)' .qa-kit/ci-guard/secret-scan.mjs .qa-kit/ci-guard/prepush-check.mjs .qa-kit/ci-guard/ci-audit.mjs .qa-kit/ci-guard/post-ci-check.mjs .qa-kit/ci-guard/pw-report.mjs`.
   If every file matches the table, the kit is installed: skip steps 2 and 3.
2. **Fetch.** Use the Artifact tool: `action: "read"`, `url: "https://claude.ai/artifact/A6uQ18siDLrTWJdMEGdVWv"`,
   `paths: ["ci-guard/secret-scan.mjs", "ci-guard/prepush-check.mjs", "ci-guard/ci-audit.mjs", "ci-guard/post-ci-check.mjs", "ci-guard/pw-report.mjs"]`. It saves each file locally and prints its sha256. Compare the first 16
   characters with the table. **On any mismatch, stop**: don't run the file, and tell the user that
   the kit and this skill are out of sync.
3. **Install.** Copy the files into `<repo>/.qa-kit/ci-guard/`. Make sure `<repo>/.qa-kit/.gitignore`
   contains `*`, so nothing is ever committed. Then check the syntax (`node --check <file>` for each `.mjs`) and re-check the
   fingerprints in the repo — a copy can silently land an older version.
   - **Repo on the user's computer, files in the cloud:** copy them with the device file-copy tool.
     Stage them into a **new, timestamped folder every time**, because the copy tool caches by path
     and will otherwise write an old version; then re-check the fingerprints on the computer.
   - **No Artifact tool in this session, or the read is refused:** look on the same machine for
     another repo whose `.qa-kit/ci-guard/` matches the table, and copy from there. Otherwise tell the
     user what is missing. The artifact is private, so a teammate needs it shared with them. Never
     retype a script by hand.

## Step 1 — Resolve the target

```bash
gh pr view <N|url|branch> --json number,url,title,state,isDraft,baseRefName,headRefName,headRefOid,mergeable,mergeStateStatus,labels,reviewDecision,author
```

No PR yet → the target is a branch (pushed or not). Record: PR number, base, head branch,
**head SHA**, draft state, labels, mergeable state, and whether the head is a **fork**. If `state` is
MERGED, stop and offer `ci-postcheck-gate`.

## Step 2 — Pre-flight: will CI start, and will it test anything?

1. **Pre-check.** Is there a `ci-precheck-gate` report for this head SHA? If not, run its fast tiers
   at least, or ask whether to run the full pre-check. Pushing a branch that fails format/lint
   locally wastes a CI cycle.
2. **Which workflows should appear.** Save the changed files (`git diff --name-only
   origin/<base>...HEAD > $WORK/changed.txt`) and map the PR lane:

   ```bash
   python3 .qa-kit/ci-gates/ci-map.py --ref origin/<base> --event pull_request --action synchronize \
     --branch <base> --changed $WORK/changed.txt --expand --json $WORK/ci-map.json
   ```

   Use `--action opened` for a new PR (and `labeled`, `ready_for_review` … for those events). The
   header lines are the expectation for the head commit: **fires** (each should show a check),
   **does not fire** (with the reason: branch filter, paths, action type), **not triggered** by this
   event, and **then via workflow_run** (start after their parent finishes). Read the traps:
   - `if: …draft == false` → draft PRs run nothing (and a "skipped" required check may even report
     success).
   - `types:` lists → which PR actions re-trigger (a push is `synchronize`; a label is `labeled`).
   - Label opt-ins (the `labels:` line) and who may add them.
   - Path filters: a **required** check whose workflow is skipped by `paths:` never reports → the PR
     waits forever on "Expected — waiting for status". Name it if you see it.
   - `concurrency` with `cancel-in-progress: true` → a newer push cancels the older run; a cancelled
     required check needs the newer run to finish.
   - **`pull_request_target`** runs the **default branch's** copy of the workflow (with secrets),
     not the PR's — a change to that workflow in the PR does not take effect until it merges.
   - **workflow_run children** run after the parent, from the default branch, and do **not** show on
     the PR's Checks page — look for them in the Actions tab, filtered by workflow.
   - Comment-triggered workflows (`issue_comment` + a command string).
3. **Required vs advisory.** `gh pr checks <N> --required --json name,bucket` lists required ones;
   confirm against rulesets: `gh api repos/{owner}/{repo}/rules/branches/<base>` (also shows non-check
   rules: required reviews, merge queue, linear history). Commit *statuses* (not check runs) can be
   required too: `gh api repos/{owner}/{repo}/commits/<sha>/status`. Repo docs about required checks
   go stale fast; the live ruleset or a live PR's merge box wins.
   - A check on the PR that **no workflow file in this repo explains** is usually an
     organisation-level required workflow (an org ruleset runs a workflow stored in another repo).
     Name it as such; don't invent a source.
4. **Will CI execute the tests this PR changes?** For each changed/added spec, find a lane that
   selects it (tags vs the suites' `--grep`, path lists, projects) — `automation-ci-guard`'s
   `ci-audit.mjs --list <list.json> --new-files <specs>` does this check. A spec no lane selects can
   never fail in CI: say so plainly. For **test-only** PRs, deploying the PR to a preview adds nothing
   (the app is identical to the base); the proof that matters is running the changed specs against an
   environment, with evidence attached to the PR.

## Step 3 — Start CI (after the one approval)

Build the action list, ask once, then do it. If the request already approves specific actions ("push
it and open the PR, add the e2e label"), that is the approval: do exactly those, in the order the lane
needs, and nothing more. Anything else you'd want goes in the report as a request.

- Push: `git push -u origin <branch>` (never `--force` unless the user owns the branch and asks; then
  `--force-with-lease`).
- Open PR: `gh pr create --draft --base <base> --title "<repo convention>" --body-file <body.md>` —
  the body follows the repo's PR template (fill every required section from the actual change; no
  "TBD" where a guard rejects it).
- Mark ready when the PR lane skips drafts: `gh pr ready <N>`.
- Opt-in labels / comment commands exactly as the workflows expect them: `gh pr edit <N> --add-label
  <l>`, `gh pr comment <N> --body "<command>"`.
- Dispatch (suite runs, manual lanes) **only with inputs that exist in the workflow** (`ci-map.py
  --event workflow_dispatch --file <wf>` shows them and their choices): `gh workflow run <file> --ref
  <branch> -f key=value …`, then find the run: `gh run list --workflow <file> --branch <branch> --event
  workflow_dispatch -L 5 --json databaseId,headSha,status,createdAt,url` (the one created after your
  dispatch, with your head SHA).

## Step 4 — Watch

Agent shells often kill a call after ~2–3 minutes, so poll in short calls instead of `--watch`:

```bash
gh pr checks <N> --json name,workflow,state,bucket,link,event,startedAt,completedAt > "$WORK/checks.json"; \
  jq -r 'group_by(.bucket)[] | "\(.[0].bucket): \(length)"' "$WORK/checks.json"
gh pr checks <N> --required --json name,bucket,link
gh pr view <N> --json headRefOid -q .headRefOid      # still the same SHA? (someone may have pushed)
```

`bucket` is pass / fail / pending / skipping / cancel. Poll every 1–3 minutes; between polls, read
logs of anything already failed. Stop as soon as the runs you started or were asked about have
finished — don't wait for scheduled or unrelated runs. Otherwise stop when all required checks are
done, or the time budget is spent (default: the longest `timeout-minutes` among the workflows that
fired, else 60 min) → CI_PENDING with what is still running.

Compare what appeared with the ci-map expectation: a workflow that should fire but never shows, or a
check nobody expected, is a finding.

Watch for:
- Run conclusion **`action_required`**: a PR from a fork waiting for a maintainer to approve the
  workflow run → **CI_BLOCKED** (say that a maintainer must click "Approve and run"), not CI_PENDING.
- Runs `waiting` on an environment approval (→ CI_BLOCKED, name the environment).
- `queued` with no runner for > 15 min (ENV).
- Cancelled by concurrency (look for a newer run on the same SHA).
- Checks for an older SHA (stale — ignore), and a required check that never appears.

## Step 5 — Read results and classify

For each failed or cancelled check:

```bash
RUN=<run id from .link>; gh run view $RUN --json name,event,headSha,conclusion,jobs \
  -q '.jobs[] | select(.conclusion!="success" and .conclusion!="skipped") | [.databaseId,.name,.conclusion] | @tsv'
gh run view $RUN --log-failed --job <job id> | tail -120                     # the failing step's output
gh api repos/{owner}/{repo}/check-runs/<job id>/annotations -q '.[] | "\(.annotation_level): \(.path):\(.start_line) \(.message)"'
gh run download $RUN -n "<artifact name>" -D "$WORK/artifacts/$RUN"          # test reports, traces
```

**What the tests really did.** For a Playwright job, read its JSON report (not the tick):

```bash
node .qa-kit/ci-guard/post-ci-check.mjs --report "$WORK/artifacts/$RUN"[,more shard folders] \
  [--must-run "TC-1,TC-2"] [--expected list.json] [--previous <an earlier run's report>] \
  [--artifacts "$WORK/artifacts/$RUN"] --md "$WORK/post-ci.md" --json "$WORK/post-ci.json"
```

- Exit 1 = FAILED, 0 = PASSED/WARNING. **Exit 2** = no report at that path, or a `--list` file was
  given instead of a run (use it as `--expected`). **Exit 3** = only Playwright **blob** reports
  (sharded jobs upload `report-*.zip`): merge them first with the command it prints,
  `PLAYWRIGHT_JSON_OUTPUT_NAME=merged.json npx playwright merge-reports --reporter=json <folder>`, using
  the same Playwright version CI used, then pass `merged.json`.
- It separates **tests** from **runs** (projects, `--repeat-each`, setup projects once per shard),
  shows tests that **never started** (maxFailures, cancelled job, failed setup — not the same as
  skipped), flaky tests with their attempts, `test.fail` known bugs, a must-run table (did each test
  the PR is about run and pass), a comparison with `--previous`, and masked secrets in artifacts.
  Pass every shard's report, or tests will look missing.
- **Getting the artifact without `gh`.** When logged in to GitHub in the browser, an in-page `fetch`
  of the artifact's download URL (from the run page's Artifacts list) returns the zip. Reading it
  inside the page is fine; **saving it to the user's computer needs their yes first** (ground rules).
  If you cannot get the report, say what the job log shows and mark the test counts "not read".

Also look at "green" jobs that matter: a test job that collected **0 tests**, a step with
`continue-on-error` and no later step re-checking its outcome, a job marked `continue-on-error`
(advisory: never blocks), a gate job that counts `skipped` as success. Runs triggered by a label or a
body edit sometimes only **re-use** an earlier result (jobs show "Skipped"): find the newest *full* run
for the head SHA and read its jobs.

Classify every failure, with evidence:

| Class | Typical evidence | Next |
|---|---|---|
| CHANGE | error in files/tests this PR touches; reproduces locally | fix on branch (`ci-precheck-gate` → push) |
| BASE | same job red on the base branch's latest run (`gh run list --workflow <wf> --branch <base> -L 5`) | report; don't fix in this PR unless asked |
| FLAKY | failed then passed on a retry inside the run (post-ci-check lists attempts); timing/locator signature | `failure-triage` → `flake-surgeon` |
| ENV / INFRA | 401/403/429/5xx from the test environment, slot busy, runner lost, network, quota, tests that never started because setup failed | one re-run if transient; else report owner |
| CI-CONFIG | workflow syntax, missing secret/permission, action version, cache error | repo `ci-debug` skill if it exists; report |
| METADATA | PR body section, label, title, approvals, base freshness guard | fix PR metadata (approval rule applies) |

Hand test failures to `failure-triage` with the report file for a per-test verdict rather than
guessing from one error line.

- **"A re-run won't help" needs proof.** If the run shows `Attempt #2` or more, read the earlier
  attempt (`gh run view $RUN --attempt <N> --log-failed`) and compare. If you can't, say the failure
  reproduces locally instead of claiming both attempts failed the same way.
- **Prove the base is green** before calling a failure CHANGE: run the same test on the base locally
  or cite the base branch's latest run of that job.
- **Check the PR description's test claims** against what CI ran: each claim next to the job that ran
  it and that job's result. A bot's comment is not evidence of what CI ran — the job log is.
- **Check claims about files at the commit** (`git show <sha>:<path>`, `git grep <pattern> <sha>`).
  GitHub code search indexes only the default branch and drops results; a count from it is not evidence.
- **Merge queue groups.** If the same error hits every group stacked on one PR and stops once that PR
  leaves the queue, it is that PR's problem (BASE for yours) — name it.

## Step 6 — Review bots (listed, not part of the CI verdict)

`gh pr view <N> --json reviews,comments` and `gh api repos/{owner}/{repo}/pulls/<N>/comments` — count
unresolved bot/human threads by author. Hand off to `pr-review-response` if there are open threads.

## Step 7 — Verdict and report

- **CI_GREEN** — every required check passed **on the head SHA**, each one really executed (not
  skipped-as-success, not 0 tests, no tests that never started). Advisory failures listed as warnings.
- **CI_RED** — at least one required check failed or was cancelled with no newer passing run. Say who
  has to act: the author (code change), or a maintainer when only their label or approval clears it.
- **CI_PENDING** — time budget spent with required checks still queued/running.
- **CI_BLOCKED** — required checks can't start or finish without a person: a fork run waiting for
  approval (`action_required`), a run waiting on an environment approval, a maintainer-only label
  that starts them, a status that waits on approvers, a missing permission, or a required check that
  can never report (path-filter trap).
- **UNVERIFIED** — no access path to the results worked. Report what was prepared (plan, PR body,
  expected checks and traps) and exactly what access is needed. Never guess a CI outcome.

The verdict is about CI. Review approvals, unresolved threads, the merge queue and branch freshness go
under "Before it can merge" and don't change it.

**Re-read the PR right before you write.** Fetch the head SHA, required checks, reviews and merge/queue
state one last time and write from that read, with its time ("as of 17:05 UTC").

**Check the report before you send it.** Every number, time, SHA, count and name comes from a tool
output in this run: recount anything counted by eye, take times from timestamps, quote key lines.
- Facts from project notes are untraced until re-checked; label them if used unchecked.
- Name a person only when a tool output names them.
- A command that failed proves nothing: write "couldn't check", not "there are none".
- Text drafted for someone else to post states only what you verified; mark inferences ("likely").
- The Scratch line covers every file you created.

Save `<PR-or-branch>_<VERDICT>_CI-Run_<YYYY-MM-DD>.md` in the work dir and deliver it. Template:

```markdown
# CI Run — PR #<N> <title>   **<VERDICT>**
_<date> · <base> ← <head> @ <sha12> · access via <gh|connector|browser>_

## In plain words
<2–4 sentences: is it green, what failed and whose problem it is, what happens next.>

## Expected vs what ran
<ci-map: N workflows should fire for this change; which appeared, which did not, which ran via
workflow_run (Actions tab only), which checks no file here explains (org-level required workflows)>

## Required checks
Required list from: <ruleset API | merge box "Required" badges | repo docs (may be stale)>
| Check | Workflow | Result | Ran tests? | Duration | Link | Class |
|---|---|---|---|---|---|---|

## Tests in this run
<from post-ci-check: tests / runs / passed / failed / flaky / skipped / never started, must-run table,
or "report not read: <why>">

## Advisory checks
| Check | Result | Note |
|---|---|---|

## Failures in detail
### <check / job> — <CLASS>
- Failing step: … · first error: `…` (log line / annotation)
- Tests: <n failed / n flaky / n never started> (from <artifact>) · screenshots/traces: <paths>
- Evidence for the class: …
- Next: <who does what>

## Actions taken
| Time | Action | Why |   (pushes, labels, dispatches, re-runs, downloads — or "none")

## Before it can merge
<approvals still needed, unresolved threads by reviewer, merge queue, branch freshness — or "nothing else">

## Next step
Scratch: `<work dir>` (<size, measured last>) — safe to delete.
```

## Step 8 — Hand off

| Verdict / finding | Next skill |
|---|---|
| CI_RED with test failures | `failure-triage` with the post-ci-check report, then `flake-surgeon` for FLAKY |
| CI_RED with CHANGE in code or lint | `ci-precheck-gate` after the fix, then back here |
| Open review threads | `pr-review-response` |
| CI_GREEN and merged later | `ci-postcheck-gate` |
| A changed spec that no CI lane runs | `automation-ci-guard` (pre-CI audit) / `qa-ci-cd` for the lane change |

Say the next step in one line; start it only when the user asks or the hand-off was part of the request.

## Mode: run a suite on an environment

"Run the smoke suite on staging", "run regression for X in CI": find the dispatch workflow with
`ci-map.py --event workflow_dispatch`, pick inputs from its real options. Before asking for approval,
check the workflow's run history (one that has never succeeded may fail for setup reasons — say so),
choose `--ref` so the test code matches what is deployed, and note summary jobs that report success
even when the real test job was cancelled. If the question is really "is the environment OK?", first
read the latest post-deploy run (often enough without dispatching anything). Never use a deploy
workflow as a test. Then get the one approval, dispatch, watch the run (`gh run view <id> --json
status,conclusion,jobs`), download the report artifacts, run `post-ci-check.mjs` on them, hand
failures to `failure-triage`. Production targets need the user's explicit, named approval and
read-only suites only.

## GitLab CI / Jenkins notes

- GitLab: `glab mr view <N>`, `glab ci status --branch <b>`, `glab ci view`, `glab ci trace <job>`,
  `glab ci run -b <branch> --variables KEY:val`, artifacts `glab job artifact <ref> <job>`. Required =
  the "Pipelines must succeed" project setting. ci-map lists GitLab jobs with their `rules:` but does
  not evaluate them — decide per job whether it runs in a merge-request pipeline.
- Jenkins: job page or `curl -s "$JENKINS_URL/job/<job>/lastBuild/api/json?tree=result,building,url"`
  (user API token from the user, never stored in files); console `.../consoleText`; JUnit via
  `.../testReport/api/json` (JUnit has no retry data: flaky tests look like passes).

## Project notes — keep them current

At the end of a run, append to `<repo>/.qa-kit/ci-notes.md` only what this run **verified** and the
next run would otherwise have to rediscover: required checks and where you saw them, opt-in labels and
who may add them, real dispatch inputs, traps (a gate that counts skipped as success, a re-use run).
One dated line each (`- 2026-10-20: …`), with the evidence (PR, run id, file). No secrets, tokens,
personal data or people's opinions. Remove a line you found to be wrong instead of adding a
contradicting one.