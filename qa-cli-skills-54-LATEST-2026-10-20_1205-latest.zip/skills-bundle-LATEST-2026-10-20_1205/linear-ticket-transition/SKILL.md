---
name: "linear-ticket-transition"
description: "Transition a verified Linear issue to the team's release-ready state after QA passes (First Recon AI: 'Ready for Release'). Posts a QA verification comment and moves the issue with the Linear connector. Use whenever the user says 'Passed' followed by an issue ID, wants to mark an issue as QA verified, or confirm QA completion on a Linear issue. Triggers on: Passed, QA verified, ready for release, mark as passed, QA complete, transition ticket, move to release."
---

# Linear Ticket Transition (Passed)

This skill handles the post-QA workflow: verifying an issue passed, posting a QA comment, and transitioning the issue to the team's release-ready state.

> **Fixed 2026-10-16 (verified on FRAI-8354).** The state is named **`Ready for Release`**
> (lowercase "for") — `Ready To Release` does not exist and `save_issue` rejects it. There are no
> `Code Review` / `QA Review` / `In QA` states on either team, so there is no multi-hop sequence.
> Everything goes through the Linear connector (`save_comment`, `save_issue`, `list_issue_statuses`,
> `get_issue`); no API key or script is needed.

## Trigger

`Passed [ISSUE-ID or bug issue reference]`

## Shared References

Before proceeding, read:
- `shared-qa-base/references/environments.md` — environment URLs and routing rules

## Team workflow states (as of 2026-10-16)

| Team | Key | States | Release-ready state |
|---|---|---|---|
| First Recon AI | `FRAI` | Backlog, Reported, Blocked, Ready, Symphony, Building, In Review, Staging, **Ready for Release**, Done, Released, Canceled, Duplicate | `Ready for Release` |
| SpydySense AI | `SSAI` | Triage, Under consideration, Backlog, Blocked (legacy), Ready, Building, In review, Needs rework, Blocked, Staging (legacy), Staging, Released, Canceled, Duplicate | **none** — stop and ask which state QA-passed issues should move to |

Always confirm with `list_issue_statuses(team)` before transitioning; states can be renamed.

## Step 1 — Verify the Issue

- `get_issue(id)` — note the current state and team
- Confirm the referenced item is recorded as ✅ Pass in the most recent `.md` report for the environment used
- Inspect the issue title — if it contains `[Pro]` or `[Prod]`, the expected primary test environment was Production
- If the issue did NOT pass, stop and report — do not transition a failing issue

## Step 2 — Post a Verification Comment

`save_comment(issueId, body)` with a short, factual **plain Markdown** comment. The "Tested on" line follows the routing convention:

**Normal ticket (no `[Pro]`/`[Prod]`):**
```
✅ QA Verified — [YYYY-MM-DD]

Tested on: Dev (https://app.dev.firstrecon.ai)
Tested by: belle.ung@persefoni.com

All acceptance criteria verified and passed.
No issues observed. This ticket is ready for release.
```

**`[Pro]` / `[Prod]` ticket, fully verified on Production:**
```
✅ QA Verified — [YYYY-MM-DD]

Tested on: Production (https://app.firstrecon.ai)
Tested by: belle.ung@persefoni.com

All acceptance criteria verified and passed.
No issues observed. This ticket is ready for release.
```

**`[Pro]` / `[Prod]` ticket, verified on Dev because Production has a deployment gap:**
```
✅ QA Verified — [YYYY-MM-DD]

Tested on: Dev (https://app.dev.firstrecon.ai) — Production fallback used due to deployment gap
Tested by: belle.ung@persefoni.com

All acceptance criteria verified and passed on Dev. The fix has not yet rolled out to
Production (https://app.firstrecon.ai). Release/deployment team to push to Prod for the fix
to be live for users.
```

- Include only the environment that was actually used for testing
- Keep it short and factual — no lengthy test case details
- Date format: YYYY-MM-DD

## Step 3 — Transition the Issue

1. `list_issue_statuses(team)` — confirm the release-ready state exists and get its exact name.
2. `save_issue(id="{ISSUE_ID}", state="Ready for Release")` — one call; there are no intermediate states to pass through.
3. If the team has no release-ready state (SpydySense AI today): **report the blocker and stop** — do not guess a substitute state.
4. `get_issue(id)` — confirm the new state.

## Step 4 — Confirm and Report

Output a confirmation with:

- **Issue ID** and its **new state**
- **Direct Linear link** to the issue (`https://linear.app/persefoni/issue/{ISSUE_ID}`)
- **Comment posted**: confirmation that the QA verification comment was added
- **Environment used**: which environment was tested (and whether a Production → Dev fallback was used for `[Pro]`/`[Prod]` tickets)
- Flag any transition steps that could not be completed, with the reason

## Important Notes

- This skill does NOT run any tests — it only processes issues that have already been fully tested and passed
- No media capture is needed — the Passed flow is purely about status updates
- No `bun run` commands are executed — ignore any build/lint steps in the transition
- If the issue is already in `Ready for Release`, note it and skip the transition
- For `[Pro]`/`[Prod]` tickets verified only on Dev (Prod deployment pending), the QA verification still moves the issue forward — but the comment makes the deployment gap explicit so the release team knows action is needed