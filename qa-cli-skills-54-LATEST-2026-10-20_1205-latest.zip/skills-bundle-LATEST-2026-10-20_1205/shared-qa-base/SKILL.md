---
name: shared-qa-base
description: "Shared reference base for all QA skills. Contains environment configuration (Dev = primary test environment with no UI fallback; localhost available for code verification only; Staging URL listed for reference; Production used only when ticket title contains [Pro]/[Prod]), three-layer testing approach (code verification → UI testing → integration), status definitions, and media capture rules used across the QA testing workflow. This is NOT a standalone skill — it provides references that other QA skills read from. Do not trigger this skill directly."
---

# Shared QA Base

This is a reference package used by all QA testing skills. It contains shared configuration and rules that other skills reference to avoid duplication.

> The QA suite's ticketing system is Linear (migrated from Jira). Nothing in this file is
> ticketing-system-specific — environment routing, test accounts, and the three-layer testing
> approach are unchanged by the migration. For anything ticket/issue-API related (creating
> issues, comments, attachments, workflow states), see `LINEAR_CHEATSHEET.md` delivered
> alongside this skill set.

## Environment Configuration (single source of truth)

These URLs and rules apply to every QA skill. Other skills must follow this section verbatim — do not override.

| Environment | URL | Role | Notes |
|-------------|-----|------|-------|
| **Dev** | `https://app.dev.firstrecon.ai` | **Primary test environment** | Sole UI testing surface for normal tickets. No fallback — if Dev fails, mark ❌ and report. |
| **Localhost** | `http://localhost:3000` | Code verification only | Available for Layer 2 (codebase) verification. **Not** a UI-test fallback. |
| **Staging** | `https://app.staging.firstrecon.ai` | Reference only | Listed for awareness. Skills do not test on Staging unless the user explicitly requests it. |
| **Production** | `https://app.firstrecon.ai` | Test only when ticket title contains `[Pro]` or `[Prod]` | If Prod fails due to a deployment gap, fall back to Dev. |

### Routing Rules

1. **Default ticket** (no `[Pro]`/`[Prod]` tag in title) → test on **Dev only**. Do not fall back to localhost or Staging for UI testing.
2. **Ticket title contains `[Pro]` or `[Prod]`** → test on **Production**. If Production has a deployment gap (fix not yet live), fall back to **Dev** and clearly note the fallback in the QA report and Linear comment.
3. **Layer 2 (codebase verification)** can use localhost as a working environment regardless of routing — it is not a UI test.

### Test Account

`belle.ung@persefoni.com` (Google SSO)

## Key Principles

- **Dev is the only routine UI test target.** No automatic fallback to Staging or localhost on UI failures — a failure on Dev is a real failure, not a reason to try another env.
- **Three-layer testing**: Every ticket is verified across Layer 1 (UI testing), Layer 2 (code verification), and Layer 3 (integration) — recommended execution order is Layer 2 → Layer 1 → Layer 3 so codebase understanding shapes the UI test plan.
- **Full coverage**: Every test case must be executed across all applicable layers. No skipping.
- **[Pro]/[Prod] tickets only touch production.** Without the tag in the title, never run tests on `app.firstrecon.ai`.

## Contents

| Reference File | What It Contains | When to Read |
|---------------|-----------------|--------------|
| `references/environments.md` | Full environment URLs, routing rules, test account, three-layer testing approach, coverage rules, escalation flow, pre-flight format | Before any environment interaction or test execution |
| `references/status-definitions.md` | All status icons, per-layer statuses, per-environment statuses, overall status rules | When recording or reporting test results |
| `references/media-rules.md` | Screenshot/recording capture rules, naming, save locations, Playwright code | When capturing evidence for failures |

## How Other Skills Use This

Each QA skill's SKILL.md includes a pointer like:

```
Before proceeding, read the shared references:
→ shared-qa-base/references/environments.md
→ shared-qa-base/references/status-definitions.md
```

Skills should read only the references they need for their specific responsibility.
