---
name: test-case-generator
description: "Generate comprehensive test cases from Linear issue acceptance criteria, codebase analysis, AND merged GitHub PR context. Produces happy path, negative, and edge case scenarios with detailed steps and expected results, grounded in the actual diff so test cases target what the developer changed (not just what the ticket described). Use this skill whenever you need to create test cases, derive test scenarios from acceptance criteria, build a test plan, or generate test coverage for a ticket. Triggers on: generate test cases, create test plan, derive tests from AC, test scenarios, what should I test, test coverage."
---

# Test Case Generator

This skill takes the ticket's acceptance criteria, expected results, description, codebase context, **and the merged GitHub PR diff** — and produces a comprehensive set of test cases covering happy paths, negative cases, and edge cases.

The PR diff is what makes the test cases sharp: instead of writing generic tests against the AC, you write tests that target the exact lines, functions, and components the developer changed.

## Input

This skill expects context from the `ticket-inspector` skill:
- Ticket ID, type, scope, acceptance criteria, expected results, description
- Relevant code files and their roles
- Implementation observations
- **GitHub PR information** — PR URL, status, files changed, diff summary, key code changes (gathered in Step 3 of `ticket-inspector`)

If the PR context is missing (because `ticket-inspector` hasn't been run, or the ticket has no linked PR), do not silently proceed. First try to read the PR yourself — see "Reading the PR" below — and if that also fails, generate test cases from the ticket alone and flag the report with `⚠️ Test cases generated without PR context — coverage may be less precise`.

## Reading the PR (when not already provided)

Before generating test cases, ensure you have the PR diff. Two paths, in order of preference:

1. **Chrome browser (preferred):** Open the Linear issue → find the linked Pull Request in its attachments → click through to the GitHub PR page → read the description and the "Files changed" tab.
2. **web_fetch fallback:** If Chrome is unavailable or the page fails to load, fetch the PR URL directly:
   - `https://github.com/<org>/<repo>/pull/<number>` — overview
   - `https://github.com/<org>/<repo>/pull/<number>/files` — diff
   - `https://github.com/<org>/<repo>/pull/<number>/commits` — commit history

Capture: PR status (must be Merged for a meaningful test plan), files changed, key diff observations (logic changes — not formatting noise), and any reviewer notes that hint at edge cases.

If neither path works, proceed with codebase + ticket only and flag the limitation in the output.

## Shared References

For status definitions used in test case results:
- `shared-qa-base/references/status-definitions.md`

## Test Case Derivation Rules

### Primary Sources

Analyze the following to generate test cases with full ticket coverage:

1. **Acceptance Criteria** — each AC should map to at least one test case
2. **Expected Results** — specific outcomes that must be verified
3. **Description** — additional context, constraints, and behaviors described in the ticket
4. **GitHub PR diff** — the exact code changes the developer made; every meaningfully-changed file/function should be exercised by at least one test case
5. **Codebase analysis** from `ticket-inspector` — supporting context (logic paths, validations, edge conditions)

The ticket tells you *what* should be true; the PR tells you *how* the developer made it true. Good test cases verify both.

### How to Use the PR Diff for Test Generation

For each notable change in the PR, ask:

- **What input flows through this changed code?** → Happy path test
- **What inputs would break the new logic?** → Negative test
- **What boundary values touch the new branch / new validation?** → Edge case test
- **What existing call sites use the changed function?** → Note as integration touchpoints (still in-scope for this ticket; full regression goes to `automation-runner`)
- **Are there new error messages, status codes, or UI states introduced?** → Each should be verified

Example: PR adds `if file.size > MAX_SIZE: raise FileTooLarge(...)` →
- Happy path: file just under MAX_SIZE uploads successfully
- Negative: file just over MAX_SIZE raises `FileTooLarge` with the exact error message
- Edge case: file exactly at MAX_SIZE (boundary)

### Coverage Categories — Type Column

Every test case is categorized by type:

- **Happy Path** — valid inputs, expected flows, correct states. These verify the AC works as specified and the PR's main code path executes correctly.
- **Negative** — invalid inputs, missing fields, unauthorized access, error states. These verify the system handles bad input gracefully and the PR's error-handling branches work.
- **Edge Case** — boundary values, empty states, concurrent actions, unusual but valid scenarios. These catch the subtle bugs and test the PR's boundary conditions.

### What NOT to Include

- No regression scenarios — regression testing is reserved exclusively for the `automation-runner` skill
- No tests outside the ticket scope — only test what this ticket addresses, even if the PR touches adjacent code
- No duplicate coverage — if an AC is already fully covered by a happy path test, don't add a trivially different variant
- No tests for code that was NOT changed by the PR and is NOT mentioned in the AC

## Test Case Structure

Each test case must contain:

| Field | Description |
|-------|------------|
| **#** | Sequential number |
| **Priority** | `High` / `Medium` / `Low` — see Priority Rules below |
| **Type** | `Happy Path` / `Negative` / `Edge Case` |
| **Test Description** | What is being tested and why (cite the AC and/or the PR change it targets) |
| **Test Steps** | Numbered, detailed, fully reproducible steps — see Writing Good Test Steps |
| **Expected Result** | From AC, Expected Results, or Description |
| **Actual Result** | Filled after execution (by manual-test-executor) |
| **Status** | Filled after execution |
| **Screenshot** | Only for failures — `—` otherwise |
| **Recording** | Only for failures — `—` otherwise |

## Priority Rules

Assign a priority to every test case based on the risk and impact of the functionality being tested:

- **High** — Core functionality directly tied to an AC or business-critical flow, OR the primary code path introduced by the PR. A failure here would block release or cause significant user impact. Covers the main happy path(s) and any negative cases that could result in data loss, security issues, or a broken primary workflow.
- **Medium** — Supporting functionality or secondary flows. A failure would be noticeable and should be fixed, but wouldn't block the main feature from working. Covers most negative cases and edge cases that affect real users under normal conditions.
- **Low** — Edge cases unlikely to occur in practice, cosmetic validations, or scenarios that have low user impact. A failure here is a nice-to-fix but not a blocker.

**Guideline**: Most tickets should have at least one `High` test case (the primary happy path tied to the PR's main change). Not every test case needs to be High — reserve High for things that matter most.

## Writing Good Test Steps

Test steps should be specific enough that someone unfamiliar with the feature can follow them exactly:

- Include exact URLs or navigation paths (use Dev URL as default)
- Specify exact input values, not placeholders
- State what to observe at each step, not just what to do
- Number every step — no sub-bullets or nested lists
- End with a clear verification point
- When the step targets behavior introduced by the PR, the input values should hit the new code path (e.g. test the exact boundary the PR validates against)

Example of good steps:
```
1. Navigate to https://app.dev.firstrecon.ai/admin/security
2. Click the "DLP Policies" tab
3. Click "Create New Policy"
4. Leave the "Policy Name" field empty
5. Click "Save"
6. Observe the validation error message below the Policy Name field
```

Example of bad steps:
```
1. Go to admin
2. Try to create a policy without a name
3. Check if error shows
```

## Output Format

Begin the output with a short PR context block, then the test case table:

```
### PR Context
- **PR**: [GitHub URL] — [Merged ✓ / Open ⚠️ / Not linked ⚠️]
- **Files Changed**: [count] — [highlight: which files matter most for testing]
- **Key changes targeted by these test cases**:
  - [Change 1 — e.g. "Added MAX_FILE_SIZE validation in upload_handler.py"]
  - [Change 2 — e.g. "New formatLocalTime helper used by ChatMessage.tsx"]

### Test Cases

| # | Priority | Type | Test Description | Test Steps | Expected Result | Actual Result | Status | Screenshot | Recording |
|---|----------|------|-----------------|------------|-----------------|---------------|--------|------------|-----------|
| 1 | High   | Happy Path | [description — cite AC# and/or PR change] | 1. Step one<br>2. Step two<br>3. Verify result | [expected] | — | — | — | — |
| 2 | Medium | Negative   | [description — cite AC# and/or PR change] | 1. Step one<br>2. Step two<br>3. Verify result | [expected] | — | — | — | — |
| 3 | Low    | Edge Case  | [description — cite AC# and/or PR change] | 1. Step one<br>2. Step two<br>3. Verify result | [expected] | — | — | — | — |
```

If PR context is unavailable, replace the PR Context block with:
```
### PR Context
⚠️ Test cases generated without PR context — coverage may be less precise.
Reason: [no PR linked in Development tab / Chrome and web_fetch both failed / etc.]
```

The Actual Result, Status, Screenshot, and Recording columns are left as `—` placeholders — they get filled by the `manual-test-executor` skill during execution.
