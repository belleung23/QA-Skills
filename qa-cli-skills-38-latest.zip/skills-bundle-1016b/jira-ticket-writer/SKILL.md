---
name: "jira-ticket-writer"
description: "Create bug tickets directly in Jira via API with full automation — sets title, priority, assignee, labels, and attachments. Requires a completed root-cause-forensics RCA before any ticket is created; the RCA block goes into the description and sets priority. Labels are determined by scope (Frontend/Backend/Both), priority (Critical/High/Medium/Low), and workspace (ai-chat/prompt-security/platform-admin/developer-tools/operations/qa-feedback/wip-workspace/product-intent/test-policies). Records the environment where the bug was observed per the routing policy — Dev (https://app.dev.firstrecon.ai) for normal tickets (no UI fallback), or Production (https://app.firstrecon.ai) with Dev fallback for [Pro]/[Prod] tickets. Use whenever the user says 'Jira' followed by AC numbers or test case references, or wants to auto-create a bug ticket without manual copy-paste. Triggers on: Jira, create Jira ticket, file bug in Jira, submit bug to Jira, auto-create ticket, push to Jira."
---

# Jira Ticket Writer

Creates bug tickets in Jira via REST API with evidence attached automatically.

**Script used:** `create_jira_bug.py` — reads credentials from `.dev.vars`, uses `TESTING_JIRA_API_TOKEN`. Never uses Jira MCP for creation or attachment.

The description is the most important part of a bug ticket. A developer reading it must be able to understand the bug, reproduce it, and know exactly what "fixed" looks like — without needing to ask QA a single question. Every field below exists for a reason; don't skip or abbreviate them.

---

## Step 0a — RCA prerequisite (MANDATORY GATE)

> **No ticket is created without a completed `root-cause-forensics` RCA.** A bug report that describes only a symptom is not ready to file.

Before doing anything else, confirm you hold an RCA for every failure going into this ticket:

| Required from `root-cause-forensics` | Used for |
|---|---|
| Class — 🎨 Frontend / ⚙️ Backend / 🔗 Integration / 🗄️ Data / 🔧 Config | `h2. Root Cause Analysis` + the `scope` label in Step 4 |
| Location — `path/to/file.ts:142 — functionName()` | `h2. Root Cause Analysis` |
| Mechanism — one or two sentences | `h2. Root Cause Analysis` |
| Confidence — High / Medium / Low | `h2. Root Cause Analysis` (state it; never inflate it) |
| Type — Regression / Latent defect / Incomplete fix | Priority, and whether to file at all |
| Console log (verbatim, secrets redacted) | `h3. Console Errors` `{code}` block |
| Network log (verbatim, secrets redacted) | `h3. Network Failures` `{code}` block |
| RCA `.md` + `-console.log` + `-network.json` paths | `--attachment` flags in Step 7 |

**If no RCA exists → stop and run `root-cause-forensics` first.** Do not file from the symptom alone.

**RCA verdicts that mean DO NOT FILE:**

| Verdict | Instead |
|---|---|
| 🔌 **Environment** | Not a bug. Report the env fault to the user; re-test once healthy. |
| 📋 **Spec gap** | Post a Clarification comment via `jira-comment-writer` and escalate the AC ambiguity. |
| ❓ **Not reproducible** | Attach evidence to the parent ticket via `jira-comment-writer`; assert no cause. |
| **Incomplete fix** on the ticket under test | Reopen that ticket with the full RCA — do not create a new bug. |

**Priority comes from the RCA class, not the visible symptom.** A 500 on a core write path is High/Critical even when the only thing the user sees is a missing toast. Conversely, a cosmetic 🎨 Frontend defect with no data impact stays Low regardless of how obvious it looks.

---

## Step 0b — Resolve repo root

```bash
REPO_ROOT=$(git -C /home rev-parse --show-toplevel 2>/dev/null \
  || git -C /root rev-parse --show-toplevel 2>/dev/null \
  || find /home /root -maxdepth 4 -name ".git" -type d 2>/dev/null | head -1 | xargs dirname)
[ -z "$REPO_ROOT" ] && echo "[ERROR] Cannot find repo root" && exit 1
echo "REPO_ROOT=$REPO_ROOT"
```

---

## Step 1 — Gather all TC data from the Google Sheet

When the command references TC IDs (e.g. TC-PA-443, TC-WC-458), fetch the full row for each TC from the QA test suite Google Sheet **before** writing the description. Do not paraphrase — copy the exact text from the sheet columns:

| Sheet column | Maps to description field |
|---|---|
| Test Case ID | TC identifier in heading |
| Nav | Navigation path |
| Priority | P1 / P2 / P3 label |
| Description | Short heading / summary |
| Test Steps | Numbered steps to reproduce |
| Expected Result | Expected section |
| Actual Result (or observed) | Actual section |
| Acceptance Criteria | AC list |

**Fetch method** — use the gviz/tq API from within the authenticated Google Sheets browser tab (tabId from Claude in Chrome):

```javascript
const sid = '1tOOMsej7yuwiahUEk0foR-6Mk4fWnzrjbhycTwnUAAM';
const ids = ['TC-PA-443', 'TC-WC-458']; // replace with actual IDs
const sheetName = 'Platform-Admin'; // match the correct sheet tab
const conditions = ids.map(id => `A = '${id}'`).join(' or ');
const tq = encodeURIComponent(`select * where ${conditions}`);
const url = `https://docs.google.com/spreadsheets/d/${sid}/gviz/tq?tqx=out:csv&sheet=${encodeURIComponent(sheetName)}&tq=${tq}`;
const resp = await fetch(url, { credentials: 'include' });
const csv = await resp.text();
return csv;
```

Run this for each sheet tab that contains TCs referenced in the command. Parse the CSV to extract the fields above for every TC.

If the TC data is already available in sessionStorage (stored as `tc_TC-PA-443`), read from there first to avoid redundant fetches.

---

## Step 2 — Identify failing items

For each TC, extract:
- TC ID, Nav, Priority, description/title
- Numbered test steps (verbatim from sheet)
- Expected result (verbatim)
- Actual result (verbatim — what was observed on screen, not a summary)
- Acceptance criteria (verbatim, each as a separate AC bullet)
- Existing media paths (screenshots / recordings already captured)
- **RCA verdict** (class, location, mechanism, confidence, type) and RCA artifact paths
- Parent Jira ticket ID (if applicable)

**Group by root cause, not by symptom.** If several TCs share one RCA location and mechanism, they belong in **one** ticket listing every affected TC — not one ticket each. Distinct root causes always get separate tickets even when the symptom looks identical.

---

## Step 3 — Capture fresh evidence (UI bugs only, if not already captured)

```bash
mkdir -p "$REPO_ROOT/test-reports/screenshots"

# Highlight failing element
playwright-cli eval "
  const el = document.querySelector('{selector}');
  if (el) {
    el.style.outline = '3px solid red';
    el.style.outlineOffset = '2px';
    const label = document.createElement('div');
    label.textContent = '❌ FAILED';
    label.style.cssText = 'position:absolute;background:red;color:white;font-size:12px;font-weight:bold;padding:2px 6px;border-radius:3px;z-index:99999;';
    el.parentNode.insertBefore(label, el.nextSibling);
  }
"
# Screenshot — absolute path, save to test-reports/screenshots/
playwright-cli screenshot --filename="$REPO_ROOT/test-reports/screenshots/$TICKET_KEY-TC{id}.png"

# Video recording
playwright-cli video-start
# reproduce steps...
playwright-cli video-stop "$REPO_ROOT/test-reports/screenshots/$TICKET_KEY-TC{id}.webm"
```

Skip for pure backend failures.

Console and network logs are **not** re-captured here — `root-cause-forensics` already saved them to `$REPO_ROOT/manual-testing/evidences/{TICKET_KEY}/rca/`. Re-capturing now would collect a clean page, not the failure.

---

## Step 4 — Label strategy

Final label array: `[scope, priority-label, workspace-label, "qa-found", "FRAI-Guardrails"]`

**Scope** (one): `frontend` / `backend` / `both` — take it from the RCA class:

| RCA class | Scope label |
|---|---|
| 🎨 Frontend | `frontend` |
| ⚙️ Backend | `backend` |
| 🔗 Integration / Contract | `both` |
| 🗄️ Data | `backend` |
| 🔧 Config / Flag | `backend` (or `both` if a UI guard is also missing) |

**Priority** (one): `priority-critical` / `priority-high` / `priority-medium` / `priority-low` — set from RCA severity and blast radius, not the surface symptom.

**Workspace** (one):

| Label | Routes |
|-------|--------|
| `ai-chat` | `/chat/*`, `chat-worker` |
| `prompt-security` | `/prompt-security/*`, `guardrails-worker` |
| `platform-admin` | `/admin/*`, `admin-worker` |
| `developer-tools` | `/developer/*`, `gateway-worker` |
| `operations` | `/dev-admin/*`, `/operations/*` |
| `qa-feedback` | DLP, `guardrails-worker`, `services/guardrails/*` |
| `wip-workspace` | `workers/*/`, `migrations/`, `.github/workflows/` |
| `product-intent` | `corpus-worker`, knowledge base |
| `test-policies` | Cross-cutting / unclear |

Prefer the workspace that owns the **RCA location file**, not the page where the symptom appeared — they differ when a shared worker is at fault.

---

## Step 5 — Duplicate check

Search before creating:
```
project = GR AND issuetype = Bug AND summary ~ "[feature] [what broke]"
```
Run 2–3 keyword variants. If open duplicate found → do NOT create; report existing ticket. If closed → create and link "Relates".

Also search on the **RCA location** — `summary ~ "validator"` or the function name — since the same root cause often surfaced earlier under a different symptom and was filed with different wording.

---

## Step 6 — Write payload JSON

Save to: `$REPO_ROOT/bug-drafts/{PARENT_KEY}_bug_payload.json`

### Summary line

```
[Area] Short plain-English statement of what is broken (≤ 80 chars)
```

Good: `[Platform Admin] Security Dashboard time-range selector does not apply to chart`
Bad: `Bug in admin`

### Description — full template

The description must be written in **Jira wiki markup**. Every TC referenced in the ticket gets its own named section. The goal is that a developer can read this ticket, open the app, follow the steps, and reproduce the bug in under 5 minutes.

```
h2. Summary
[2–3 sentences that tell the whole story: what feature is affected, what broke, and why it matters to the user. No jargon abbreviations — write it so a new developer on their first day can understand.]

h2. Environment
* Affected: Dev — https://app.dev.firstrecon.ai
* URL: https://app.dev.firstrecon.ai/[exact path where bug occurs]
* Browser: Chrome
* Tested by: belle.ung@persefoni.com
* Area: [workspace / feature area from Nav path]

----

h2. Failing Test Cases ({N})

h3. {TC-ID} — {verbatim description from sheet}
*Priority:* {P1 / P2 / P3}
*Nav:* {exact nav path from sheet, e.g. Platform Admin > Dashboards & Feeds > Security}

*Steps to Reproduce:*
# {Step 1 — verbatim from sheet, written as a complete action: "Navigate to /admin > Security"}
# {Step 2}
# {Step 3}
# {Step 4 — include "Observe [what]" as the last step so the reader knows where to look}

*Expected:* {Exact expected behaviour — what should happen, from the sheet. Complete sentence.}
*Actual:* {Exactly what happened — what appeared on screen or what failed. Complete sentence. Quote error messages verbatim if any.}

*Acceptance Criteria:*
* AC1: {First criterion — complete sentence starting with a noun or verb, e.g. "Selecting a range updates the selector label."}
* AC2: {Second criterion if present}
* AC3: {Third criterion if present}

[Repeat h3 block for each additional TC]

----

h2. Root Cause Analysis

*Class:* {Frontend | Backend | Integration | Data | Config}
*Location:* {code:path/to/file.ts:142} — {code:functionName()}
*Mechanism:* {One or two sentences naming the exact faulty behaviour and why the bad input reaches it.}
*Confidence:* {High | Medium | Low}
*Type:* {Regression — PR #4821 (abc1234, @author, 2026-07-24) | Latent defect | Incomplete fix}

h3. Console Errors
{code}
[error] {verbatim console message, including source:line}
[warning] {verbatim warning}
{code}

h3. Network Failures
{code}
{METHOD} {full URL}
  → {status} {statusText} ({duration}ms)
  Request:  {payload verbatim, secrets redacted}
  Response: {body verbatim, secrets redacted}
{code}

h3. Blast Radius
{Other flows that hit the same code path and are therefore also broken. State which are verified vs suspected.}

h3. Suggested Direction
{Mechanism-level suggestion — what a fix should address, not a patch. Leave the implementation to the developer.}

----

h2. Evidence
[Include this section only if screenshots or recordings were captured]
*Screenshot:* !{TICKET_KEY}-TC{id}.png|thumbnail!
*Recording:* {TICKET_KEY}-TC{id}.webm (attached)
*RCA report:* {TICKET_KEY}_RCA_{TC-ID}_{date}.md (attached)

h2. Impact
[One sentence: who is affected (which user roles), what workflow is blocked, and whether a workaround exists. E.g. "Platform Admins cannot use the time-range selector to investigate security incidents over custom windows; no workaround."]

h2. Source
QA Test Suite — {Sheet tab name}: {TC-ID list, comma-separated} (verified on Dev {date})
```

### Rules
- Use Jira wiki markup throughout: `h2.` `h3.` headings, `*bold*`, `# ordered list`, `* unordered`, `!filename.png|thumbnail!`
- `!filename.png|thumbnail!` uses **base filename only** — file must be uploaded via `--attachment`
- Description is a single JSON string — escape newlines as `\n`
- Never truncate steps — include every step from the sheet, numbered in order
- Never write "N/A" or leave a field blank — if data is missing, fetch it from the sheet before proceeding
- If multiple TCs are grouped in one ticket, each gets its own `h3.` block with all fields filled in
- AC bullets must be complete sentences — not fragments like "Should validate" but "The form must block submission and show an inline error when the required field is empty."

### Root Cause Analysis section rules
- **`h2. Root Cause Analysis` is mandatory.** A ticket without it is not ready to file.
- Console and network text goes inside `{code}` blocks, **verbatim** — never reflowed, summarized, or paraphrased. Developers grep for exact strings.
- **Redact every secret** before it reaches Jira: bearer tokens, cookies, API keys, passwords → `<REDACTED>`. Keep the header name so its presence is still provable.
- If there was genuinely no console output, write `(no console output — see RCA report)`. If the action fired no request, write `(no network request fired — this is the finding)`. Absence is evidence; never leave the block empty.
- State the real confidence. `Low` with attached evidence is more useful than a fabricated `High`.
- Only write "Regression — PR #X" when the diff line is in hand. Otherwise: `Latent defect — not in linked PR; last modified {sha}`.
- Suggested Direction addresses the **mechanism**, not the symptom. "Populate scope.tenantId on the template path" — not "add a null check", which would hide the missing tenant.

### Example payload

```json
{
  "summary": "[Platform Admin] Security Dashboard time-range selector does not apply to chart or widgets",
  "description": "h2. Summary\nThe Security Dashboard time-range dropdown accepts a new selection but does not update the chart or widget data. Admins investigating security incidents over a custom window receive stale, misleading data.\n\nh2. Environment\n* Affected: Dev — https://app.dev.firstrecon.ai\n* URL: https://app.dev.firstrecon.ai/admin\n* Browser: Chrome\n* Tested by: belle.ung@persefoni.com\n* Area: Platform Admin > Dashboards & Feeds > Security\n\n----\n\nh2. Failing Test Cases (1)\n\nh3. TC-PA-413 — Security Dashboard time-range selector does not apply the chosen range to widgets/chart\n*Priority:* P2\n*Nav:* Platform Admin > Dashboards & Feeds > Security\n\n*Steps to Reproduce:*\n# Navigate to /admin (Security Dashboard).\n# Click the time-range dropdown (default \"7d\").\n# Select \"30d\".\n# Observe the selector label and \"Security Events Over Time\" chart x-axis.\n\n*Expected:* After selecting 30d the selector shows the new value and the chart window expands to match the chosen range.\n*Actual:* Selecting a range does not update the chart; data stays on the default 7-day window regardless of selection.\n\n*Acceptance Criteria:*\n* AC1: Selecting a time range updates the dropdown label to reflect the new value.\n* AC2: The chart x-axis and all widget data refresh to reflect the chosen time window.\n\n----\n\nh2. Root Cause Analysis\n\n*Class:* Frontend\n*Location:* {code:src/admin/security/SecurityDashboard.tsx:88} — {code:handleRangeChange()}\n*Mechanism:* handleRangeChange writes the new range to local component state but the widget query key omits it, so react-query serves the cached 7d result and never refetches.\n*Confidence:* High\n*Type:* Regression — PR #4821 (abc1234, @dev.name, 2026-07-24) removed range from the query key during a caching refactor.\n\nh3. Console Errors\n{code}\n(no console output — the failure is silent; see RCA report)\n{code}\n\nh3. Network Failures\n{code}\nGET https://app.dev.firstrecon.ai/api/v1/security/events?window=7d\n  → 200 OK (from cache, 4ms)\n  Note: no request fired for window=30d — the finding is the absent refetch\n{code}\n\nh3. Blast Radius\nEvery widget on the Security Dashboard shares this query key (verified: Events chart, Alerts card, Top Sources). The Compliance dashboard uses a different hook and is unaffected (verified).\n\nh3. Suggested Direction\nInclude the selected range in the react-query key so a range change invalidates the cache, rather than forcing a manual refetch in the handler.\n\n----\n\nh2. Evidence\n*Screenshot:* !GR-10452-TC413.png|thumbnail!\n*RCA report:* GR-10452_RCA_TC-PA-413_2026-07-29.md (attached)\n\nh2. Impact\nPlatform Admins cannot filter security data by time window and will read stale 7-day data believing it covers 30 or 90 days; no workaround.\n\nh2. Source\nQA Test Suite — Platform-Admin: TC-PA-413 (verified on Dev 2026-07-29)",
  "priority": "High",
  "labels": ["frontend", "priority-high", "platform-admin", "qa-found", "FRAI-Guardrails"]
}
```

---

## Step 7 — Create ticket and attach evidence

```bash
python3 "$REPO_ROOT/.claude/skills/gr-bug-writer/scripts/create_jira_bug.py" \
  --payload "$REPO_ROOT/bug-drafts/{PARENT_KEY}_bug_payload.json" \
  --attachment "$REPO_ROOT/test-reports/screenshots/{TICKET_KEY}-TC1.png" \
  --attachment "$REPO_ROOT/test-reports/screenshots/{TICKET_KEY}-TC1.webm" \
  --attachment "$REPO_ROOT/test-reports/{TICKET_KEY}_RCA_{TC-ID}_{date}.md" \
  --attachment "$REPO_ROOT/manual-testing/evidences/{TICKET_KEY}/rca/{TC-ID}-console.log" \
  --attachment "$REPO_ROOT/manual-testing/evidences/{TICKET_KEY}/rca/{TC-ID}-network.json"
```

Add one `--attachment` flag per evidence file. **Always attach the RCA `.md` plus its raw console and network logs** — the `{code}` blocks in the description are the summary; the raw logs are the full record. **Do NOT use `--parent` flag** — linking is handled separately in Step 7b below.

What the script does:
1. Runs duplicate check (pass `--skip-duplicate-check` to bypass)
2. Looks up Kim Stroh's account ID automatically
3. Creates the Bug issue via `/rest/api/2/issue` (wiki markup description — `!filename|thumbnail!` renders once files are attached)
4. Uploads each `--attachment` file to the new ticket
5. Prints the new ticket key and URL

If script exits non-zero → read the error, fix payload or path, re-run.

If the script fails with a proxy 403 in a sandboxed session, create the issue via Jira MCP and attach files via Playwright `setInputFiles` using absolute user-machine paths.

---

## Step 7b — Link to parent ticket via Jira MCP (MANDATORY)

> ⚠️ **Critical linking rule — always run this step after ticket creation.**
>
> NEVER use `parent` field or `--parent` flag — those create "Child work items" hierarchy (wrong).
> ALWAYS use `mcp__5e7d7dc5-7757-461d-8a63-33b4d9f8e532__createIssueLink` — creates "Link work items" (correct).

| Situation | type | inwardIssue | outwardIssue |
|-----------|------|-------------|--------------|
| Bug caused by Epic / Story / Task | `Caused` | `{PARENT_KEY}` | `{NEW_BUG_KEY}` |
| Bug relates to another Bug | `Relates` | `{OTHER_BUG}` | `{NEW_BUG_KEY}` |
| Bug duplicates existing | `Duplicate` | `{EXISTING}` | `{NEW_BUG_KEY}` |

```
mcp__5e7d7dc5-7757-461d-8a63-33b4d9f8e532__createIssueLink(
  cloudId="dce2ce03-4355-4e26-8af2-06995df138ef",
  type="Caused",
  inwardIssue="{PARENT_KEY}",
  outwardIssue="{NEW_BUG_KEY}"
)
```

When the RCA identified a **Regression** introduced by a PR belonging to a *different* ticket, also link `Caused` from that ticket — the bug was caused by that change, not by the ticket under test.

---

## Step 8 — Post cross-reference comment on parent ticket

```bash
python3 "$REPO_ROOT/.claude/skills/jira-comment-writer/scripts/post_jira_comment.py" {PARENT_KEY} \
  --comment-file <(echo "Bug ticket filed for QA failures: [{NEW_KEY}|https://persefoni.atlassian.net/browse/{NEW_KEY}]
Failing cases: {TC numbers}
Root cause: {class} — {file:line} — {one-line mechanism} ({confidence} confidence)
Type: {Regression (PR #n) | Latent defect}")
```

---

## Step 9 — Report

```
Bug ticket created: {NEW_KEY}
URL: https://persefoni.atlassian.net/browse/{NEW_KEY}
Title: {summary}
Priority: {priority}  (set from RCA class + blast radius)
Assignee: Kim Stroh
Labels: {label list}
Linked to: {PARENT_KEY} via "is caused by" (Link work items — Caused type)
Root cause: {class} — {file:line} — {confidence} confidence
Type: {Regression (PR #n) | Latent defect | Incomplete fix}
Attachments uploaded: {n} files
  - {filename1}
  - {RCA .md}
  - {console.log}
  - {network.json}
Covers: {TC-ID list}
```

---

## Env file

Script reads `TESTING_JIRA_API_TOKEN` from `.dev.vars` in CWD (= `$REPO_ROOT` when called with absolute path). Uses `tranngoc.lan@persefoni.com` as API actor.

