---
name: playwright-media-capture
description: "Capture screenshots (snapshots) and GIF recordings for QA test cases. Captures PASS screenshots (green badge) and FAIL screenshots (red highlight + badge). Also captures GIF recordings for failed cases. Use this skill for every test case — PASS gets a green-badged screenshot, FAIL gets red-highlighted screenshot + GIF reproduction. Attach evidence to Linear via the fileUpload GraphQL mutation + signed PUT (no browser upload needed). Triggers on: screenshot, snapshot, screen recording, test passed, test failed, ✅ pass, ❌ fail, capture evidence, record bug, save evidence, highlight failing element, bug reproduction, attach to Linear."
---

# Playwright Media Capture

Runs for **every test case** — PASS and FAIL both get screenshots. GIF recordings are for FAIL only.

**Badge placement rule: ALWAYS bottom-right (`bottom:12px;right:12px`). NEVER top-left.** Top-left overlaps modals, dialogs, and confirmation boxes that appear in the center/top of the viewport. Bottom-right stays clear.

> Files are saved using **absolute paths** anchored to `$REPO_ROOT` — never relative paths.
>
> **Only two paths are writable in this environment:**
> - **Workspace (persistent):** `/Users/belleung/Documents/guardrails/eng-guardrails-platform/` — survives sessions, accessible via `computer://` links. Sandbox path: `/sessions/<session-id>/mnt/eng-guardrails-platform/`
> - **Outputs (temp):** session-scoped temp folder — cleared between sessions, do NOT use for Linear attachments.

---

## When to Capture

| Situation | Snapshot | Recording |
|-----------|----------|-----------|
| ✅ Pass (UI) | ✅ Green badge bottom-right | Never |
| 🔍 BE-only | ✅ Green badge if UI visible | Never |
| ❌ Fail (UI) | ✅ Red highlight + red badge bottom-right | ✅ GIF repro steps |

---

## Part 0 — Resolve Repo Root (once per session)

```bash
REPO_ROOT="/sessions/friendly-admiring-mendel/mnt/eng-guardrails-platform"

if [ ! -d "$REPO_ROOT/.git" ]; then
  REPO_ROOT=$(find /sessions -maxdepth 5 -name ".git" -type d 2>/dev/null | head -1 | xargs dirname 2>/dev/null)
fi

[ -z "$REPO_ROOT" ] && echo "[ERROR] Cannot find repo root" && exit 1
echo "REPO_ROOT=$REPO_ROOT"

mkdir -p "$REPO_ROOT/manual-testing/evidences/$TICKET_KEY"
mkdir -p "$REPO_ROOT/manual-testing/test-results/done"
```

---

## Part 1 — Screenshot (PASS and FAIL)

### Primary method: Playwright MCP (stays on current page)

Use Playwright MCP to navigate to the same URL being tested, inject the badge, and take the screenshot. Claude in Chrome drives all testing; Playwright MCP captures evidence.

#### Step 1: Get the current URL from Claude in Chrome

```
mcp__Claude_in_Chrome__get_current_tab()
```
Note the URL — Playwright MCP will navigate to the same page.

#### Step 2: Close any modals before screenshot (if modal is NOT the evidence)

If a dialog/modal/confirmation box is open that is NOT what you're documenting, close it before screenshotting:

```javascript
// Via mcp__Claude_in_Chrome__javascript_tool
document.querySelector('[data-testid="modal-close"]')?.click();
// or press Escape
```

**Exception:** If the modal IS the evidence (e.g. you're documenting that a modal appeared or failed), keep it open for the screenshot.

#### Step 3: Inject badge via Claude in Chrome (while on the page)

**PASS — green badge, bottom-right:**
```javascript
// Via mcp__Claude_in_Chrome__javascript_tool
const label = document.createElement('div');
label.textContent = '✅ PASSED';
label.style.cssText = 'position:fixed;bottom:12px;right:12px;background:#16a34a;color:white;font-size:13px;font-weight:bold;padding:6px 12px;border-radius:6px;z-index:2147483647;box-shadow:0 2px 8px rgba(0,0,0,0.4);';
document.body.appendChild(label);
```

**FAIL — red highlight on failing element + red badge, bottom-right:**
```javascript
// Via mcp__Claude_in_Chrome__javascript_tool
const el = document.querySelector('{failing-element-selector}');
if (el) {
  el.style.outline = '4px solid red';
  el.style.outlineOffset = '2px';
  el.scrollIntoView({ behavior: 'instant', block: 'center' });
}
const label = document.createElement('div');
label.textContent = '❌ FAILED';
label.style.cssText = 'position:fixed;bottom:12px;right:12px;background:#dc2626;color:white;font-size:13px;font-weight:bold;padding:6px 12px;border-radius:6px;z-index:2147483647;box-shadow:0 2px 8px rgba(0,0,0,0.4);';
document.body.appendChild(label);
```

#### Step 4: Navigate Playwright MCP to the same URL and capture

> **Page load rule:** Always wait for full page render before injecting badge or taking screenshot. Use `waitForLoadState('networkidle')` + a 4-second buffer — not just a fixed 2-second delay.

```javascript
// mcp__playwright__browser_run_code_unsafe — navigate + wait for full page load
async (page) => {
  await page.goto('{same URL from step 1}', { waitUntil: 'domcontentloaded' });
  await page.waitForLoadState('networkidle').catch(() => {});
  await page.waitForTimeout(4000); // extra buffer for JS-rendered content
  return { url: page.url(), title: await page.title() };
}
```

Inject the same badge in Playwright context:

**PASS:**
```javascript
// mcp__playwright__browser_evaluate
const label = document.createElement('div');
label.textContent = '✅ PASSED';
label.style.cssText = 'position:fixed;bottom:12px;right:12px;background:#16a34a;color:white;font-size:13px;font-weight:bold;padding:6px 12px;border-radius:6px;z-index:2147483647;box-shadow:0 2px 8px rgba(0,0,0,0.4);';
document.body.appendChild(label);
'done'
```

**FAIL:**
```javascript
// mcp__playwright__browser_evaluate
const el = document.querySelector('{failing-element-selector}');
if (el) {
  el.style.outline = '4px solid red';
  el.style.outlineOffset = '2px';
  el.scrollIntoView({ behavior: 'instant', block: 'center' });
}
const label = document.createElement('div');
label.textContent = '❌ FAILED';
label.style.cssText = 'position:fixed;bottom:12px;right:12px;background:#dc2626;color:white;font-size:13px;font-weight:bold;padding:6px 12px;border-radius:6px;z-index:2147483647;box-shadow:0 2px 8px rgba(0,0,0,0.4);';
document.body.appendChild(label);
'done'
```

Save to disk — **always `fullPage: true`** to capture the entire page, not just the visible viewport:

**PASS:**
```
mcp__playwright__browser_take_screenshot(
  filename="/Users/belleung/Documents/guardrails/eng-guardrails-platform/manual-testing/evidences/{TICKET_KEY}/{TICKET_KEY}-TC{n}-PASS-{description}.png",
  fullPage=true
)
```

**FAIL:**
```
mcp__playwright__browser_take_screenshot(
  filename="/Users/belleung/Documents/guardrails/eng-guardrails-platform/manual-testing/evidences/{TICKET_KEY}/{TICKET_KEY}-TC{n}-FAIL-{description}.png",
  fullPage=true
)
```

Verify saved:
```bash
ls -lh "$REPO_ROOT/manual-testing/evidences/$TICKET_KEY/"
```

Naming conventions:
- PASS: `{TICKET_KEY}-TC{n}-PASS-{description}.png`
- FAIL: `{TICKET_KEY}-TC{n}-FAIL-{description}.png`

---

## Part 2 — GIF Recording (FAIL only)

GIF recordings document the full reproduction steps for a failed test case. One GIF per failed TC — single file, correct order guaranteed, works on all pages including SSO-protected Dev/Prod.

> **Verified working.** `gif_creator` was tested and confirmed functional. Key rule: you MUST call `computer screenshot` after every action to add frames — actions alone do NOT auto-capture frames. `download: true` is required on export.

### Step-by-step GIF recording

**1. Start recording BEFORE replaying repro steps:**
```
mcp__Claude_in_Chrome__gif_creator(action="start_recording", tabId={tabId})
```

**2. Take first frame (initial state):**
```
mcp__Claude_in_Chrome__computer(action="screenshot", tabId={tabId})
```

**3. Replay each repro step — screenshot after EVERY action:**
```
# click action
mcp__Claude_in_Chrome__computer(action="left_click", coordinate=[x, y], tabId={tabId})
mcp__Claude_in_Chrome__computer(action="screenshot", tabId={tabId})   ← adds frame

# navigation
mcp__Claude_in_Chrome__navigate(url="{url}", tabId={tabId})
mcp__Claude_in_Chrome__computer(action="screenshot", tabId={tabId})   ← adds frame

# repeat for every repro step
```

**4. Take final frame showing the failure state:**
```
mcp__Claude_in_Chrome__computer(action="screenshot", tabId={tabId})
```

**5. Stop recording:**
```
mcp__Claude_in_Chrome__gif_creator(action="stop_recording", tabId={tabId})
```

**6. Export GIF (`download: true` is required to save the file):**
```
mcp__Claude_in_Chrome__gif_creator(
  action="export",
  tabId={tabId},
  filename="{TICKET_KEY}-TC{n}-FAIL-{description}.gif",
  download=true,
  options={
    "showClickIndicators": true,
    "showActionLabels": true,
    "showProgressBar": true,
    "showWatermark": false,
    "quality": 10
  }
)
```

**7. Move from Downloads to evidence folder:**
```bash
mv ~/Downloads/{TICKET_KEY}-TC{n}-FAIL-{description}.gif \
   "$REPO_ROOT/manual-testing/evidences/$TICKET_KEY/"
ls -lh "$REPO_ROOT/manual-testing/evidences/$TICKET_KEY/"
```

Naming: `{TICKET_KEY}-TC{n}-FAIL-{description}.gif`

---

## Part 3 — Upload to Linear (`fileUpload` + PUT)

> Linear's `fileUpload` GraphQL mutation plus a signed `PUT` is a direct API call — it works the
> same in every environment, sandboxed or not. There is no Playwright-navigate-to-the-ticket
> workaround needed anymore: uploading no longer depends on the ticket's page being open in a
> browser at all.

### Step 1: Upload every file via the `linear-comment-writer` helper script

```bash
python3 "$REPO_ROOT/.claude/skills/linear-comment-writer/scripts/upload_linear_file.py" \
  "$REPO_ROOT/manual-testing/evidences/{TICKET_KEY}/{TICKET_KEY}-TC1-PASS-{desc}.png" \
  "$REPO_ROOT/manual-testing/evidences/{TICKET_KEY}/{TICKET_KEY}-TC2-FAIL-{desc}.png" \
  "$REPO_ROOT/manual-testing/evidences/{TICKET_KEY}/{TICKET_KEY}-TC2-FAIL-{desc}.gif"
```

This calls `fileUpload` for each file, then `PUT`s the raw bytes to the returned `uploadUrl` with
the exact `headers` Linear supplies — one `filename -> assetUrl` line is printed per file. (The
raw GraphQL shape is in `LINEAR_CHEATSHEET.md` §3 if you need to do this without the helper
script.)

### Step 2: Verify upload

Confirm one `assetUrl` line came back per file passed in. If fewer came back, re-run for the
missing files only (check stderr for `[WARN]`/`[ERROR]` lines naming the failing file).

Record each `assetUrl` by filename — that's what Part 5 needs for the inline `![alt](assetUrl)` images.

> **Important:** Files MUST be uploaded (and their `assetUrl`s recorded) before posting the Linear comment.

---

## Part 4 — Result File

Save to: `$REPO_ROOT/manual-testing/test-results/{TICKET_KEY}_result_{passed|failed}.md`

| Outcome | Filename |
|---------|---------|
| All passed | `_result_passed.md` |
| > 50% failed | `_result_failed.md` |
| ≤ 50% failed | `_result_passed.md` |

```markdown
# Test Result: {TICKET_KEY}

**Date**: {YYYY-MM-DD}
**Tested by**: belle.ung@persefoni.com
**Environment**: Dev (https://app.dev.firstrecon.ai)
**Overall**: PASSED | FAILED | PARTIAL

## Summary
[What was tested, what passed, what failed.]

## Test Cases

| # | Type | Description | Status | Screenshot | Recording |
|---|------|-------------|--------|------------|-----------|
| 1 | Happy Path | [desc] | ✅ Pass | ![{TICKET_KEY}-TC1-PASS-desc.png](ASSET_URL_FROM_UPLOAD) | — |
| 2 | Negative | [desc] | ❌ Fail | ![{TICKET_KEY}-TC2-FAIL-desc.png](ASSET_URL_FROM_UPLOAD) | ![{TICKET_KEY}-TC2-FAIL-desc.gif](ASSET_URL_FROM_UPLOAD) |

## Failed Test Cases — Detail

### TC-{n}: [title]
**AC**: AC#{n} — [verbatim text]
**Steps to Reproduce**:
1. Navigate to [URL]
2. [action]
3. Observe: [what happened]
**Expected**: [per AC]
**Actual**: [exactly what appeared]
**Screenshot**: ![{TICKET_KEY}-TC{n}-FAIL-{description}.png](ASSET_URL_FROM_UPLOAD)
**Recording**: ![{TICKET_KEY}-TC{n}-FAIL-{description}.gif](ASSET_URL_FROM_UPLOAD)

## Evidence Files
- Location: /Users/belleung/Documents/guardrails/eng-guardrails-platform/manual-testing/evidences/{TICKET_KEY}/
```

`ASSET_URL_FROM_UPLOAD` is the real `assetUrl` recorded per filename in Part 3 — swap in the
actual URL for each image before this file is handed to `linear-comment-writer` as a comment file.

---

## Part 5 — Post Linear Comment

Hand off to `linear-comment-writer`, which posts the result-file content as a plain Markdown
string via Linear's `commentCreate` mutation — no format conversion, no UUID scraping:

```bash
python3 "$REPO_ROOT/.claude/skills/linear-comment-writer/scripts/post_linear_comment.py" {TICKET_KEY} \
  --comment-file "$REPO_ROOT/manual-testing/test-results/{TICKET_KEY}_result_{passed|failed}.md"
```

Transition if passed (steps through `In QA` → `Ready To Release` as needed):
```bash
python3 "$REPO_ROOT/.claude/skills/linear-comment-writer/scripts/post_linear_comment.py" {TICKET_KEY} \
  --transition "qa passed"
```

Move result to done:
```bash
mv "$REPO_ROOT/manual-testing/test-results/${TICKET_KEY}_result_*.md" \
   "$REPO_ROOT/manual-testing/test-results/done/"
```

---

## File Flow

```
Claude in Chrome → drives all UI testing
  ↓ each test case result
Playwright MCP → browser_take_screenshot(fullPage=true) → PNG to disk

  ↓ FAIL only: GIF
gif_creator start → screenshot(frame1) → [action+screenshot] x N → stop → export(download=true)
→ mv ~/Downloads/{gif} → evidences/

  ↓ upload to Linear
upload_linear_file.py [...PNG, GIF...] → assetUrl per file ✅

  ↓ comment
post_linear_comment.py → ![alt](assetUrl) inline ✅
```

---

## Badge Placement — Why Bottom-Right

Modals and overlays appear center/top of viewport. Bottom-right (`bottom:12px;right:12px`) stays clear. Use `z-index:2147483647` so badge is never covered.

---

## GIF Save Path — Important Note

`gif_creator export` with `download: true` saves the GIF to your **Mac's `~/Downloads/` folder**. The Linux sandbox cannot access this path directly, and the Linear upload step (`upload_linear_file.py`, Part 3) runs from the sandbox side — so the file needs to land in the repo evidence folder before it can be uploaded.

### Copy to repo evidence folder, then upload via Linear's API

Copy the GIF from Downloads into the repo evidence folder after export:

```bash
cp ~/Downloads/{TICKET_KEY}-TC{n}-FAIL-{description}.gif \
   /Users/belleung/Documents/guardrails/eng-guardrails-platform/manual-testing/evidences/{TICKET_KEY}/
```

Then upload it the same way as the screenshots (Part 3):

```bash
python3 "$REPO_ROOT/.claude/skills/linear-comment-writer/scripts/upload_linear_file.py" \
  "$REPO_ROOT/manual-testing/evidences/{TICKET_KEY}/{TICKET_KEY}-TC{n}-FAIL-{description}.gif"
```

No browser navigation or `setInputFiles` is needed for the upload itself — the direct API call
works from the sandbox once the file is in a path the sandbox can read.
