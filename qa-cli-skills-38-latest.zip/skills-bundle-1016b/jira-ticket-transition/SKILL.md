---
name: jira-ticket-transition
description: "Transition a verified Jira ticket to Ready To Release status after QA passes. Posts a QA verification comment and moves the ticket through the required lane sequence. Records which environment was used per the new routing policy: Dev (https://app.dev.firstrecon.ai) for normal tickets, or Production (https://app.firstrecon.ai) — with Dev fallback — for [Pro]/[Prod] tickets. Use this skill whenever the user says 'Passed' followed by a ticket ID, wants to mark a ticket as QA verified, move a ticket to Ready To Release, or confirm QA completion on a Jira ticket. Triggers on: Passed, QA verified, ready to release, mark as passed, QA complete, transition ticket, move to release."
---

# Jira Ticket Transition (Passed)

This skill handles the post-QA workflow: verifying a ticket passed, posting a QA comment, and transitioning the ticket to Ready To Release.

## Trigger

`Passed [TICKET-ID or bug ticket reference]`

## Shared References

Before proceeding, read:
- `shared-qa-base/references/environments.md` — environment URLs and routing rules

## Step 1 — Verify the Ticket

- Locate the referenced Jira ticket (bug ticket or original test ticket)
- Review its current status/lane in Jira
- Confirm the referenced item is recorded as ✅ Pass in the most recent `.md` report for the environment used
- Inspect the ticket title — if it contains `[Pro]` or `[Prod]`, the expected primary test environment was Production
- If the ticket did NOT pass, stop and report — do not transition a failing ticket

## Step 2 — Post a Verification Comment

Add a professional, concise comment to the Jira ticket. The "Tested on" line follows the routing convention:

**Normal ticket (no `[Pro]`/`[Prod]`):**
```
✅ QA Verified — [YYYY-MM-DD]

Tested on: Dev (https://app.dev.firstrecon.ai)
Tested by: belle.ung@persefoni.com

All acceptance criteria verified and passed.
No issues observed. This ticket is ready for release.
```

**`[Pro]` / `[Prod]` ticket, fully verified on Production:**
```
✅ QA Verified — [YYYY-MM-DD]

Tested on: Production (https://app.firstrecon.ai)
Tested by: belle.ung@persefoni.com

All acceptance criteria verified and passed.
No issues observed. This ticket is ready for release.
```

**`[Pro]` / `[Prod]` ticket, verified on Dev because Production has a deployment gap:**
```
✅ QA Verified — [YYYY-MM-DD]

Tested on: Dev (https://app.dev.firstrecon.ai) — Production fallback used due to deployment gap
Tested by: belle.ung@persefoni.com

All acceptance criteria verified and passed on Dev. The fix has not yet rolled out to
Production (https://app.firstrecon.ai). Release/deployment team to push to Prod for the fix
to be live for users.
```

- Include only the environment that was actually used for testing
- Keep it short and factual — no lengthy test case details
- Date format: YYYY-MM-DD

## Step 3 — Transition the Ticket

Move the ticket through the required lane sequence:

```
Code Review → QA Review → In QA → Ready To Release
```

- Use the Jira transition API to move through each required state
- If any intermediate transition is required (e.g., must pass through QA Review before In QA), execute each transition in order
- If a transition is unavailable or blocked: **report the blocker and stop** — do not skip steps
- Confirm the final status of the ticket after transition

## Step 4 — Confirm and Report

Output a confirmation with:

- **Ticket ID** and its **new status** (Ready To Release)
- **Direct Jira link** to the ticket
- **Comment posted**: confirmation that the QA verification comment was added
- **Environment used**: which environment was tested (and whether a Production → Dev fallback was used for `[Pro]`/`[Prod]` tickets)
- **Transition path**: the sequence of transitions executed
- Flag any transition steps that could not be completed, with the reason

## Important Notes

- This skill does NOT run any tests — it only processes tickets that have already been fully tested and passed
- No media capture is needed — the Passed flow is purely about status updates
- No `bun run` commands are executed — ignore any build/lint steps in the transition
- If the ticket is already in Ready To Release, note it and skip the transition
- For `[Pro]`/`[Prod]` tickets verified only on Dev (Prod deployment pending), the QA verification still moves the ticket forward — but the comment makes the deployment gap explicit so the release team knows action is needed
