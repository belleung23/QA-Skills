---
name: linear-ticket-transition
description: "Transition a verified Linear issue to Ready To Release status after QA passes. Posts a QA verification comment and moves the issue through the required workflow-state sequence. Records which environment was used per the routing policy: Dev (https://app.dev.firstrecon.ai) for normal tickets, or Production (https://app.firstrecon.ai) — with Dev fallback — for [Pro]/[Prod] tickets. Use this skill whenever the user says 'Passed' followed by an issue ID, wants to mark an issue as QA verified, move an issue to Ready To Release, or confirm QA completion on a Linear issue. Triggers on: Passed, QA verified, ready to release, mark as passed, QA complete, transition ticket, move to release."
---

# Linear Ticket Transition (Passed)

This skill handles the post-QA workflow: verifying an issue passed, posting a QA comment, and transitioning the issue to Ready To Release.

## Trigger

`Passed [ISSUE-ID or bug issue reference]`

## Shared References

Before proceeding, read:
- `shared-qa-base/references/environments.md` — environment URLs and routing rules

## Step 1 — Verify the Issue

- Locate the referenced Linear issue (bug issue or original test issue)
- Review its current workflow state in Linear
- Confirm the referenced item is recorded as ✅ Pass in the most recent `.md` report for the environment used
- Inspect the issue title — if it contains `[Pro]` or `[Prod]`, the expected primary test environment was Production
- If the issue did NOT pass, stop and report — do not transition a failing issue

## Step 2 — Post a Verification Comment

Add a professional, concise **plain Markdown** comment to the Linear issue via `commentCreate` (see `linear-comment-writer`, or the direct mutation in `LINEAR_CHEATSHEET.md` §3). The "Tested on" line follows the routing convention:

**Normal ticket (no `[Pro]`/`[Prod]`):**
```
✅ QA Verified — [YYYY-MM-DD]

Tested on: Dev (https://app.dev.firstrecon.ai)
Tested by: belle.ung@persefoni.com

All acceptance criteria verified and passed.
No issues observed. This ticket is ready for release.
```

**`[Pro]` / `[Prod]` ticket, fully verified on Production:**
```
✅ QA Verified — [YYYY-MM-DD]

Tested on: Production (https://app.firstrecon.ai)
Tested by: belle.ung@persefoni.com

All acceptance criteria verified and passed.
No issues observed. This ticket is ready for release.
```

**`[Pro]` / `[Prod]` ticket, verified on Dev because Production has a deployment gap:**
```
✅ QA Verified — [YYYY-MM-DD]

Tested on: Dev (https://app.dev.firstrecon.ai) — Production fallback used due to deployment gap
Tested by: belle.ung@persefoni.com

All acceptance criteria verified and passed on Dev. The fix has not yet rolled out to
Production (https://app.firstrecon.ai). Release/deployment team to push to Prod for the fix
to be live for users.
```

- Include only the environment that was actually used for testing
- Keep it short and factual — no lengthy test case details
- Date format: YYYY-MM-DD
- This is a plain Markdown string, posted verbatim — no wiki markup or ADF conversion needed

## Step 3 — Transition the Issue

Move the issue through the required workflow-state sequence:

```
Code Review → QA Review → In QA → Ready To Release
```

- Use `issueUpdate(input: { stateId })` to move through each required state — look up each state's id by name on the team first (`LINEAR_CHEATSHEET.md` §3)
- If any intermediate transition is required (e.g., must pass through QA Review before In QA), execute each `issueUpdate` in order
- If a target state doesn't exist on the team's workflow: **report the blocker and stop** — do not skip steps (this usually means the state needs to be created on the Linear team; see the migration notes)
- Confirm the final state of the issue after transition by re-querying it

## Step 4 — Confirm and Report

Output a confirmation with:

- **Issue ID** and its **new state** (Ready To Release)
- **Direct Linear link** to the issue (`https://linear.app/persefoni/issue/{ISSUE_ID}`)
- **Comment posted**: confirmation that the QA verification comment was added
- **Environment used**: which environment was tested (and whether a Production → Dev fallback was used for `[Pro]`/`[Prod]` tickets)
- **Transition path**: the sequence of state changes executed
- Flag any transition steps that could not be completed, with the reason

## Important Notes

- This skill does NOT run any tests — it only processes issues that have already been fully tested and passed
- No media capture is needed — the Passed flow is purely about status updates
- No `bun run` commands are executed — ignore any build/lint steps in the transition
- If the issue is already in Ready To Release, note it and skip the transition
- For `[Pro]`/`[Prod]` tickets verified only on Dev (Prod deployment pending), the QA verification still moves the issue forward — but the comment makes the deployment gap explicit so the release team knows action is needed
