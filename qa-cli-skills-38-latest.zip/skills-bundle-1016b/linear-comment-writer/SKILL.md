---
name: linear-comment-writer
description: "Write and post the Linear QA comment. Picks comment type automatically — PASS ✅, FAIL ❌ with root-cause, or clarification. Posts as plain Markdown with inline screenshots via ![alt](assetUrl) — Linear renders Markdown natively, no ADF/UUID workaround needed. Upload files first (fileUpload + PUT), then reference the returned assetUrl directly in the comment body. Follows the same 7-column table format as before (empty | Test Case | Status | Expected Result | Actual Result | Reproduction Steps | Screenshot), Execution Summary as bullet list, h2 headings. Use whenever: write comment, post comment, QA comment, post results, comment on Linear issue, verification comment, tag for review."
---

# Linear Comment Writer

Final step after QA execution. Posts the Linear comment as **plain Markdown** with inline screenshot evidence, uploads artifacts, and transitions the issue's workflow state.

> Migrated from Jira. The single biggest change: Linear comments are Markdown, not ADF. There
> is no `mediaSingle` node, no Atlassian Media UUID scraping from `img src`, and no
> `contentFormat: "adf"` flag — a comment is just a Markdown string, and `![alt](url)` embeds
> an image inline as long as `url` is a real asset URL (from `fileUpload`) or any public image URL.

> **Critical:** All paths must be **absolute**. Container CWD is `/` — relative paths silently fail.
> **Upload first, comment second.** The comment body needs the real `assetUrl` for each image,
> which only exists after the upload call returns.

---

## Step 0 — Resolve repo root

```bash
REPO_ROOT=$(find /sessions -maxdepth 5 -name ".git" -type d 2>/dev/null | head -1 | xargs dirname 2>/dev/null)
[ -z "$REPO_ROOT" ] && echo "[ERROR] Cannot find repo root" && exit 1
echo "REPO_ROOT=$REPO_ROOT"
```

---

## Pick Comment Type

| Situation | Type |
|-----------|------|
| Every TC passed | ✅ All Passed |
| Failures with clear root cause | ❌ Bug Report → auto-trigger `linear-ticket-writer` |
| Failures with ambiguous behaviour | ⚠️ Clarification |

Prefer Bug Report over Clarification whenever root cause is identifiable without hedging.

---

## Images: upload once, reference everywhere

There is no separate "extract Media UUID" step anymore. The flow is:

1. Upload the file via the `fileUpload` mutation + `PUT` to the returned `uploadUrl` (see
   `LINEAR_CHEATSHEET.md` §3, or just call `scripts/upload_linear_file.py <path>` which prints
   the `assetUrl`).
2. Use that `assetUrl` directly as `![TC-01 screenshot](assetUrl)` inside the Markdown table
   cell or paragraph where the screenshot belongs.
3. Optionally also call `attachmentCreate` so the file shows in the issue's attachment list,
   not just inline in the comment (both can reference the same `assetUrl`).

For a test case with no screenshot (BE-only, Layer 2), just put `—` in that table cell — no
special empty-media markup needed.

---

## Comment Format (same structural rules as before, now in Markdown)

The canonical reference stays Lan's GR-5146-style comment, adapted to Markdown:
- **7 columns:** `(empty) | Test Case | Status | Expected Result | Actual Result | Reproduction Steps | Screenshot`
- **Leading empty column** holds the TC number (TC-01, TC-02, etc.)
- **Reproduction Steps column** — numbered steps so developers can reproduce and verify without guessing:
  - **PASS cases:** concise steps covering the happy path (e.g. "1. Navigate to the feature → 2. Perform the action → 3. Verify result")
  - **FAIL cases:** detailed and precise — include exact inputs, UI state at failure point, API payload if relevant, and the exact step where failure occurs. Developer must be able to reproduce end-to-end from this column alone without additional context.
- **Execution Summary** is a bullet list (not a table)
- **Headings** use `##` (h2): "Execution Summary" and "Test Cases"
- **Technical values** use backtick code spans
- **Comment is posted as a plain Markdown string** via `commentCreate` — no format flag needed

### Markdown Comment Skeleton

```markdown
QA Verification PASS ✅

- Date: `YYYY-MM-DD`
- Issue: `GR-XXXX`
- Environment: `Dev — https://app.dev.firstrecon.ai`
- Tester: `belle.ung@persefoni.com`
- Scope: `Frontend + Backend`

## Execution Summary

- Total: `N`
- Passed: `N`
- Failed: `0`
- Skipped: `0`
- Blocked: `0`

## Test Cases

|  | Test Case | Status | Expected Result | Actual Result | Reproduction Steps | Screenshot |
|---|---|---|---|---|---|---|
| TC-01 | Test case description | ✅ Pass | Expected outcome | Actual outcome matched | 1. Navigate to feature URL → 2. Perform the tested action → 3. Observe result | ![TC-01](ASSET_URL_FROM_UPLOAD) |

Summary narrative here.
```

That's the entire comment — a plain Markdown string handed to `commentCreate`. No JSON document tree to build.

---

## Posting Workflow

### 1. Capture screenshots with Playwright

```javascript
// mcp__playwright__browser_run_code_unsafe
async (page) => {
  await page.goto('{URL}', { waitUntil: 'domcontentloaded' });
  await page.waitForLoadState('networkidle').catch(() => {});
  await page.waitForTimeout(4000); // wait for JS-rendered content before screenshotting
  await page.evaluate(() => {
    const b = document.getElementById('qa-pass-badge');
    if (b) b.remove();
    const label = document.createElement('div');
    label.id = 'qa-pass-badge';
    label.textContent = '✅ PASSED';
    label.style.cssText = 'position:fixed;bottom:12px;right:12px;background:#16a34a;color:white;font-size:13px;font-weight:bold;padding:6px 12px;border-radius:6px;z-index:2147483647;box-shadow:0 2px 8px rgba(0,0,0,0.4);';
    document.body.appendChild(label);
  });
  await page.screenshot({
    path: '/sessions/<session>/mnt/eng-guardrails-platform/manual-testing/evidences/{TICKET_KEY}/{TICKET_KEY}-TC1-PASS-{desc}.png'
  });
  return 'saved';
}
```

For FAIL: red badge (`background:#dc2626`, text `❌ FAILED`) + red outline on failing element.

### 2. Upload all evidence files (BEFORE posting comment)

```bash
python3 "$REPO_ROOT/.claude/skills/linear-comment-writer/scripts/upload_linear_file.py" \
  /sessions/<session>/mnt/eng-guardrails-platform/manual-testing/evidences/{TICKET_KEY}/file1.png \
  /sessions/<session>/mnt/eng-guardrails-platform/manual-testing/evidences/{TICKET_KEY}/file2.png
```

This is a direct API call (`fileUpload` + `PUT`), not a browser upload — it works the same in
every environment, sandboxed or not, and prints one `filename -> assetUrl` line per file. No
403s from a sandbox proxy, because there's no Playwright/`setInputFiles` step involved at all.

Record each `assetUrl` by filename — that's what goes into the Screenshot column / `![alt](url)` embeds.

### 3. Post comment via Linear API

```bash
python3 "$REPO_ROOT/.claude/skills/linear-comment-writer/scripts/post_linear_comment.py" {TICKET_KEY} \
  --comment-file test-reports/linear-comments/{TICKET_KEY}_{date}_comment.md
```

The comment file is the exact Markdown skeleton from above, already filled in with real
`assetUrl`s. The script posts it verbatim via `commentCreate` — no conversion step (contrast
with the old Jira script, which had to convert Markdown → wiki markup; that entire conversion
layer is gone).

### 4. Transition if all passed

```bash
python3 "$REPO_ROOT/.claude/skills/linear-comment-writer/scripts/post_linear_comment.py" {TICKET_KEY} \
  --transition "qa passed"
```

The script resolves `"qa passed"` to Linear's `Ready To Release` workflow state on the team
(matching by state name — see `LINEAR_CHEATSHEET.md` §3) and applies it via `issueUpdate`. If
the current state is `QA Review`, it steps through `In QA` first, same two-hop logic as before.

### 5. Auto-trigger linear-ticket-writer (Bug Report only — MANDATORY)

If comment type is Bug Report, immediately invoke `linear-ticket-writer` for every failed TC. Do not wait for user confirmation.

---

## Status Transitions

| Outcome | Transition | Status |
|---------|-----------|--------|
| All passed | `qa passed` | → Ready To Release |
| Any failure | none | unchanged |
| Clarification | none | unchanged |

---

## Final Report

Output after completion:
- Issue ID + URL
- Comment type (Pass / Bug Report / Clarification)
- Artifacts uploaded (filenames + count)
- TC count: passed / failed / skipped / blocked
- Bug issues filed (if any, with links)
- Transition applied (if any)

---

## Fallback (if the Linear API is unreachable)

1. Note evidence path: `/Users/belleung/Documents/guardrails/eng-guardrails-platform/manual-testing/evidences/{TICKET_KEY}/`
2. Tell the user the comment could not be posted and give them the Markdown file path so they can paste it manually into the Linear issue.
3. Unlike the old Jira flow, there is no UUID-extraction step to redo manually — a manually pasted `![alt](path-or-url)` will still render once the file is reachable at that URL.
