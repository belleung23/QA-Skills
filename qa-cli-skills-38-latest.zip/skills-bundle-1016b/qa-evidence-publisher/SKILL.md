---
name: qa-evidence-publisher
description: "Upload QA evidence screenshots and videos to a Linear issue, then trigger linear-comment-writer to post the structured Markdown comment. Uploads files via Linear's fileUpload mutation + signed PUT, embeds them inline in the comment via ![alt](assetUrl), and attaches them to the issue's file list. Use this skill whenever you need to upload evidence files to Linear, attach screenshots or recordings to an issue, publish test results with media, or when an orchestrator calls the evidence upload step. Triggers on: upload evidence, attach screenshots, publish evidence, upload test results, attach to Linear, evidence upload, post evidence, qa-evidence-publisher."
---

# Post Test Result — Upload Evidence & Comment to Linear

Uploads evidence and report files, posts a formatted comment, and transitions the issue if all tests passed.

> Migrated from Jira. The old flow depended on Playwright `setInputFiles` because a direct
> Python upload got a 403 through the sandbox proxy talking to Jira's REST API. Linear's
> `fileUpload` mutation is a normal authenticated GraphQL call plus a signed `PUT`, so this
> works as a direct API call from Bash in every environment — no browser automation required
> for the upload step at all.

> **Critical:** All paths must be **absolute**. Container CWD is `/` — relative paths silently fail.

---

## Step 0 — Resolve Repo Root

```bash
REPO_ROOT="/sessions/friendly-admiring-mendel/mnt/eng-guardrails-platform"
if [ ! -d "$REPO_ROOT/.git" ]; then
  REPO_ROOT=$(find /sessions -maxdepth 5 -name ".git" -type d 2>/dev/null | head -1 | xargs dirname 2>/dev/null)
fi
[ -z "$REPO_ROOT" ] && echo "[ERROR] Cannot find repo root" && exit 1
echo "REPO_ROOT=$REPO_ROOT"
```

---

## Screenshot & Video — Scope Rules

| Scope | Upload screenshots | Upload videos |
|-------|-------------------|---------------|
| **FE** or **FE+BE** | ✅ Yes — all TCs (PASS + FAIL) | ✅ Yes — FAIL cases only |
| **BE** only | ❌ No | ❌ No |

Only attach evidence files when scope is FE or FE+BE. For BE-only tickets, upload only the report .md files.

---

## Step 1 — Build the File List

Collect all files to upload:

**Always include (every ticket):**
```bash
ls "$REPO_ROOT/test-reports/${TICKET_KEY}_"*.md 2>/dev/null    # QA Report
ls "$REPO_ROOT/test-cases/${TICKET_KEY}_"*.md 2>/dev/null      # Test Cases
```

**FE / FE+BE scope — also include:**
```bash
ls "$REPO_ROOT/manual-testing/evidences/$TICKET_KEY/"*.png 2>/dev/null   # screenshots
ls "$REPO_ROOT/manual-testing/evidences/$TICKET_KEY/"*.webm 2>/dev/null  # recordings
```

---

## Step 2 — Upload Every File via Linear's API

```bash
python3 "$REPO_ROOT/.claude/skills/linear-comment-writer/scripts/upload_linear_file.py" \
  "$REPO_ROOT/test-reports/${TICKET_KEY}_"*.md \
  "$REPO_ROOT/test-cases/${TICKET_KEY}_"*.md \
  "$REPO_ROOT/manual-testing/evidences/$TICKET_KEY/"*.png \
  "$REPO_ROOT/manual-testing/evidences/$TICKET_KEY/"*.webm
```

This prints one `filename -> assetUrl` line per file — no navigation to the issue page, no
`setInputFiles`, no polling for the upload to "process" before the asset is usable. Record
each `assetUrl` by filename; that's what Step 3 needs.

Verify the count before proceeding — if fewer `assetUrl` lines came back than files passed in, re-run for the missing ones (check stderr for `[WARN]`/`[ERROR]` lines naming the failing file).

---

## Step 3 — Build the Screenshots Lane (FE / FE+BE only)

**Skip entirely for BE-only tickets.**

For every screenshot, add a Markdown image reference using its `assetUrl` from Step 2, in the
Screenshot column of the Test Cases table (see `linear-comment-writer`'s comment skeleton):

```markdown
![TC1-PASS](https://uploads.linear.app/.../GR-1234-TC1-PASS-desc.png)
```

**Rules:**
- Include **all** screenshots — both PASS (green badge) and FAIL (red badge) — for FE/FE+BE scope.
- Order by TC number: TC1-PASS, TC2-PASS … TC1-FAIL, TC2-FAIL … (or interleaved — match the test case table order).
- Pass the list of `assetUrl`s to `linear-comment-writer` so they land in the Screenshots column of the Markdown comment.
- Screenshots must appear **visually** in the comment for FE/FE+BE scope (a rendered `![alt](url)` image), not just as a filename or attachment link.

---

## Step 4 — Post Comment via Linear API

Use the `linear-comment-writer` skill to write and post the formatted comment.

Files must be uploaded (Step 2) and their `assetUrl`s collected (Step 3, FE/FE+BE only)
**before** the comment is posted.

```bash
python3 "$REPO_ROOT/.claude/skills/linear-comment-writer/scripts/post_linear_comment.py" "$TICKET_KEY" \
  --comment-file "$REPO_ROOT/test-reports/linear-comments/${TICKET_KEY}_${date}_comment.md"
```

The comment file already has real `assetUrl`s embedded from Step 3 — the script posts it verbatim, no format conversion.

---

## Step 5 — Transition if All Passed

If result is passed (`_result_passed.md` or all TCs ✅):

```bash
python3 "$REPO_ROOT/.claude/skills/linear-comment-writer/scripts/post_linear_comment.py" "$TICKET_KEY" \
  --transition "qa passed" --transition-only
```

| Result | Action |
|--------|--------|
| All passed | → Ready To Release |
| Any failure | No status change |

---

## Step 6 — Move Result File to Done

```bash
mv "$REPO_ROOT/manual-testing/test-results/${TICKET_KEY}_result_"*.md \
   "$REPO_ROOT/manual-testing/test-results/done/" 2>/dev/null || true
```

---

## Expected File Layout

```
{REPO_ROOT}/
  test-reports/
    GR-1234_PASSED_QA-Report_2026-05-28.md
  test-cases/
    GR-1234_PASSED_Test-Cases_2026-05-28.md
  manual-testing/
    evidences/
      GR-1234/
        GR-1234-TC1-PASS-desc.png     ← FE/FE+BE only
        GR-1234-TC2-FAIL-desc.png     ← FE/FE+BE only
        GR-1234-TC2-FAIL-desc.webm    ← FE/FE+BE only
```

---

## Linear Team

Team key: `GR` (see `LINEAR_CHEATSHEET.md` §7 — confirm this against the real Linear workspace).
