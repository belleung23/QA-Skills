---
name: "api-testing-standards"
description: "Standards for designing, writing and reviewing API tests (REST/GraphQL) in Playwright TypeScript — payload (request and response), authentication, authorization matrix, coverage checklist, assertion rules, test data, naming and PR scope. Use whenever writing, generating, reviewing or planning API/backend/endpoint tests, or when a ticket needs API-layer verification."
---

# API Testing Standards

This skill defines what a *good* API test looks like, project by project, without hardcoding anything about one product. Use it in three situations: writing new API tests, generating API tests from a ticket or test case, and reviewing API tests someone else wrote. The standards are the same in all three — a review is just checking the same list in reverse.

The goal of an API test is to prove, independently of the UI, that an endpoint does what its contract says: right status, right shape, right data, right behaviour on bad input, and right behaviour for the wrong user. A UI test can pass while the API silently returns the wrong thing; API tests are the layer that catches that.

Every endpoint gets tested on **three pillars**, in this order, before anything else: **payload**, **authentication**, **authorization**. The rest of the coverage checklist builds on those. If a PR covers only the happy path and skips any pillar, it is not done.

## Before writing anything: establish the contract

An API test without a contract is a guess. Before writing a test, find or build the contract for the endpoint:

1. Look for an OpenAPI/Swagger spec, GraphQL schema, Postman collection, or route handler in the repo. Read the actual handler if the docs are missing or stale — the code is the truth.
2. Record for each endpoint: method + path, auth required (and which roles), request body/query params with types and required fields, success status + response shape, every documented error status, pagination/filtering/sorting params, and any side effects (emails, jobs, writes to other tables).
3. If the contract is unclear, ask or write the test as `test.fixme` with the open question in the title — never invent expected values to make a test pass.

Write this down briefly in the spec file header or the PR description so the reviewer can check the test against it.

## Pillar 1 — Payload (request and response)

"Payload" means both what you send and what you get back. Test both; most teams only test the response.

### Request payload

For every field in the request body and query string, work through this list. The reason: each row is a distinct code path in the server's validation, and a server that handles one correctly often mishandles the next.

| Case | Example | Expected |
|---|---|---|
| Valid, typical | normal name/email | success status + stored exactly as sent |
| Required field missing | omit `email` | `400`/`422`, error names the field |
| Required field present but empty | `""`, `null`, `[]`, `{}` | `400`/`422` (unless contract allows) |
| Wrong type | string where number expected, `"true"` for boolean | `400`/`422`, never coerced silently unless documented |
| Boundary values | min, min−1, max, max+1 length/number | min and max accepted, outside rejected |
| Invalid format | bad email, bad UUID, bad ISO date, bad enum value | `400`/`422` |
| Unknown/extra field | `{"isAdmin": true}` on a user update | ignored or rejected per contract — **must not be applied** (mass-assignment) |
| Read-only field in body | `id`, `createdAt`, `ownerId` | ignored, original value unchanged |
| Malformed body | invalid JSON, wrong `Content-Type` | `400`/`415`, not `500` |
| Oversized | very long strings, huge arrays, large files | `413` or `400` with a clear limit |
| Special characters & encoding | unicode, emoji, quotes, `<script>`, `'; DROP TABLE` | stored/escaped safely, returned unchanged, not executed |
| Whitespace handling | leading/trailing spaces | trimmed or kept per contract — assert which |
| Nested objects/arrays | missing nested required, wrong item type, empty array, duplicates | validated to the same depth as top-level |

For each case assert the status **and** the error body: the field name, a human-readable message, and the project's error code if it has one. A `400` with an empty body is a bug for API clients.

### Response payload

- Validate the whole shape with a schema (zod/ajv or `toMatchObject` with every expected field), not one lucky field. Types matter: `"42"` is not `42`, `null` is not missing.
- Assert the **values** come back as sent (round trip): create with payload X, `GET` it, compare field by field.
- Check formats explicitly: IDs (UUID/numeric), timestamps (ISO 8601, UTC), money (precision), enums (exact casing).
- Check nothing leaks: no `passwordHash`, internal flags, secrets, other users'/tenants' data, stack traces in errors. Add a negative assertion (`not.toHaveProperty`) for the obvious ones.
- Check `Content-Type`, and headers the contract promises (pagination headers, `Location` on `201`, rate-limit headers).
- Error responses follow one envelope across all endpoints; test that it is the same envelope on `400`, `401`, `403`, `404`, `409`, `500`.

## Pillar 2 — Authentication (who are you?)

Authentication tests answer "does the API correctly identify the caller?" Run this matrix against **every** protected endpoint, not just login — a single endpoint that forgets the auth middleware is a full data leak.

| Credential state | Expected |
|---|---|
| No `Authorization` header | `401` |
| Empty / malformed header (`Bearer`, `Bearer abc`, wrong scheme like `Basic`) | `401` |
| Expired token | `401`, with a distinguishable error code if the contract has one |
| Revoked token / logged-out session | `401` |
| Token with invalid signature (tampered payload, wrong secret, `alg: none`) | `401` |
| Token for a different audience/issuer/environment | `401` |
| Valid token | proceeds to authorization checks |
| Refresh flow (if present) | old access token rejected after refresh, new one accepted; refresh token single-use if contract says so |
| API key (if used) | missing, wrong, disabled key → `401`; key scoped to another tenant → `403`/`404` |

Also check that `401` responses do not reveal which part failed in a way that helps an attacker (e.g. "user exists but wrong password" on login), and that failed-login rate limiting or lockout, where it exists, returns `429`/`423` after the documented threshold.

For login/token endpoints themselves, add: correct credentials → token with expected claims and expiry; wrong password → `401`; unknown user → same `401` and same timing class; disabled user → `401`/`403` per contract.

## Pillar 3 — Authorization (what may you do?)

Authorization tests answer "given a valid identity, is the caller allowed this action on this resource?" This is the most expensive category to skip. Build a **role × action matrix** for the resource and turn every cell into a test.

```
                 create  read-own  read-others  update-own  update-others  delete  admin-action
anonymous          401     401        401          401          401         401       401
viewer             403     200        403/404      403          403/404     403       403
member             201     200        403/404      200          403/404     403       403
admin (same org)   201     200        200          200          200         204       200
admin (other org)  403     403/404    403/404      403/404      403/404     403/404   403
```

Fill it from the contract, then write one test per cell that is not obviously redundant. Use the project's convention consistently for "you may not see this": `403` (exists, forbidden) or `404` (hide existence) — mixing them leaks information.

Specific authorization cases that must be present:

- **Horizontal (IDOR)** — user A requests/updates/deletes user B's resource by swapping the ID in the path, query, or body. This is the single most common serious API bug; test it on every endpoint that takes an ID.
- **Vertical (privilege escalation)** — low role calls an admin endpoint; low role sets a privileged field (`role`, `isAdmin`, `orgId`, `ownerId`) in a create/update body — must be ignored or rejected, and the stored value must be checked afterwards.
- **Tenant / organisation isolation** — valid admin of tenant A cannot list, read or write tenant B's data, including via list filters, search, bulk endpoints, exports and "include related" params.
- **Ownership transfer and state** — permissions re-evaluated after a role change or ownership change (demoted admin loses access on the next request, not after re-login — unless the contract says tokens carry roles and documents the window).
- **Method coverage** — the same resource through `GET`, `POST`, `PUT`/`PATCH`, `DELETE`, and any bulk/batch or GraphQL mutation path. Authorization frequently exists on `GET` and is missing on `PATCH`.
- **Scoped tokens / API keys** — a token with `read` scope cannot write; a key limited to one project cannot touch another.
- **Field-level** — if the contract hides fields per role (e.g. salary visible to HR only), assert the field is absent, not just empty, for lower roles.

Authorization tests need fixtures for at least: anonymous client, one user per role, and a user in a second tenant. Create them in global setup from config, never hardcoded.

## Remaining coverage checklist per endpoint

After the three pillars, cover these groups unless they do not apply (say so in a comment rather than silently skipping):

**Happy path** — the main valid request returns the expected status and a response that matches the schema. Verify the *data*, not just the status.

**Not found and conflicts** — unknown ID → `404`; duplicate create → `409` or the project's convention; updating/deleting something already deleted.

**Idempotency and state** — `GET` after `POST` shows the created record; `DELETE` twice; `PUT` with the same body twice gives the same result; the resource is actually gone after delete (verify with a follow-up `GET`).

**Lists** — pagination (page 1, last page, beyond last page, page size limits), filtering, sorting direction, empty results returning `[]` not `null`, and that list filters respect authorization.

**Security smoke** — injection strings stored/escaped and not executed; oversized payloads rejected; rate limits, if present, return `429`; CORS and security headers if the contract specifies them.

**Side effects** — if an endpoint sends email, enqueues a job or writes an audit log, at least one test checks the effect through whatever is observable (mailbox stub, job table, audit endpoint).

## Assertion rules

These rules exist because weak assertions produce green tests that prove nothing.

- Assert status **and** body on every request. `expect(res.status()).toBe(200)` alone is not a test.
- Assert on values you derived independently (from the request you sent, from seed data, from the contract) — never on values copied from a previous run's output.
- Check error responses have the project's error envelope (message, code, field errors) so clients can rely on them.
- Prefer `toMatchObject` / schema validation for shape, exact `toEqual` for the fields the ticket is about.
- One behaviour per test. A test called "creates user" that also tests deletion will fail for the wrong reason and hide the real one.
- No conditional assertions (`if (res.ok()) expect(...)`) — a test must have one defined outcome.
- Avoid `expect(x).toBeTruthy()` on response data; it passes on `"undefined"` strings and `[]`.
- For authorization denials, also assert that **nothing changed**: after a `403` on update, `GET` the resource as the owner and confirm the old value.

## Test data and isolation

- Each test creates what it needs and cleans up after itself (`test.afterEach`/fixture teardown). Tests that rely on data left by another test are order-dependent and will flake under parallel runs.
- Use unique identifiers per run (timestamp or `crypto.randomUUID()` suffix) so parallel workers and re-runs never collide.
- Seed through the API or a documented seed script, not by hand in the UI.
- Never delete or modify data you did not create in that test.
- Keep fixtures small and named by purpose (`validUserPayload`, `expiredToken`, `otherTenantAdmin`), not `data1`.

## Configuration — nothing hardcoded

Base URL, credentials for every role, tenant/org IDs, tokens and environment names come from environment variables or a config file read at startup, with a clear error if missing. A test file should never contain a literal URL, email, password or API key. This keeps the suite portable between Dev/Staging/Prod and between projects, and keeps secrets out of git.

```ts
// playwright.config.ts (excerpt)
use: {
  baseURL: process.env.API_BASE_URL,            // required
  extraHTTPHeaders: { Accept: 'application/json' },
},
```

Obtain auth tokens once per worker per role in a fixture (login call or client-credentials flow) and reuse them; re-logging in per test is slow and hammers the auth server. Build expired/tampered tokens in a helper rather than waiting for real expiry.

## Playwright TypeScript pattern

Structure: `tests/api/<resource>/<resource>.<pillar-or-behaviour>.spec.ts` (e.g. `users.payload.spec.ts`, `users.auth.spec.ts`, `users.authz.spec.ts`), a thin `ApiClient` class per resource in `src/api/`, and auth/config in `fixtures/`. Keep the client dumb (build request, return response) so assertions live in the spec where a reviewer expects them.

```ts
import { test, expect } from '../../fixtures/api';

test.describe('POST /users — payload', { tag: ['@api', '@users', '@payload'] }, () => {
  test('creates a user and returns it with an id', async ({ api, uniqueEmail }) => {
    const payload = { email: uniqueEmail, name: 'QA User' };
    const res = await api.post('/users', { data: payload });

    expect(res.status()).toBe(201);
    const body = await res.json();
    expect(body).toMatchObject({ email: payload.email, name: payload.name });
    expect(body.id).toMatch(/^[0-9a-f-]{36}$/);
    expect(body).not.toHaveProperty('passwordHash');

    const fetched = await api.get(`/users/${body.id}`);
    expect(await fetched.json()).toMatchObject({ id: body.id, email: payload.email });
  });

  test('rejects a missing email with 400 and a field error', async ({ api }) => {
    const res = await api.post('/users', { data: { name: 'No Email' } });
    expect(res.status()).toBe(400);
    expect(await res.json()).toMatchObject({ errors: [{ field: 'email' }] });
  });

  test('ignores a privileged field sent by a normal member', async ({ memberApi, uniqueEmail }) => {
    const res = await memberApi.post('/users', { data: { email: uniqueEmail, name: 'x', role: 'admin' } });
    expect(res.status()).toBe(201);
    expect((await res.json()).role).toBe('member');
  });
});

test.describe('PATCH /users/{id} — authentication & authorization', { tag: ['@api', '@users', '@auth'] }, () => {
  test('returns 401 without a token', async ({ anonApi, seededUser }) => {
    const res = await anonApi.patch(`/users/${seededUser.id}`, { data: { name: 'x' } });
    expect(res.status()).toBe(401);
  });

  test('returns 401 for an expired token', async ({ apiWithToken, expiredToken, seededUser }) => {
    const res = await apiWithToken(expiredToken).patch(`/users/${seededUser.id}`, { data: { name: 'x' } });
    expect(res.status()).toBe(401);
  });

  test('member cannot update another user (IDOR) and nothing changes', async ({ memberApi, ownerApi, otherUser }) => {
    const res = await memberApi.patch(`/users/${otherUser.id}`, { data: { name: 'Hacked' } });
    expect([403, 404]).toContain(res.status());
    const after = await (await ownerApi.get(`/users/${otherUser.id}`)).json();
    expect(after.name).toBe(otherUser.name);
  });

  test('admin of another tenant cannot read this tenant\'s user', async ({ otherTenantAdminApi, seededUser }) => {
    const res = await otherTenantAdminApi.get(`/users/${seededUser.id}`);
    expect([403, 404]).toContain(res.status());
  });
});
```

Tag every test with `@api`, the resource, and the pillar (`@payload`, `@auth`, `@authz`) so CI can run or report each pillar separately. Name tests as sentences describing the behaviour and the expected result, so a failure in the report reads like a bug title.

## Review checklist (use for PR review or self-review)

Go through this list and name the file:line for anything missing:

1. Contract referenced (spec, schema or handler) and tests match it.
2. **Payload**: request-field matrix covered for every field the ticket touches (missing, empty, wrong type, boundary, format, unknown/read-only field); response validated by schema, round-tripped, and checked for leaks.
3. **Authentication**: no-token, malformed, expired and tampered token cases on every protected endpoint in scope.
4. **Authorization**: role × action matrix filled; IDOR, privileged-field, and cross-tenant cases present; denial tests confirm nothing changed.
5. Happy path, not-found, idempotency and list behaviour where applicable.
6. Every test asserts status and body; no truthy-only or conditional assertions.
7. No hardcoded URLs, credentials, IDs or tokens; a fixture exists per role and for a second tenant.
8. Tests create and clean up their own data; unique identifiers used.
9. No `waitForTimeout`/sleeps — API tests should never need them; async side effects use `expect.poll`.
10. Names and tags follow the repo convention; one behaviour per test; `tsc` and eslint clean; the suite passes locally twice in a row.

Report the result as **PASS** or **BLOCKED** with findings ordered by severity, each with file:line and a concrete fix. A missing pillar is always at least **High**.

## Scope and delivery

Keep each branch/PR to one resource or one feature and at most 10–15 tests, so review is quick and a failure is easy to locate. A natural split is one PR per pillar per resource (`users.payload`, `users.auth`, `users.authz`). Use the repo's existing branch naming convention. Write the PR description in detail: which endpoints, which pillars and coverage groups, which contract source, the role matrix used, how to run, and anything marked `fixme` with the open question. Do not add Claude as author, co-author or in any "generated with" line on commits or PRs.

## Plain-language glossary

- **Payload**: the data in a request body (what you send) or response body (what you get back).
- **Contract**: the agreed rules for an endpoint — what you send, what you get back.
- **Schema validation**: checking the response has the right fields with the right types, not just one value.
- **Authentication (authn)**: proving who you are — is the token valid?
- **Authorization (authz)**: what you are allowed to do — right role, right tenant, your own resource?
- **IDOR**: Insecure Direct Object Reference — changing an ID in the request to reach someone else's data.
- **Mass assignment**: the server blindly saving every field you send, including ones you should not be able to set (like `role`).
- **Tenant isolation**: data from one customer/organisation never visible to another.
- **Idempotent**: doing the same request twice gives the same result (safe to retry).
- **Flaky**: a test that sometimes passes and sometimes fails with no code change — almost always caused by shared data, timing, or order dependence.