---
name: screenshot-video-capture
description: "Capture screenshots and GIF recordings for QA test cases. PASS cases get green-badged full-page screenshots. FAIL cases get red-highlighted full-page screenshots + GIF reproduction. Badge is ALWAYS at bottom-right (never top-left). Attach to Linear using setInputFiles via Playwright MCP. Use this skill automatically for every test case result. Triggers on: test passed, test failed, ✅ pass, ❌ fail, screenshot, take screenshot, bug reproduction, capture failure, record failed test, failed test evidence, screenshot on failure, video on failure, reproduce bug steps, attach to Linear."
---

# Screenshot & Video Capture

Runs for every test case result. PASS → full-page green badge screenshot. FAIL → full-page red highlight screenshot + GIF reproduction.

**Badge placement: ALWAYS `bottom:12px;right:12px`. NEVER top-left.** Modals and confirmation dialogs appear center/top — bottom-right stays clear.

---

## Step 0 — Resolve Repo Root

```bash
REPO_ROOT="/sessions/friendly-admiring-mendel/mnt/eng-guardrails-platform"

if [ ! -d "$REPO_ROOT/.git" ]; then
  REPO_ROOT=$(find /sessions -maxdepth 5 -name ".git" -type d 2>/dev/null | head -1 | xargs dirname 2>/dev/null)
fi

[ -z "$REPO_ROOT" ] && echo "[ERROR] Cannot find repo root" && exit 1
echo "REPO_ROOT=$REPO_ROOT"
mkdir -p "$REPO_ROOT/manual-testing/evidences/$TICKET_KEY"
```

---

## Step 1 — Screenshot via Playwright MCP

### Get current URL from Claude in Chrome
```
mcp__Claude_in_Chrome__get_current_tab()
```

### Close irrelevant modals before screenshotting
If a modal is open that is NOT the evidence, close it first. Exception: if the modal IS what you're documenting, keep it open.

### Navigate Playwright MCP to same URL and inject badge

> **Page load rule:** Always wait for the page to be fully rendered. Use `browser_run_code_unsafe` with `waitForLoadState('networkidle')` + a 4-second buffer.

```javascript
// mcp__playwright__browser_run_code_unsafe
async (page) => {
  await page.goto('{URL from step above}', { waitUntil: 'domcontentloaded' });
  await page.waitForLoadState('networkidle').catch(() => {});
  await page.waitForTimeout(4000);
  return { url: page.url(), title: await page.title() };
}
```

**PASS — green badge, bottom-right:**
```javascript
// mcp__playwright__browser_evaluate
const label = document.createElement('div');
label.textContent = '✅ PASSED';
label.style.cssText = 'position:fixed;bottom:12px;right:12px;background:#16a34a;color:white;font-size:13px;font-weight:bold;padding:6px 12px;border-radius:6px;z-index:2147483647;box-shadow:0 2px 8px rgba(0,0,0,0.4);';
document.body.appendChild(label);
'done'
```

**FAIL — red highlight + red badge, bottom-right:**
```javascript
// mcp__playwright__browser_evaluate
const el = document.querySelector('{failing-selector}');
if (el) {
  el.style.outline = '4px solid red';
  el.style.outlineOffset = '2px';
  el.scrollIntoView({ behavior: 'instant', block: 'center' });
}
const label = document.createElement('div');
label.textContent = '❌ FAILED';
label.style.cssText = 'position:fixed;bottom:12px;right:12px;background:#dc2626;color:white;font-size:13px;font-weight:bold;padding:6px 12px;border-radius:6px;z-index:2147483647;box-shadow:0 2px 8px rgba(0,0,0,0.4);';
document.body.appendChild(label);
'done'
```

Save to disk — **always `fullPage: true`** to capture the entire page, not just the visible viewport:

PASS: `{TICKET_KEY}-TC{n}-PASS-{description}.png`
```
mcp__playwright__browser_take_screenshot(
  filename="/Users/belleung/Documents/guardrails/eng-guardrails-platform/manual-testing/evidences/{TICKET_KEY}/{TICKET_KEY}-TC{n}-PASS-{description}.png",
  fullPage=true
)
```

FAIL: `{TICKET_KEY}-TC{n}-FAIL-{description}.png`
```
mcp__playwright__browser_take_screenshot(
  filename="/Users/belleung/Documents/guardrails/eng-guardrails-platform/manual-testing/evidences/{TICKET_KEY}/{TICKET_KEY}-TC{n}-FAIL-{description}.png",
  fullPage=true
)
```

---

## Step 2 — GIF Recording (FAIL only)

One GIF per failed test case. Replaces multi-screenshot approach — single file, correct order, works on SSO-protected pages.

> **Verified working.** Must take `computer screenshot` after every action — actions alone do NOT add frames. `download: true` required on export.

```
# 1. Start recording
mcp__Claude_in_Chrome__gif_creator(action="start_recording", tabId={tabId})

# 2. First frame
mcp__Claude_in_Chrome__computer(action="screenshot", tabId={tabId})

# 3. Each repro step — screenshot after every action
mcp__Claude_in_Chrome__computer(action="left_click", coordinate=[x,y], tabId={tabId})
mcp__Claude_in_Chrome__computer(action="screenshot", tabId={tabId})
# ... repeat per step

# 4. Stop
mcp__Claude_in_Chrome__gif_creator(action="stop_recording", tabId={tabId})

# 5. Export
mcp__Claude_in_Chrome__gif_creator(
  action="export",
  tabId={tabId},
  filename="{TICKET_KEY}-TC{n}-FAIL-{description}.gif",
  download=true,
  options={"showClickIndicators": true, "showActionLabels": true, "showProgressBar": true, "showWatermark": false, "quality": 10}
)

# 6. Move to evidences
mv ~/Downloads/{TICKET_KEY}-TC{n}-FAIL-{description}.gif \
   "$REPO_ROOT/manual-testing/evidences/$TICKET_KEY/"
```

---

## Step 3 — Upload to Linear

**Must happen BEFORE posting the comment.**

```javascript
// mcp__playwright__browser_navigate(url="https://linear.app/persefoni/issue/{TICKET_KEY}")
// mcp__playwright__browser_wait_for(time=3000)
// mcp__playwright__browser_run_code_unsafe:
async (page) => {
  const fileInput = await page.locator('input[type="file"]').first();
  await fileInput.setInputFiles([
    '/sessions/<session-id>/mnt/eng-guardrails-platform/manual-testing/evidences/{TICKET_KEY}/file1.png',
    '/sessions/<session-id>/mnt/eng-guardrails-platform/manual-testing/evidences/{TICKET_KEY}/file2.png',
    '/sessions/<session-id>/mnt/eng-guardrails-platform/manual-testing/evidences/{TICKET_KEY}/file2.gif',
  ]);
  await page.waitForTimeout(5000);
  const attached = await page.evaluate(() =>
    Array.from(document.querySelectorAll('button'))
      .filter(b => b.ariaLabel && b.ariaLabel.includes('Download'))
      .map(b => b.ariaLabel.replace(' — Download', ''))
  );
  return { count: attached.length, files: attached };
}
```

Verify count matches expected before posting comment.
