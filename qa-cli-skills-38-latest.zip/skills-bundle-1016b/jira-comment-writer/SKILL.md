---
name: jira-comment-writer
description: "Write and post the Jira QA comment. Picks comment type automatically — PASS ✅, FAIL ❌ with root-cause, or clarification. CRITICAL: Posts as ADF JSON (contentFormat=adf) with mediaSingle image nodes — NOT !filename.png! markdown (renders as plain text in table cells). Upload files first, extract Atlassian Media UUIDs from img src, embed via mediaSingle. Follow Lan's GR-5146 format: 7-column table (empty | Test Case | Status | Expected Result | Actual Result | Reproduction Steps | Screenshot), Execution Summary as bullet list, h2 headings. Use whenever: write comment, post comment, QA comment, post results, comment on Jira ticket, verification comment, tag for review."
---

# Jira Comment Writer

Final step after QA execution. Posts the Jira comment as **ADF (Atlassian Document Format) JSON** with inline screenshot evidence, uploads artifacts, and transitions the ticket.

> **Critical:** All paths must be **absolute**. Container CWD is `/` — relative paths silently fail.
> **Upload first, comment second.** Images only embed inline if the file is already attached to the ticket when the ADF comment is posted.
> **ADF format required for inline images.** `!filename.png!` markdown does NOT embed images inside Jira table cells — it renders as plain text. You MUST use ADF `mediaSingle` nodes with Atlassian Media UUIDs.

---

## Step 0 — Resolve repo root

```bash
REPO_ROOT=$(find /sessions -maxdepth 5 -name ".git" -type d 2>/dev/null | head -1 | xargs dirname 2>/dev/null)
[ -z "$REPO_ROOT" ] && echo "[ERROR] Cannot find repo root" && exit 1
echo "REPO_ROOT=$REPO_ROOT"
```

---

## Pick Comment Type

| Situation | Type |
|-----------|------|
| Every TC passed | ✅ All Passed |
| Failures with clear root cause | ❌ Bug Report → auto-trigger `jira-ticket-writer` |
| Failures with ambiguous behaviour | ⚠️ Clarification |

Prefer Bug Report over Clarification whenever root cause is identifiable without hedging.

---

## ⚠️ CRITICAL: ADF Format for Inline Images

**NEVER use `!filename.png!` syntax in Jira table cells.** It renders as plain text — not as an image.

**The only way to embed inline images in a Jira table is via ADF (Atlassian Document Format)** using `mediaSingle` nodes with Atlassian Media UUIDs.

### How to get Media UUIDs

After uploading files via `setInputFiles`, inspect the page to extract UUIDs from the `img[src*="media-cdn"]` elements:

```javascript
// mcp__playwright__browser_run_code_unsafe
async (page) => {
  const imgs = await page.evaluate(() => {
    return Array.from(document.querySelectorAll('img[src*="media"]'))
      .map(img => ({
        alt: img.alt,
        uuid: (img.src.match(/\/file\/([a-f0-9-]{36})\//) || [])[1] ||
              (img.src.match(/[?&]id=([a-f0-9-]{36})/) || [])[1]
      }))
      .filter(i => i.uuid);
  });
  return imgs;
}
```

Match each filename (from `alt` attribute) to its UUID. This is the ID you put in the `mediaSingle` node.

### ADF mediaSingle cell structure (from Lan's GR-5146 reference)

```json
{
  "type": "tableCell",
  "attrs": {},
  "content": [
    {
      "type": "mediaSingle",
      "attrs": {"layout": "center"},
      "content": [
        {
          "type": "media",
          "attrs": {
            "type": "file",
            "id": "<ATLASSIAN-MEDIA-UUID>",
            "collection": "",
            "height": 183,
            "width": 200
          }
        }
      ]
    },
    {"type": "paragraph", "content": [{"type": "text", "text": " "}]}
  ]
}
```

For test cases with no screenshot (BE-only, Layer 2):
```json
{"type": "tableCell", "attrs": {}, "content": [{"type": "paragraph", "content": [{"type": "text", "text": "— "}]}]}
```

---

## Comment Format (Lan's GR-5146 style)

The canonical reference is Lan's comment on GR-5146. Key structural rules:
- **7 columns:** `(empty) | Test Case | Status | Expected Result | Actual Result | Reproduction Steps | Screenshot`
- **Leading empty column** holds the TC number (TC-01, TC-02, etc.)
- **Reproduction Steps column** — numbered steps so developers can reproduce and verify without guessing:
  - **PASS cases:** concise steps covering the happy path (e.g. "1. Navigate to the feature → 2. Perform the action → 3. Verify result")
  - **FAIL cases:** detailed and precise — include exact inputs, UI state at failure point, API payload if relevant, and the exact step where failure occurs. Developer must be able to reproduce end-to-end from this column alone without additional context.
- **Execution Summary** is a bullet list (not a table)
- **Headings** use `##` h2: "Execution Summary" and "Test Cases"
- **Technical values** use `code` marks
- **Comment is posted as ADF JSON** via `contentFormat: "adf"`

### ADF Comment Skeleton

```json
{
  "type": "doc",
  "version": 1,
  "content": [
    {
      "type": "paragraph",
      "content": [{"type": "text", "text": "QA Verification PASS ✅"}]
    },
    {
      "type": "bulletList",
      "content": [
        {"type": "listItem", "content": [{"type": "paragraph", "content": [
          {"type": "text", "text": "Date: "},
          {"type": "text", "text": "YYYY-MM-DD", "marks": [{"type": "code"}]}
        ]}]},
        {"type": "listItem", "content": [{"type": "paragraph", "content": [
          {"type": "text", "text": "Ticket: "},
          {"type": "text", "text": "GR-XXXX", "marks": [{"type": "code"}]}
        ]}]},
        {"type": "listItem", "content": [{"type": "paragraph", "content": [
          {"type": "text", "text": "Environment: "},
          {"type": "text", "text": "Dev — https://app.dev.firstrecon.ai", "marks": [{"type": "code"}]}
        ]}]},
        {"type": "listItem", "content": [{"type": "paragraph", "content": [
          {"type": "text", "text": "Tester: "},
          {"type": "text", "text": "belle.ung@persefoni.com", "marks": [{"type": "code"}]}
        ]}]},
        {"type": "listItem", "content": [{"type": "paragraph", "content": [
          {"type": "text", "text": "Scope: "},
          {"type": "text", "text": "Frontend + Backend", "marks": [{"type": "code"}]}
        ]}]}
      ]
    },
    {
      "type": "heading",
      "attrs": {"level": 2},
      "content": [{"type": "text", "text": "Execution Summary"}]
    },
    {
      "type": "bulletList",
      "content": [
        {"type": "listItem", "content": [{"type": "paragraph", "content": [{"type": "text", "text": "Total: "}, {"type": "text", "text": "N", "marks": [{"type": "code"}]}]}]},
        {"type": "listItem", "content": [{"type": "paragraph", "content": [{"type": "text", "text": "Passed: "}, {"type": "text", "text": "N", "marks": [{"type": "code"}]}]}]},
        {"type": "listItem", "content": [{"type": "paragraph", "content": [{"type": "text", "text": "Failed: "}, {"type": "text", "text": "0", "marks": [{"type": "code"}]}]}]},
        {"type": "listItem", "content": [{"type": "paragraph", "content": [{"type": "text", "text": "Skipped: "}, {"type": "text", "text": "0", "marks": [{"type": "code"}]}]}]},
        {"type": "listItem", "content": [{"type": "paragraph", "content": [{"type": "text", "text": "Blocked: "}, {"type": "text", "text": "0", "marks": [{"type": "code"}]}]}]}
      ]
    },
    {
      "type": "heading",
      "attrs": {"level": 2},
      "content": [{"type": "text", "text": "Test Cases"}]
    },
    {
      "type": "table",
      "attrs": {"isNumberColumnEnabled": false, "layout": "default"},
      "content": [
        {
          "type": "tableRow",
          "content": [
            {"type": "tableHeader", "attrs": {}, "content": [{"type": "paragraph", "content": [{"type": "text", "text": ""}]}]},
            {"type": "tableHeader", "attrs": {}, "content": [{"type": "paragraph", "content": [{"type": "text", "text": "Test Case"}]}]},
            {"type": "tableHeader", "attrs": {}, "content": [{"type": "paragraph", "content": [{"type": "text", "text": "Status"}]}]},
            {"type": "tableHeader", "attrs": {}, "content": [{"type": "paragraph", "content": [{"type": "text", "text": "Expected Result"}]}]},
            {"type": "tableHeader", "attrs": {}, "content": [{"type": "paragraph", "content": [{"type": "text", "text": "Actual Result"}]}]},
            {"type": "tableHeader", "attrs": {}, "content": [{"type": "paragraph", "content": [{"type": "text", "text": "Reproduction Steps"}]}]},
            {"type": "tableHeader", "attrs": {}, "content": [{"type": "paragraph", "content": [{"type": "text", "text": "Screenshot"}]}]}
          ]
        },
        {
          "type": "tableRow",
          "content": [
            {"type": "tableCell", "attrs": {}, "content": [{"type": "paragraph", "content": [{"type": "text", "text": "TC-01"}]}]},
            {"type": "tableCell", "attrs": {}, "content": [{"type": "paragraph", "content": [{"type": "text", "text": "Test case description"}]}]},
            {"type": "tableCell", "attrs": {}, "content": [{"type": "paragraph", "content": [{"type": "text", "text": "✅ Pass"}]}]},
            {"type": "tableCell", "attrs": {}, "content": [{"type": "paragraph", "content": [{"type": "text", "text": "Expected outcome"}]}]},
            {"type": "tableCell", "attrs": {}, "content": [{"type": "paragraph", "content": [{"type": "text", "text": "Actual outcome matched"}]}]},
            {"type": "tableCell", "attrs": {}, "content": [{"type": "paragraph", "content": [{"type": "text", "text": "1. Navigate to feature URL → 2. Perform the tested action → 3. Observe result"}]}]},
            {
              "type": "tableCell",
              "attrs": {},
              "content": [
                {
                  "type": "mediaSingle",
                  "attrs": {"layout": "center"},
                  "content": [
                    {"type": "media", "attrs": {"type": "file", "id": "<UUID-FROM-UPLOAD>", "collection": "", "height": 183, "width": 200}}
                  ]
                },
                {"type": "paragraph", "content": [{"type": "text", "text": " "}]}
              ]
            }
          ]
        }
      ]
    },
    {
      "type": "paragraph",
      "content": [{"type": "text", "text": "Summary narrative here."}]
    }
  ]
}
```

---

## Posting Workflow

### 1. Capture screenshots with Playwright

`save_to_disk` on `mcp__Claude_in_Chrome__computer` silently fails in Cowork. Always use Playwright:

```javascript
// mcp__playwright__browser_run_code_unsafe
async (page) => {
  await page.goto('{URL}', { waitUntil: 'domcontentloaded' });
  await page.waitForLoadState('networkidle').catch(() => {});
  await page.waitForTimeout(4000); // wait for JS-rendered content before screenshotting
  await page.evaluate(() => {
    const b = document.getElementById('qa-pass-badge');
    if (b) b.remove();
    const label = document.createElement('div');
    label.id = 'qa-pass-badge';
    label.textContent = '✅ PASSED';
    label.style.cssText = 'position:fixed;bottom:12px;right:12px;background:#16a34a;color:white;font-size:13px;font-weight:bold;padding:6px 12px;border-radius:6px;z-index:2147483647;box-shadow:0 2px 8px rgba(0,0,0,0.4);';
    document.body.appendChild(label);
  });
  await page.screenshot({
    path: '/sessions/<session>/mnt/eng-guardrails-platform/manual-testing/evidences/{TICKET_KEY}/{TICKET_KEY}-TC1-PASS-{desc}.png'
  });
  return 'saved';
}
```

For FAIL: red badge (`background:#dc2626`, text `❌ FAILED`) + red outline on failing element.

### 2. Upload all evidence files (BEFORE posting comment)

**This is the only working method in Cowork sessions.** Python scripts fail with 403.

Navigate to the Jira ticket and upload all at once. Do everything in one `browser_run_code_unsafe` call to avoid navigating away mid-upload:

```javascript
// mcp__playwright__browser_run_code_unsafe
async (page) => {
  await page.goto('https://persefoni.atlassian.net/browse/{TICKET_KEY}');
  await page.waitForTimeout(5000);
  const fileInput = page.locator('input[type="file"]').first();
  await fileInput.setInputFiles([
    '/sessions/<session>/mnt/eng-guardrails-platform/manual-testing/evidences/{TICKET_KEY}/file1.png',
    '/sessions/<session>/mnt/eng-guardrails-platform/manual-testing/evidences/{TICKET_KEY}/file2.png',
  ]);
  await page.waitForTimeout(8000);
  // Verify upload
  const url = page.url();
  const title = await page.title();
  return { url, title };
}
```

### 3. Extract Media UUIDs (stay on the Jira page)

```javascript
// mcp__playwright__browser_run_code_unsafe
async (page) => {
  const imgs = await page.evaluate(() => {
    return Array.from(document.querySelectorAll('img[src*="media"]'))
      .map(img => ({
        alt: img.alt,
        uuid: (img.src.match(/\/file\/([a-f0-9-]{36})\//) || [])[1] ||
              (img.src.match(/[?&]id=([a-f0-9-]{36})/) || [])[1]
      }))
      .filter(i => i.uuid);
  });
  return imgs;
}
```

Record the UUID for each uploaded file by matching `alt` to filename.

### 4. Post comment via Jira MCP as ADF

```
mcp__5e7d7dc5-7757-461d-8a63-33b4d9f8e532__addCommentToJiraIssue(
  cloudId="dce2ce03-4355-4e26-8af2-06995df138ef",
  issueIdOrKey="{TICKET_KEY}",
  contentFormat="adf",
  commentBody="<ADF JSON string>"
)
```

### 5. Transition if all passed

```
mcp__5e7d7dc5-7757-461d-8a63-33b4d9f8e532__getTransitionsForJiraIssue(
  cloudId="dce2ce03-4355-4e26-8af2-06995df138ef",
  issueIdOrKey="{TICKET_KEY}"
)
```

Find the "Ready to Release" / "qa passed" transition ID, then:

```
mcp__5e7d7dc5-7757-461d-8a63-33b4d9f8e532__transitionJiraIssue(
  cloudId="dce2ce03-4355-4e26-8af2-06995df138ef",
  issueIdOrKey="{TICKET_KEY}",
  transitionId="{id}"
)
```

### 6. Auto-trigger jira-ticket-writer (Bug Report only — MANDATORY)

If comment type is Bug Report, immediately invoke `jira-ticket-writer` for every failed TC. Do not wait for user confirmation.

---

## Status Transitions

| Outcome | Transition | Status |
|---------|-----------|--------|
| All passed | `qa passed` | → Ready to Release |
| Any failure | none | unchanged |
| Clarification | none | unchanged |

---

## Final Report

Output after completion:
- Ticket ID + URL
- Comment type (Pass / Bug Report / Clarification)
- Artifacts uploaded (filenames + count)
- TC count: passed / failed / skipped / blocked
- Bug tickets filed (if any, with links)
- Transition applied (if any)

---

## Fallback (if setInputFiles fails)

1. Post ADF comment via Jira MCP with Screenshot cells showing `"— (see attachments)"` text
2. Note evidence path: `/Users/belleung/Documents/guardrails/eng-guardrails-platform/manual-testing/evidences/{TICKET_KEY}/`
3. Tell user inline images require manual attachment and UUID extraction
