---
name: visual-smoke
description: "Run the daily UI visual smoke: compare today's screenshots against the last run, point out what changed, and flag new UI that has no test coverage. Triggers on: visual smoke, visual diff, UI diff, compare screenshots, what changed in the UI, daily UI check."
---

# Daily UI Visual Smoke

Drives the harness at `automation/visual-diff/` in eng-guardrails-platform: screenshots
every route, compares against the previous run, **names** what changed, and fails when a
control appeared that no spec covers.

Triggers: `Visual smoke`, `Visual diff`, `UI diff`, "compare the screenshots", "what changed
in the UI", "run the daily UI check", "what needs test coverage".

Read `automation/visual-diff/README.md` before changing anything in that folder.

## The run is one Playwright command

```bash
npx playwright test automation/visual-diff --project=chromium
```

That captures, compares, attaches before/after/diff images to the Playwright HTML report,
writes `test-reports/ui-diff/<run>_UI-Visual-Smoke.md`, and **fails the test when new UI
appeared**. Do not run a separate capture step — there isn't one any more.

Useful variants:

```bash
UI_DIFF_ROUTES=/admin,/settings npx playwright test automation/visual-diff --project=chromium
UI_DIFF_RUN_ID=2026-09-18 npx playwright test automation/visual-diff --project=chromium
UI_SMOKE_SOFT=1 npx playwright test automation/visual-diff --project=chromium
```

`UI_SMOKE_SOFT=1` downgrades new UI from a failure to an annotation. Use it when the user
wants a look rather than a gate, and say which mode you used.

## Workflow

### Step 1 — check for a baseline

```bash
ls automation/visual-diff/.snapshots/
```

Baselines are local and gitignored. If the folder is empty, say plainly that this run only
establishes the baseline and the first real comparison comes next run. Never invent a
comparison against nothing.

### Step 2 — run it

The sweep covers ~76 routes across 7 role groups and takes a while; it runs serially
because parallel workers would re-authenticate and race on the run folder. Routes with
`skipInSmokeTest` or `:params` are skipped automatically.

### Step 3 — read the result, not just the exit code

A failure message lists each new control with its route and testid. That is the finding.
Also check the annotations: `baseline created` (routes with no previous capture) and
`not compared` (routes that failed to load, or a viewport mismatch).

### Step 4 — get the coverage gaps and stubs

```bash
node automation/visual-diff/run.mjs diff --stubs
```

Cross-references each new control against the spec corpus and writes the gap report plus
`test.fixme` skeletons in `automation/visual-diff/stubs/`.

Use `run.mjs`, not `npx tsx` — tsx is broken in this repo (bundled esbuild is
version-mismatched: Host "0.28.2" vs binary "0.27.7"). `npm rebuild esbuild` fixes it; do
not run that without asking.

### Step 5 — report back in plain language

Lead with the count of routes that gained new UI. Then name the controls and their pages —
not selector internals, not pixel percentages. Link the report path. Do not paste the
whole report into chat, and do not paste raw region coordinates unless asked.

### Step 6 — hand off the stubs

Every generated test is `test.fixme` so it can never report green or count as coverage.
Tell the user each one still needs: the real TC ID in place of `@TC-TBD`; an assertion
about what the control *does* (state change, request fired, row updated) rather than that
it is visible; and a move into its proper feature folder. Tags must carry TC ID + App path
+ priority + `@regression` + env.

## Reading the output honestly

**The pixel percentage is not the finding.** Inserting one button reflows everything below
and beside it. Measured on a 4-row table with an Edit button added per row: 11 changed
regions, only 1 of them the new button. Regions whose text is unchanged but relocated are
classified `reflow` and collapsed to one line — report the real regions, never the reflow
count, and never the raw percentage as if it were severity.

**A page that grew is flagged as `sizeChanged`.** The percentage overstates it badly.
Say so rather than reporting a scary number.

**`restyle or new data`** means changed pixels that no control and no shifted text
explains. That is usually a CSS change or different seeded data — worth a look, not a
finding on its own.

**A control that disappeared** is a signal for a now-dead spec, not automatically a bug.

**An unreachable route is blocked, not clean.** Never let a route that failed to load read
as "nothing changed here".

## Never loosen these

A false "already covered" hides the exact thing this tool exists to find. Both of these
were real bugs during the build and are pinned by self-tests:

1. A control **with** a testid is matched only on its testid, contiguously. Matching on the
   visible label reported every new row action as covered, because "Edit" and "Delete"
   appear in most spec files.
2. Generated stubs are excluded from the spec corpus. Indexing them let the previous run's
   stub close its own gap.

After touching `findCoverage` or `labelRegions`:

```bash
node automation/visual-diff/run.mjs selftest
node automation/visual-diff/run.mjs visual-selftest   # needs npx playwright install chromium
```

Also never change `CAPTURE_VIEWPORT` casually — it invalidates every existing baseline, and
the spec refuses to compare captures taken at different viewports.

## Validation gates on this repo

- `npx tsc --noEmit -p tsconfig.eslint.json` — works; this is the config that includes
  `automation/`. Slow (>45s), so run with `nohup … &` then wait.
- `npx playwright test automation/visual-diff --project=chromium --list` — works, confirms
  collection (expect 8 tests in 1 file).
- `npx eslint` — **OOMs ("Killed") on the user's local VM even for one small file**, at
  `--max-old-space-size=8192`. That is the VM's memory ceiling, not a code problem. Never
  claim lint passed there; say it could not run.

A clean tsc and a clean `--list` prove the files compile and collect. They prove nothing
about whether an assertion can fail — say so when reporting.