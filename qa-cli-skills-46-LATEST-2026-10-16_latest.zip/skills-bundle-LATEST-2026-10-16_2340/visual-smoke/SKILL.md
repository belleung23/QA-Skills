---
name: "visual-smoke"
description: "Agent-run UI visual smoke for any web project: screenshot every page, compare with the last run, name what changed, flag new UI with no test, and hand the human a report plus screenshots to review. Triggers on: visual smoke, visual diff, UI diff, compare screenshots, what changed in the UI, daily UI check."
---

# UI Visual Smoke (agent-run, any project)

**The agent does the whole run. The human only reviews the report and the screenshots.**
Never end with "please run this command". If the agent cannot reach the app, say exactly what
blocked it (network, no browser, no session) and stop.

Triggers: `Visual smoke`, `Visual diff`, `UI diff`, "compare the screenshots", "what changed
in the UI", "run the daily UI check", "what needs test coverage".

What it does: screenshots every page, compares each with the previous run, **names** what
changed (new control, removed control, restyle, text that only moved), and lists new controls
that no existing test references.

## The tool (engine)

The engine is a folder of 9 files, `automation/visual-diff/`. Its home today is the
**eng-guardrails-platform** repo (`automation/visual-diff/`). Other projects do not have it;
Step 0 sets it up without changing the project's code.

| File | Role |
| --- | --- |
| `run.mjs` | entry point / loader — every command goes through it |
| `setup-deps.mjs` | `run.mjs setup`: makes the two libraries resolvable (no-op where installed) |
| `agent-capture.ts` | takes the screenshots from a JSON page list; reuses a saved login session |
| `capture-inventory.ts` | records the controls and text on each page |
| `compare-screenshots.ts` | pixel diff; names what changed; spots text that only moved |
| `diff-inventory.ts` | writes the report, coverage gaps and `test.fixme` stubs |
| `inventory-types.ts`, `pngjs.d.ts` | types |
| `README.md` | design notes — read before changing the engine |

`visual-smoke.spec.ts` + `capture-route.ts` (+ `__selftest__/`) also live there but are tied to
eng-guardrails-platform's own routes and login. Do not copy them to other projects.

Needs Node 22.18 or newer (`node --version`): `run.mjs` uses `module.registerHooks` and Node's
built-in TypeScript loading. Commands: `setup`, `capture`, `diff` (plus `selftest`,
`visual-selftest` inside eng-guardrails-platform).

## Login is not this skill's job

Login happens BEFORE the visual smoke: the project's own login skill or a person does it. This
skill only reuses the result, a Playwright storage-state file (cookies + local storage). It never
types credentials, never clicks through SSO, and never writes session files into the repo.

- Session file given → every page is captured with that login. Every page of that run is
  labelled `signed-in` — the label only means "a session file was passed", not that the login
  worked. The proof is the session check in Step 4.
- No session file → pages are captured as an anonymous visitor (fine for public pages).
- A session only works for the exact address it was made for (scheme + host + port). Serve or
  open the app at that address — check the `origin` / cookie `domain` inside the file.
- A page that bounces to a sign-in screen → **BLOCKED: redirected to a sign-in page — not logged
  in, or the session expired**. It is never compared. Report it so the login step can be re-run.
- Session file path given but missing → the capture refuses to start ("run the login step first")
  and writes nothing.

## Step 0 — set up the engine (skip if the project already has `automation/visual-diff/`)

1. Get the engine files listed in the table above from eng-guardrails-platform
   `automation/visual-diff/` (on the user's computer: list it, then stage ONLY those files —
   read only, never write there; never stage its `.snapshots/` (real baselines) or `__selftest__/`).
2. Put them in **your own scratch folder**, e.g. `<scratch>/vs-engine/automation/visual-diff/`,
   not inside the project. The project's code stays untouched.
3. Run `node <scratch>/vs-engine/automation/visual-diff/run.mjs setup`. It makes the engine's two
   libraries (`@playwright/test`, `pngjs`) resolvable: if they already resolve it does nothing;
   otherwise (e.g. npm blocked) it writes small stand-ins into `<scratch>/vs-engine/node_modules/`
   (needs the global `playwright` package, preinstalled in the cloud container). Running it again
   is harmless.
4. **Always run commands from the project root** and call the engine by its scratch path:
   `cd <project> && node <scratch>/vs-engine/automation/visual-diff/run.mjs …`.
   The report (`test-reports/ui-diff/`), stubs (`automation/visual-diff/stubs/`), saved
   screenshots (`automation/visual-diff/.snapshots/`) and the spec corpus it searches for
   coverage (`automation/`) are all resolved from the folder you run it in.
5. **Saved screenshots (the baseline) must survive until the next run and must not be
   committed.** Keep them in the project at `automation/visual-diff/.snapshots/` (the default —
   no `--root` needed). If the project's `.gitignore` doesn't already cover that folder, add the
   line `automation/visual-diff/.snapshots/` and tell the human. Never keep the baseline only in
   your scratch folder: it is deleted with the session and tomorrow's run would have nothing to
   compare against. If the project folder itself is temporary, say plainly that the baseline
   will not survive.
6. **Save the page list(s) in the project too**, at `automation/visual-diff/pages.json` (or
   `pages-<release>.json`), so the next run reuses exactly the same `path` keys.
7. The run's deliverables land in the project on purpose: the report folder
   `test-reports/ui-diff/` and the stubs `automation/visual-diff/stubs/`. Don't commit anything
   yourself; tell the human which files are new.

Below, `RUN` means `node <engine>/automation/visual-diff/run.mjs` (the scratch path from Step 0,
or the project's own `automation/visual-diff/run.mjs` if it has the engine).

## Step 1 — make sure the browser can reach the app

Chromium is preinstalled in the cloud container (`PLAYWRIGHT_BROWSERS_PATH=/opt/pw-browsers`);
the user's VM usually has none. Check reachability first: `curl -s -o /dev/null -w '%{http_code}' <url>`
for one or two pages. **Only `200` counts as reachable** — a 404/500 means wrong address or the
wrong server; fix that before capturing.

- **Hosted app:** a proxy `connect_rejected` means the host is not on the egress allowlist —
  report BLOCKED, don't work around it.
- **Static build / local app:** serve it yourself (`python3 -m http.server <port> --bind
  127.0.0.1` from the folder, or `npm run preview`) and stop the server when done. Make sure the
  port isn't already used by something else (`curl` it BEFORE starting your server: it should
  fail), and that the page you get back is your app (check its `<title>`).
- Two releases side by side (e.g. `site/v1`, `site/v2`): serve their parent folder ONCE (at the
  session's address if there is a session file), give each release its own `baseUrl` by path
  (`…/v1/`, `…/v2/`), write one page list per release with the SAME `path` keys, and capture
  each release under its own run id.
- If a session file is in play, serve at the address it was made for (see "Login" above).

Never drive the human's real logged-in browser into an app they did not name for this run.

## Step 2 — check for a baseline

`ls automation/visual-diff/.snapshots/` (or your `--root`). Each run is a folder named by run id.
Reuse `automation/visual-diff/pages*.json` from the last run if it exists.
If there is no earlier run, today's capture only creates the baseline — say so plainly; the first
real comparison is next run. Never invent a comparison against nothing. (If you were given two
releases to compare in one go, capture both now under the run ids you were given.)

## Step 3 — write the page list

```json
{ "baseUrl": "https://app.example.test/",
  "storageState": "auth/state.json",
  "routes": [ { "path": "/users", "url": "users", "name": "Users" } ] }
```

`path` is the stable key used to match runs (keep it identical every day); `url` is resolved
against `baseUrl` (defaults to `path`). `storageState` is optional (or pass
`--storage-state <file>`). `loginPagePattern` (a regex on the final URL + title) overrides the
default sign-in detector if the app's login page has an unusual address.

Which pages: every page a user can open — take them from the project's route list, router
config or sitemap if it has one, otherwise from the built pages / menu, and include pages not in
the menu. Skip routes with `:params` and the sign-in page itself. A page that only exists in the
newer release goes only in the newer list (listing it in the older one would produce a fake
"did not load"); it is reported as a new page.

## Step 4 — capture

```bash
cd <project> && RUN capture --config <pages.json> --run <run-id> [--storage-state <file>] [--root <dir>]
```

Same conditions every run: viewport 1440×900, page scrolled once for lazy content, animations
off, caret hidden. A page is recorded `BLOCKED` with the reason — never compared — when it fails
to load, returns an HTTP error ("page returned HTTP 404"), or lands on a sign-in screen. The next
page starts in a fresh tab so one broken page can't knock out the next.

**Check the session worked:** with a session file, any `BLOCKED … sign-in page` line means the
session is missing, expired or for another address — stop and report it rather than comparing.
Also open one members-only page's screenshot (`<snapshots>/<run>/<page>.png`) and confirm it
shows signed-in content.

**eng-guardrails-platform only:** that repo also has a one-command Playwright run that uses its
own login fixtures (~76 routes, 7 role groups): `npx playwright test automation/visual-diff
--project=chromium` (variants: `UI_DIFF_ROUTES=/admin,/settings`, `UI_DIFF_RUN_ID=<id>`,
`UI_SMOKE_SOFT=1` to annotate instead of fail — say which mode you used). Read the failure
message and the `baseline created` / `not compared` annotations, not just the exit code.

## Step 5 — compare

```bash
cd <project> && RUN diff --from <older-run> --to <newer-run> --stubs [--root <dir>]
```

Always pass `--from` and `--to`; without them it silently takes the two newest run folders.
Use `run.mjs`, never `npx tsx` or `node file.ts` (only `run.mjs` resolves the engine's imports).

Output, all under `<project>/test-reports/ui-diff/`:
`<to>_UI-Visual-Smoke.md` (the report), `<to>-diff-images/` (red = changed pixels, cyan box = a
detected change), `<to>-screenshots/` (`<page>-before.png` / `<page>-after.png` for every changed
page, `<page>-new-page.png` for new pages). Unchanged pages are not copied; their screenshots stay
in the saved-captures folder (`<snapshots>/<run>/<page>.png`) — mention it, hand over on request.

## Step 6 — check your own output, then hand it over

Open (Read) the diff image of every page marked changed and confirm the boxes sit on what the
report claims. Then report in plain language:

- how many pages gained new UI, and which controls (by visible name and page)
- removed controls, restyles, and pages that were blocked (did not load, HTTP error, needed
  login — with the reason)
- the paths of the report, diff images and screenshots folder

If you are the agent talking to the human: deliver those files into the chat as well. If you
are a sub-agent: return the paths to the agent that called you; it delivers them.
Your summary uses plain words: no pixel percentages as severity, no region coordinates, no
selector internals unless asked. (The report file itself does show percentages and coordinates —
they help a reviewer find the spot; leave them.) Do not paste the whole report into chat.

Add your own judgement where the tool can't: e.g. a control marked "already referenced" whose
only reference is in a spec for a DIFFERENT page is probably still a gap — say so and count it
in your summary (the tool writes no stub for it; don't hand-write one); a style change on one
page but not its siblings may be half-finished — say so; a new page no menu links to may be
unreachable — say so; an existing spec that uses a removed control is now a dead test — say so.

Reading the counts: "Compared N routes" counts only pages present in BOTH runs; new pages are
listed separately under "New routes", so N is one less per new page — not a skipped page.

## Step 7 — stubs

`--stubs` writes `test.fixme` skeletons to `automation/visual-diff/stubs/` — they can never pass
or count as coverage. Pages captured by `agent-capture` get plain `@playwright/test` stubs (env
tag `@env-TBD`); signed-in pages also get a `test.use({ storageState: 'TODO-…' })` line to point
at the project's login file. eng-guardrails-platform role pages use that repo's auth fixture. A
testid with a row number becomes a pattern (`getByTestId(/^user-row-\d+-edit$/)`). Each stub
still needs: the real TC ID instead of `@TC-TBD`; the page's real URL (the stub uses the page
key); an assertion about what the control DOES (state change, request fired, row updated), not
that it is visible; and a move into its feature folder with the project's tags (TC ID + App path
+ priority + `@regression` + env).

## Reading the output honestly

- **Pixel % is not severity.** One inserted button reflows everything beside it.
- **Reflow** = the same text, but at a different place — within 40px, or anywhere along the same
  row or column (a new table column re-divides widths and slides headers 60–170px). The spot
  text moved away from also counts. Reflow regions are counted ("Plus N region(s)…"), not listed.
  When a change also makes rows taller, the whole table can merge into ONE region named after the
  new control, so no separate reflow line appears — that is correct too.
- **"no control changed — restyle, copy edit, or different data"** = pixels changed but no control
  changed and no text moved (e.g. a new header colour, a new column heading). Its text is shown.
  Worth a look, not a finding on its own.
- **A page that grew** (`sizeChanged`) overstates its percentage badly — say so.
- **A new page** only lists controls not seen on any page last run — shared nav links are not
  new features.
- **A blocked page** (did not load, HTTP error, needed login) → "page did not load in <run>:
  <reason>"; it produces no added/removed controls. Blocked is never "clean" and never
  "everything disappeared".
- **A control that disappeared** signals a now-dead spec, not automatically a bug.
- **Already referenced by a spec** only means the testid/label string appears somewhere under
  `automation/` — even in a comment. It does not prove the spec asserts the behaviour.

## Never loosen these

1. A control **with** a testid is matched only on its testid, contiguously — never on its visible
   label ("Edit"/"Delete" appear in most spec files and would hide every new row action).
2. Generated stubs are excluded from the coverage search, or last run's stub closes its own gap.
3. Never change the 1440×900 viewport casually — it invalidates every baseline, and comparisons
   across viewports are refused.

## Testing this skill (no real project needed)

Planted-change test in the cloud container: a small made-up site with `v1` and `v2`; capture v1
twice (noise check) and v2 once, then diff. Write the planted changes down BEFORE comparing, then
grade each row. Verified 2026-10-16: "Taskly" demo, 3 fresh agents given only this skill, and a
4th fresh agent that built its own site ("Shelfwise") and passed every row.

| Planted in v2 | Must report |
| --- | --- |
| nothing (v1 → v1 again) | 0 of N pages changed, 0 gaps |
| Edit button per table row (testid) | NEW Edit + coverage gap; shifted headings counted as reflow, or merged into the Edit region if rows got taller |
| removed Export button | GONE Export, in "controls that disappeared" |
| header colour change only | restyle row ("no control changed"), not reflow, no new UI |
| new switch without testid | NEW switch, P3 gap "ask the dev to add a testid" |
| identical page | not listed as changed |
| new page sharing the nav | new route; only its own button, not the nav links |
| page pointed at a dead address (closed port, e.g. 127.0.0.1:59999) | "page did not load" with the error; no fake removals |
| page that returns 404 | BLOCKED "page returned HTTP 404"; no fake removals |
| a spec using the word "Edit" only as a label | Edit still a gap (trap 1) |
| re-run diff after stubs exist | gap count unchanged (trap 2) |
| members-only page, no session | BLOCKED "redirected to a sign-in page" |
| same page with a saved session file | captured as the real page (own heading and controls) |
| session file path that doesn't exist | capture refuses to start; no empty run folder left |

In eng-guardrails-platform there are also two built-in self-tests — run them after changing the
engine: `RUN selftest` (3 gaps, 1 new route, `budget-create-button` not a gap) and
`RUN visual-selftest` (1 real region, 10 reflow; needs a browser → cloud container). In the
user's VM, `selftest`'s final `rmSync` throws EPERM (the sandbox can't delete) — read the
verdict from a copy without that line.

## Changing the engine (validation gates)

- Edit the engine only in eng-guardrails-platform (its home), then re-run the planted-change test.
- Type-check just the engine on the user's VM (~4 GB RAM): full `tsc -p tsconfig.eslint.json` and
  `eslint` run out of memory there — never claim they passed. Use a temp config in `$HOME`
  extending `automation/tsconfig.json`, with `types:["node"]`,
  `typeRoots:["<repo>/node_modules/@types"]`, `include:[]`, and the visual-diff files in `files`.
  Expect 0 errors under `automation/visual-diff/`.
- Strict mode (`noUncheckedIndexedAccess`): guard array reads with `?? 0` or
  `const [first] = items; if (!first) …`, not `!` (non-null assertion is a lint warning).
- `pngjs` types come from the local `pngjs.d.ts`; don't add `@types/pngjs` without asking.
- eng-guardrails-platform: `npx playwright test automation/visual-diff --list` → 8 tests in 1 file.
- After copying a changed file onto the user's computer, stage it under a NEW path each time and
  confirm the content landed (compare a `sha256sum`), not just the "written" message — a stale
  copy has landed before.
- Polling a background tsc: `pgrep -f "tsc --noEmit"` matches the shell wrapper itself; use
  `ps -eo args | grep "[b]in/tsc"`.

Clean tsc and `--list` prove compile and collection only, not that an assertion can fail.