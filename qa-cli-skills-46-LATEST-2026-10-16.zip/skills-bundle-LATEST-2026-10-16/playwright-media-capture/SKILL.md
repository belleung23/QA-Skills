---
name: "playwright-media-capture"
description: "Capture screenshots (snapshots) and GIF recordings for QA test cases. PASS gets a green-badged screenshot, FAIL gets red-highlighted screenshot + GIF reproduction. Attach evidence to Linear via the Linear connector (prepare → PUT → finalize). Triggers on: screenshot, snapshot, screen recording, test passed, test failed, ✅ pass, ❌ fail, capture evidence, record bug, save evidence, highlight failing element, bug reproduction, attach to Linear."
---

# Playwright Media Capture

Runs for **every test case** — PASS and FAIL both get screenshots. GIF recordings are for FAIL only.

**Badge placement rule: ALWAYS bottom-right (`bottom:12px;right:12px`). NEVER top-left.** Top-left overlaps modals, dialogs, and confirmation boxes that appear in the center/top of the viewport. Bottom-right stays clear.

> Files are saved using **absolute paths** in the repo workspace — never relative paths, never a temp folder.
>
> **Workspace (persistent):** `/Users/belleung/Documents/guardrails/eng-guardrails-platform/` — survives sessions. In the Mac sandbox shell it is `$HOME/mnt/eng-guardrails-platform/`; Playwright on the Mac uses the `/Users/belleung/...` path directly.

> **Fixed 2026-10-16 (verified on FRAI-8354 — Part 1 PASS and FAIL, Part 3 upload):**
> - `mcp__playwright__browser_take_screenshot` hangs ("waiting for fonts"). Screenshot with `browser_run_code_unsafe` on a **fresh page** instead (Part 1).
> - `upload_linear_file.py` is not in the repo, needs an API key that is not configured, and the cloud sandbox cannot reach Linear's storage host. Upload through the **Linear connector** + a PUT from the Mac's Playwright process instead (Part 3).
> - The release state is named **`Ready for Release`** (not "Ready To Release").
> - A sibling skill, `qa-evidence-capture`, does the same chain in one call with element outlines and labels; prefer it when a FAIL needs the failing element outlined.

---

## When to Capture

| Situation | Snapshot | Recording |
|-----------|----------|-----------|
| ✅ Pass (UI) | ✅ Green badge bottom-right | Never |
| 🔍 BE-only | ✅ Green badge if UI visible | Never |
| ❌ Fail (UI) | ✅ Red highlight + red badge bottom-right | ✅ GIF repro steps |

---

## Part 0 — Paths (once per ticket)

```bash
REPO_ROOT="$HOME/mnt/eng-guardrails-platform"      # device_bash on the Mac
mkdir -p "$REPO_ROOT/manual-testing/evidences/$TICKET_KEY"
mkdir -p "$REPO_ROOT/manual-testing/test-results/done"
```

Create the evidence folder **before** the first screenshot — `page.screenshot` hangs on a missing folder.

Naming: `{TICKET_KEY}-TC{n}-PASS-{description}.png`, `{TICKET_KEY}-TC{n}-FAIL-{description}.png`, `{TICKET_KEY}-TC{n}-FAIL-{description}.gif`.

---

## Part 1 — Screenshot (PASS and FAIL)

Claude in Chrome drives the testing; Playwright MCP captures evidence.

**Step 1.** Get the current URL from Chrome (`tabs_context_mcp`).

**Step 2.** If a modal is open that is NOT the evidence, close it first (Escape, or its close button). If the modal IS the evidence, keep it.

**Step 3.** One `browser_run_code_unsafe` call on a **fresh page** — never the shared `page`, it gets stuck:

```javascript
async (page) => {
  const URL = '{same URL as Chrome}';
  const OUT = '/Users/belleung/Documents/guardrails/eng-guardrails-platform/manual-testing/evidences/{TICKET_KEY}/{TICKET_KEY}-TC{n}-{PASS|FAIL}-{desc}.png';
  const RESULT = 'PASS';                      // or 'FAIL'
  const FAILING = '';                         // FAIL only: CSS selector of the failing element
  const p = await page.context().newPage();
  await p.setViewportSize({ width: 1440, height: 900 });
  await p.goto(URL, { waitUntil: 'domcontentloaded' });
  await p.waitForLoadState('networkidle').catch(() => {});
  await p.waitForTimeout(2000);
  await p.evaluate(({ result, failing }) => {
    if (failing) {
      const el = document.querySelector(failing);
      if (el) { el.style.outline = '4px solid red'; el.style.outlineOffset = '2px'; el.scrollIntoView({ behavior: 'instant', block: 'center' }); }
    }
    const label = document.createElement('div');
    label.textContent = result === 'PASS' ? '✅ PASSED' : '❌ FAILED';
    label.style.cssText = 'position:fixed;bottom:12px;right:12px;background:' + (result === 'PASS' ? '#16a34a' : '#dc2626') + ';color:white;font-size:13px;font-weight:bold;padding:6px 12px;border-radius:6px;z-index:2147483647;box-shadow:0 2px 8px rgba(0,0,0,0.4);white-space:nowrap;';
    document.body.appendChild(label);
  }, { result: RESULT, failing: FAILING });
  const highlighted = FAILING ? await p.evaluate((s) => !!document.querySelector(s), FAILING) : null;
  const buf = await p.screenshot({ path: OUT, fullPage: true, timeout: 20000 });
  await p.close();
  return { bytes: buf.length, path: OUT, highlighted };
}
```

**Read the result.** On a FAIL, `highlighted: false` means the failing element was not found — the shot is a bare screen. Fix the selector (or the page state) and retake; do not ship it as evidence.

Verify on disk: `ls -l "$REPO_ROOT/manual-testing/evidences/$TICKET_KEY/"` — note the exact byte size, Part 3 needs it.

---

## Part 2 — GIF Recording (FAIL only)

One GIF per failed TC. `gif_creator` only adds a frame when you call `computer screenshot`; actions alone add nothing, and identical consecutive frames are collapsed. Run **strictly in order, one call at a time** — never batch start/stop with the screenshots.

1. `gif_creator(action="start_recording", tabId)`
2. `computer(action="screenshot", tabId)` — initial state
3. For each repro step: do the action (`left_click`, `navigate`, `type`…), then `computer(action="screenshot", tabId)`
4. `computer(action="screenshot", tabId)` — final failure state
5. `gif_creator(action="stop_recording", tabId)`
6. `gif_creator(action="export", tabId, filename="{TICKET_KEY}-TC{n}-FAIL-{description}.gif", download=true, options={"showClickIndicators": true, "showActionLabels": true, "showProgressBar": true, "showWatermark": false, "quality": 10})`
7. The GIF lands in `~/Downloads` on the Mac. **Copy** it (the sandbox cannot delete, so `mv` fails):

```bash
cp "$HOME/mnt/Downloads/{TICKET_KEY}-TC{n}-FAIL-{description}.gif" "$REPO_ROOT/manual-testing/evidences/$TICKET_KEY/"
```

(Needs `~/Downloads` connected as a folder; ask for it with `device_request_folder_access` if it is not.)

---

## Part 3 — Upload to Linear (one file at a time)

The signed upload URL expires in **60 seconds**: do prepare → PUT → finalize for one file before preparing the next. Never batch the prepare calls.

**3a. Prepare** (Linear connector):
`prepare_attachment_upload(issue="{TICKET_KEY}", filename, contentType, size)` — `size` is the exact byte count from `ls -l`; `contentType` is `image/png` or `image/gif`. Note `assetUrl`, `uploadRequest.url` and `uploadRequest.headers`.

**3b. PUT the bytes** from the Mac's Playwright process (it has normal network; the sandbox shells do not):

```javascript
async (page) => {
  const FILE = '/Users/belleung/Documents/guardrails/eng-guardrails-platform/manual-testing/evidences/{TICKET_KEY}/{file}';
  const URL = '{uploadRequest.url}';
  const HEADERS = { /* uploadRequest.headers verbatim, same key casing */ };
  const p = await page.context().newPage();
  await p.setContent('<input type="file" id="f">');
  await p.setInputFiles('#f', FILE);
  const b64 = await p.evaluate(() => new Promise((res) => { const f = document.getElementById('f').files[0]; const r = new FileReader(); r.onload = () => res(r.result.split(',')[1]); r.readAsDataURL(f); }));
  await p.close();
  const data = Buffer.from(b64, 'base64');
  const r = await page.request.put(URL, { data, headers: HEADERS, timeout: 30000 });
  return { status: r.status(), bytes: data.length };
}
```

Expect `status: 200` and `bytes` equal to the prepared `size`. Anything else → prepare again and retry.

**3c. Finalize**: `create_attachment_from_upload(issue="{TICKET_KEY}", assetUrl, title=filename)`.

Record `filename → assetUrl` for every file — Part 4/5 embed them with `![name](assetUrl)`.

> If a `.dev.vars` with `TESTING_LINEAR_API_KEY` exists in the repo, `linear-comment-writer/scripts/upload_linear_file.py` is an alternative — but only from a shell that can reach `storage.googleapis.com`, which neither sandbox can today.

---

## Part 4 — Result File

Save to: `$REPO_ROOT/manual-testing/test-results/{TICKET_KEY}_result_{passed|failed}.md`

| Outcome | Filename |
|---------|---------|
| All passed | `_result_passed.md` |
| > 50% failed | `_result_failed.md` |
| ≤ 50% failed | `_result_passed.md` |

```markdown
# Test Result: {TICKET_KEY}

**Date**: {YYYY-MM-DD}
**Tested by**: belle.ung@persefoni.com
**Environment**: Dev (https://app.dev.firstrecon.ai)
**Overall**: PASSED | FAILED | PARTIAL

## Summary
[What was tested, what passed, what failed.]

## Test Cases

| # | Type | Description | Status | Screenshot | Recording |
|---|------|-------------|--------|------------|-----------|
| 1 | Happy Path | [desc] | ✅ Pass | ![{TICKET_KEY}-TC1-PASS-desc.png](ASSET_URL) | — |
| 2 | Negative | [desc] | ❌ Fail | ![{TICKET_KEY}-TC2-FAIL-desc.png](ASSET_URL) | ![{TICKET_KEY}-TC2-FAIL-desc.gif](ASSET_URL) |

## Failed Test Cases — Detail

### TC-{n}: [title]
**AC**: AC#{n} — [verbatim text]
**Steps to Reproduce**:
1. Navigate to [URL]
2. [action]
3. Observe: [what happened]
**Expected**: [per AC]
**Actual**: [exactly what appeared]
**Screenshot**: ![...](ASSET_URL)
**Recording**: ![...](ASSET_URL)

## Evidence Files
- Location: /Users/belleung/Documents/guardrails/eng-guardrails-platform/manual-testing/evidences/{TICKET_KEY}/
```

`ASSET_URL` is the real `assetUrl` recorded in Part 3.

---

## Part 5 — Post Linear Comment

Hand off to `linear-comment-writer`: it posts the result-file content with the Linear connector's `save_comment(issueId, body)` as plain Markdown. Then open the issue in Chrome and confirm the images render (reload once if the newest comment is not shown).

If all passed, hand off to `linear-ticket-transition` (connector `save_issue(id, state="Ready for Release")` — one call, no intermediate states).

Move the result file to done:
```bash
mv "$REPO_ROOT/manual-testing/test-results/${TICKET_KEY}_result_"*.md "$REPO_ROOT/manual-testing/test-results/done/"
```

---

## File Flow

```
Claude in Chrome → drives all UI testing
  ↓ each test case result
Playwright run_code (fresh page) → badge → screenshot(fullPage) → PNG in evidences/

  ↓ FAIL only
gif_creator start → screenshot → [action + screenshot] × N → stop → export(download) → cp ~/Downloads → evidences/

  ↓ upload, one file at a time
prepare_attachment_upload → PUT (Playwright on the Mac) → create_attachment_from_upload → assetUrl

  ↓ comment
save_comment with ![name](assetUrl) inline → verify in Chrome
```

---

## Badge Placement — Why Bottom-Right

Modals and overlays appear center/top of viewport. Bottom-right (`bottom:12px;right:12px`) stays clear. Use `z-index:2147483647` so the badge is never covered, and `white-space:nowrap` so it stays on one line.