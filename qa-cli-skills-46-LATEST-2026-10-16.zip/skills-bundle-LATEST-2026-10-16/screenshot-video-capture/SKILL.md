---
name: "screenshot-video-capture"
description: "Capture screenshots and GIF recordings for QA test cases. PASS cases get green-badged full-page screenshots. FAIL cases get red-highlighted full-page screenshots + GIF reproduction. Badge is ALWAYS at bottom-right. Attach to Linear via the Linear connector (prepare → PUT → finalize). Use automatically for every test case result. Triggers on: test passed, test failed, ✅ pass, ❌ fail, screenshot, take screenshot, bug reproduction, capture failure, record failed test, failed test evidence, screenshot on failure, video on failure, reproduce bug steps, attach to Linear."
---

# Screenshot & Video Capture

Runs for every test case result. PASS → full-page green badge screenshot. FAIL → full-page red highlight screenshot + GIF reproduction.

**Badge placement: ALWAYS `bottom:12px;right:12px`. NEVER top-left.** Modals and confirmation dialogs appear center/top — bottom-right stays clear.

> This skill is the short form of `playwright-media-capture` (same capture rules, same upload path). For FAILs that need the failing element outlined and labelled, use `qa-evidence-capture`.

> **Fixed 2026-10-16 (verified on FRAI-8354):** `browser_take_screenshot` hangs → screenshot via `browser_run_code_unsafe` on a fresh page. The old Step 3 (`setInputFiles` on the Linear issue page) is replaced by the Linear connector upload, which does not need the issue page open at all.

---

## Step 0 — Paths

```bash
REPO_ROOT="$HOME/mnt/eng-guardrails-platform"      # device_bash on the Mac
mkdir -p "$REPO_ROOT/manual-testing/evidences/$TICKET_KEY"
```

Playwright on the Mac writes to the same folder as `/Users/belleung/Documents/guardrails/eng-guardrails-platform/manual-testing/evidences/{TICKET_KEY}/`. Create it first or `page.screenshot` hangs.

---

## Step 1 — Screenshot via Playwright (fresh page)

Get the URL from Chrome (`tabs_context_mcp`). Close any modal that is NOT the evidence (keep it if the modal IS the evidence). Then:

```javascript
// mcp__playwright__browser_run_code_unsafe
async (page) => {
  const URL = '{URL from Chrome}';
  const OUT = '/Users/belleung/Documents/guardrails/eng-guardrails-platform/manual-testing/evidences/{TICKET_KEY}/{TICKET_KEY}-TC{n}-{PASS|FAIL}-{description}.png';
  const RESULT = 'PASS';          // or 'FAIL'
  const FAILING = '';             // FAIL only: selector of the failing element
  const p = await page.context().newPage();
  await p.setViewportSize({ width: 1440, height: 900 });
  await p.goto(URL, { waitUntil: 'domcontentloaded' });
  await p.waitForLoadState('networkidle').catch(() => {});
  await p.waitForTimeout(2000);
  await p.evaluate(({ result, failing }) => {
    if (failing) { const el = document.querySelector(failing); if (el) { el.style.outline = '4px solid red'; el.style.outlineOffset = '2px'; el.scrollIntoView({ behavior: 'instant', block: 'center' }); } }
    const label = document.createElement('div');
    label.textContent = result === 'PASS' ? '✅ PASSED' : '❌ FAILED';
    label.style.cssText = 'position:fixed;bottom:12px;right:12px;background:' + (result === 'PASS' ? '#16a34a' : '#dc2626') + ';color:white;font-size:13px;font-weight:bold;padding:6px 12px;border-radius:6px;z-index:2147483647;box-shadow:0 2px 8px rgba(0,0,0,0.4);white-space:nowrap;';
    document.body.appendChild(label);
  }, { result: RESULT, failing: FAILING });
  const highlighted = FAILING ? await p.evaluate((s) => !!document.querySelector(s), FAILING) : null;
  const buf = await p.screenshot({ path: OUT, fullPage: true, timeout: 20000 });
  await p.close();
  return { bytes: buf.length, path: OUT, highlighted };
}
```

On a FAIL, `highlighted: false` = bare screen → fix the selector and retake. Note `bytes`; the upload needs the exact size.

Naming: PASS `{TICKET_KEY}-TC{n}-PASS-{description}.png`, FAIL `{TICKET_KEY}-TC{n}-FAIL-{description}.png`.

---

## Step 2 — GIF Recording (FAIL only)

One GIF per failed test case. A frame is captured only on `computer screenshot`. Run strictly in order, one call at a time:

```
1. gif_creator(action="start_recording", tabId)
2. computer(action="screenshot", tabId)                       ← first frame
3. per repro step: the action, then computer(action="screenshot", tabId)
4. computer(action="screenshot", tabId)                       ← final frame
5. gif_creator(action="stop_recording", tabId)
6. gif_creator(action="export", tabId, filename="{TICKET_KEY}-TC{n}-FAIL-{description}.gif", download=true,
     options={"showClickIndicators": true, "showActionLabels": true, "showProgressBar": true, "showWatermark": false, "quality": 10})
7. cp "$HOME/mnt/Downloads/{file}.gif" "$REPO_ROOT/manual-testing/evidences/$TICKET_KEY/"   (copy, not mv)
```

---

## Step 3 — Upload to Linear (connector, one file at a time)

**Must happen BEFORE posting the comment.** The signed URL lives 60 seconds — finish one file before preparing the next.

1. `prepare_attachment_upload(issue="{TICKET_KEY}", filename, contentType="image/png"|"image/gif", size=<exact bytes>)` → note `assetUrl`, `uploadRequest.url`, `uploadRequest.headers`.
2. PUT from the Mac's Playwright process:

```javascript
// mcp__playwright__browser_run_code_unsafe
async (page) => {
  const FILE = '/Users/belleung/Documents/guardrails/eng-guardrails-platform/manual-testing/evidences/{TICKET_KEY}/{file}';
  const URL = '{uploadRequest.url}';
  const HEADERS = { /* uploadRequest.headers verbatim */ };
  const p = await page.context().newPage();
  await p.setContent('<input type="file" id="f">');
  await p.setInputFiles('#f', FILE);
  const b64 = await p.evaluate(() => new Promise((res) => { const f = document.getElementById('f').files[0]; const r = new FileReader(); r.onload = () => res(r.result.split(',')[1]); r.readAsDataURL(f); }));
  await p.close();
  const data = Buffer.from(b64, 'base64');
  const r = await page.request.put(URL, { data, headers: HEADERS, timeout: 30000 });
  return { status: r.status(), bytes: data.length };
}
```

   Expect `status: 200` and matching `bytes`.
3. `create_attachment_from_upload(issue="{TICKET_KEY}", assetUrl, title=filename)`.

Record `filename → assetUrl`; the comment embeds each as `![name](assetUrl)` (see `linear-comment-writer`). Verify the count matches the files before posting, then check the rendered comment in Chrome.