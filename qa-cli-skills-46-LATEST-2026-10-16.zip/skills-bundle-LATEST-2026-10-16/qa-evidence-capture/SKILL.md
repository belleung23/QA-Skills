---
name: "qa-evidence-capture"
description: "Capture badged, annotated QA evidence (PASS/FAIL screenshots + FAIL GIF) and attach it to a Linear or Jira ticket with an inline QA comment. Use for every manual test case result, or on: evidence, screenshot, snapshot, record bug, attach to Linear, attach to Jira."
---

# QA Evidence Capture

One skill for the whole evidence chain: **capture → annotate → check → upload → comment**.
It replaces `playwright-media-capture` + `screenshot-video-capture` for the capture half and the
`fileUpload + PUT` script in `linear-comment-writer` for the upload half. Verified end to end on
2026-10-16 (FRAI-8354): PASS + FAIL captures, GIF, three uploads, inline comment.

Ideas borrowed from the spydysense-ux bug board (`hunt/scripts/ux-shot-annotate.mjs`,
`web/src/lib/drawMarks.ts`, `shotCheck.ts`, `AttachPage.tsx`):

1. **Draw on the image, not on the app page.** A modal with a blurred backdrop sits in the browser's
   top layer and blurs anything injected into the page. Take a clean screenshot, put it on a blank
   page, draw badge/outlines/labels there, screenshot that.
2. **Reject bad captures before upload.** Too narrow, or the wrong shape for the viewport, means a retake.
3. **Report `drawn / total / overlaps`.** A FAIL screenshot whose failing element was not found is a
   bare screen — flag it, never ship it silently as evidence.
4. **Wait on facts, not timers.** `networkidle` + a landmark selector, then a short buffer.

## Tracker connection

The ticket tracker is **Linear or Jira**, whichever the ticket key belongs to (`FRAI-`/`SSAI-` →
Linear, `GR-` → Jira). Each is reached in one of two ways — use whichever is present in the session:

| Tracker | Via connector (preferred) | Via API key |
|---|---|---|
| Linear | Linear connector tools (`prepare_attachment_upload`, `create_attachment_from_upload`, `save_comment`) | `TESTING_LINEAR_API_KEY` in the repo's `.dev.vars`, used by `linear-comment-writer/scripts/upload_linear_file.py` |
| Jira | Atlassian connector tools (`addCommentToJiraIssue`, `transitionJiraIssue`, …) | `TESTING_JIRA_API_TOKEN` in the repo's `.dev.vars`, used by `jira-comment-writer/scripts/post_jira_comment_with_evidence.py` |

If neither is available for the tracker the ticket needs, stop after Part 2 and tell the user which
connection to add. Do not invent a third route.

## Division of labour

| Who | Does |
|---|---|
| Claude in Chrome | Drives the manual test, records the GIF |
| Playwright MCP (`browser_run_code_unsafe`) | Captures and annotates the PNG, PUTs file bytes when the upload URL is signed |
| Tracker connector or API key | Creates the attachment and posts the comment |

**Known breakages (as of 2026-10-16):**
- `mcp__playwright__browser_take_screenshot` hangs ("waiting for fonts") — always screenshot via
  `browser_run_code_unsafe` on a **fresh page** (`page.context().newPage()`).
- The cloud sandbox cannot reach `storage.googleapis.com` (Linear's upload host) or
  `persefoni.atlassian.net`; the Mac sandbox shell (`device_bash`) has no network at all. File bytes
  go out through the Mac's Playwright process (Part 3).
- Inside `browser_run_code_unsafe` there is no `require`/`import`; `Buffer` is available. Read a file
  through an `<input type=file>` + `setInputFiles` + `FileReader` (Part 3).

## When to capture

| Result | Screenshot | GIF |
|---|---|---|
| ✅ Pass (UI) | green badge | never |
| 🔍 BE-only with visible UI | green badge | never |
| ❌ Fail (UI) | red outline on the failing element + numbered label + red badge | yes, repro steps |

Badge is **always bottom-right** (`bottom:12px;right:12px`). A footer strip (42px, dark) records
`host · path · env · viewport` so anyone reading the ticket knows where the shot was taken.

---

## Part 0 — Paths (once per ticket)

Evidence lives in the repo, never in a temp folder:

```
/Users/belleung/Documents/guardrails/eng-guardrails-platform/manual-testing/evidences/{TICKET_KEY}/
```

Create it **before** the first screenshot (a missing folder makes `page.screenshot` hang). In the
Mac sandbox shell the same folder is `$HOME/mnt/eng-guardrails-platform/manual-testing/evidences/{TICKET_KEY}/`:

```bash
mkdir -p "$HOME/mnt/eng-guardrails-platform/manual-testing/evidences/$TICKET_KEY"
```

Naming: `{TICKET_KEY}-TC{n}-PASS-{desc}.png`, `{TICKET_KEY}-TC{n}-FAIL-{desc}.png`,
`{TICKET_KEY}-TC{n}-FAIL-{desc}.gif`.

---

## Part 1 — Screenshot (PASS and FAIL)

Get the URL under test from Chrome (`tabs_context_mcp`). Close any modal that is NOT the evidence.
Then one `browser_run_code_unsafe` call does everything on a fresh page:

```javascript
async (page) => {
  const URL = '{url from Chrome}';
  const OUT = '/Users/belleung/Documents/guardrails/eng-guardrails-platform/manual-testing/evidences/{TICKET_KEY}/{TICKET_KEY}-TC{n}-{PASS|FAIL}-{desc}.png';
  const RESULT = 'PASS';                  // or 'FAIL'
  const READY = '{landmark selector}';    // e.g. 'main h1', '[data-testid="table"]'
  const STEPS = [];                       // FAIL only: [{click:'text=Settings'}, {fill:'#name', value:'x'}, {press:'Enter'}]
  const MARKS = [];                       // FAIL only: [{n:1, selector:'{failing selector}', label:'{one full sentence: what is wrong}'}]
  const FOOTER = '{host}{path} · {env} · ';
  const VP = { width: 1440, height: 900 };

  const p = await page.context().newPage();
  await p.setViewportSize(VP);
  await p.goto(URL, { waitUntil: 'domcontentloaded' });
  await p.waitForLoadState('networkidle').catch(() => {});
  if (READY) await p.waitForSelector(READY, { timeout: 15000 }).catch(() => {});
  await p.waitForTimeout(1500);

  // Replay the steps that make the bug visible — open URL + shoot gives a bare screen.
  for (const st of STEPS) {
    try {
      if (st.click) await p.locator(st.click).first().click({ timeout: 8000 });
      else if (st.fill) await p.locator(st.fill).first().fill(String(st.value ?? ''), { timeout: 8000 });
      else if (st.press) await p.keyboard.press(st.press);
      await p.waitForTimeout(st.wait ?? 900);
    } catch (e) { console.warn('step failed', JSON.stringify(st), String(e).split('\n')[0]); }
  }

  // Measure marks on the live page (full-page coordinates), scroll the first into view.
  const measured = await p.evaluate((marks) => marks.map((m) => {
    let found = []; try { found = [...document.querySelectorAll(m.selector)]; } catch { return null; }
    const el = found.find((e) => { const r = e.getBoundingClientRect(); return r.width >= 2 && r.height >= 2 && getComputedStyle(e).visibility !== 'hidden'; });
    if (!el) return null;
    const r = el.getBoundingClientRect();
    return { n: m.n, label: m.label, box: { x: r.x + scrollX, y: r.y + scrollY, w: r.width, h: r.height } };
  }).filter(Boolean), MARKS);
  if (measured[0]) { await p.evaluate((y) => scrollTo(0, Math.max(0, y - 180)), measured[0].box.y); await p.waitForTimeout(300); }

  const raw = await p.screenshot({ fullPage: true, timeout: 20000 });

  // Draw on a blank page over the image (never into the app page).
  const canvas = await p.context().newPage();
  await canvas.setViewportSize(VP);
  await canvas.setContent(`<!doctype html><html><body style="margin:0;background:#fff"><img id="shot" style="display:block" src="data:image/png;base64,${raw.toString('base64')}"></body></html>`);
  await canvas.waitForFunction(() => document.getElementById('shot')?.complete);
  const report = await canvas.evaluate(({ marks, result, footer, vp }) => {
    const RED = '#dc2626', GREEN = '#16a34a';
    const img = document.getElementById('shot');
    const W = img.naturalWidth, H = img.naturalHeight;
    const layer = document.createElement('div');
    Object.assign(layer.style, { position: 'absolute', left: 0, top: 0, width: W + 'px', height: H + 'px', pointerEvents: 'none' });
    document.body.appendChild(layer);
    const placed = [];
    const hits = (a, b) => !(a.x + a.w < b.x || b.x + b.w < a.x || a.y + a.h < b.y || b.y + b.h < a.y);
    let drawn = 0, overlaps = 0;
    for (const m of marks) {
      const b = m.box, pad = 3; drawn++;
      const o = document.createElement('div');
      Object.assign(o.style, { position: 'absolute', left: (b.x - pad) + 'px', top: (b.y - pad) + 'px', width: (b.w + pad * 2) + 'px', height: (b.h + pad * 2) + 'px', border: '3px solid ' + RED, borderRadius: '6px', boxSizing: 'border-box' });
      layer.appendChild(o); placed.push({ x: b.x - pad, y: b.y - pad, w: b.w + pad * 2, h: b.h + pad * 2 });
      if (!m.label) continue;
      const l = document.createElement('div');
      l.textContent = '#' + m.n + ': ' + m.label;
      Object.assign(l.style, { position: 'absolute', background: RED, color: '#fff', font: '600 15px/1.3 -apple-system,Segoe UI,sans-serif', padding: '7px 13px', borderRadius: '7px', maxWidth: Math.min(520, W - 32) + 'px', whiteSpace: 'normal', boxShadow: '0 2px 8px rgba(0,0,0,.25)' });
      layer.appendChild(l);
      const lr = l.getBoundingClientRect();
      // Try below, above, right, left of the box; keep the first spot that overlaps nothing.
      const cands = [
        { x: b.x, y: b.y + b.h + 10 }, { x: b.x, y: b.y - lr.height - 10 },
        { x: b.x + b.w + 10, y: b.y }, { x: b.x - lr.width - 10, y: b.y },
      ].map((c) => ({ x: Math.min(Math.max(8, c.x), W - lr.width - 8), y: Math.min(Math.max(8, c.y), H - 42 - lr.height - 8), w: lr.width, h: lr.height }));
      const spot = cands.find((c) => !placed.some((q) => hits(c, q))) ?? (overlaps++, cands[0]);
      l.style.left = spot.x + 'px'; l.style.top = spot.y + 'px'; placed.push(spot);
    }
    const f = document.createElement('div');
    f.textContent = footer + vp.width + 'x' + vp.height;
    Object.assign(f.style, { position: 'absolute', left: 0, top: (H - 42) + 'px', width: W + 'px', height: '42px', background: '#111418', color: '#e9edf3', font: '400 15px/42px -apple-system,Segoe UI,sans-serif', paddingLeft: '22px', boxSizing: 'border-box' });
    layer.appendChild(f);
    const badge = document.createElement('div');
    badge.textContent = result === 'PASS' ? '✅ PASSED' : '❌ FAILED';
    Object.assign(badge.style, { position: 'absolute', left: (W - 12) + 'px', top: (H - 42 - 12) + 'px', transform: 'translate(-100%,-100%)', background: result === 'PASS' ? GREEN : RED, color: '#fff', font: '700 13px -apple-system,Segoe UI,sans-serif', padding: '6px 12px', borderRadius: '6px', whiteSpace: 'nowrap', boxShadow: '0 2px 8px rgba(0,0,0,.4)' });
    layer.appendChild(badge);
    return { drawn, total: marks.length, overlaps, w: W, h: H };
  }, { marks: measured, result: RESULT, footer: FOOTER, vp: VP });
  await canvas.waitForTimeout(150);
  await canvas.screenshot({ path: OUT, fullPage: true, timeout: 20000 });
  await canvas.close(); await p.close();

  // Size/shape check: a capture narrower than 1000px is unreadable — retake.
  const problem = report.w < 1000 ? `too narrow (${report.w}px)` : null;
  return { ...report, path: OUT, problem, expectedMarks: MARKS.length };
}
```

**Read the return value.** `drawn < expectedMarks` on a FAIL means a failing element was not
found: fix the selector or replay steps and retake — a bare screen is not evidence. `overlaps > 0`
means a label still covers something; move it or shorten the label. `problem` set → retake.

Verify on disk and note the **exact byte size** for Part 3:
`ls -l "$HOME/mnt/eng-guardrails-platform/manual-testing/evidences/$TICKET_KEY/"`.

---

## Part 2 — GIF (FAIL only)

`gif_creator` only captures a frame when you call `computer screenshot`; actions alone add nothing,
and two identical consecutive frames are collapsed into one. Run **strictly in order**, one call at
a time — never batch start/stop with the screenshots.

1. `gif_creator(action="start_recording", tabId)`
2. `computer(action="screenshot", tabId)` — first frame
3. For every repro step: do the action, then `computer(action="screenshot", tabId)`
4. `computer(action="screenshot", tabId)` — final frame showing the failure
5. `gif_creator(action="stop_recording", tabId)`
6. `gif_creator(action="export", tabId, filename="{TICKET_KEY}-TC{n}-FAIL-{desc}.gif", download=true, options={showClickIndicators:true, showActionLabels:true, showProgressBar:true, showWatermark:false, quality:10})`
7. It lands in `~/Downloads` (connect that folder if needed). Copy (not move — the sandbox cannot delete):
   `cp "$HOME/mnt/Downloads/{file}.gif" "$HOME/mnt/eng-guardrails-platform/manual-testing/evidences/$TICKET_KEY/"`

---

## Part 3 — Upload (one file at a time)

### Linear

The signed URL expires in **60 seconds**: prepare → PUT → finalize for one file before preparing
the next. Never batch the prepare calls.

**3a. Prepare** (connector): `prepare_attachment_upload(issue, filename, contentType, size)`.
`size` must be the exact byte count (`ls -l`). Note `assetUrl`, `uploadRequest.url`, `uploadRequest.headers`.

**3b. PUT the bytes from the Mac's Playwright process** (it has normal network):

```javascript
async (page) => {
  const FILE = '/Users/belleung/Documents/guardrails/eng-guardrails-platform/manual-testing/evidences/{TICKET_KEY}/{file}';
  const URL = '{uploadRequest.url}';
  const HEADERS = { /* uploadRequest.headers verbatim, same casing */ };
  const p = await page.context().newPage();
  await p.setContent('<input type="file" id="f">');
  await p.setInputFiles('#f', FILE);
  const b64 = await p.evaluate(() => new Promise((res) => { const f = document.getElementById('f').files[0]; const r = new FileReader(); r.onload = () => res(r.result.split(',')[1]); r.readAsDataURL(f); }));
  await p.close();
  const data = Buffer.from(b64, 'base64');
  const r = await page.request.put(URL, { data, headers: HEADERS, timeout: 30000 });
  return { status: r.status(), bytes: data.length };
}
```

Expect `status: 200` and `bytes` equal to the prepared `size`. Anything else → re-prepare and retry.

**3c. Finalize**: `create_attachment_from_upload(issue, assetUrl, title=filename)`.

With an API key instead of the connector: `python3 upload_linear_file.py <files…>` from the repo
root (reads `.dev.vars`), which prints `filename -> assetUrl` per file — only from a shell that can
reach `storage.googleapis.com`.

Record `filename → assetUrl` for every file. PNG (`image/png`) and GIF (`image/gif`) go the same way.

### Jira

With the Atlassian connector: upload the files to the ticket (attachment tool, or
`setInputFiles` on `input[type="file"]` at `https://persefoni.atlassian.net/browse/{TICKET_KEY}`
from a logged-in Playwright page), then read each `img[src*="media"]` on the ticket to get the
Atlassian Media UUID per filename.

With an API key: `python3 post_jira_comment_with_evidence.py {TICKET_KEY} <files…>` from the repo
root (reads `TESTING_JIRA_API_TOKEN` from `.dev.vars`) — it uploads and comments in one go; skip Part 4.

Record `filename → media UUID` for every file.

---

## Part 4 — Post the QA comment

Same content for both trackers (format from `linear-comment-writer` / `jira-comment-writer`):

```markdown
## QA Verification ✅ | ❌

**Date**: YYYY-MM-DD
**Tested by**: belle.ung@persefoni.com
**Environment**: Dev (https://app.dev.firstrecon.ai) | Production (https://app.firstrecon.ai)

## Execution Summary

- {what was tested, counts of pass/fail}

## Test Cases

| | Test Case | Status | Expected Result | Actual Result | Reproduction Steps | Screenshot |
|---|---|---|---|---|---|---|
| 1 | … | ✅ Pass | … | … | … | {image} |
| 2 | … | ❌ Fail | … | … | … | {image} {gif} |
```

- **Linear**: `save_comment(issueId, body)` as plain Markdown; `{image}` is `![{file}.png]({assetUrl})` — renders inline, including inside table cells.
- **Jira**: post as **ADF JSON** (`contentFormat="adf"`); `{image}` is a `mediaSingle` node with the
  media UUID. `!file.png!` markdown does **not** embed inside table cells.

For a ❌ Fail, add a **Failed Test Cases — Detail** section (AC verbatim, steps, expected,
actual) and run `root-cause-forensics` first. Then open the ticket in Chrome and check the images
actually show. If all passed, hand off to `linear-ticket-transition` / `jira-ticket-transition`.