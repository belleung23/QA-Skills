---
name: "database-testing"
description: "Test the database layer behind any API or feature in any project: verify what each request actually did to the data, constraints, triggers/fences, row-level security, transactions, tenant isolation, migrations and rollbacks, data-lifecycle jobs, performance and security — manual SQL checklist plus Playwright TypeScript templates verified across PostgreSQL and SQLite with a config-driven spec and a driver/CLI/admin-API access adapter."
---

# Database Testing

Use this skill whenever a ticket, feature, bug or migration needs proof that the **data** is right — not only that the API answered 200. It is project-agnostic: it works for any relational database (PostgreSQL, MySQL, SQL Server, SQLite and serverless SQLite-compatible databases) and gives notes for document/KV stores. Every connection detail, URL, account, table name and environment comes from config or environment variables — **nothing in this skill is hardcoded, and nothing project-specific may be added to it**. Project facts (table names, which service owns a table, how to reach the DB) are discovered per project in Step 1 and recorded in the test plan and the per-feature config file, not in this skill.

Plain-language rule of thumb: **the API is the door, the database is the room.** Every test opens the door (sends a request or runs a job), walks into the room (queries the tables) and checks exactly what changed — and that nothing else did.

---

## 0. Safety rules (read first, never skip)

1. **Never touch production.** Only connect to local / dev / test databases. If the connection target looks like production (contains `prod`, `production`, `live`, or the production hostname from the project config), stop and ask.
2. **Prefer SELECT.** Manual UPDATE / DELETE is only for test setup or cleanup, and always:
   - inside a transaction (`BEGIN; ... ROLLBACK;` first to preview, `COMMIT` only when the affected row count is exactly what you expect),
   - with a `WHERE` clause that targets only rows this test created (by a unique run marker such as `qa_<runId>` in a name/email/code field),
   - never `DELETE FROM table;` or `TRUNCATE` on a shared database.
3. **Credentials** live in `.env` / CI secrets / a secrets manager. Never paste a connection string, password or token into a ticket, PR, comment, screenshot or chat.
4. **Use a read-only DB user** for verification queries when one exists; a separate writable user only for seed/teardown.
5. **Tests create their own data and clean it up.** Never rely on "user id 42" or a row somebody else made.
6. Sensitive columns (passwords, tokens, PII) are checked for *shape* (hashed, encrypted, masked, null) — never copied into reports.
7. **Never run a migration, purge or retention job yourself on a shared environment.** A migration file existing in the repo is not evidence it was applied — verify through the migration ledger (section 3.4). Ask the owner to run it, or run it only on a local/throwaway database.

---

## 1. Workflow: ticket → DB test plan → execution → report

### Step 1 — Discover the data model behind the feature (per project)
From the ticket, API docs, ORM models, migration files or code (`grep` for the endpoint handler → repository/model → table name), write down:
- **Which store(s)** hold the data. Many projects use more than one: a relational DB plus a document DB, a KV cache, an object store, a search index, a queue/outbox table. Each store the feature writes to needs its own check.
- **Primary table(s)** written or read by the endpoint, and **related tables** (foreign keys, join tables, audit/history tables, outbox/event tables, search/FTS shadow tables, counters).
- **Which service/component is the write owner** of each table (some projects keep a DB-ownership file; otherwise ask). This tells you where the business rule lives — in code or in the database.
- Columns that must change (`status`, `updated_at`), columns that must NOT change (`id`, `created_at`, `tenant_id`, `created_by`, identity/digest columns).
- Whether delete is **hard** (row removed) or **soft** (`deleted_at` / `is_deleted` / status set).
- **Database-enforced rules**: NOT NULL, UNIQUE, FOREIGN KEY, CHECK, defaults, enums, length limits, **triggers / fences** (rules that reject or stamp writes), **row-level security (RLS) policies**, and generated/computed columns. Query them (section 4) — do not trust the ticket alone.
- **How to reach the database** in each environment (section 5.1): direct driver, a CLI, or only through an admin/operations API.
- The **API body field names** for the same things (they often differ from the column names).

Everything found here goes into `<feature>.config.ts` (section 5.5). If you cannot find it, ask the developer one precise question: "Which tables does `<endpoint>` write to, which service owns them, and is delete hard or soft?"

### Step 2 — Write the plan as before/after statements
Every DB test case follows one shape:

```
Given   <state in the DB before — seeded by the test>
When    <request, job or migration>
Then    <exact rows/columns after>  AND  <what must be unchanged>
```

Always include the **unchanged** part. Most real bugs are side effects: deleted too much, updated the wrong tenant, overwrote a column you did not send, a bookkeeping table that did not follow the main write.

### Step 3 — Execute (manual or automated)
1. Seed data with a unique run marker, e.g. `qa_${runId}` inside a name/email/code field.
2. Snapshot the rows you care about (`SELECT ... WHERE marker = ...`) → **before**.
3. Send the request / run the job.
4. Query again → **after** (in every store the feature touches).
5. Assert the diff is exactly what you expected (section 2 has the assertions per request type).
6. Teardown everything with the marker.

### Step 4 — Report
For each test case record: store and table(s) queried, the SELECT used (with the marker value), before row(s), after row(s), expected vs actual, pass/fail. Failures go through the project's root-cause flow before a ticket is written; the ticket includes the exact query and the row evidence (sensitive columns masked).

---

## 2. Manual checklist by request type

Tick every line that applies. "Row" means the row(s) your test created.

### GET (read)
- [ ] Returned fields match the DB row value-for-value (ids, names, numbers, booleans, dates in the right timezone/format).
- [ ] Computed/derived fields (totals, counts, statuses) match a SQL aggregate you ran yourself.
- [ ] Soft-deleted rows are NOT returned (unless the endpoint is explicitly "include deleted").
- [ ] Rows from another tenant / organization / user are NOT returned.
- [ ] Filters, sorting and pagination match an equivalent `WHERE` / `ORDER BY` / `LIMIT OFFSET` query (check total count too).
- [ ] A GET does not write anything (no `updated_at` change, no new audit row unless "viewed" auditing is a feature).
- [ ] Sensitive columns never appear in the response.

### POST (create)
- [ ] Exactly **one** new row in the primary table (not 0, not 2 — check with `COUNT(*)` on the marker).
- [ ] Every sent field is stored correctly (exact string, trimmed?, case preserved?, numbers not rounded, decimals precise, unicode intact).
- [ ] Fields you did not send get the right **default** (`status`, `is_active`, `currency`, etc.).
- [ ] System columns are filled: `id` generated, `created_at` ≈ now, `updated_at` ≈ `created_at`, `created_by` / `tenant_id` set from the auth context — not from the request body (send a fake `tenant_id` in the body and confirm it is ignored).
- [ ] **Bookkeeping rows** are written in the same transaction/batch: child rows, audit/history row, outbox/event row, search-index entry, counters/aggregates. If the main write succeeds and the bookkeeping is missing, that is a failure.
- [ ] Response id matches the DB id.
- [ ] Duplicate request (same unique field) → rejected with 4xx and **no** new row.
- [ ] Invalid body (missing required, wrong type, too long, bad enum, negative where not allowed) → 4xx and **no** new row, no partial related rows.
- [ ] Double submit / retry → still one row (idempotency), when the feature promises it.

### PUT / PATCH (update)
- [ ] Only the sent fields changed; every other column equals the **before** snapshot.
- [ ] `updated_at` moved forward; `created_at`, `id`, `tenant_id`, `created_by` unchanged.
- [ ] Setting a field to `null` / empty behaves as specified (cleared vs ignored).
- [ ] Updating a row that belongs to another tenant/user → 403/404 and the row is unchanged.
- [ ] Updating a non-existent or soft-deleted row → 404, nothing created.
- [ ] Unique constraint on update (change email to one already used) → 4xx, unchanged.
- [ ] **State transitions** follow the allowed graph (e.g. `draft → submitted → approved`; `approved → draft` rejected) and the DB status matches. Where the code uses a guarded update (`UPDATE ... WHERE id = ? AND status = ?`), a stale transition must affect 0 rows and the API must report it, not silently succeed.
- [ ] Immutable columns (identity, generation, digest, write-once fields) cannot be changed through any endpoint — attempt it and confirm the DB value is untouched.
- [ ] Concurrent updates (two PATCHes at once, or a stale version) behave as designed (last-write-wins, optimistic-lock error, etc.).

### DELETE
- [ ] **Hard delete:** row gone (`COUNT = 0`). **Soft delete:** row still exists with `deleted_at` / `is_deleted` set, and a subsequent GET no longer returns it.
- [ ] Child rows behave as designed: cascade-deleted, blocked (409/400 with parent unchanged), or detached (FK set null). Check each child table.
- [ ] Bookkeeping follows: search-index entry removed, counters decremented, audit row written, outbox event emitted — whichever the design says.
- [ ] Only the targeted row is affected — count other rows with the same marker before and after.
- [ ] Deleting another tenant's row → 403/404, row untouched.
- [ ] Deleting twice → second call 404 (or idempotent 204 per spec), no error row.
- [ ] Unique fields of a soft-deleted row: can a new row reuse the same email/code? Verify against the spec.

### Bulk / import / background jobs
- [ ] Row counts before/after equal input count (minus rejected rows, which are reported).
- [ ] One bad row does not corrupt the batch: either all-or-nothing (transaction) or per-row error reporting — whichever the spec says.
- [ ] Jobs are idempotent: running twice does not duplicate data.
- [ ] Progress/status table (if any) reaches a terminal state; failed jobs leave a readable error, not a half-written row.

---

## 3. Deeper test areas

### 3.1 Constraints and data integrity
For every constraint found in Step 1, write one negative test:
- NOT NULL → omit the field → 4xx, no row.
- UNIQUE → send duplicate → 4xx, no row (and check case-sensitivity: `Belle@x.com` vs `belle@x.com`).
- FOREIGN KEY → point to a non-existent parent → 4xx, no row.
- CHECK / enum / range → out-of-range value → 4xx.
- Length → max length passes, max+1 fails; emoji / multibyte characters count correctly.
- Precision → `19.999` into a 2-decimal money column: rounded, truncated, or rejected? Must match spec.
- Dates → timezone handling (stored as UTC?), leap day, far past/future.

The API must return a clean 4xx (never a 500 with a raw SQL error), and the DB must be unchanged.

### 3.2 Database-enforced rules: triggers, fences, RLS
Some rules live *inside* the database rather than in code, so they apply to every writer. Test them directly, not only through one endpoint:
- **Blocking trigger / fence** (e.g. "no writes to a record whose parent is being deleted", "this column can never change"): attempt the forbidden write → it is rejected with the documented error, and the row is unchanged. Then attempt the **allowed** write on the same table → it succeeds. A fence that is too wide and blocks legitimate writes is a critical bug (it surfaces as generic 5xx errors on unrelated features), so always test the allow path too.
- **Stamping trigger / bookkeeping** (`updated_at`, history row, counter, search index): after the write, the stamped value exists and is correct; after a failed write, nothing was stamped.
- **Row-level security (RLS)**: with the tenant/user context set, reads and writes see only that tenant's rows; with the context **missing**, the policy fails closed (no rows, or write rejected) — never "all rows". Test both.
- **Hot tables** (high write volume: messages, events, receipts, ledgers): any new trigger or constraint there needs a timing check (section 3.6) because every writer pays its cost.

### 3.3 Transactions and rollback
A transaction means "all steps succeed or none do". Force a failure in the middle of a multi-table write (invalid child item, unique violation on the second insert, simulated downstream error) and assert that **no** rows from the first step remain — including bookkeeping rows. Also check nothing is left locked (follow-up requests still work).

### 3.4 Migrations, rollbacks and schema changes
When a ticket changes the schema (run these on a **local or throwaway** database, never a shared one):
- **Fresh vs existing**: apply the migration to (a) an empty database built from scratch and (b) a database that already has the old shape *and data*. Both must succeed. Some engines (SQLite-based ones in particular) have no `ADD COLUMN IF NOT EXISTS`, so a migration that passes on one and fails on the other is a real bug.
- **Idempotent / re-runnable**: applying the same migration twice must not fail or duplicate anything, when the project's migration tool expects that.
- **Data preservation**: `COUNT(*)` and a checksum/sample of key columns before = after; backfilled values for new columns are correct; renamed/moved data is intact.
- **Structure**: new columns, indexes, constraints, triggers and policies actually exist afterwards (query `information_schema` / catalog tables; do not trust the file).
- **Ledger**: the migration tracking table records the migration as applied in the target environment. A file in the repo is not proof.
- **Rollback**: the down/rollback script exists, its stated preconditions are checked (e.g. "fails if any NULLs — backfill first"), it restores the previous shape, and data survives it.
- **Expand–contract (phased) changes**: when a change ships in two steps (add the new column/path first, remove the old one later), verify each phase separately: after phase 1 old and new code both work; after phase 2 the old path is gone and nothing still depends on it.
- **Rolling deploys**: if the database migrates before the application, old application code must still work against the new schema during the gap.

### 3.5 Tenant / user isolation (multi-tenant systems)
Seed data for tenant A and tenant B. With A's credentials run every GET/PUT/PATCH/DELETE against B's ids. Expect 403/404 and B's rows byte-for-byte unchanged. Also check list endpoints never leak B's rows via filters, search, sorting or pagination tricks (`?tenantId=B`, large page sizes, id guessing). Where RLS exists, repeat with the DB context missing (section 3.2).

### 3.6 Performance basics
- List endpoints paginate and never return the whole table.
- With realistic volume (seed thousands to hundreds of thousands of rows in a perf environment) key queries stay within the project's budget; run `EXPLAIN` / `EXPLAIN ANALYZE` on the slow query and confirm an index is used (no full table scan for filtered lookups).
- No N+1: one list request should not fire one query per row (check query logs or ORM debug output).
- New triggers, constraints or indexes on hot tables: measure write latency before vs after.

### 3.7 Security
- SQL injection strings in every text input (`' OR 1=1 --`, `"; DROP TABLE users; --`, `1; SELECT pg_sleep(5)`) are stored as plain text and never change other rows or delay the response.
- Passwords are hashed (prefix like `$2b$` / `$argon2`), tokens/secrets encrypted or hashed, PII masked where the spec says.
- Audit tables record who/when for sensitive actions and cannot be edited through the API.
- The DB user used by the application has only the permissions it needs (no superuser; writer roles limited to their tables) — ask if unsure.

### 3.8 Concurrency and race conditions
- Two parallel POSTs with the same unique value → exactly one row.
- Parallel increments/decrements (stock, balance, counters) → final value equals the arithmetic result (no lost updates).
- Parallel delete + update on the same row → consistent end state, no 500.

### 3.9 Data-lifecycle jobs: purge, retention, erasure, archiving
Jobs that delete or move data in bulk (account deletion, GDPR erasure, retention windows, archiving) deserve their own pass:
- **Dry run / plan first**: the job (or script) can produce a plan listing what it will delete, per store and table, with **before counts**, without deleting anything. Verify the plan against your own `COUNT` queries.
- **Classification**: tables marked "purge" lose only the target's rows; tables marked "retain" (audit, billing, legal) keep theirs; anything ambiguous is a blocker to raise, not to guess.
- **Execute** only on a test/demo target, after the confirmation step the job requires. Then **after counts**: target rows are 0 in purge tables, unchanged in retain tables, and **other tenants'/users' counts are identical** to before.
- Every store is covered (relational rows, document records, KV keys, object-storage files, search-index entries) — a job that cleans the main DB but leaves files behind has failed.
- Running the job twice is safe (second run finds nothing).

---

## 4. SQL query templates

Replace `<...>`. PostgreSQL syntax; dialect notes below.

```sql
-- Snapshot rows created by this test run
SELECT * FROM <table> WHERE <marker_column> LIKE 'qa_<runId>%' ORDER BY id;

-- Count (expect exact number)
SELECT COUNT(*) FROM <table> WHERE <marker_column> LIKE 'qa_<runId>%';

-- Verify one row and its system columns
SELECT id, <fields>, created_at, updated_at, created_by, tenant_id, deleted_at
FROM <table> WHERE id = <id>;

-- Children / bookkeeping of a parent (cascade, block, detach, outbox, history)
SELECT COUNT(*) FROM <child_table> WHERE <parent_fk> = <parent_id>;

-- Soft-delete check
SELECT id, deleted_at, is_deleted FROM <table> WHERE id = <id>;

-- Cross-tenant leak check (should be 0 for ids the API returned to tenant A)
SELECT COUNT(*) FROM <table> WHERE tenant_id <> '<tenantA>' AND id IN (<ids returned by API>);

-- Discover constraints, indexes, triggers and RLS policies (PostgreSQL)
SELECT conname, contype, pg_get_constraintdef(oid) FROM pg_constraint WHERE conrelid = '<table>'::regclass;
SELECT indexname, indexdef FROM pg_indexes WHERE tablename = '<table>';
SELECT tgname, pg_get_triggerdef(oid) FROM pg_trigger WHERE tgrelid = '<table>'::regclass AND NOT tgisinternal;
SELECT polname, polcmd, pg_get_expr(polqual, polrelid) FROM pg_policy WHERE polrelid = '<table>'::regclass;
SELECT relrowsecurity, relforcerowsecurity FROM pg_class WHERE oid = '<table>'::regclass;

-- Column definitions (any SQL DB with information_schema)
SELECT column_name, data_type, is_nullable, column_default, character_maximum_length
FROM information_schema.columns WHERE table_name = '<table>' ORDER BY ordinal_position;

-- Migration ledger (name varies by tool: schema_migrations, flyway_schema_history, _migrations, d1_migrations ...)
SELECT * FROM <migration_table> ORDER BY 1 DESC LIMIT 10;

-- RLS fail-closed check (PostgreSQL): with no tenant context, expect 0 rows / rejected write
RESET app.tenant_id;  SELECT COUNT(*) FROM <table>;
SET app.tenant_id = '<tenantA>';  SELECT COUNT(*) FROM <table>;

-- Query plan for a slow endpoint query
EXPLAIN ANALYZE <the query the endpoint runs>;

-- Safe cleanup (preview, then commit)
BEGIN;
DELETE FROM <child_table> WHERE <marker_column> LIKE 'qa_<runId>%';
DELETE FROM <table>       WHERE <marker_column> LIKE 'qa_<runId>%';
-- check the row counts printed above; then:
COMMIT;   -- or ROLLBACK;
```

Dialect notes:
- **MySQL**: backticks; `SHOW CREATE TABLE <table>;`, `SHOW INDEX FROM <table>;`, `SHOW TRIGGERS LIKE '<table>';`.
- **SQL Server**: `TOP n` instead of `LIMIT`, `GETDATE()`, `sp_help '<table>'`, `sys.triggers`.
- **SQLite and serverless SQLite-compatible DBs**: `PRAGMA table_info(<table>)`, `PRAGMA foreign_key_list(<table>)`, `SELECT name, sql FROM sqlite_master WHERE tbl_name = '<table>'` (shows indexes and triggers), `datetime('now')`; no `ADD COLUMN IF NOT EXISTS`; migrations often recreate the table — verify data copied across. Often reachable only through the vendor CLI (`--local` vs remote flags) rather than a driver.
- **Document / KV / object stores**: same ideas — `countDocuments`, `findOne`, `getIndexes()`, list keys by prefix, list objects by prefix; verify each store the feature writes to.

---

## 5. Automation templates (Playwright TypeScript)

Structure (adapt to the repo's existing layout — look before creating folders):

```
tests/
  db/
    db.adapter.ts       # reads env, refuses production-looking targets; ONE interface, three implementations: driver | cli | admin-api
    db.helpers.ts       # typed helpers: getRow, countRows, snapshot, cleanupByMarker, expectUnchangedExcept, expectDbRejects
    db.fixture.ts       # Playwright fixture: runId + auto-teardown
  config/
    <feature>.config.ts # the ONLY file that changes per project: table, column and body names from Step 1
  api/
    <feature>.db.spec.ts
```

### 5.1 Environment and access modes (never hardcode)
```
DB_ACCESS_MODE=driver            # driver | cli | api
DB_URL=postgres://user:pass@host:5432/dbname      # driver mode, dev/test only
DB_CLI_COMMAND="<cli> <db-name> --local --command" # cli mode, e.g. a vendor CLI or psql/sqlite3 wrapper
DB_ADMIN_API_URL=https://<dev-api>/admin/query    # api mode: an operations endpoint that runs SQL and returns { rows }
DB_ADMIN_API_TOKEN=...                            # from secrets
API_BASE_URL=https://<dev-api>
QA_MARKER_PREFIX=qa_
QA_ENV_NAME=dev
QA_TENANT_B_ID=<id of a second tenant that exists in the test DB>  # isolation tests only
```
Install for driver mode: `npm i -D pg @types/pg` (strict TypeScript fails without `@types/pg`; `mysql2` / `mssql` / `better-sqlite3` ship their own types).
Why three modes: locally the database is usually reachable with a driver or the vendor CLI, but in shared dev/staging it is often behind a private network and only an operations/admin API can run queries. The tests must not care which — they call the adapter. Fail fast if the mode's variables are missing or the target looks like production.

### 5.2 db.adapter.ts
```ts
export interface DbAdapter {
  query<T = any>(sql: string, params?: unknown[]): Promise<T[]>;
  close(): Promise<void>;
}

function assertNotProduction(target: string) {
  if (/prod|production|live/i.test(target)) throw new Error('Refusing to run DB tests against a production-looking target');
}

async function driverAdapter(): Promise<DbAdapter> {
  const url = process.env.DB_URL; if (!url) throw new Error('DB_URL is not set');
  assertNotProduction(url);
  const { Pool } = await import('pg');            // mysql2 / mssql / better-sqlite3 for other engines
  const pool = new Pool({ connectionString: url, max: 5 });
  return {
    query: async (sql, params = []) => (await pool.query(sql, params)).rows,
    close: () => pool.end(),
  };
}

async function cliAdapter(): Promise<DbAdapter> {
  const cmd = process.env.DB_CLI_COMMAND; if (!cmd) throw new Error('DB_CLI_COMMAND is not set');
  assertNotProduction(cmd);
  const { execFile } = await import('node:child_process');
  const { promisify } = await import('node:util');
  const run = promisify(execFile);
  return {
    query: async (sql, params = []) => {
      // CLI mode cannot bind parameters: inline ONLY values you generated yourself (runId, ids), never user input.
      // Contract for the wrapper named in DB_CLI_COMMAND: print ONLY one JSON document (an array of row objects, or the vendor's
      // { results: [...] } shape) on stdout, nothing else; exit non-zero on a SQL error so expectDbRejects can see it.
      const quote = (v: unknown) => v === null || v === undefined ? 'NULL' : typeof v === 'number' ? String(v) : `'${String(v).replace(/'/g, "''")}'`;
      const inlined = sql.replace(/\$(\d+)/g, (_, n) => quote(params[Number(n) - 1]));   // handles $10+, repeated $n, NULL and numbers
      const [bin, ...args] = cmd.split(' ');
      const { stdout } = await run(bin, [...args, inlined, '--json']);
      const parsed = JSON.parse(stdout);
      return parsed[0]?.results ?? parsed.results ?? parsed;   // normalise to the CLI's JSON shape
    },
    close: async () => {},
  };
}

async function apiAdapter(): Promise<DbAdapter> {
  const url = process.env.DB_ADMIN_API_URL; if (!url) throw new Error('DB_ADMIN_API_URL is not set');
  assertNotProduction(url);
  return {
    query: async (sql, params = []) => {
      const res = await fetch(url, {
        method: 'POST',
        headers: { 'content-type': 'application/json', authorization: `Bearer ${process.env.DB_ADMIN_API_TOKEN ?? ''}` },
        body: JSON.stringify({ sql, params }),
      });
      if (!res.ok) throw new Error(`Admin query failed: ${res.status} ${await res.text()}`);
      return (await res.json()).rows;
    },
    close: async () => {},
  };
}

export async function createDb(): Promise<DbAdapter> {
  switch (process.env.DB_ACCESS_MODE ?? 'driver') {
    case 'driver': return driverAdapter();
    case 'cli':    return cliAdapter();
    case 'api':    return apiAdapter();
    default: throw new Error(`Unknown DB_ACCESS_MODE ${process.env.DB_ACCESS_MODE}`);
  }
}
```

### 5.3 db.helpers.ts
```ts
import type { DbAdapter } from './db.adapter';

export async function getRow<T>(db: DbAdapter, table: string, id: string | number): Promise<T | undefined> {
  return (await db.query<T>(`SELECT * FROM ${table} WHERE id = $1`, [id]))[0];
}

export async function countRows(db: DbAdapter, table: string, where: string, params: unknown[]): Promise<number> {
  const rows = await db.query<{ count: string | number }>(`SELECT COUNT(*) AS count FROM ${table} WHERE ${where}`, params);
  return Number(rows[0].count);
}

/** Snapshot every row carrying this run's marker so "unchanged" can be asserted later. */
export async function snapshot<T>(db: DbAdapter, table: string, markerColumn: string, runId: string): Promise<T[]> {
  return db.query<T>(`SELECT * FROM ${table} WHERE ${markerColumn} LIKE $1 ORDER BY id`, [`${runId}%`]);
}

/** Delete only rows created by this run. Children first. */
export async function cleanupByMarker(db: DbAdapter, tables: Array<{ table: string; markerColumn: string }>, runId: string) {
  for (const { table, markerColumn } of tables) {
    await db.query(`DELETE FROM ${table} WHERE ${markerColumn} LIKE $1`, [`${runId}%`]);
  }
}

/** Assert two row objects are equal except for the listed columns. */
export function expectUnchangedExcept(before: Record<string, unknown>, after: Record<string, unknown>, changed: string[]) {
  for (const key of Object.keys(before)) {
    if (changed.includes(key)) continue;
    if (JSON.stringify(before[key]) !== JSON.stringify(after[key])) {
      throw new Error(`Column "${key}" changed unexpectedly: ${JSON.stringify(before[key])} -> ${JSON.stringify(after[key])}`);
    }
  }
}

/** Expect a write to be rejected by the database (constraint, trigger, fence, RLS) and leave the row untouched. */
export async function expectDbRejects(db: DbAdapter, sql: string, params: unknown[], messagePattern?: RegExp) {
  let error: unknown;
  try { await db.query(sql, params); } catch (e) { error = e; }
  if (!error) throw new Error('Expected the database to reject the write, but it succeeded');
  if (messagePattern && !messagePattern.test(String(error))) throw new Error(`Rejected, but with an unexpected message: ${String(error)}`);
}
```

### 5.4 db.fixture.ts
```ts
import { test as base, expect } from '@playwright/test';
import { createDb, type DbAdapter } from './db.adapter';
import { cleanupByMarker } from './db.helpers';

type DbFixtures = {
  db: DbAdapter;
  runId: string;
  trackTable: (table: string, markerColumn: string) => void;
};

export const test = base.extend<DbFixtures>({
  db: async ({}, use) => { const db = await createDb(); await use(db); await db.close(); },
  runId: async ({}, use) => {
    await use(`${process.env.QA_MARKER_PREFIX ?? 'qa_'}${Date.now()}_${Math.random().toString(36).slice(2, 8)}`);
  },
  trackTable: async ({ db, runId }, use) => {
    const tracked: Array<{ table: string; markerColumn: string }> = [];
    await use((table, markerColumn) => tracked.unshift({ table, markerColumn })); // registered later = deleted first (children)
    await cleanupByMarker(db, tracked, runId);
  },
});
export { expect };
```

### 5.5 <feature>.config.ts — the only per-project file
Everything the spec needs to know about this project's names lives here (from Step 1 of the plan). Nothing else changes between projects. Save it as `tests/config/feature.config.ts` (or adjust the import in the spec).
```ts
// Per-feature config: the ONLY file that changes between projects. Filled from Step 1 of the plan.
export type FeatureConfig = {
  resource: string;                 // API path, e.g. '/orders'
  table: string; child: string; bookkeeping: string;
  col: {
    id: string; marker: string; amount: string; status: string; tenant: string;
    createdAt: string; updatedAt: string; immutable: string; mutable: string; optional: string;
    softDelete: string | null;      // null = hard delete
    childMarker: string; bookkeepingFk: string;
  };
  isSoftDeleted: (row: any) => boolean;
  defaultStatus: string;
  immutableError: RegExp;
  body: {                           // how the API body names things
    marker: string; amount: string; optional: string; items: string; itemLabel: string; itemQty: string;
  };
};

export const feature: FeatureConfig = {
  resource: '/<resource>', table: '<primary_table>', child: '<child_table>', bookkeeping: '<audit_or_outbox_table>',
  col: { id: 'id', marker: '<marker_column>', amount: '<amount_column>', status: '<status_column>', tenant: '<tenant_column>',
         createdAt: 'created_at', updatedAt: 'updated_at', immutable: '<write_once_column>', mutable: '<any_editable_column>',
         optional: '<optional_column>', softDelete: '<deleted_at | is_deleted | null for hard delete>',
         childMarker: '<child_marker_column>', bookkeepingFk: '<fk_column_in_bookkeeping_table>' },
  isSoftDeleted: (r) => r.deleted_at !== null,          // or: r.is_deleted === 1
  defaultStatus: '<default_status>', immutableError: /<documented error text>/i,
  body: { marker: '<body field for marker>', amount: '<body field for amount>', optional: '<body field for optional>',
          items: '<body field for child list>', itemLabel: '<child label field>', itemQty: '<child qty field>' },
};
```

### 5.6 Generic spec — POST / PATCH / DELETE / transaction / DB rule / tenant isolation
This file is identical in every project; it reads names from the config above.
```ts
import { test, expect } from '../db/db.fixture';
import { getRow, countRows, expectUnchangedExcept, expectDbRejects } from '../db/db.helpers';
import { feature as F } from '../config/feature.config';

const C = F.col;
const api = (p: string) => `${process.env.API_BASE_URL}${p}`;
// Drivers return Date objects, CLIs/APIs return strings; String(Date) drops milliseconds, so branch.
const tsOf = (v: unknown) => (v instanceof Date ? v : new Date(String(v))).getTime();

test.describe(`${F.resource} — database effects @db`, () => {
  test('POST creates exactly one row with sent values, defaults and bookkeeping @TC-DB-001', async ({ request, db, runId, trackTable }) => {
    trackTable(F.child, C.childMarker); trackTable(F.table, C.marker);
    const marker = `${runId}_create`;
    const res = await request.post(api(F.resource), { data: { [F.body.marker]: marker, [F.body.amount]: 1234.56 } });
    expect(res.status()).toBe(201);
    const body = await res.json();

    expect(await countRows(db, F.table, `${C.marker} = $1`, [marker])).toBe(1);
    const row = await getRow<any>(db, F.table, body[C.id]);
    expect(row[C.marker]).toBe(marker);
    expect(Number(row[C.amount])).toBe(1234.56);
    expect(row[C.status]).toBe(F.defaultStatus);
    expect(tsOf(row[C.createdAt])).toBeGreaterThan(Date.now() - 60_000);
    if (C.softDelete) expect(F.isSoftDeleted(row)).toBe(false);
    expect(await countRows(db, F.bookkeeping, `${C.bookkeepingFk} = $1`, [body[C.id]])).toBe(1); // bookkeeping followed
  });

  test('POST with duplicate unique value is rejected and creates no row @TC-DB-002', async ({ request, db, runId, trackTable }) => {
    trackTable(F.table, C.marker);
    const marker = `${runId}_dup`;
    expect((await request.post(api(F.resource), { data: { [F.body.marker]: marker } })).status()).toBe(201);
    const second = await request.post(api(F.resource), { data: { [F.body.marker]: marker } });
    expect([400, 409]).toContain(second.status());
    expect(await countRows(db, F.table, `${C.marker} = $1`, [marker])).toBe(1);
  });

  test('PATCH changes only the sent field and bumps updated_at @TC-DB-003', async ({ request, db, runId, trackTable }) => {
    trackTable(F.table, C.marker);
    // Populate EVERY optional column when seeding: an accidental overwrite of NULL with NULL is invisible.
    const created = await (await request.post(api(F.resource), { data: { [F.body.marker]: `${runId}_patch`, [F.body.amount]: 10, [F.body.optional]: 'keep-me' } })).json();
    const before = await getRow<any>(db, F.table, created[C.id]);
    expect((await request.patch(api(`${F.resource}/${created[C.id]}`), { data: { [F.body.amount]: 20 } })).status()).toBe(200);
    const after = await getRow<any>(db, F.table, created[C.id]);
    expect(Number(after[C.amount])).toBe(20);
    expect(tsOf(after[C.updatedAt])).toBeGreaterThan(tsOf(before[C.updatedAt]));
    expectUnchangedExcept(before, after, [C.amount, C.updatedAt]);
  });

  test('DELETE removes or soft-deletes the row and GET no longer returns it @TC-DB-004', async ({ request, db, runId, trackTable }) => {
    trackTable(F.table, C.marker);
    const created = await (await request.post(api(F.resource), { data: { [F.body.marker]: `${runId}_delete` } })).json();
    expect((await request.delete(api(`${F.resource}/${created[C.id]}`))).status()).toBe(204);
    const row = await getRow<any>(db, F.table, created[C.id]);
    if (C.softDelete) { expect(row).toBeDefined(); expect(F.isSoftDeleted(row)).toBe(true); }
    else { expect(row).toBeUndefined(); }
    expect((await request.get(api(`${F.resource}/${created[C.id]}`))).status()).toBe(404);
  });

  test('Transaction rolls back when a child row is invalid @TC-DB-005', async ({ request, db, runId, trackTable }) => {
    trackTable(F.child, C.childMarker); trackTable(F.table, C.marker);
    const marker = `${runId}_tx`;
    const res = await request.post(api(F.resource), { data: { [F.body.marker]: marker, [F.body.items]: [
      { [F.body.itemLabel]: `${runId}_ok`, [F.body.itemQty]: 1 }, { [F.body.itemLabel]: `${runId}_bad`, [F.body.itemQty]: -1 } ] } });
    expect([400, 422]).toContain(res.status());
    expect(await countRows(db, F.table, `${C.marker} = $1`, [marker])).toBe(0);
    expect(await countRows(db, F.child, `${C.childMarker} LIKE $1`, [`${runId}%`])).toBe(0);
  });

  test('DB-enforced rule blocks the forbidden write and allows the normal one @TC-DB-006', async ({ db, runId, trackTable }) => {
    trackTable(F.table, C.marker);
    const seeded = (await db.query<any>(`INSERT INTO ${F.table} (${C.marker}, ${C.immutable}, ${C.createdAt}, ${C.updatedAt}) VALUES ($1, $2, $3, $4) RETURNING *`,
      [`${runId}_rule`, 'v1', new Date().toISOString(), new Date().toISOString()]))[0];
    await expectDbRejects(db, `UPDATE ${F.table} SET ${C.immutable} = $1 WHERE ${C.id} = $2`, ['v2', seeded[C.id]], F.immutableError);
    expect((await getRow<any>(db, F.table, seeded[C.id]))[C.immutable]).toBe('v1');
    await db.query(`UPDATE ${F.table} SET ${C.mutable} = $1 WHERE ${C.id} = $2`, ['allowed', seeded[C.id]]);   // allow path still works
  });

  test('Tenant A cannot update, delete or read tenant B row @TC-DB-007', async ({ request, db, runId, trackTable }) => {
    trackTable(F.table, C.marker);
    const tenantB = process.env.QA_TENANT_B_ID; if (!tenantB) throw new Error('QA_TENANT_B_ID is not set');
    const seeded = (await db.query<any>(`INSERT INTO ${F.table} (${C.marker}, ${C.tenant}, ${C.createdAt}, ${C.updatedAt}) VALUES ($1, $2, $3, $4) RETURNING *`,
      [`${runId}_tenantB`, tenantB, new Date().toISOString(), new Date().toISOString()]))[0];
    const before = await getRow<any>(db, F.table, seeded[C.id]);

    expect([403, 404]).toContain((await request.patch(api(`${F.resource}/${seeded[C.id]}`), { data: { [F.body.amount]: 99 } })).status());
    expect([403, 404]).toContain((await request.delete(api(`${F.resource}/${seeded[C.id]}`))).status());
    expect([403, 404]).toContain((await request.get(api(`${F.resource}/${seeded[C.id]}`))).status());

    const after = await getRow<any>(db, F.table, seeded[C.id]);
    expect(after).toBeDefined();
    expectUnchangedExcept(before, after, []);
  });
});
```

Rules for the automation:
- Every test seeds its own data with `runId`, registers tables with `trackTable`, and never depends on another test.
- Assertions compare to values the test itself sent or computed — never to whatever is currently in the DB ("it equals itself" is not a test).
- Never leave a test as a comment-only stub: it passes green while checking nothing. Implement it or mark it `test.fixme(...)`.
- When seeding a row for an update test, populate every optional column; otherwise an endpoint that wipes a column you did not send goes unnoticed.
- Use parameterised queries (`$1`) in driver/api mode; in CLI mode inline only values the test generated.
- Numeric/decimal columns often come back as strings; convert before comparing. Timestamps: compare through `tsOf()`, never as strings.
- Tag specs `@db` so they can be run or excluded in CI (`npx playwright test --grep @db`), and run them in a CI job that has the test DB available (service container, ephemeral DB, or the admin-API mode against dev).
- Keep PRs small: one feature per branch, at most 10–15 tests per PR, branch name following the repo's convention. No AI co-author / "generated with" lines on commits or PRs.

These templates were verified end to end: type-checked with strict TypeScript and run with Playwright, with the **same spec file unchanged**, against two different projects — one on PostgreSQL (tables `widgets`/`widget_items`, `deleted_at` soft delete, `tenant_id`) and one on SQLite (tables `orders`/`order_lines`, `is_deleted` flag, `org_id`, different body field names) — in all three access modes (driver, CLI wrapper, admin API). Only `<feature>.config.ts` differed. 7/7 green everywhere, teardown left 0 rows. Mutation-checked: a PATCH that wiped an unsent column, a hard delete where soft delete was expected, a missing transaction and a tenant-blind DELETE each made exactly the right test fail. The production-target and missing-variable guards stop the run before any query.

Portability notes learned from that run: drivers return timestamps as `Date` objects while CLIs and APIs return strings — compare through `tsOf()` above, never `String(date)` (it drops milliseconds); SQLite needs the app to store millisecond timestamps (ISO strings) or `updated_at` may not move inside one second; `RETURNING *` needs SQLite ≥ 3.35; in CLI mode every `$n` is inlined, so never pass user-supplied text as a parameter there.

---

## 6. Test-case template (manual sheet / Linear / Jira)

| TC ID | Title | Store / Table(s) | Precondition (seed) | Steps | SQL to verify | Expected in DB | Expected API | Priority |
|---|---|---|---|---|---|---|---|---|
| TC-DB-001 | POST creates one row with defaults | `<table>` | none | 1. POST `/<resource>` {name} 2. query | `SELECT * FROM <table> WHERE <marker>='qa_<run>_create'` | 1 row, status=default, created_at≈now, bookkeeping row present | 201, id = DB id | High |

Minimum coverage per endpoint: happy path, one negative per constraint, unchanged-columns check, bookkeeping check, tenant isolation, and (for delete) child-row behaviour. Per migration: fresh + existing + data-preservation + rollback. Per DB rule (trigger/fence/RLS): block path + allow path.

---

## 7. Definition of done for a DB test pass

- [ ] Stores, tables, write owners and delete mode (hard/soft) identified and written in the report (and in `<feature>.config.ts` when automating).
- [ ] Before/after evidence for every create/update/delete case, including bookkeeping tables.
- [ ] At least one negative test per constraint; all return 4xx with DB unchanged.
- [ ] Every DB-enforced rule tested on both the block path and the allow path.
- [ ] Tenant/user isolation verified for every write endpoint (and RLS fail-closed where it exists).
- [ ] Transaction rollback verified for every multi-table write.
- [ ] Migrations verified on fresh and existing data, ledger checked, rollback exercised (local only).
- [ ] No test data left in the shared DB (`SELECT COUNT(*) ... LIKE 'qa_%'` returns 0 for this run).
- [ ] Sensitive columns never shown in evidence; no credentials in any artifact.
- [ ] Failures went through root-cause analysis before a ticket was filed, and the ticket includes the exact query + masked rows.

---

## Glossary (plain language)
- **Constraint** — a rule the database enforces on data (required, unique, must point to a real parent).
- **Foreign key (FK)** — a column that must match an id in another table.
- **Cascade** — deleting a parent automatically deletes its children.
- **Soft delete** — the row stays but is marked deleted; **hard delete** — the row is removed.
- **Transaction** — a group of writes that all succeed or all roll back.
- **Trigger / fence** — code inside the database that runs on insert/update/delete; a *fence* rejects writes that break a rule, a *stamping* trigger fills columns like `updated_at` or writes history rows.
- **Row-level security (RLS)** — a database policy that filters every query by tenant/user automatically; "fail closed" means no context → no rows.
- **Bookkeeping** — side tables that must follow the main write: audit/history, outbox events, search index, counters.
- **Idempotent** — doing the same thing twice leaves the same result as doing it once.
- **Seed / teardown** — create test data before, remove it after.
- **Index** — a lookup structure that makes filtered queries fast; missing ones cause slow endpoints.
- **N+1** — one query for a list plus one extra query per item; a common performance bug.
- **Migration** — a scripted change to the database structure; **rollback** — the script that undoes it; **ledger** — the table that records which migrations were applied.
- **Expand–contract** — shipping a schema change in two phases (add new, then remove old) so old and new code can run together during deploy.
- **Write owner** — the one service/component allowed to write a table; rules for that table usually live there.
- **Hot table** — a table with very high write volume where every extra rule costs performance.