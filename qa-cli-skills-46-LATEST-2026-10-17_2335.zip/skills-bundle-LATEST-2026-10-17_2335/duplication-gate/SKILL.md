---
name: "duplication-gate"
description: "Check newly generated Playwright specs for duplication before they reach a PR — against the manual test cases they came from, against the existing suite, and against each other — and flag any generated test that cannot fail. Reports first, applies the fold only after you approve. Run after automation-runner or test-script-generator, before automation-aegis. Triggers on: check duplication, dedupe the new tests, is this a duplicate, did we already automate this, duplicate TC ID, already covered, does this test already exist."
---

# Duplication Gate

Runs **after** scripts are generated (`automation-runner`, `test-script-generator`) and
**before** `automation-aegis` and any commit. Aegis asks "is this test well written?" — this
asks "should this test exist at all?"

Three comparisons plus one quality check:

| Check | Catches |
| --- | --- |
| New scripts vs the **source manual cases** | two sheet rows / tickets describing the same flow — caught before a line is written |
| New scripts vs the **whole existing suite** | the row was already automated by someone else, usually with different code |
| New scripts vs **each other** | one generation pass emitting the same body twice |
| New scripts **can they fail** | generated tests that assert nothing, or only inside an `if` |

**Always report first. Never edit until the user says go.**

---

## Why code-diffing alone does not work here

Across 15 clean-up passes on `eng-guardrails-platform`, body-level matching found almost
nothing while **structural** matching found nearly everything. Two people automating the same
QA sheet row write code that looks nothing alike — text similarity 0.07 to 0.31 — but the
coverage is identical. The ranking that actually pays:

1. **Same declared TC ID in two files** — by far the highest yield (11 of 15 real duplicates in one pass).
2. **Same spec basename in two directories** — rare, but when it fires it is always real.
3. **More than one spec file per bug ticket** — `gr-7801-nav-settings-ja`, `gr-7801-tc7-tc8-retest`, `gr-7801-tc8-notif-check`.
4. **Fuzzy title match** (strip the TC ID, normalise, compare word sets).
5. Strict statement prefix (new test ⊂ existing test).
6. Identical body hash — almost always a false positive (a `forEach` loop), check it last.

---

## Step 0 — check the source before generating

If the manual cases are to hand (sheet range, Excel rows, Linear/Jira ticket), scan them first:

- Two rows whose **steps and expected result** say the same thing under different IDs.
- A row whose ID is **already tagged** in the suite — grep `'@<TC-ID>'` across the test folders.
- A **bug ticket** that restates a case already covered by a feature row.

Report those before writing any script. A duplicate never generated costs nothing to remove.

---

## Step 1 — run the detector

The detector is the script at the bottom of this skill.

**Put it on the machine where the suite lives.** If the repo is in a folder connected from the
user's computer, the detector must be written and run *there* — the Write tool writes to the
cloud container, which cannot see that repo at all. Use the device shell and a quoted heredoc
(`cat > "$TOOL" <<'PYEOF' ... PYEOF`) so nothing is interpolated. Only when the repo is in the
container itself is the Write tool the right way.

Cache it so it is written once, checking in the same shell you will run it from:

```bash
TOOL="$HOME/.qa-tools/dupcheck.py"       # any stable path outside the repo
grep -q 'dupcheck v1' "$TOOL" 2>/dev/null || echo "write it"
```

If that path does not already hold `dupcheck v1`, write the script there verbatim, then run
it. Never retype it from memory — the regexes encode bug fixes (see **Why the script looks
like this**). After writing, confirm it is intact before trusting a result:

```bash
python3 -c "import ast;ast.parse(open('$TOOL').read())" && echo ok
```

```bash
python3 "$TOOL" --root <repo-root> \
  --suite automation --suite electron-automation \
  --new <relative/path/to/new1.spec.ts> --new <relative/path/to/new2.spec.ts>
```

`--new` paths are repo-relative and must sit under one of the `--suite` roots; anything it
cannot find is reported as `!! --new paths not found`. Add `--json` for machine-readable output.

It prints three sections: **DUPLICATION**, **FILE-LEVEL**, **CANNOT FAIL**. It changes nothing.

---

## Step 2 — triage every finding by reading the code

The detector proposes; it never decides. Open both tests and reject these, which are
**legitimate and must not be removed**:

- **Parameterised by describe.** Eight tests titled "should load without JavaScript errors",
  each in its own describe whose `beforeEach` navigates to a different page. Only the
  `console.log` label differs. Correct.
- **Parameterised by subject.** Same shape, different endpoint (`/api/policies` vs
  `/api/policies/:id`), role (`chat_user` vs `platform_admin`), locale (ja vs fr), page
  (`/operations/users` vs `/operations/feature-flags`) or viewport.
- **Per-page boilerplate.** "Page loads successfully", "Page has no console errors", "Page is
  responsive" repeated once per feature area.
- **Different layer.** A UI spec and an API spec for one bug are not duplicates.
- **Different mechanism for one root cause.** Two specs may reach the same defect by different
  routes because the API cannot configure the first route at all — read the comments.
- **A regex argument.** `/compact/i` vs `/comfortable/i` is a real difference.

**The most common wrong HIGH is `IDENTICAL BODY` on per-page boilerplate.** The detector reads
one test at a time, so two tests whose bodies are byte-identical but whose enclosing describes
have different `beforeEach` navigation look like twins to it and are not. Before acting on an
`IDENTICAL BODY` hit, read the `beforeEach` of both describes — if they open different pages,
reject it.

Then establish **which copy is stronger**. In practice the duplicate is nearly always the
weaker one, and these are the tells:

| Stronger | Weaker |
| --- | --- |
| a real testid found by reading `src/` | a wildcard: `[data-testid*="search"]`, `input[placeholder*="Search"]` |
| asserts it reached the state, then asserts the outcome | asserts only the outcome, which was already true on arrival |
| declared in the file whose header owns that TC ID range | a stray outside the file's declared range |
| carries a researched comment or a live-verified date | no provenance |
| a tagged test | no `tag:` array at all — invisible to coverage reporting |

Confirm every testid against the application source before calling a copy stronger.

---

## Step 3 — decide, one line per finding

| Verdict | When | Action |
| --- | --- | --- |
| **DROP** | the new test is a subset of, or identical to, an existing one | delete the new test, fold its TC ID into the survivor |
| **FOLD-IN** | the new test is a *superset* — it covers the old one and more | keep the new test, delete the old one, carry the old TC ID and app tag onto the new |
| **KEEP** | legitimate parameterisation, or genuinely different coverage | say which rejection rule applies |
| **ASK** | folding would cost coverage (see below) | report, do not change |

Cases that must go to **ASK**, never auto-folded:

- The survivor's describe carries a gate the loser does not (`skipIfMfaGated`, an entitlement
  check) — folding makes that row skip where it used to run.
- The survivor **mocks** what the loser runs live, or vice versa.
- Either copy is `test.skip` / `test.fixme` — skipped tests are owned separately.
- The two differ in environment tags (`@staging` only vs `@staging @prod`).

### The fold pattern

Removing a test must never retire its QA sheet row. Add the removed ID to the survivor's tag
array and explain it inline:

```typescript
test(
  'TC-OP-181: Confirm filter/search/export controls',
  { tag: ['@TC-OP-181', '@TC-OP-165', '@App.Operations.AuditLogs', '@P1', '@staging'] },
  async ({ page, authenticatedRequest }) => {
    // Also covers TC-OP-165 ('Audit Logs filters'): that test's entire body was the two
    // filter-verification calls below, in this order, with nothing else.
    await verifyActorFilterScopesRows(page, authenticatedRequest);
    ...
```

Rules for the fold:

- **Keep the stricter priority.** Folding a `@P1` row into a `@P2` test raises it to `@P1`.
- **Keep both app tags** when the two rows were filed under different `@App.*` paths.
- **Keep the union of environment tags.**
- If the file has **no tag arrays** (TC IDs live in the titles), record it as an
  `Also covers TC-XXX (...)` comment on the survivor instead.
- Update the file header's declared TC ID range.

---

## Step 4 — apply, only after approval

Present the findings as a table — new test, existing test, verdict, one-line why — and stop.
On approval:

1. Remove the duplicate declaration **and its attached leading comment block**.
2. Add the folded tags and the "Also covers" note to the survivor.
3. Fix the file header range.
4. Drop imports that lost their last user — but verify by counting occurrences in the whole
   file, not by eye: `Page`, `ElectronApplication` and similar are used in module-level
   declarations above the describe and look unused.

Then verify, every time:

```bash
npx prettier --check --stdin-filepath <path> < <file>   # see the gotcha below
npx playwright test --list <path>                        # still collects
```

- **Prettier exits 0 on a syntax error** and only prints `[error]` on stderr. Check the output
  for `[error]`, not just the exit code — a stray `);` left behind by a bad deletion will
  otherwise pass silently.
- Confirm no TC ID disappeared: diff the `@TC-...` set before and after; every removed ID must
  still appear in the survivor file.
- Confirm no describe was left empty, and no `beforeEach` orphaned.

Hand off to **automation-aegis** once this is clean.

---

## Why the script looks like this

Every one of these cost a wrong result before it was fixed. Do not "simplify" them away.

1. **Regex literals are not masked.** Blanking string contents is right; blanking
   `/compact/i` made two correctly parameterised density tests look byte-identical.
2. **The statement splitter counts block statements.** Closing only on a `;` at depth 1 drops
   `for (...) { ... }` and `if (...) { ... }` — which is where API specs keep their real
   assertions — and made dozens of tests look like prefixes of each other. Fixing it took one
   run's candidates from 80 to 15.
3. **`expect` may be split across lines.** `expect\n  .soft(...)` is common after Prettier;
   a regex requiring `expect.soft` adjacent misses it and reports a real test as assertion-free.
4. **Playwright's throwing waits are assertions.** `waitForURL`, `waitForSelector`,
   `waitForFunction`, `waitForResponse`, `toPass` fail the test on timeout with no `expect()`
   in sight — unless the call is followed by `.catch(...)`, which swallows it.
5. **Helper functions assert too.** A test calling only `checkA11y(page)` is not assertion-free.
   The script builds a transitive call graph of every function in the suites and marks the ones
   that reach an `expect()` or a `throw`.
6. **Finding a function's body needs care.** Taking the first `{` after the name lands on a
   default parameter (`options: A11yCheckOptions = {}`), so most helpers index as empty bodies
   and every test that uses them is wrongly flagged. Skip the parameter list and any
   return-type annotation first.
7. **Files quarantined at module level are skipped.** A `test.fixme(true, ...)` or
   `test.skip(true, ...)` at the top level disables the whole file; those belong to whoever owns
   the quarantine, not to this gate.

A helper that reports findings with `console.warn` and returns normally **never fails a test**.
Nine of fourteen helpers in one a11y util file did exactly that, and ten tests built on them had
been green for months without checking anything.

---

## Report format

```
## Duplication gate — <N> new tests checked against <M> existing

| New test | Verdict | Existing | Why |
| --- | --- | --- | --- |
| TC-XX-01 … | DROP | TC-YY-07 in other.spec.ts | subset; survivor asserts the same testids and more |
| TC-XX-02 … | KEEP | — | parameterised by role (platform_admin vs chat_user) |
| TC-XX-03 … | ASK  | TC-ZZ-12 | survivor's describe is MFA-gated; folding would skip this row |

### Cannot fail (<K>)
- <file>:<line> <title> — no expect(), no asserting helper

Nothing changed yet. Say go and I will apply the DROP and FOLD-IN rows.
```

If nothing is found, say so in one line and hand off to `automation-aegis`.

---

## The detector

Write this to the cached path verbatim, then run it.

```python
#!/usr/bin/env python3
"""dupcheck.py — duplication + no-op gate for newly generated Playwright specs.
# dupcheck v1

  python3 dupcheck.py --root <repo> --suite automation --suite electron-automation --new <file> [--new <file> ...]

Prints a findings report. Changes nothing on disk.
"""
import argparse, collections, difflib, hashlib, json, os, re, sys

# ---------- masking -------------------------------------------------------
# Blanks comments and the CONTENTS of string literals, keeping quotes and
# newlines so offsets line up with the raw source. Regex literals are left
# intact on purpose: /compact/i vs /comfortable/i is a real difference and
# blanking them makes parameterised tests look identical.
TOK = re.compile(r"""//[^\n]*|/\*.*?\*/|"(?:\\.|[^"\\\n])*"|'(?:\\.|[^'\\\n])*'|`(?:\\.|[^`\\])*`""", re.S)
def _blank(mo):
    s = mo.group(0)
    if s[:2] in ('//', '/*'):
        return ''.join(c if c == '\n' else ' ' for c in s)
    q = s[0]
    return q + ''.join(c if c == '\n' else ' ' for c in s[1:-1]) + q
def mask(src): return TOK.sub(_blank, src)

def match_close(m, i):
    o = m[i]; c = {'(': ')', '{': '}', '[': ']'}[o]; d = 0
    while i < len(m):
        if m[i] == o: d += 1
        elif m[i] == c:
            d -= 1
            if d == 0: return i
        i += 1
    return -1

MODS = {'describe','skip','fixme','only','serial','parallel','concurrent','failing',
        'each','todo','runIf','skipIf','sequential','for','fails'}
DECL = re.compile(r'(?<![\w$.])(test|it|describe|xit|xdescribe|fit|fdescribe)((?:\.[A-Za-z_$][\w$]*)*)\s*\(')
LIT  = re.compile(r"""['"`]""")

def scan_file(path, rel):
    try: src = open(path, encoding='utf-8', errors='replace').read()
    except Exception: return []
    m = mask(src)
    nl = [0]; st = 0
    while True:
        k = src.find('\n', st)
        if k < 0: break
        nl.append(k + 1); st = k + 1
    import bisect
    out = []
    for mo in DECL.finditer(m):
        base = mo.group(1); chain = [p for p in mo.group(2).split('.') if p]
        if any(p not in MODS for p in chain): continue
        ap = mo.end() - 1; ae = match_close(m, ap)
        if ae < 0: continue
        tm = LIT.search(m, ap + 1, ae)
        title = None
        if tm:
            q = tm.group(0); s = tm.start(); e = m.find(q, s + 1)
            if 0 < e < ae: title = src[s + 1:e]
        bs = be = -1
        ar = m.find('=>', ap, ae)
        if ar > 0:
            k = m.find('{', ar)
            if k >= 0: bs = k; be = match_close(m, k)
        if be < 0 or be > ae: bs, be = ap, ae
        out.append({
            'file': rel, 'line': bisect.bisect_right(nl, mo.start()),
            'suite': base in ('describe','xdescribe','fdescribe') or 'describe' in chain,
            'skip': 'skip' in chain or base == 'xit', 'fixme': 'fixme' in chain,
            'todo': 'todo' in chain, 'title': title,
            'body': src[bs:be + 1], 'mbody': m[bs:be + 1],
            'opts': src[ap:bs if bs > ap else ae],
        })
    return out

# ---------- quarantine ----------------------------------------------------
QUAR = re.compile(r'(?m)^(test\.(fixme|skip)\(|test\.describe\.(fixme|skip))')
def is_quarantined(path):
    try: return bool(QUAR.search(open(path, encoding='utf-8', errors='replace').read()))
    except Exception: return False

# ---------- asserting-helper call graph -----------------------------------
FN    = re.compile(r'(?<![\w$.])(?:export\s+)?(?:default\s+)?(?:async\s+)?function\s*\*?\s*([A-Za-z_$][\w$]*)\s*(?:<[^>(]{0,120}>)?\s*\(')
CONST = re.compile(r'(?<![\w$.])(?:export\s+)?const\s+([A-Za-z_$][\w$]*)\s*(?::\s*[^=\n]{0,200})?=\s*(?:async\s*)?(?:<[^>(]{0,120}>)?\s*\(')
EXPECT = re.compile(r'(?<![\w$.])expect\s*(?:\.\s*(?:soft|poll)\s*)?\(')   # tolerates expect\n  .soft(
THROW  = re.compile(r'(?<![\w$.])throw\s+new\s+\w*Error')
CALL   = re.compile(r'(?<![\w$.])([A-Za-z_$][\w$]*)\s*\(')

def _body_after_params(m, popen):
    """popen = index of the param list's '('. Skip it, skip a return-type
    annotation (which may contain <...>), then take the real body braces.
    Naively taking the first '{' lands on a default param like `opts = {}`."""
    e = match_close(m, popen)
    if e < 0: return None
    i = e + 1; ang = 0
    while i < len(m):
        ch = m[i]
        if ch == '<': ang += 1
        elif ch == '>' and ang > 0: ang -= 1
        elif ch == '{' and ang == 0:
            j = match_close(m, i)
            return (i, j) if j > 0 else None
        elif ch == ';' and ang == 0: return None
        i += 1
    return None

def build_assert_index(roots):
    fns = collections.defaultdict(list)
    for root in roots:
        for dp, _, files in os.walk(root):
            for fn in files:
                if not fn.endswith('.ts'): continue
                try: src = open(os.path.join(dp, fn), encoding='utf-8', errors='replace').read()
                except Exception: continue
                m = mask(src)
                for rx in (FN, CONST):
                    for mo in rx.finditer(m):
                        b = _body_after_params(m, mo.end() - 1)
                        if b: fns[mo.group(1)].append(m[b[0]:b[1] + 1])
    asserting = {n for n, bs in fns.items() if any(EXPECT.search(b) or THROW.search(b) for b in bs)}
    calls = {n: {c for b in bs for c in CALL.findall(b)} for n, bs in fns.items()}
    changed = True
    while changed:
        changed = False
        for n, cs in calls.items():
            if n not in asserting and (cs & asserting):
                asserting.add(n); changed = True
    return asserting

# ---------- no-op detection ----------------------------------------------
# Playwright waits that THROW on failure are assertions even with no expect().
THROWY = re.compile(r'\.\s*(waitForURL|waitForSelector|waitForFunction|waitForResponse|waitForRequest|waitForEvent|toPass)\s*\(')
IFG = re.compile(r'(?<![\w$])if\s*\(')

def _clean_mask(t):
    mm = re.sub(r'/\*.*?\*/', lambda x: ' ' * len(x.group(0)), t['mbody'], flags=re.S)
    return re.sub(r'(?m)//[^\n]*', lambda x: ' ' * len(x.group(0)), mm)

def throwy_unswallowed(mm):
    out = []
    for m in THROWY.finditer(mm):
        i = match_close(mm, m.end() - 1)
        if i < 0: continue
        if not re.match(r'\s*\.\s*catch', mm[i + 1:i + 40]): out.append(m.start())
    return out

def if_regions(mm):
    regions = []
    for m in IFG.finditer(mm):
        i = match_close(mm, m.end() - 1)
        if i < 0: continue
        j = i + 1
        while j < len(mm) and mm[j].isspace(): j += 1
        if j < len(mm) and mm[j] == '{':
            k = match_close(mm, j)
            if k > 0: regions.append((j, k))
        elif j < len(mm):
            k = mm.find(';', j)
            if k > 0: regions.append((j, k))
    return regions

def noop_verdict(t, asserting):
    mm = _clean_mask(t)
    exps = [m.start() for m in EXPECT.finditer(mm)]
    helpers = [c for c in CALL.findall(mm) if c in asserting]
    thr = throwy_unswallowed(mm)
    if not exps and not helpers and not thr:
        return 'ASSERTS NOTHING', 'no expect(), no asserting helper, no throwing wait'
    if exps and not helpers and not thr:
        reg = if_regions(mm)
        if all(any(a < p < b for a, b in reg) for p in exps):
            return 'ALL ASSERTIONS CONDITIONAL', '%d expect(), every one inside an if-block' % len(exps)
    return None, None

# ---------- statement split (block statements included) -------------------
CONT = re.compile(r'^(catch|finally|else|while)\b')
def stmts(t):
    src = t['body']; mm = _clean_mask(t)
    if len(mm) != len(src): return None
    out = []; d = 0; start = None; i = 0; n = len(mm)
    def emit(a, b):
        s = re.sub(r'\s+', ' ', src[a:b]).strip()
        s = re.sub(r'/\*.*?\*/', '', s, flags=re.S)
        return re.sub(r'//[^\n]*', '', s).strip()
    while i < n:
        ch = mm[i]
        if ch in '{([': d += 1; i += 1; continue
        if ch in '})]':
            d -= 1
            # a '}' returning to depth 1 ends a block statement (for/if/try)
            if d == 1 and ch == '}':
                j = i + 1
                while j < n and mm[j].isspace(): j += 1
                if j < n and mm[j] not in ')].,;:=+-*/&|?' and not CONT.match(mm[j:j + 9]):
                    if start is not None:
                        s = emit(start, i + 1)
                        if s: out.append(s)
                    start = None
            i += 1; continue
        if d == 1:
            if start is None and not ch.isspace(): start = i
            if ch == ';' and start is not None:
                s = emit(start, i + 1)
                if s: out.append(s)
                start = None
        i += 1
    return out

def nocomment(b):
    b = re.sub(r'/\*.*?\*/', '', b, flags=re.S)
    b = re.sub(r'(?m)//[^\n]*', '', b)
    return re.sub(r'\s+', ' ', b).strip()

TAG = re.compile(r"'@([A-Za-z][\w.-]*)'")
def tc_ids(t):
    return {g for g in TAG.findall(t.get('opts') or '')
            if re.search(r'\d', g) and not g.startswith(('App.', 'P1', 'P2', 'P3'))}

STOP = {'the','and','for','with','should','test','from','that','are','has','have','not',
        'its','via','can','when','all','out','into','this','page','does','was','were'}
def title_key(title):
    s = re.sub(r'^[A-Za-z][\w-]*\d+\s*[:\-]\s*', '', title or '')
    s = re.sub(r'\(.*?\)', '', s)
    s = re.sub(r'[^a-z0-9 ]', ' ', s.lower())
    return ' '.join(sorted({w for w in s.split() if len(w) > 2 and w not in STOP}))

# ---------- main ----------------------------------------------------------
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--root', required=True)
    ap.add_argument('--suite', action='append', required=True)
    ap.add_argument('--new', action='append', required=True)
    ap.add_argument('--json', action='store_true')
    a = ap.parse_args()
    root = os.path.abspath(a.root)
    new_rel = {os.path.relpath(os.path.abspath(p), root) if os.path.isabs(p) else p for p in a.new}

    existing, new, quar = [], [], []
    for suite in a.suite:
        for dp, _, files in os.walk(os.path.join(root, suite)):
            for fn in files:
                if not fn.endswith('.spec.ts'): continue
                p = os.path.join(dp, fn); rel = os.path.relpath(p, root)
                rows = scan_file(p, rel)
                if rel in new_rel: new.extend(rows)
                elif is_quarantined(p): quar.append(rel)
                else: existing.extend(rows)
    missing = new_rel - {r['file'] for r in new}
    asserting = build_assert_index([os.path.join(root, s) for s in a.suite])

    live = lambda rs: [r for r in rs if not r['suite'] and r['title'] and r['body']
                       and not r['skip'] and not r['fixme'] and not r['todo']]
    E, N = live(existing), live(new)
    findings = []
    def add(kind, sev, newt, oldt, why):
        findings.append({'kind': kind, 'severity': sev, 'why': why,
                         'new': '%s:%d  %s' % (newt['file'], newt['line'], newt['title']),
                         'existing': ('%s:%d  %s' % (oldt['file'], oldt['line'], oldt['title'])) if oldt else None})

    # 1. TC ID already declared elsewhere  (highest yield)
    byid = collections.defaultdict(list)
    for t in E:
        for i in tc_ids(t): byid[i].append(t)
    for t in N:
        for i in tc_ids(t):
            for o in byid.get(i, []):
                add('TC-ID COLLISION', 'HIGH', t, o, '@%s is already declared in another file' % i)

    # 2. identical body
    h = collections.defaultdict(list)
    for t in E: h[hashlib.md5(nocomment(t['body']).encode()).hexdigest()].append(t)
    for t in N:
        for o in h.get(hashlib.md5(nocomment(t['body']).encode()).hexdigest(), []):
            add('IDENTICAL BODY', 'HIGH', t, o, 'byte-identical once comments are stripped')

    # 3. strict prefix (new ⊂ existing, or existing ⊂ new)
    SE = [(t, stmts(t)) for t in E]; SN = [(t, stmts(t)) for t in N]
    SE = [(t, s) for t, s in SE if s and len(s) >= 2]
    SN = [(t, s) for t, s in SN if s and len(s) >= 2]
    for t, sn in SN:
        for o, se in SE:
            if len(sn) < len(se) and se[:len(sn)] == sn:
                add('NEW IS A SUBSET', 'HIGH', t, o, 'every statement is the opening of the existing test')
            elif len(se) < len(sn) and sn[:len(se)] == se:
                add('NEW IS A SUPERSET', 'MEDIUM', t, o, 'the existing test is the opening of this one — fold the old ID in')

    # 4. fuzzy title
    bt = collections.defaultdict(list)
    for t in E:
        k = title_key(t['title'])
        if len(k.split()) >= 3: bt[k].append(t)
    for t in N:
        k = title_key(t['title'])
        if len(k.split()) >= 3:
            for o in bt.get(k, []):
                r = difflib.SequenceMatcher(None, nocomment(t['body']), nocomment(o['body'])).ratio()
                add('SAME TITLE', 'MEDIUM', t, o, 'same normalised title; body similarity %.2f' % r)

    # 5. new vs new
    seen = collections.defaultdict(list)
    for t in N: seen[hashlib.md5(nocomment(t['body']).encode()).hexdigest()].append(t)
    for v in seen.values():
        if len(v) > 1:
            for t in v[1:]: add('DUPLICATE AMONG NEW', 'HIGH', t, v[0], 'two generated tests share a body')

    # 6. structural: filename / per-ticket
    bn = collections.defaultdict(set)
    for r in existing + new: bn[r['file'].split('/')[-1]].add(r['file'])
    fileflags = []
    for rel in sorted(new_rel):
        base = rel.split('/')[-1]
        others = sorted(bn.get(base, set()) - {rel})
        if others: fileflags.append(('FILENAME ALREADY EXISTS', rel, 'same basename at: ' + ', '.join(others)))
        m = re.search(r'(gr-\d+|[A-Z]{2,}-\d+)', base, re.I)
        if m:
            tk = m.group(1).lower()
            sib = sorted({ff for vv in bn.values() for ff in vv if tk in ff.lower() and ff != rel})
            if sib: fileflags.append(('TICKET ALREADY HAS A SPEC', rel, '%s also covered by: %s' % (tk, ', '.join(sib))))

    # 7. no-op
    noops = []
    for t in N:
        v, why = noop_verdict(t, asserting)
        if v: noops.append((v, t, why))

    if a.json:
        print(json.dumps({'findings': findings, 'file_flags': fileflags,
                          'noops': [(v, '%s:%d %s' % (t['file'], t['line'], t['title']), w) for v, t, w in noops],
                          'missing': sorted(missing), 'quarantined_skipped': len(quar)}, indent=2))
        return

    print('scanned: %d existing live tests, %d new live tests, %d quarantined files skipped'
          % (len(E), len(N), len(quar)))
    if missing:
        print('!! --new paths not found under the suites: %s' % ', '.join(sorted(missing)))
    order = {'HIGH': 0, 'MEDIUM': 1}
    print('\n== DUPLICATION (%d) ==' % len(findings))
    for f in sorted(findings, key=lambda x: order.get(x['severity'], 9)):
        print('[%s] %s\n    new      %s\n    existing %s\n    why      %s'
              % (f['severity'], f['kind'], f['new'], f['existing'], f['why']))
    print('\n== FILE-LEVEL (%d) ==' % len(fileflags))
    for k, rel, why in fileflags: print('[%s] %s\n    %s' % (k, rel, why))
    print('\n== CANNOT FAIL (%d) ==' % len(noops))
    for v, t, why in noops: print('[%s] %s:%d  %s\n    %s' % (v, t['file'], t['line'], t['title'], why))

if __name__ == '__main__':
    main()
```