---
name: "ci-postcheck-gate"
description: "After a PR merges, prove it actually deployed and works: find its post-merge runs, catch superseded or hidden-failure runs, check the live environment, and compare with the baseline (LANDED_HEALTHY / LANDED_WITH_WARNINGS / NOT_LANDED / REGRESSED). Use it whenever someone asks about a merged PR or fix: did it make it to dev, staging or prod yet, is it live, did the deploy work, did it break develop, is the release out. Short questions like 'is #N on dev yet?' count too."
---

# CI Post-check Gate

Third of three gates:

```
ci-precheck-gate  ──►  ci-run-gate  ──►  ci-postcheck-gate
```

"Merged" is not "deployed", and "deployed" is not "working". Post-merge pipelines are full of
quiet exits — a newer push supersedes the run, a "nothing to deploy" path finishes green, a smoke
job collects zero tests, a health probe is `continue-on-error`. This skill finds the evidence that
**this commit** is running in the environment and that it behaves, or says precisely why not.

Not this skill: CI on an open PR (`ci-run-gate`), merge readiness (`pr-closeout`), ticket-level
functional QA (`manual-test-executor` / repo QA flows), root cause of a found regression
(`root-cause-forensics`). If the repo ships its own deploy-verification skills (e.g. `verify-deploy`,
`verify-chat`), use them as evidence sources — but cross-check their probes (see appendix for a
known false alarm).

The agent runs everything; the user approves shared actions and reads the report.

## Ground rules

- **Read-only on environments by default.** GET health/version endpoints and read-only smoke
  suites are fine on dev/staging. Anything that writes data, needs secrets, or targets
  **production** beyond unauthenticated GETs needs the user's explicit approval naming the
  environment. Some tests that look read-only still write (a short-link redirect that counts a
  click, a login that records a session). The smoke suite the pipeline itself runs against that
  environment after every deploy is fine to run, since every deploy already causes its side effects;
  say in the report that you ran it and what it may have recorded. Other data-writing tests need
  approval, or skip them and say so.
- **Never** trigger deploys, rollbacks, break-glass/emergency workflows, or re-runs of deploy jobs
  yourself. Recommend them in the report with the exact command; a human runs them.
- **One approval** for any shared action you do take (dispatching a read-only smoke workflow,
  posting a ticket/PR comment). List them together, ask once.
- **Secrets stay out.** If a check needs a token (test-session mint, automation token), use it only
  if it's already in the user's local env/secret store and they agree; never print or save it.
- **No AI attribution** in any comment you post. **Plain language first** in the report.

## Step 0 — Access and setup

GitHub access ladder as in `ci-run-gate` (`gh` → connector → browser Checks/Actions pages → ask).
Live checks need network to the environment: try the user's machine shell and the cloud shell;
if neither reaches the host, read-only GET endpoints (health/version JSON, login page) can be opened
in the browser and read as page text — that worked in Cowork testing. If nothing reaches the host,
mark those checks NOT_RUN (no network); don't call the environment down.
Work dir `<repo>/tmp/ci-gate/post-<pr>/` (if git-ignored) else `${TMPDIR:-/tmp}/ci-gate/...`.
Write `ci-map.py`, `gate-run.py`, `pw-failures.py` (end of this file) there.

## Step 1 — Resolve what merged and where it should be

```bash
gh pr view <N> --json number,title,state,mergedAt,mergeCommit,baseRefName,headRefName,url,files -q '{state,mergedAt,merge:.mergeCommit.oid,base:.baseRefName}'
```

Not merged → stop; offer `ci-run-gate`. Without `gh`: `git log --merges --grep "#<N>" origin/<base>`
or the squash commit `git log --grep "(#<N>)" origin/<base> -1`; in the browser, the PR page's
"merged commit … into <base>" timeline entry gives the commit and the time (read the relative
time's `datetime` attribute). Record both: the merge time is what deploy timing and the baseline hang on.

Map base branch → environment(s) from the push lane:
`python3 ci-map.py --ref origin/<base> --event push --branch <base> --expand` → deploy workflows,
their `environment:` names, base URLs in `env:`/vars, health/smoke jobs, Slack notify jobs; then
`--event workflow_run` for chained workflows (`on.workflow_run.workflows` naming the deploy). Note
`concurrency` groups: shared deploy locks and queue/cancel behaviour decide whether a run can be
replaced. Also note schedules that redeploy or test the same environment (they move the baseline).

## Step 2 — Find the runs for the merge commit

```bash
gh api "repos/{owner}/{repo}/actions/runs?head_sha=<MERGE_SHA>&per_page=50" \
  -q '.workflow_runs[] | [.id,.name,.event,.status,.conclusion,.run_attempt,.created_at,.html_url] | @tsv'
```

Expect the push-lane workflows plus their `workflow_run` children. Then check the traps:

- **No run / cancelled / replaced** — a newer push in the same concurrency group took over. Find the
  next run on the base branch that did deploy and check it contains our commit:
  `git merge-base --is-ancestor <MERGE_SHA> <that run's headSha> && echo contains`.
- **Superseded / admitted-later** — a run that deliberately does nothing because a newer commit is
  queued (search its log for "superseded", "skip", "nothing to deploy", "no changes").
- **Green without deploying** — deploy jobs `skipped` because a change detector found no deployable
  paths. That's correct for docs/test-only PRs (say so: "nothing to deploy — verified by <job>"),
  wrong for code PRs.
- **Waiting** — environment approval or a lock queue; report CI is still in progress.

## Step 3 — Audit the jobs (don't trust the run's tick)

```bash
gh run view <RUN> --json jobs -q '.jobs[] | [.databaseId,.name,.conclusion] | @tsv'
gh run view <RUN> --json jobs -q '.jobs[] | select(.conclusion=="success") | .name as $j | .steps[] | select(.conclusion=="failure") | "\($j) :: \(.name)"'   # first pass only — often EMPTY for continue-on-error steps
gh api repos/{owner}/{repo}/check-runs/<JOB>/annotations -q '.[] | "\(.annotation_level): \(.message)"' | head
gh run view <RUN> --log --job <JOB> | grep -iE "no tests found|0 passed|pass-with-no-tests|skipp(ed|ing) .*health|superseded|nothing to deploy" | head
```

For every job record: conclusion, whether it **ran tests** (count), whether a failure was
swallowed, and why a skipped job skipped (its `if:`).

**Swallowed failures need the log.** GitHub often records a failed `continue-on-error` step as
*success*, so the step-conclusion query above can come back empty while tests really failed. For every
step `ci-map.py` marks `continue-on-error`, and every green job whose annotations say "Process
completed with exit code 1", read that step's log and count passed/failed tests. That is the only
reliable check. Download test artifacts and summarise with `pw-failures.py`.

Read the **notices** of verification jobs, not just their colour: teams sometimes make a check
advisory by an owner decision (e.g. "never fails the deploy"), so a green deploy may say nothing
about the feature, and a red one may be unrelated. Quote the notice text in the report.

Note which follow-on workflows **did not run** because they only fire after a successful deploy —
that is missing coverage, not a pass.

For "nothing to deploy" changes (tests, docs), the change detector's own output is the evidence —
e.g. a summary row like `<service> ⏭️ skip unchanged`. Quote it; don't call that run a failure.

## Step 4 — Prove the deployed version contains the commit

Use the strongest evidence available and name it:
1. A version/health endpoint that reports a SHA, build id or version → compare to the merge SHA
   (or confirm it's a descendant with `git merge-base --is-ancestor`).
2. GitHub Deployments: `gh api "repos/{owner}/{repo}/deployments?sha=<SHA>&environment=<env>"` +
   `/deployments/<id>/statuses`. Caution: any job with `environment:` creates a deployment record —
   a Slack-notify job that succeeds shows "Deployed" even when the real deploy failed. Check which
   job created each record before trusting it.
3. Platform CLIs if installed and authenticated (e.g. `wrangler deployments list`, `kubectl rollout history`,
   `vercel ls`, `fly releases`) — read-only.
4. Deploy job log lines that print the deployed version/SHA.
5. Weakest: deploy job green for a run whose head contains the SHA (say it's indirect).

Per environment: **MATCH** (our SHA or a descendant is live), **BEHIND** (live version predates it),
**UNKNOWN** (no evidence reachable).

Environments move while you check. If a newer deploy finishes during the check (version, build id or
bundle names change), re-check presence at the end and say which build your evidence comes from.

## Step 5 — Live checks against the environment

Build `plan.tsv` for `gate-run.py` — read-only checks first. Run it with `run --budget 150` (repeat until
exit 0) in shells that cut calls after a few minutes, else `start` + `status`; results are resumable.

| Check | How |
|---|---|
| Front door / health | `curl -sS -o /dev/null -w '%{http_code}' <url>` for the health/liveness/login URLs the pipeline itself probes (take them from the workflows, not guesses); check JSON status fields too |
| Smoke suite | the repo's smoke tag/project locally: `BASE_URL=<env> npx playwright test --grep @smoke --reporter=json,line` (use the env var the config reads), or — with approval — dispatch the repo's smoke workflow |
| The change itself | specs added/changed by the PR (`git diff --name-only <SHA>^1 <SHA> -- '*.spec.*' '*.test.*'`) run against the environment when they're E2E and safe for that env; UI changes → screenshots of the changed screens as evidence |
| Repo verifiers | the repo's own post-deploy scripts/skills (chat probes, version checks) when they're read-only |

Keep screenshots/traces from Playwright (`--trace on-first-retry`, `screenshot: only-on-failure`, or
explicit `page.screenshot`) in the work dir — reviewers judge by evidence, not ticks.

## Step 5b — If the merge's own run couldn't verify it

When the run for the merge SHA was red for pre-existing reasons, superseded, or skipped its checks,
walk forward through later runs on the base branch and name the **first run whose verification
genuinely passed** and whose head contains the commit (`git merge-base --is-ancestor`). That is the
earliest real evidence the change works in the environment. Also list later commits that touched
the same files (`git log --oneline <SHA>..origin/<base> -- <files of the PR>`): what is live today
may not be exactly what merged. Finally, if the PR body promised its own post-merge validation
("after merge we will…", latency/perf runs, data checks), look for evidence it happened and report
"not evidenced" if none. Also compare the ticket's status with reality: a ticket marked
Released/Done while the environment is BEHIND is a finding to report (and a ticket comment to offer).
Check the PR description's claims too — a wrong claim (e.g. "still covered by tests X" when X is
skipped) is worth a correcting comment, offered for approval. Check claims about files by reading them
at the commit (`git show <sha>:<path>`, `git grep <pattern> <sha>`), not with GitHub code search,
which indexes only the default branch and drops results.
If a revert PR, incident or bot alert points at this change, report it with its status and any clock it
sets (a fix-forward window, a revert deadline): the reader needs to know how long they have. Report it;
don't act on it.

**If the change misbehaves live, size the damage** (a few minutes, read-only) before the verdict:
- try other inputs of the same kind (date formats, locales, empty or edge values). Some fail
  *silently wrong* instead of visibly broken, which is worse;
- list lanes that are now red because of it: nightly runs, other open PRs whose advisory E2E runs
  against this environment;
- check whether the change's own tests could have caught it (only one item checked, inputs unlike
  real data), and whether they ran before the merge at all (label-gated or path-filtered suites the
  PR never triggered).
This makes the fix and the ticket cover the whole problem.

## Step 6 — Compare with the baseline

Previous run of the same post-merge workflow on the base branch, before our merge:
`gh run list --workflow <file> --branch <base> --event push -L 6 --json databaseId,headSha,conclusion,createdAt`.
For each failing job/test now: was it failing before? → **pre-existing** (report, not ours) vs
**new since this merge** (candidate regression; look at what else merged in between:
`git log --oneline <prev headSha>..<our run headSha>`). Scheduled runs on the same environment are
useful extra baselines.

Then account for **every** run since the merge, up to now, whose head contains the commit — not only
the ones that tell a tidy story:
`gh run list --branch <base> --event push --created ">=<mergedAt>" -L 50 --json databaseId,workflowName,headSha,conclusion,createdAt`
(plus `merge_group`/`schedule` runs on the same environment that already ran; don't wait for future
scheduled runs, name them as the next check), keep those where
`git merge-base --is-ancestor <MERGE_SHA> <headSha>` holds, and give each a line: passed, failed (and
whether that failure is pre-existing or new), cancelled, still running. Runs on other branches belong
here only when they test this environment (an E2E lane pointed at it, say). A failing later run that
contains the change and goes unmentioned makes the whole report look cherry-picked.

## Step 7 — Verdict and report

- **LANDED_HEALTHY** — deployed version contains the commit (MATCH), post-merge jobs genuinely
  passed, live checks pass (including any check of what the change itself does), nothing new is failing.
- **LANDED_WITH_WARNINGS** — MATCH and no new failures, but the proof that it landed and works is
  weaker than it should be, for a reason you can name: presence shown only indirectly; a step failure
  swallowed (`continue-on-error`, advisory); health or smoke coverage the pipeline normally runs was
  skipped or collected 0 tests; a pre-existing failure hides part of the result; a check the
  pipeline itself runs could not be run here (NOT_RUN); or a live check of what the change does gave
  a result you can't call right or wrong without its owner (it may be by design). Name the open
  question.
- **NOT_LANDED** — no deploy contains the commit yet (cancelled, waiting, superseded with no later
  deploy, deploy failed), or it was rolled back.
- **REGRESSED** — landed, and something is broken because of it: the change itself misbehaves live
  (its own tests or a live check of what it does fail, e.g. a new badge shows "NaN"), or a check that
  passed on the baseline now fails in a way tied to this change or its deploy.
- **UNVERIFIED** — the evidence needed (CI runs, deployed version, live checks) could not be reached.
  List what was proven (e.g. "commit is on develop"), what wasn't, and the access that would settle it.
  Don't upgrade "couldn't check" to healthy or to not-landed.

Pick the verdict from the landing evidence, not from how much more could be tested. Every change has
untested corners, latent code worries and follow-up ideas, and an extra check you chose not to run
because it would write to a shared environment is caution, not a gap. Those go under "Notes and
follow-ups" and leave a clean landing LANDED_HEALTHY. A warning needs one of the reasons above, named
in the report; if you can't name one, the verdict is LANDED_HEALTHY.

**Check the report before you send it.** Every number, time, SHA, count and name in it should come
from a tool output in this run: recount anything counted by eye, take times from timestamps or
`date -u` rather than estimates, and quote key lines instead of paraphrasing them. Mark anything you
can't trace as approximate, or leave it out — a wrong detail makes the reader doubt the right ones.
In particular:
- Facts from this skill's appendix or earlier notes are untraced until you re-check them in this run;
  if you use one without re-checking, label it "(from earlier notes, not re-checked)".
- Counts of your own actions (how many times you loaded or ran something) come from the commands, not
  from memory, and durations ("within an hour") are worked out from the two timestamps.
- Name a person (author, owner, reviewer) only when a tool output names them.
- A command that failed or isn't supported proves nothing: write "couldn't check", not "there are none".
- Keep any timeline or actions table in the order things happened, with times copied from the outputs.
- Text you draft for someone else to post (a PR comment, a ticket update) states only what you
  verified. Mark inferences as such ("likely", "appears to") and leave out promises and statuses
  nobody confirmed, such as "fix in progress" or "fix to follow".
- The Scratch line covers every file you created. Keep them all in the work dir (downloads,
  `curl -o`/`-D` output, screenshots), or list any other path next to it.

Save `<PR>_<VERDICT>_CI-Postcheck_<YYYY-MM-DD>.md` and deliver it. Template:

```markdown
# CI Post-check — PR #<N> <title>   **<VERDICT>**
_<date> · merged <mergedAt> into <base> as <sha12> · environment(s): <env → URL>_

## In plain words
<2–4 sentences: is it live, is it working, anything to worry about, what next.>

## Pipeline runs for <sha12>
| Workflow | Event | Run | Conclusion | Real result (after audit) | Notes |
|---|---|---|---|---|---|

## Is this commit deployed?
| Environment | Evidence | Live version | Status (MATCH/BEHIND/UNKNOWN) |
|---|---|---|---|

## Live checks
| Check | Target | Result | Evidence (status code, test counts, screenshot) |
|---|---|---|---|

## Hidden problems found
- <swallowed step / 0-test job / skipped health coverage> — impact

## Compared with baseline (run <id>, <sha12>)
| Job / test | Before | Now | New? |
|---|---|---|---|

## Later runs that contain the commit (merge → now)
| Run | Workflow | Head | Result | Pre-existing or new? |
|---|---|---|---|---|

## Notes and follow-ups (don't change the verdict)
- <test gaps, latent code worries, ideas — or "none">

## Next step
<e.g. post results to the ticket (linear-comment-writer / jira-comment-writer); move ticket (… transition skill);
regression → root-cause-forensics + ticket writer; NOT_LANDED → who to ask and the exact re-deploy command for a human>
Scratch: `<work dir>` (<size, measured last>) — safe to delete.
```

## Promotion lanes (develop → staging → main style repos)

When the base is a promotion target, the same steps apply per hop: promotion PR checks (often
stricter gates than feature PRs), then the post-merge deploy of that environment. A change is
"in production" only when the production deploy run's head contains the commit — trace it hop by
hop (`git merge-base --is-ancestor <SHA> origin/<env-branch>` then that branch's deploy run).

## Helper scripts (write to the work dir exactly as given)

### ci-map.py

````python
#!/usr/bin/env python3
# ci-map v1 — read-only map of a repo's GitHub Actions / GitLab CI. Shared by ci-precheck-gate, ci-run-gate, ci-postcheck-gate.
# usage: python3 ci-map.py [--repo DIR] [--ref origin/develop] [--event pull_request|push|merge_group|schedule|workflow_dispatch|workflow_run|any]
#                          [--branch develop] [--file NAME] [--expand] [--json OUT]
import argparse, json, os, re, signal, subprocess, sys
signal.signal(signal.SIGPIPE, signal.SIG_DFL)

try:
    import yaml
except ImportError:
    sys.exit("ci-map: PyYAML missing -> python3 -m pip install --user pyyaml (or run where it exists)")

ap = argparse.ArgumentParser()
ap.add_argument("--repo", default=".")
ap.add_argument("--ref", default=None, help="read files from this git ref instead of the working tree")
ap.add_argument("--event", default="any")
ap.add_argument("--branch", default=None, help="target branch (PR base for pull_request, pushed branch for push)")
ap.add_argument("--file", default=None, help="only this workflow file (basename)")
ap.add_argument("--expand", action="store_true", help="inline local reusable workflows (uses: ./.github/workflows/_x.yml)")
ap.add_argument("--changed", default=None, help="file with changed paths (one per line): evaluates on.<event>.paths / paths-ignore")
ap.add_argument("--json", default=None)
a = ap.parse_args()
CHANGED = [l.strip() for l in open(a.changed) if l.strip()] if a.changed else None
os.chdir(a.repo)

def git(*args):
    return subprocess.run(["git", *args], capture_output=True, text=True).stdout

def ls(d):
    if a.ref:
        return sorted(p for p in git("ls-tree", "--name-only", f"{a.ref}:{d}").split() if p)
    return sorted(os.listdir(d)) if os.path.isdir(d) else []

def read(p):
    if a.ref:
        r = subprocess.run(["git", "show", f"{a.ref}:{p}"], capture_output=True, text=True)
        return r.stdout if r.returncode == 0 else None
    return open(p, encoding="utf-8").read() if os.path.exists(p) else None

def load(p):
    t = read(p)
    if t is None: return None
    try: return yaml.safe_load(t) or {}
    except yaml.YAMLError as e: return {"__error__": str(e)}

def triggers(doc):
    on = doc.get("on", doc.get(True, {}))  # PyYAML reads bare `on:` as boolean True
    if isinstance(on, str): on = {on: None}
    if isinstance(on, list): on = {k: None for k in on}
    return on or {}

def gh_glob(p):  # GitHub filter glob: ** crosses '/', * and ? do not
    r, i = "", 0
    while i < len(p):
        if p.startswith("**/", i): r += "(?:.*/)?"; i += 3
        elif p.startswith("**", i): r += ".*"; i += 2
        elif p[i] == "*": r += "[^/]*"; i += 1
        elif p[i] == "?": r += "[^/]"; i += 1
        else: r += re.escape(p[i]); i += 1
    return re.compile(r + r"\Z")

def matches(x, pats):  # ordered patterns, '!' negates
    hit = False
    for p in pats:
        neg = p.startswith("!")
        if gh_glob(p[1:] if neg else p).match(x): hit = not neg
    return hit

def glob_ok(branch, pats):
    return matches(branch, pats)

def path_verdict(cfg):
    if CHANGED is None or not isinstance(cfg, dict): return None
    if "paths" in cfg:
        hits = [f for f in CHANGED if matches(f, cfg["paths"])]
        return ("fires", hits[:5]) if hits else ("skipped-by-paths", [])
    if "paths-ignore" in cfg:
        rest = [f for f in CHANGED if not matches(f, cfg["paths-ignore"])]
        return ("fires", rest[:5]) if rest else ("skipped-by-paths-ignore", [])
    return None

def fires(on, event, branch):
    if event == "any": return True
    if event not in on: return False
    cfg = on.get(event) or {}
    if not branch or event not in ("pull_request", "pull_request_target", "push", "merge_group"): return True
    if not isinstance(cfg, dict): return True
    if "branches" in cfg: return glob_ok(branch, cfg["branches"])
    if "branches-ignore" in cfg: return not glob_ok(branch, cfg["branches-ignore"])
    return "tags" not in cfg  # tags-only push filters never fire for a branch

def short(s, n=160):
    s = " ".join(str(s).split())
    return s if len(s) <= n else s[: n - 1] + "…"

LABEL_OK = re.compile(r"^[A-Za-z0-9][\w:./ -]{1,60}$")
LABEL_RE = re.compile(r"labels\.\*\.name\s*,\s*'([^']+)'|label\.name\s*==\s*'([^']+)'|--add-label[ =]\"?([\w:./-]+)")
CTX_RE = re.compile(r"""context['"]?\s*[:=]\s*['"]([^'"$]{3,80})['"]""")

def job_info(jid, j, wf_path, depth=0):
    j = j or {}
    steps = j.get("steps") or []
    runs, uses_actions, coe = [], [], []
    for s in steps:
        if not isinstance(s, dict): continue
        if "run" in s:
            first = next((ln.strip() for ln in str(s["run"]).splitlines() if ln.strip() and not ln.strip().startswith("#")), "")
            runs.append(short(f"{s.get('name', '')}: {first}" if s.get("name") else first, 200))
        if "uses" in s: uses_actions.append(s["uses"])
        if s.get("continue-on-error") not in (None, False): coe.append(short(s.get("name") or s.get("run") or s.get("uses"), 80))
    info = {
        "id": jid, "name": short(j.get("name", jid), 90), "needs": j.get("needs"), "if": short(j["if"], 220) if "if" in j else None,
        "uses": j.get("uses"), "environment": j.get("environment"), "runs_on": j.get("runs-on"),
        "continue_on_error": j.get("continue-on-error"), "timeout": j.get("timeout-minutes"),
        "steps": len(steps), "run": runs, "actions": sorted(set(uses_actions)), "step_continue_on_error": coe,
    }
    u = j.get("uses")
    if a.expand and isinstance(u, str) and u.startswith("./.github/workflows/") and depth < 2:
        sub = load(u[2:])
        if sub and "__error__" not in sub:
            info["called_jobs"] = [job_info(k, v, u[2:], depth + 1) for k, v in (sub.get("jobs") or {}).items()]
    return info

out = {"platform": [], "workflows": [], "filter": {"event": a.event, "branch": a.branch, "ref": a.ref or "working-tree"}}
wf_dir = ".github/workflows"
files = [f for f in ls(wf_dir) if f.endswith((".yml", ".yaml"))]
if files: out["platform"].append("github-actions")
if read(".gitlab-ci.yml") is not None: out["platform"].append("gitlab-ci")
if any(f.startswith("Jenkinsfile") for f in ls(".")): out["platform"].append("jenkins")

for f in files:
    if a.file and f != a.file: continue
    p = f"{wf_dir}/{f}"
    doc = load(p)
    if doc is None: continue
    if "__error__" in doc:
        out["workflows"].append({"file": f, "error": doc["__error__"]}); continue
    on = triggers(doc)
    if not fires(on, a.event, a.branch): continue
    text = read(p) or ""
    trig = {}
    for ev, cfg in on.items():
        if isinstance(cfg, dict):
            c = {k: v for k, v in cfg.items() if k != "inputs"}
            if ev == "workflow_dispatch" or ev == "workflow_call":
                c["inputs"] = {k: {kk: vv for kk, vv in (v or {}).items() if kk in ("type", "default", "options", "required")} for k, v in (cfg.get("inputs") or {}).items()}
            trig[ev] = c
        else:
            trig[ev] = cfg
    labels = sorted({g for m in LABEL_RE.finditer(text) for g in m.groups() if g and LABEL_OK.match(g)})
    pv = path_verdict(on.get(a.event)) if a.event != "any" else None
    out["workflows"].append({
        "file": f, "name": doc.get("name", f), "reusable_only": set(on) <= {"workflow_call"}, "on": trig,
        "paths_verdict": pv,
        "concurrency": doc.get("concurrency"), "labels_referenced": labels,
        "status_contexts_published": sorted(set(CTX_RE.findall(text))),
        "jobs": [job_info(k, v, p) for k, v in (doc.get("jobs") or {}).items()],
    })

gl = read(".gitlab-ci.yml")
if gl is not None:
    try:
        d = yaml.safe_load(gl) or {}
        out["gitlab"] = {"stages": d.get("stages"), "include": d.get("include"),
                         "jobs": {k: {"stage": v.get("stage"), "rules": v.get("rules"), "only": v.get("only"), "script": [short(x) for x in (v.get("script") or [])][:6]}
                                  for k, v in d.items() if isinstance(v, dict) and ("script" in v or "trigger" in v or "extends" in v)}}
    except yaml.YAMLError as e:
        out["gitlab"] = {"error": str(e)}

if a.json:
    with open(a.json, "w") as fh: json.dump(out, fh, indent=1, default=str)

print(f"# ci-map  platform={','.join(out['platform']) or 'none found'}  filter={out['filter']}  workflows={len(out['workflows'])}")
if CHANGED is not None:
    fire = [w["file"] for w in out["workflows"] if not (w.get("paths_verdict") or ("fires",))[0].startswith("skipped")]
    skip = [w["file"] for w in out["workflows"] if (w.get("paths_verdict") or ("fires",))[0].startswith("skipped")]
    print(f"# would fire ({len(fire)}): {', '.join(fire)}")
    print(f"# skipped by path filters ({len(skip)}): {', '.join(skip)}")
    print("# note: job-level `if:` conditions (draft, labels, event type) can still skip jobs inside a firing workflow")
for w in out["workflows"]:
    if "error" in w:
        print(f"\n## {w['file']}  YAML ERROR: {short(w['error'])}"); continue
    pv = w.get("paths_verdict")
    tag = f"  [{pv[0]}{': ' + ', '.join(pv[1]) if pv[1] else ''}]" if pv else ""
    print(f"\n## {w['file']} — {w['name']}{'  [reusable]' if w['reusable_only'] else ''}{tag}")
    for ev, c in w["on"].items():
        print(f"  on.{ev}: {short(json.dumps(c, default=str), 300)}")
    if w["concurrency"]: print(f"  concurrency: {short(json.dumps(w['concurrency'], default=str))}")
    if w["labels_referenced"]: print(f"  labels: {', '.join(w['labels_referenced'])}")
    if w["status_contexts_published"]: print(f"  publishes status: {', '.join(w['status_contexts_published'])}")
    def pj(j, ind="  "):
        flags = [x for x in (f"needs={j['needs']}" if j["needs"] else "", f"if={j['if']}" if j["if"] else "",
                             f"env={j['environment']}" if j["environment"] else "", "CONTINUE-ON-ERROR" if j["continue_on_error"] else "",
                             f"uses={j['uses']}" if j["uses"] else "") if x]
        print(f"{ind}- job {j['id']} \"{j['name']}\" {' | '.join(flags)}")
        for r in j["run"][:12]: print(f"{ind}    $ {r}")
        if len(j["run"]) > 12: print(f"{ind}    … {len(j['run']) - 12} more run steps")
        if j["step_continue_on_error"]: print(f"{ind}    ! continue-on-error steps: {'; '.join(j['step_continue_on_error'])}")
        for c in j.get("called_jobs", []): pj(c, ind + "    ")
    for j in w["jobs"]: pj(j)
if "gitlab" in out:
    print("\n## .gitlab-ci.yml"); print(short(json.dumps(out["gitlab"], default=str), 4000))
````

### gate-run.py

````python
#!/usr/bin/env python3
# gate-run v2 — run a list of check commands with timeouts, logs and a resumable results.json.
#   plan file (TSV, '#' = comment):  id <TAB> mirrors-CI-job <TAB> timeout-seconds <TAB> command...
#   python3 gate-run.py run    --plan plan.tsv --out DIR [--repo .] [--budget 150]   foreground; with --budget it stops before
#                                                     the shell's per-call limit (exit 3 = checks still pending → call again)
#   python3 gate-run.py start  --plan plan.tsv --out DIR [--repo .]                  background; only in shells that keep
#                                                     child processes alive after the call returns
#   python3 gate-run.py status --out DIR       exit 0 = finished, 3 = pending/running, 4 = background runner died (use run --budget)
#   add --rerun failed | --rerun id1,id2 to repeat finished checks when the code did not change
import argparse, hashlib, json, os, signal, subprocess, sys, time
signal.signal(signal.SIGPIPE, signal.SIG_DFL)

ap = argparse.ArgumentParser()
ap.add_argument("mode", choices=["start", "run", "status"])
ap.add_argument("--plan"); ap.add_argument("--out", required=True); ap.add_argument("--repo", default=".")
ap.add_argument("--rerun", default="", help="'failed' or comma-separated ids to run again even if the code did not change")
ap.add_argument("--budget", type=int, default=0, help="seconds this call may use (0 = unlimited)")
a = ap.parse_args()
out = os.path.abspath(a.out); os.makedirs(os.path.join(out, "logs"), exist_ok=True)
RES = os.path.join(out, "results.json")
T_START = time.time()

def sh(cmd, cwd):
    return subprocess.run(cmd, shell=True, cwd=cwd, capture_output=True, text=True).stdout.strip()

def fingerprint(repo):
    head = sh("git rev-parse HEAD", repo)
    dirty = sh("git diff HEAD; git ls-files --others --exclude-standard", repo)
    return head, hashlib.sha1(dirty.encode()).hexdigest()[:12]

def load():
    try: return json.load(open(RES))
    except Exception: return None

def save(d):
    tmp = RES + ".tmp"; json.dump(d, open(tmp, "w"), indent=1); os.replace(tmp, RES)

def parse_plan(p):
    rows = []
    for ln in open(p, encoding="utf-8"):
        if not ln.strip() or ln.lstrip().startswith("#"): continue
        parts = ln.rstrip("\n").split("\t")
        if len(parts) < 4: sys.exit(f"gate-run: bad plan line (need 4 tab-separated fields): {ln!r}")
        rows.append({"id": parts[0].strip(), "mirrors": parts[1].strip(), "timeout": int(parts[2]), "cmd": "\t".join(parts[3:]).strip()})
    return rows

def show(d, alive=False):
    print(f"head={d['head'][:12]} dirty={d['dirty']} started={d['started']} finished={d['finished']}")
    print(f"{'id':28} {'status':8} {'secs':>7}  mirrors")
    for c in d["checks"]:
        print(f"{c['id'][:28]:28} {c['status']:8} {str(c.get('secs', '')):>7}  {c['mirrors'][:70]}")
    for c in d["checks"]:
        if c["status"] in ("FAIL", "TIMEOUT", "NOT_RUN"):
            print(f"\n--- {c['id']} [{c['status']} exit={c.get('exit')}{' · ' + c['reason'] if c.get('reason') else ''}] {c.get('log')}")
            print("\n".join(c.get("tail", [])[-15:]))

if a.mode == "start":
    repo = os.path.abspath(a.repo)
    log = open(os.path.join(out, "runner.log"), "a")
    p = subprocess.Popen([sys.executable, os.path.abspath(__file__), "run", "--plan", os.path.abspath(a.plan), "--out", out, "--repo", repo, "--rerun", a.rerun],
                         stdout=log, stderr=log, start_new_session=True)
    open(os.path.join(out, "runner.pid"), "w").write(str(p.pid))
    print(f"gate-run started pid={p.pid} out={out}\n  poll: python3 {os.path.abspath(__file__)} status --out {out}"
          f"\n  if status exits 4 (runner died when this shell call ended) use: run --budget 150")
    sys.exit(0)

if a.mode == "run":
    repo = os.path.abspath(a.repo)
    head, dirty = fingerprint(repo)
    plan = parse_plan(a.plan)
    prev = load()
    done = {}
    if prev and prev.get("head") == head and prev.get("dirty") == dirty:
        done = {c["id"]: c for c in prev.get("checks", []) if c.get("status") not in (None, "RUNNING", "PENDING")}
        again = {k for k, c in done.items() if c["status"] != "PASS"} if a.rerun == "failed" else set(filter(None, a.rerun.split(",")))
        done = {k: c for k, c in done.items() if k not in again}
    started = prev["started"] if prev and done else time.strftime("%Y-%m-%dT%H:%M:%S%z")
    d = {"head": head, "dirty": dirty, "repo": repo, "started": started, "finished": None,
         "checks": [done.get(r["id"]) or {**r, "status": "PENDING"} for r in plan]}
    save(d)
    ran = 0
    for c in d["checks"]:
        if c["status"] != "PENDING": continue
        left = a.budget - (time.time() - T_START) if a.budget else None
        limit = c["timeout"]
        if left is not None:
            if ran and c["timeout"] > left:  # would not fit in this call: leave it for the next call
                break
            limit = min(c["timeout"], max(5, int(left) - 5))
        c["status"] = "RUNNING"; save(d)
        logf = os.path.join(out, "logs", f"{c['id']}.log")
        t0 = time.time()
        with open(logf, "w") as lf:
            lf.write(f"$ {c['cmd']}\n# cwd={repo} head={head[:12]} timeout={limit}s\n\n"); lf.flush()
            p = subprocess.Popen(c["cmd"], shell=True, cwd=repo, stdout=lf, stderr=subprocess.STDOUT, start_new_session=True,
                                 executable="/bin/bash")
            try:
                rc = p.wait(timeout=limit)
            except subprocess.TimeoutExpired:
                os.killpg(p.pid, signal.SIGTERM); time.sleep(1)
                try: os.killpg(p.pid, signal.SIGKILL)
                except ProcessLookupError: pass
                rc = 124
        ran += 1
        tail = open(logf, errors="replace").read().splitlines()[-40:]
        last = "\n".join(tail[-25:])
        env_reason = ("tool missing" if rc == 127 or "command not found" in last else
                      "out of memory on this machine" if rc in (134, 137) or any(k in last for k in ("heap out of memory", "OOMErrorHandler", "FatalProcessOutOfMemory")) else
                      "binary built for another platform" if any(k in last for k in ("Exec format error", "wrong ELF class", "not a valid Win32", "for another platform", "@esbuild/linux", "@esbuild/darwin")) and rc != 0 else
                      f"needs > {limit}s, longer than this shell allows per call" if rc == 124 and limit < c["timeout"] else None)
        c.update(exit=rc, secs=round(time.time() - t0, 1), log=logf, tail=tail, reason=env_reason if rc != 0 else None,
                 status="PASS" if rc == 0 else "NOT_RUN" if env_reason else "TIMEOUT" if rc == 124 else "FAIL")
        save(d)
    if all(c["status"] not in ("PENDING", "RUNNING") for c in d["checks"]):
        d["finished"] = time.strftime("%Y-%m-%dT%H:%M:%S%z"); save(d)
        show(d); sys.exit(0)
    show(d); print("\n(more checks pending — call run again with the same arguments)"); sys.exit(3)

# status
d = load()
if not d: print("gate-run: no results yet"); sys.exit(3)
alive = False
try:
    pid = int(open(os.path.join(out, "runner.pid")).read()); os.kill(pid, 0); alive = True
except Exception: pass
show(d)
if d["finished"]: sys.exit(0)
sys.exit(3 if alive else 4)
````

### pw-failures.py

````python
#!/usr/bin/env python3
# pw-failures v1 — list failed / flaky / skipped tests from a Playwright JSON report (or a folder of them) and JUnit XML files.
# usage: python3 pw-failures.py <report.json|junit.xml|dir> [...]
import json, os, re, sys, xml.etree.ElementTree as ET
rows, totals = [], {"passed": 0, "failed": 0, "flaky": 0, "skipped": 0}
def walk_pw(suite, path):
    for s in suite.get("suites", []) or []: walk_pw(s, path + [s.get("title", "")])
    for spec in suite.get("specs", []) or []:
        for t in spec.get("tests", []) or []:
            st = t.get("status")  # expected | unexpected | flaky | skipped
            key = {"expected": "passed", "unexpected": "failed", "flaky": "flaky", "skipped": "skipped"}.get(st, "failed")
            totals[key] += 1
            if key in ("failed", "flaky"):
                res = t.get("results") or [{}]
                err = next((r.get("error", {}).get("message", "") for r in reversed(res) if r.get("error")), "")
                att = [x.get("path") for r in res for x in r.get("attachments", []) if x.get("path")]
                rows.append({"status": key, "file": f"{spec.get('file')}:{spec.get('line')}", "title": " › ".join([p for p in path if p] + [spec.get("title", "")]),
                             "project": t.get("projectName"), "retries": len(res) - 1, "tags": spec.get("tags"),
                             "error": re.sub(r"\x1b\[[0-9;]*m", "", err).strip().splitlines()[:3], "attachments": att[:4]})
def read(p):
    if os.path.isdir(p):
        for root, _, fs in os.walk(p):
            for f in fs:
                if f.endswith((".json", ".xml")): read(os.path.join(root, f))
        return
    if p.endswith(".json"):
        try: d = json.load(open(p))
        except Exception: return
        if isinstance(d, dict) and "suites" in d:
            for s in d["suites"]: walk_pw(s, [s.get("title", "")])
    elif p.endswith(".xml"):
        try: root = ET.parse(p).getroot()
        except Exception: return
        for tc in root.iter("testcase"):
            f = tc.find("failure") if tc.find("failure") is not None else tc.find("error")
            if tc.find("skipped") is not None: totals["skipped"] += 1
            elif f is not None:
                totals["failed"] += 1
                rows.append({"status": "failed", "file": tc.get("file") or tc.get("classname"), "title": tc.get("name"), "project": None, "retries": None,
                             "tags": None, "error": (f.get("message") or f.text or "").strip().splitlines()[:3], "attachments": []})
            else: totals["passed"] += 1
for p in sys.argv[1:]: read(p)
print(f"totals: {totals}")
if sum(totals.values()) == 0: print("WARNING: zero tests found — a green run with 0 tests proves nothing")
for r in rows:
    print(f"\n[{r['status'].upper()}] {r['title']}  ({r['file']}, project={r['project']}, retries={r['retries']})")
    for e in r["error"]: print(f"    {e[:220]}")
    for a in r["attachments"]: print(f"    attachment: {a}")
````

## Appendix — project profile: Persefoni `eng-guardrails-platform`

Learned from `origin/develop` @ `50a56fc` (2026-10-16); re-verify with `ci-map.py` before relying on it.
These notes are leads, not evidence: re-check any fact you put in a report, or label it "from earlier
notes, not re-checked".

**Lanes.**
| Merge into | Post-merge workflow (event) | Environment |
|---|---|---|
| `develop` | "Deploy (dev)" `deploy-dev.yml` → `_deploy-dev.yml` (push), then "Staging PR Validation" via `workflow_run` (SEV ui-smoke + critical-smoke against app.dev) | `https://app.dev.firstrecon.ai` |
| `staging` (from `release-candidate/*` etc.) | "Staging Post-Merge Deploy" `staging-post-merge.yml` (push) | `https://app.staging.firstrecon.ai` |
| `main` (from `staging`) | "Production Post-Merge Deploy" `production-post-merge.yml` (push) | `https://app.firstrecon.ai` |

**Dev traps (Deploy (dev)).**
- `deployment-admission` ("Admit latest pending develop push") sets proceed=false when a newer
  develop push is waiting → that run deploys nothing; a later run deploys develop HEAD → use
  `git merge-base --is-ancestor`.
- Concurrency `deploy-dev-automatic-admission` (queue single) can replace a waiting run; the
  `dev-deploy` lock is shared with "scheduled-health", which redeploys develop at 00:00/08:00/16:00 UTC.
- `no-deployment-changes` path finishes green without deploying (correct for test/docs-only PRs).
- Jobs to check: "Deploy fleet / Verify deployed monolith (probes)", "Verify SEV AUTOMATION_TOKEN
  (dev-validation)", "Verify Chat Delivery + Enforcement (development)", the 9 automation shards
  (run with `--pass-with-no-tests` — check counts), then both SEV jobs in the follow-on run.
- Dev-N slot deploys skip probes/automation/verify-chat — check slots by hand.

**Live checks (read-only).**
- Dev/staging front door (what the deploy notifier probes): `GET <base>/api/health/alive` and
  `GET <base>/api/health/telemetry` → 200 and `.data.status` passing; `GET <base>/login` → 200.
- Staging IAM: `GET https://iam.staging.firstrecon.ai/health`.
- Production: `GET /health` → 200; `GET /api/health/telemetry` → 200, `success:true`;
  `GET /api/auth/auth0/login?return_url=…` → 302 to `/authorize`. No test-session in production.
- Chat: repo skill `verify-chat` / `bun scripts/ci/verify-chat-probe.ts` (exit 0 pass, 2 mint failed,
  3 delivery failed, 4 enforcement regression, 5 infra/provider) — needs an automation token; staging
  host is `guardrails-staging.guardrails-staging.workers.dev` (the `*.persefoni.workers.dev` staging
  host returns 1042 by design). Read-only chat check on staging/prod:
  `gh workflow run chat-clearance-smoke.yml -f environment=staging|production` (approval needed).

**Known false alarm.** Repo skill `verify-deploy` probes per-worker `*.workers.dev/health`; those
hosts return Cloudflare 1042/404 because `workers_dev=false` (`scripts/notify-slack-deploy.sh`). Treat
its "DOWN" as UNKNOWN and use the front-door checks above.

**Soft spots to report as warnings, not passes.** Platform-critical chat coverage skips leniently on
chat-health failure; production SEV runs only on `merge_group` (may never run); production checks are
unauthenticated only; automatic production rollback covers only the main + guardrails worker pair;
release-candidate dev-4 validation is advisory; staging suites run even if auth-state setup failed.

**Test-round lessons (2026-10-19, PR #15854).** Deploy (dev) #11102 for `50a56fc` deployed 24/24 workers
(job summary prints `deployment_sha`) but ended red on chat checks (`CLEARANCE_RECOVERY_REQUIRED`) — identical
on the parent commit's run, so pre-existing. #11189 was a superseded "green" that deployed nothing. Since a
2026-10-18 owner ruling the dev chat verification "never fails the dev deploy" (advisory) — read the
"Verify Chat Delivery + Enforcement" notice text. Automation shards run with `--pass-with-no-tests`:
`api.regression` collects 0 (its only spec is `*.spec.fix.ts`) and `browser.multi-tenant` collects 0 (no
spec has the tag) — never count them as coverage. Follow-ons ("Staging PR Validation", "PR Regression Tests
(Dev)", "Topology Security Deployed Acceptance") run only after a successful deploy. Health endpoints don't
report a version; the deploy job summary/log is the best "what's live" evidence. Both shells were blocked from
`app.dev`; the browser could read `/api/health/alive`, `/api/health/telemetry`, `/login`.

**Round-2 lessons (2026-10-19).** Test-only PR #14780: its own run #10230 was cancelled ("higher
priority waiting request for deploy-dev-automatic-admission"), #10262 was green with every job skipped
(superseded), and the "Detect changed workers" row `guardrails-dev ⏭️ skip unchanged` is the
nothing-to-deploy evidence. Production: as of 2026-10-19 the last green "Production Post-Merge Deploy"
was #314 (26 Aug); #316 (release PR #16288) failed 4 times at Preflight on Keeper custody signing keys,
so main ≠ production. The `prod` deployments page showed "Deployed" for #16288 only because the
"Notify Slack" job carries `environment: prod`. Linear may mark a ticket Released before it reaches
production (FRAI-8257 was Released before it even merged to develop). Staging "Staging Post-Merge
Deploy" #715 (19 Oct) was green, but staging chat checks are opt-in and were skipped.

**Round-3 lessons (2026-10-19).** PR #16373 (UI): the Deploy (dev) run for its merge commit (#11507)
was green with 130 of 135 jobs skipped (superseded). The real deploy was #11509 (US cell green; EU cell
failed on a pre-existing Cloudflare 10215 secrets error, same as #11506 before the merge). "Staging PR
Validation" #10665 was green in 29 s with no tests. No-login proof of a frontend change: fetch the
public JS bundle from app.dev and search it for strings the PR added or removed. The dev build changed
mid-check (#11516), so re-check at the end. Don't re-run an old deploy run: it would roll dev back.

**Round-4 lessons (2026-10-19).** PR #16433 merged through the merge queue at ~15:17 UTC (`99a1cfb`).
Its Deploy (dev) #11519 sat "Pending — waiting for Deploy (dev) #11516", and one deploy took ~40 min per
region half, so a merge can need 1–2 hours to reach dev: report NOT_LANDED with the queue position and
an ETA, not a failure. While waiting, dev served `bc7746d` (from #11516's `deployment_sha`).
`/api/version` returns 404 on dev. Linear marked FRAI-6807 Released before dev had the change.

**Round-5 lessons (2026-10-19).** PR #16434 (into develop, `c623ffe`): a bot opened revert PR #16455
after a develop full-suite failure, with a 60-minute fix-forward window; report the PR, its window and
its status, and read the failing tests yourself before agreeing with the bot's blame. After earlier dev
deploys were cancelled, Deploy (dev) #11521 (`39624df`, contains the merge) deployed guardrails-dev in
the US cell at 17:02:10Z. A later develop "Fast Path" run (#332) that contained the change failed; list
every such run, not only the green ones. "Staging PR Validation" again ran with zero tests.

**Where results go.** Ticket comment: `linear-comment-writer` (team key FRAI). Product regressions:
`root-cause-forensics` → `linear-ticket-writer`.