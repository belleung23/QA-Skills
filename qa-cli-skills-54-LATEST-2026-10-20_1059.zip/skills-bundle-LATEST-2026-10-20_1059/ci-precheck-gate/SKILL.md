---
name: "ci-precheck-gate"
description: "Before pushing a branch or opening a PR in any repo, work out what CI will run on the change and run the same checks locally, then write a READY_TO_PUSH / NOT_READY / BLOCKED report. Use it whenever someone is about to push or open a PR/MR and wants to know if CI will pass: will my branch pass, sanity-check or pre-check my branch, run what CI runs (lint, typecheck, unit tests, PR guards) locally, will a named check or guard go red. Covers test-only and spec-cleanup branches too, even when the user never says 'CI'."
---

# CI Pre-check Gate

First of three gates for getting a change through CI:

```
ci-precheck-gate  ──►  ci-run-gate  ──►  ci-postcheck-gate
(before push / PR)     (PR running in CI → verdict)     (after merge / deploy → landed & healthy?)
```

The idea: CI is slow and public, the laptop is fast and private. Every check CI will run and
that can run locally should run here first, with the **same command, config and scope** CI uses,
so a red PR only happens for things that truly can't be checked locally (deployed-environment
E2E, merge-queue-only suites, secret-backed scans).

Not this skill: code review (`pr-review`), test-quality review of new specs (`automation-aegis`,
`dead-test-audit`, `duplication-gate`), merge readiness of an open PR (`pr-closeout`), building or
editing pipelines (`qa-ci-cd`). Hand off to them when that is what's needed.

The agent runs everything end to end; the user only approves shared actions (see Ground rules)
and reads the report. Don't hand commands back to the user to run.

## Ground rules

- **Mirror, don't invent.** Take commands from the CI files and the repo's own scripts. A check
  you made up proves nothing about CI. If you must adapt a command (different runtime, smaller
  batch, cache path), say so in the report next to that check.
- **Never weaken or bypass a gate** — no `--no-verify`, `HUSKY=0`, `SKIP=`, `--max-warnings`
  raised, tests skipped/`.only`'d, bypass labels (`skip-*`, `allow-*`), or edits to CI files to
  make a check pass. If a gate can't pass legitimately, the verdict is BLOCKED and a human decides.
- **Don't touch the user's work-in-progress.** No `git stash`, `reset`, `checkout`, `clean`,
  `rebase`, or `add -A`. Read the tree as it is. Write caches and outputs outside tracked folders
  (tools that write `.eslintcache`/`.prettiercache` in the repo: point them at the work dir).
- **Shared actions need one approval.** Pushing, opening/updating a PR, labels, PR comments,
  workflow dispatches are `ci-run-gate`'s job. If the user wants them now, list every intended
  action in one message and wait for a yes.
- **No AI attribution** in commit messages, PR titles/bodies or comments (no Co-Authored-By,
  "Generated with", session links) unless the user asks for it.
- **NOT_RUN is not PASS.** A check that could not run locally (tool missing, no network, OOM,
  wrong platform binary) is reported as NOT_RUN with the reason, and CI remains the judge.
- **Plain language first.** The report opens with 2–4 plain sentences a non-specialist can act on.

## Step 0 — Set up

1. Repo root: `git rev-parse --show-toplevel`. Work dir: `<repo>/tmp/ci-gate/<branch-slug>/` if
   `git check-ignore -q tmp/ci-gate/x` succeeds (the folder is ignored), else
   `${TMPDIR:-/tmp}/ci-gate/<repo-name>/<branch-slug>/`.
2. Write the two helper scripts at the end of this file into the work dir **exactly as given**
   (`ci-map.py`, `gate-run.py`; quoted heredoc `<<'PYEOF'` or a file-write tool). They need only
   `python3` + PyYAML (`python3 -c "import yaml"`; if missing: `python3 -m pip install --user pyyaml`).
3. Note the shell limits. Some agent shells kill each command after ~2–3 minutes, kill anything it
   started in the background when the call returns, and have no network (the Cowork shell on the
   user's computer does all three). There, run checks with `gate-run.py run --budget 150` and call
   it again until it exits 0; it never starts a check that can't finish inside the call, and a
   check longer than one call is reported NOT_RUN (shell limit) rather than failed. In normal
   shells, `gate-run.py start` (background) + `status` polling is fine. If `git fetch` fails, keep
   going with the existing `origin/<base>` and record its commit date in the report.

## Step 1 — Pin down the change

```bash
git branch --show-current; git status --porcelain=v1 | head -50
BASE=<base branch>          # from the user, the PR, the repo rules (e.g. features → develop), else the default branch
git fetch origin "$BASE" --quiet || echo "fetch failed — using cached origin/$BASE"
git log -1 --format='%h %cd' "origin/$BASE"
MB=$(git merge-base HEAD "origin/$BASE")
git diff --name-only "$MB" HEAD > "$WORK/changed-committed.txt"
git diff --name-only HEAD > "$WORK/changed-uncommitted.txt"; git ls-files --others --exclude-standard >> "$WORK/changed-uncommitted.txt"
git rev-list --count HEAD.."origin/$BASE"     # commits behind base
git merge-tree --write-tree "origin/$BASE" HEAD >/dev/null || echo "CONFLICTS with $BASE"   # git ≥ 2.38; adds a few unreferenced objects to .git (harmless)
#   older git: git merge-tree "$MB" "origin/$BASE" HEAD | grep -q '^<<<<<<<\|^changed in both' && echo CONFLICTS
git cherry -v "origin/$BASE" HEAD            # lines starting with '-' = that change is ALREADY in base (same patch)
```

CI only ever sees **committed and pushed** files. If there are uncommitted changes, say clearly
which ones CI will not see, and evaluate the committed set (`changed-committed.txt`) as the PR.
If the user intends to commit the rest first, evaluate the union and say so. Also check:
- **Already upstream?** If `git cherry` marks every branch commit `-`, or the merge result's tree
  equals the base tree (`git merge-tree --write-tree origin/$BASE HEAD | head -1` = `git rev-parse
  origin/$BASE^{tree}`; catches squash-merged siblings that `git cherry` misses), the change is
  already in the base — the PR would change nothing. Stop and say so.
- **Hooks that need a clean tree.** Some pre-push hooks refuse to push while files are modified or
  untracked. A large untracked pile that isn't git-ignored is also one `git add -A` away from being
  committed — list it.
- **The PR isn't HEAD?** When the change the user means is uncommitted, or sits on a stale branch
  that must be rebuilt, check the PR they will actually open: build a **PR tree** in the work dir —
  `git archive origin/$BASE | tar -x -C "$WORK/prtree"`, copy in only the intended files, detect
  overlaps with `git merge-file -p <their file> <merge-base version> <base version>` (conflict
  markers = a real conflict to report), symlink `node_modules` (never copy dependencies; in a big repo
  extract only the folders the checks read), and run the plan there. This needs
  no git writes, which matters in shells where git lock files can't be cleaned up. Give a scope
  selector that reads `git diff` the intended file list (a small wrapper) and say so in the report.
  If you also need git history (commitlint, ancestry), make a `git clone --no-checkout` of the repo
  **outside** it (VM home or scratchpad), never inside the repo's `tmp/`: where deletes are blocked, a
  failed clone in the repo leaves a folder nobody can clean up.

## Step 2 — Find out what CI will run on this change

1. **Workflows that fire** for a PR into `$BASE` with these files:
   ```bash
   python3 "$WORK/ci-map.py" --ref "origin/$BASE" --event pull_request --branch "$BASE" \
     --changed "$WORK/changed-committed.txt" --expand --json "$WORK/ci-map-pr.json" > "$WORK/ci-map-pr.txt"
   ```
   Read from `origin/$BASE`, not the working tree: PR workflows run from the PR's merge ref, and
   many repos pin their gate scripts to the base branch so a PR can't edit its own rules. If the
   PR itself edits CI files, also map the working tree and note the difference.
   Repeat with `--event merge_group` if the repo uses a merge queue — some suites run only there,
   so "green PR, red queue" is possible; list those suites as CI-only.
2. **Jobs inside them.** Read job `if:` conditions in the map: draft PRs skipped? opt-in labels?
   event types? Note which jobs this PR will actually get.
3. **The repo's own scope selector.** If a workflow decides scope with a script (e.g.
   `detect-*-scope`, `test-changed`, `affected`, `nx affected`, `turbo --filter`), run that script
   locally **from the base ref** with the same inputs CI gives it (read its header/env vars and
   the workflow step's `env:`), e.g. `git archive origin/$BASE scripts | tar -x -C "$WORK/base"` then
   run it from the repo root with `BASE_SHA=$MB HEAD_SHA=HEAD`. Keep `$WORK` inside the repo (a
   git-ignored folder) so the script's package imports resolve against the repo's `node_modules`;
   if the repo has no ignored folder, extract to a temp dir and symlink the dependencies next to it
   (`ln -s "$REPO/node_modules" "$WORK/base/node_modules"` — ES-module imports ignore `NODE_PATH`).
   Its output is the exact scope CI will pick — use it, don't guess. The same trick runs CI's own
   guard scripts (freshness, policy, coverage-selection) exactly as CI would.
4. **Required checks.** Best source: `gh api repos/{owner}/{repo}/rules/branches/$BASE` (rulesets)
   or `.../branches/$BASE/protection/required_status_checks`. Fallbacks: infra-as-code in the repo
   (`grep -rn "required_status_checks\|required_checks" tf/ terraform/ infra/`), CI docs. Mark the
   source; say "unverified" if only docs.
5. **Contributor rules.** `AGENTS.md`, `CLAUDE.md`, `CONTRIBUTING.md`, `REVIEW.md`,
   `.github/pull_request_template.md`, `CODEOWNERS`, high-risk-path lists, commit-lint config,
   branch-naming rules, PR-size guidance, ticket-ID rules.
6. **Local hooks.** `.husky/*`, `lefthook.yml`, `.pre-commit-config.yaml`, `.lintstagedrc*`,
   `package.json` `prepare`. Hooks will run at commit/push anyway; knowing them tells you what the
   user will hit and which checks are mirrored already.

## Step 3 — Build the mirror plan

Write `$WORK/plan.tsv` — one row per check: `id<TAB>CI job it mirrors<TAB>timeout-seconds<TAB>command`.
Only include checks whose CI trigger condition matches this change. Order cheap → expensive so
fast failures surface first.

| Tier | What | Typical source of the command |
|---|---|---|
| T0 prerequisites | base freshness (commits behind, mass deletes), merge conflicts, branch name, commit messages (`npx commitlint --from $MB --to HEAD`), new-file size budgets, secrets (`gitleaks detect --log-opts "$MB..HEAD"` / `protect --staged` if installed), large binaries | repo guards, hooks, rules docs |
| T1 static | format check on changed files, lint with CI's config and warning cap, type-check with CI's tsconfig/project | the PR workflow's `run:` lines, `package.json` scripts |
| T2 tests | unit tests CI's scope selector picked (changed-only runner if the repo has one); E2E **collection** for changed/added specs and for every `--grep` pattern CI uses (`npx playwright test --list ...`) — zero collected = fail; **will CI ever run the changed specs?** match their tags/paths against the suites' `--grep`/path lists (or the repo's coverage-selection tool) — a spec no lane selects can never fail in CI, so say so | scope selector output, test workflows |
| T3 repo policy | scripts CI runs only for certain paths (CI-policy for workflow edits, i18n for locales, OpenAPI for routes, migration checks, ownership/boundaries) | conditional jobs in the map |
| T4 PR metadata | draft the PR title/body against the template + rules; required sections for high-risk paths; ticket ID; labels needed and who may add them | template, guards, rules docs |

Adapting commands when the local box differs from CI:
- Runtime missing (e.g. `bun` absent): run TypeScript scripts with `npx tsx <script>`, or — if tsx
  breaks (e.g. esbuild version mismatch) — `node --experimental-strip-types <script>` (Node ≥ 22.6);
  label "substitute runtime"; if nothing works, NOT_RUN.
- Memory-heavy linters/type-checkers: set the same `NODE_OPTIONS` heap CI uses, split into batches.
- Runtime version: use the version CI's setup step pins (`node-version`, `.nvmrc`, `python-version`).
  If CI doesn't pin one, a check can pass or fail depending on the runner — run it on the likely
  versions and report that as a CI-only risk.
- Caches: `--cache-location "$WORK/.cache/eslint"`, prettier `--cache-location`, so nothing is
  written into the repo.
- Platform binaries (esbuild/rollup/swc) built for another OS: if a tool fails with an
  exec-format/“wrong platform” error, mark NOT_RUN (environment), don't reinstall dependencies.
- A tool CI pins is missing (gitleaks, a ruff or eslint version): fetch that exact version into
  `$WORK` — the project's release download with a plain `curl -sSfL <release URL>`, `pip install
  --target "$WORK/py"`, `npx <pkg>@<version>` — never into shared locations. If the `gh` CLI is
  refused for that tool's repo, the plain release URL may still be allowed: try it once. If that is
  refused too, mark NOT_RUN; don't look for mirrors.

Things that **cannot** be mirrored locally go in a "CI-only" list in the report (deployed-env E2E,
merge-queue-only suites, scans needing CI secrets, CodeQL), never as PASS.

## Step 4 — Run

```bash
# shells with a per-call limit (e.g. Cowork's shell on the user's computer): repeat until exit 0
python3 "$WORK/gate-run.py" run --plan "$WORK/plan.tsv" --out "$WORK/run" --repo "$REPO" --budget 150
# shells without that limit:
python3 "$WORK/gate-run.py" start --plan "$WORK/plan.tsv" --out "$WORK/run" --repo "$REPO"
python3 "$WORK/gate-run.py" status --out "$WORK/run"   # 0 = done, 3 = running, 4 = runner died → switch to run --budget
```

Between calls, prepare the PR-metadata check (T4). Results resume: re-running with unchanged code
skips finished checks; `--rerun failed` or `--rerun id1,id2` forces re-runs. Any code change resets
everything (the fingerprint is HEAD + diff). A check that needs longer than one shell call (full
type-check of a big repo) shows NOT_RUN "longer than this shell allows" — run it in a shell without
the limit if one exists, else list it as CI-only.

## Step 5 — Judge each failure

For every FAIL / TIMEOUT / NOT_RUN, open its log (`$WORK/run/logs/<id>.log`) and classify:

| Class | Meaning | Evidence to cite |
|---|---|---|
| CHANGE | caused by this branch | error points at a changed file/line, or a test the change affects |
| BASE | already broken on `$BASE` | error in unchanged files; same check fails on base (latest base CI run, or the error exists at `origin/$BASE`) |
| LOCAL-ENV | local box can't run it like CI | tool missing, OOM, platform binary, no network → NOT_RUN |
| FLAKY | passes on immediate re-run with no change | `--rerun <id>` result |
| POLICY | rule/metadata gate (missing PR section, label, approvals, size) | the rule text + file:line |

**Removed or folded tests.** When the change deletes a test because another one "already covers it",
open the surviving test and check it can still **fail** for the same reason: a `test.fixme`/`test.skip`
guard, an `if (!visible) return`, a soft or always-true assertion (`expect(true).toBeTruthy()` on a
value already known to be true) means the row moves from "fail" to "skip". That is a coverage change
to state in the report, even if the tag still selects the test.

To prove BASE, run the same failing check on a clean base tree (`git archive origin/$BASE` into the
work dir, same command); if it fails the same way, it is BASE. Only CHANGE and POLICY items are the
author's to fix before pushing. BASE items get reported
(the PR may still go red on them — say which required check they hit). Never "fix" BASE items in
this PR unless the user asks; that widens the PR.

If the user asks you to fix: fix only CHANGE items, the smallest correct change, then run
`gate-run.py` again the same way (code changed → full re-run of the plan; fine, it's the truth).

When you try a fix route on a throwaway copy (to prove the suggested fixes work), report exactly
what you re-ran there and what you didn't: "on the fixed copy lint, migrations and unit passed;
secret scan and MR title not re-run". "Every check passed" or "re-ran everything" is only true when
that list is complete.

## Step 6 — Verdict and report

Predict the pipeline **as CI will show it**: with GitLab's default stage order (no `needs:`), or a
GitHub job with `needs:`, jobs after a failed one are *skipped*, not red. Say which failures will
show first and which jobs will simply never start until those are fixed. Word results exactly:
"passes every check I ran; N CI-only checks not verified" — never "passes everything CI will run".

- **READY_TO_PUSH** — every mirrored check that applies passed; no CHANGE/POLICY items left.
  BASE/FLAKY/NOT_RUN items may exist but are listed with their risk.
- **NOT_READY** — at least one CHANGE or POLICY item the author can fix.
- **BLOCKED** — needs a human decision or permission (maintainer-only label, second approver,
  governance override, conflict with a protected rule, merge conflict needing judgement).

**Check the report before you send it.** Every number, time, SHA, count and name in it should come
from a tool output in this run: recount anything counted by eye, take times from timestamps or
`date -u` rather than estimates, and quote key lines instead of paraphrasing them. Mark anything you
can't trace as approximate, or leave it out — a wrong detail makes the reader doubt the right ones.
In particular:
- Facts from this skill's appendix or earlier notes are untraced until you re-check them in this run;
  if you use one without re-checking, label it "(from earlier notes, not re-checked)".
- Counts of your own actions (how many times you loaded or ran something) come from the commands, not
  from memory, and durations ("within an hour") are worked out from the two timestamps.
- Name a person (author, owner, reviewer) only when a tool output names them.
- A command that failed or isn't supported proves nothing: write "couldn't check", not "there are none".
- Keep any timeline or actions table in the order things happened, with times copied from the outputs.
- Text you draft for someone else to post (a PR comment, a ticket update) states only what you
  verified. Mark inferences as such ("likely", "appears to") and leave out promises and statuses
  nobody confirmed, such as "fix in progress" or "fix to follow".
- The Scratch line covers every file you created. Keep them all in the work dir (downloads,
  `curl -o`/`-D` output, screenshots), or list any other path next to it.

Save `$WORK/<branch-slug>_<VERDICT>_CI-Precheck_<YYYY-MM-DD>.md` and deliver it to the user
(in Cowork: also into the conversation outputs). Template:

```markdown
# CI Pre-check — <branch> → <base>   **<VERDICT>**
_<date> · head <sha12> · base origin/<base> @ <sha12> (<base commit date>) · <N> commits ahead, <M> behind_

## In plain words
<2–4 sentences: will CI pass, what must be fixed first, what can only be known in CI.>

## What CI will run on this PR
| Workflow | Fires? | Why / why not | Required check? |
|---|---|---|---|
Scope chosen by the repo's selector: `<key outputs>` (ran `<command>` from base ref)

## Local mirror results
| # | Check | Mirrors CI job | Command (adaptations noted) | Result | Time | Class | Evidence / fix |
|---|---|---|---|---|---|---|---|

## PR prerequisites
| Requirement | Source (file:line) | Status | What to do |
|---|---|---|---|

## CI-only (cannot be checked locally)
- <suite/scan> — runs in <workflow/job>, when <condition>; risk: <low/med/high + why>

## Not seen by CI
- <uncommitted files, if any>

## Next step
<e.g. "Approve: push branch + open draft PR + add labels X → ci-run-gate" / "Fix 2 items above, then re-run">
Scratch: `<work dir>` (<size, measured last>) — safe to delete.
```

## Step 7 — Hand off

READY_TO_PUSH → offer `ci-run-gate` with the exact list of shared actions it would take (push,
draft PR with a body that already satisfies T4, labels, comment commands). The user approves once.
NOT_READY → offer to fix CHANGE items (or hand back if the user prefers). BLOCKED → name the person
or role whose decision is needed and what to ask them.

## GitLab CI / Jenkins notes

- GitLab: `ci-map.py` prints `.gitlab-ci.yml` stages/jobs/rules; also `glab ci lint`. Mirror
  `script:` lines of jobs whose `rules:` match `merge_request_event` + your paths (`changes:`).
- Jenkins: read `Jenkinsfile*` stages (`sh '...'` lines) and `when { changeset ... }` blocks; mirror
  those commands. There is no reliable offline evaluator — say which stages you assumed run.

## Helper scripts (write to the work dir exactly as given)

### ci-map.py

````python
#!/usr/bin/env python3
# ci-map v1 — read-only map of a repo's GitHub Actions / GitLab CI. Shared by ci-precheck-gate, ci-run-gate, ci-postcheck-gate.
# usage: python3 ci-map.py [--repo DIR] [--ref origin/develop] [--event pull_request|push|merge_group|schedule|workflow_dispatch|workflow_run|any]
#                          [--branch develop] [--file NAME] [--expand] [--json OUT]
import argparse, json, os, re, signal, subprocess, sys
signal.signal(signal.SIGPIPE, signal.SIG_DFL)

try:
    import yaml
except ImportError:
    sys.exit("ci-map: PyYAML missing -> python3 -m pip install --user pyyaml (or run where it exists)")

ap = argparse.ArgumentParser()
ap.add_argument("--repo", default=".")
ap.add_argument("--ref", default=None, help="read files from this git ref instead of the working tree")
ap.add_argument("--event", default="any")
ap.add_argument("--branch", default=None, help="target branch (PR base for pull_request, pushed branch for push)")
ap.add_argument("--file", default=None, help="only this workflow file (basename)")
ap.add_argument("--expand", action="store_true", help="inline local reusable workflows (uses: ./.github/workflows/_x.yml)")
ap.add_argument("--changed", default=None, help="file with changed paths (one per line): evaluates on.<event>.paths / paths-ignore")
ap.add_argument("--json", default=None)
a = ap.parse_args()
CHANGED = [l.strip() for l in open(a.changed) if l.strip()] if a.changed else None
os.chdir(a.repo)

def git(*args):
    return subprocess.run(["git", *args], capture_output=True, text=True).stdout

def ls(d):
    if a.ref:
        return sorted(p for p in git("ls-tree", "--name-only", f"{a.ref}:{d}").split() if p)
    return sorted(os.listdir(d)) if os.path.isdir(d) else []

def read(p):
    if a.ref:
        r = subprocess.run(["git", "show", f"{a.ref}:{p}"], capture_output=True, text=True)
        return r.stdout if r.returncode == 0 else None
    return open(p, encoding="utf-8").read() if os.path.exists(p) else None

def load(p):
    t = read(p)
    if t is None: return None
    try: return yaml.safe_load(t) or {}
    except yaml.YAMLError as e: return {"__error__": str(e)}

def triggers(doc):
    on = doc.get("on", doc.get(True, {}))  # PyYAML reads bare `on:` as boolean True
    if isinstance(on, str): on = {on: None}
    if isinstance(on, list): on = {k: None for k in on}
    return on or {}

def gh_glob(p):  # GitHub filter glob: ** crosses '/', * and ? do not
    r, i = "", 0
    while i < len(p):
        if p.startswith("**/", i): r += "(?:.*/)?"; i += 3
        elif p.startswith("**", i): r += ".*"; i += 2
        elif p[i] == "*": r += "[^/]*"; i += 1
        elif p[i] == "?": r += "[^/]"; i += 1
        else: r += re.escape(p[i]); i += 1
    return re.compile(r + r"\Z")

def matches(x, pats):  # ordered patterns, '!' negates
    hit = False
    for p in pats:
        neg = p.startswith("!")
        if gh_glob(p[1:] if neg else p).match(x): hit = not neg
    return hit

def glob_ok(branch, pats):
    return matches(branch, pats)

def path_verdict(cfg):
    if CHANGED is None or not isinstance(cfg, dict): return None
    if "paths" in cfg:
        hits = [f for f in CHANGED if matches(f, cfg["paths"])]
        return ("fires", hits[:5]) if hits else ("skipped-by-paths", [])
    if "paths-ignore" in cfg:
        rest = [f for f in CHANGED if not matches(f, cfg["paths-ignore"])]
        return ("fires", rest[:5]) if rest else ("skipped-by-paths-ignore", [])
    return None

def fires(on, event, branch):
    if event == "any": return True
    if event not in on: return False
    cfg = on.get(event) or {}
    if not branch or event not in ("pull_request", "pull_request_target", "push", "merge_group"): return True
    if not isinstance(cfg, dict): return True
    if "branches" in cfg: return glob_ok(branch, cfg["branches"])
    if "branches-ignore" in cfg: return not glob_ok(branch, cfg["branches-ignore"])
    return "tags" not in cfg  # tags-only push filters never fire for a branch

def short(s, n=160):
    s = " ".join(str(s).split())
    return s if len(s) <= n else s[: n - 1] + "…"

LABEL_OK = re.compile(r"^[A-Za-z0-9][\w:./ -]{1,60}$")
LABEL_RE = re.compile(r"labels\.\*\.name\s*,\s*'([^']+)'|label\.name\s*==\s*'([^']+)'|--add-label[ =]\"?([\w:./-]+)")
CTX_RE = re.compile(r"""context['"]?\s*[:=]\s*['"]([^'"$]{3,80})['"]""")

def job_info(jid, j, wf_path, depth=0):
    j = j or {}
    steps = j.get("steps") or []
    runs, uses_actions, coe = [], [], []
    for s in steps:
        if not isinstance(s, dict): continue
        if "run" in s:
            first = next((ln.strip() for ln in str(s["run"]).splitlines() if ln.strip() and not ln.strip().startswith("#")), "")
            runs.append(short(f"{s.get('name', '')}: {first}" if s.get("name") else first, 200))
        if "uses" in s: uses_actions.append(s["uses"])
        if s.get("continue-on-error") not in (None, False): coe.append(short(s.get("name") or s.get("run") or s.get("uses"), 80))
    info = {
        "id": jid, "name": short(j.get("name", jid), 90), "needs": j.get("needs"), "if": short(j["if"], 220) if "if" in j else None,
        "uses": j.get("uses"), "environment": j.get("environment"), "runs_on": j.get("runs-on"),
        "continue_on_error": j.get("continue-on-error"), "timeout": j.get("timeout-minutes"),
        "steps": len(steps), "run": runs, "actions": sorted(set(uses_actions)), "step_continue_on_error": coe,
    }
    u = j.get("uses")
    if a.expand and isinstance(u, str) and u.startswith("./.github/workflows/") and depth < 2:
        sub = load(u[2:])
        if sub and "__error__" not in sub:
            info["called_jobs"] = [job_info(k, v, u[2:], depth + 1) for k, v in (sub.get("jobs") or {}).items()]
    return info

out = {"platform": [], "workflows": [], "filter": {"event": a.event, "branch": a.branch, "ref": a.ref or "working-tree"}}
wf_dir = ".github/workflows"
files = [f for f in ls(wf_dir) if f.endswith((".yml", ".yaml"))]
if files: out["platform"].append("github-actions")
if read(".gitlab-ci.yml") is not None: out["platform"].append("gitlab-ci")
if any(f.startswith("Jenkinsfile") for f in ls(".")): out["platform"].append("jenkins")

for f in files:
    if a.file and f != a.file: continue
    p = f"{wf_dir}/{f}"
    doc = load(p)
    if doc is None: continue
    if "__error__" in doc:
        out["workflows"].append({"file": f, "error": doc["__error__"]}); continue
    on = triggers(doc)
    if not fires(on, a.event, a.branch): continue
    text = read(p) or ""
    trig = {}
    for ev, cfg in on.items():
        if isinstance(cfg, dict):
            c = {k: v for k, v in cfg.items() if k != "inputs"}
            if ev == "workflow_dispatch" or ev == "workflow_call":
                c["inputs"] = {k: {kk: vv for kk, vv in (v or {}).items() if kk in ("type", "default", "options", "required")} for k, v in (cfg.get("inputs") or {}).items()}
            trig[ev] = c
        else:
            trig[ev] = cfg
    labels = sorted({g for m in LABEL_RE.finditer(text) for g in m.groups() if g and LABEL_OK.match(g)})
    pv = path_verdict(on.get(a.event)) if a.event != "any" else None
    out["workflows"].append({
        "file": f, "name": doc.get("name", f), "reusable_only": set(on) <= {"workflow_call"}, "on": trig,
        "paths_verdict": pv,
        "concurrency": doc.get("concurrency"), "labels_referenced": labels,
        "status_contexts_published": sorted(set(CTX_RE.findall(text))),
        "jobs": [job_info(k, v, p) for k, v in (doc.get("jobs") or {}).items()],
    })

gl = read(".gitlab-ci.yml")
if gl is not None:
    try:
        d = yaml.safe_load(gl) or {}
        out["gitlab"] = {"stages": d.get("stages"), "include": d.get("include"),
                         "jobs": {k: {"stage": v.get("stage"), "rules": v.get("rules"), "only": v.get("only"), "script": [short(x) for x in (v.get("script") or [])][:6]}
                                  for k, v in d.items() if isinstance(v, dict) and ("script" in v or "trigger" in v or "extends" in v)}}
    except yaml.YAMLError as e:
        out["gitlab"] = {"error": str(e)}

if a.json:
    with open(a.json, "w") as fh: json.dump(out, fh, indent=1, default=str)

print(f"# ci-map  platform={','.join(out['platform']) or 'none found'}  filter={out['filter']}  workflows={len(out['workflows'])}")
if CHANGED is not None:
    fire = [w["file"] for w in out["workflows"] if not (w.get("paths_verdict") or ("fires",))[0].startswith("skipped")]
    skip = [w["file"] for w in out["workflows"] if (w.get("paths_verdict") or ("fires",))[0].startswith("skipped")]
    print(f"# would fire ({len(fire)}): {', '.join(fire)}")
    print(f"# skipped by path filters ({len(skip)}): {', '.join(skip)}")
    print("# note: job-level `if:` conditions (draft, labels, event type) can still skip jobs inside a firing workflow")
for w in out["workflows"]:
    if "error" in w:
        print(f"\n## {w['file']}  YAML ERROR: {short(w['error'])}"); continue
    pv = w.get("paths_verdict")
    tag = f"  [{pv[0]}{': ' + ', '.join(pv[1]) if pv[1] else ''}]" if pv else ""
    print(f"\n## {w['file']} — {w['name']}{'  [reusable]' if w['reusable_only'] else ''}{tag}")
    for ev, c in w["on"].items():
        print(f"  on.{ev}: {short(json.dumps(c, default=str), 300)}")
    if w["concurrency"]: print(f"  concurrency: {short(json.dumps(w['concurrency'], default=str))}")
    if w["labels_referenced"]: print(f"  labels: {', '.join(w['labels_referenced'])}")
    if w["status_contexts_published"]: print(f"  publishes status: {', '.join(w['status_contexts_published'])}")
    def pj(j, ind="  "):
        flags = [x for x in (f"needs={j['needs']}" if j["needs"] else "", f"if={j['if']}" if j["if"] else "",
                             f"env={j['environment']}" if j["environment"] else "", "CONTINUE-ON-ERROR" if j["continue_on_error"] else "",
                             f"uses={j['uses']}" if j["uses"] else "") if x]
        print(f"{ind}- job {j['id']} \"{j['name']}\" {' | '.join(flags)}")
        for r in j["run"][:12]: print(f"{ind}    $ {r}")
        if len(j["run"]) > 12: print(f"{ind}    … {len(j['run']) - 12} more run steps")
        if j["step_continue_on_error"]: print(f"{ind}    ! continue-on-error steps: {'; '.join(j['step_continue_on_error'])}")
        for c in j.get("called_jobs", []): pj(c, ind + "    ")
    for j in w["jobs"]: pj(j)
if "gitlab" in out:
    print("\n## .gitlab-ci.yml"); print(short(json.dumps(out["gitlab"], default=str), 4000))
````

### gate-run.py

````python
#!/usr/bin/env python3
# gate-run v2 — run a list of check commands with timeouts, logs and a resumable results.json.
#   plan file (TSV, '#' = comment):  id <TAB> mirrors-CI-job <TAB> timeout-seconds <TAB> command...
#   python3 gate-run.py run    --plan plan.tsv --out DIR [--repo .] [--budget 150]   foreground; with --budget it stops before
#                                                     the shell's per-call limit (exit 3 = checks still pending → call again)
#   python3 gate-run.py start  --plan plan.tsv --out DIR [--repo .]                  background; only in shells that keep
#                                                     child processes alive after the call returns
#   python3 gate-run.py status --out DIR       exit 0 = finished, 3 = pending/running, 4 = background runner died (use run --budget)
#   add --rerun failed | --rerun id1,id2 to repeat finished checks when the code did not change
import argparse, hashlib, json, os, signal, subprocess, sys, time
signal.signal(signal.SIGPIPE, signal.SIG_DFL)

ap = argparse.ArgumentParser()
ap.add_argument("mode", choices=["start", "run", "status"])
ap.add_argument("--plan"); ap.add_argument("--out", required=True); ap.add_argument("--repo", default=".")
ap.add_argument("--rerun", default="", help="'failed' or comma-separated ids to run again even if the code did not change")
ap.add_argument("--budget", type=int, default=0, help="seconds this call may use (0 = unlimited)")
a = ap.parse_args()
out = os.path.abspath(a.out); os.makedirs(os.path.join(out, "logs"), exist_ok=True)
RES = os.path.join(out, "results.json")
T_START = time.time()

def sh(cmd, cwd):
    return subprocess.run(cmd, shell=True, cwd=cwd, capture_output=True, text=True).stdout.strip()

def fingerprint(repo):
    head = sh("git rev-parse HEAD", repo)
    dirty = sh("git diff HEAD; git ls-files --others --exclude-standard", repo)
    return head, hashlib.sha1(dirty.encode()).hexdigest()[:12]

def load():
    try: return json.load(open(RES))
    except Exception: return None

def save(d):
    tmp = RES + ".tmp"; json.dump(d, open(tmp, "w"), indent=1); os.replace(tmp, RES)

def parse_plan(p):
    rows = []
    for ln in open(p, encoding="utf-8"):
        if not ln.strip() or ln.lstrip().startswith("#"): continue
        parts = ln.rstrip("\n").split("\t")
        if len(parts) < 4: sys.exit(f"gate-run: bad plan line (need 4 tab-separated fields): {ln!r}")
        rows.append({"id": parts[0].strip(), "mirrors": parts[1].strip(), "timeout": int(parts[2]), "cmd": "\t".join(parts[3:]).strip()})
    return rows

def show(d, alive=False):
    print(f"head={d['head'][:12]} dirty={d['dirty']} started={d['started']} finished={d['finished']}")
    print(f"{'id':28} {'status':8} {'secs':>7}  mirrors")
    for c in d["checks"]:
        print(f"{c['id'][:28]:28} {c['status']:8} {str(c.get('secs', '')):>7}  {c['mirrors'][:70]}")
    for c in d["checks"]:
        if c["status"] in ("FAIL", "TIMEOUT", "NOT_RUN"):
            print(f"\n--- {c['id']} [{c['status']} exit={c.get('exit')}{' · ' + c['reason'] if c.get('reason') else ''}] {c.get('log')}")
            print("\n".join(c.get("tail", [])[-15:]))

if a.mode == "start":
    repo = os.path.abspath(a.repo)
    log = open(os.path.join(out, "runner.log"), "a")
    p = subprocess.Popen([sys.executable, os.path.abspath(__file__), "run", "--plan", os.path.abspath(a.plan), "--out", out, "--repo", repo, "--rerun", a.rerun],
                         stdout=log, stderr=log, start_new_session=True)
    open(os.path.join(out, "runner.pid"), "w").write(str(p.pid))
    print(f"gate-run started pid={p.pid} out={out}\n  poll: python3 {os.path.abspath(__file__)} status --out {out}"
          f"\n  if status exits 4 (runner died when this shell call ended) use: run --budget 150")
    sys.exit(0)

if a.mode == "run":
    repo = os.path.abspath(a.repo)
    head, dirty = fingerprint(repo)
    plan = parse_plan(a.plan)
    prev = load()
    done = {}
    if prev and prev.get("head") == head and prev.get("dirty") == dirty:
        done = {c["id"]: c for c in prev.get("checks", []) if c.get("status") not in (None, "RUNNING", "PENDING")}
        again = {k for k, c in done.items() if c["status"] != "PASS"} if a.rerun == "failed" else set(filter(None, a.rerun.split(",")))
        done = {k: c for k, c in done.items() if k not in again}
    started = prev["started"] if prev and done else time.strftime("%Y-%m-%dT%H:%M:%S%z")
    d = {"head": head, "dirty": dirty, "repo": repo, "started": started, "finished": None,
         "checks": [done.get(r["id"]) or {**r, "status": "PENDING"} for r in plan]}
    save(d)
    ran = 0
    for c in d["checks"]:
        if c["status"] != "PENDING": continue
        left = a.budget - (time.time() - T_START) if a.budget else None
        limit = c["timeout"]
        if left is not None:
            if ran and c["timeout"] > left:  # would not fit in this call: leave it for the next call
                break
            limit = min(c["timeout"], max(5, int(left) - 5))
        c["status"] = "RUNNING"; save(d)
        logf = os.path.join(out, "logs", f"{c['id']}.log")
        t0 = time.time()
        with open(logf, "w") as lf:
            lf.write(f"$ {c['cmd']}\n# cwd={repo} head={head[:12]} timeout={limit}s\n\n"); lf.flush()
            p = subprocess.Popen(c["cmd"], shell=True, cwd=repo, stdout=lf, stderr=subprocess.STDOUT, start_new_session=True,
                                 executable="/bin/bash")
            try:
                rc = p.wait(timeout=limit)
            except subprocess.TimeoutExpired:
                os.killpg(p.pid, signal.SIGTERM); time.sleep(1)
                try: os.killpg(p.pid, signal.SIGKILL)
                except ProcessLookupError: pass
                rc = 124
        ran += 1
        tail = open(logf, errors="replace").read().splitlines()[-40:]
        last = "\n".join(tail[-25:])
        env_reason = ("tool missing" if rc == 127 or "command not found" in last else
                      "out of memory on this machine" if rc in (134, 137) or any(k in last for k in ("heap out of memory", "OOMErrorHandler", "FatalProcessOutOfMemory")) else
                      "binary built for another platform" if any(k in last for k in ("Exec format error", "wrong ELF class", "not a valid Win32", "for another platform", "@esbuild/linux", "@esbuild/darwin")) and rc != 0 else
                      f"needs > {limit}s, longer than this shell allows per call" if rc == 124 and limit < c["timeout"] else None)
        c.update(exit=rc, secs=round(time.time() - t0, 1), log=logf, tail=tail, reason=env_reason if rc != 0 else None,
                 status="PASS" if rc == 0 else "NOT_RUN" if env_reason else "TIMEOUT" if rc == 124 else "FAIL")
        save(d)
    if all(c["status"] not in ("PENDING", "RUNNING") for c in d["checks"]):
        d["finished"] = time.strftime("%Y-%m-%dT%H:%M:%S%z"); save(d)
        show(d); sys.exit(0)
    show(d); print("\n(more checks pending — call run again with the same arguments)"); sys.exit(3)

# status
d = load()
if not d: print("gate-run: no results yet"); sys.exit(3)
alive = False
try:
    pid = int(open(os.path.join(out, "runner.pid")).read()); os.kill(pid, 0); alive = True
except Exception: pass
show(d)
if d["finished"]: sys.exit(0)
sys.exit(3 if alive else 4)
````

## Appendix — project profile: Persefoni `eng-guardrails-platform` (GitHub Actions)

Learned from `origin/develop` @ `50a56fc` (2026-10-16). These notes are leads, not evidence: re-check
any fact you put in a report, or label it "from earlier notes, not re-checked". CI here changes weekly (three guard
workflows were deleted Sept–Oct 2026) — re-verify any item with `ci-map.py` before relying on it,
and update this appendix when it's wrong.

**Bases.** Features/tests branch from and target `develop` (`AGENTS.md:15-16`). `staging` accepts only
`release-candidate/*`, `release/cut-*`, `hotfix/*`, `fix/sync-main-*` (`staging-branch-guard.yml`);
`main` only from `staging`. Never push to `develop`/`staging`/`main` directly.

**Hooks (husky).** pre-commit: `type-check:changed`, `boundary:check`, `governance:preflight` (skipped
on merge commits), `ci-policy:check` when workflow files are staged, `scripts/ci/file-line-budget.ts
--staged` (new source files ≤ 500 lines — **no CI job runs this**, only the hook), `lint-staged`
(eslint --fix + prettier), `gitleaks protect --staged` (fails if gitleaks missing), conditional
migrations/i18n/harness checks. pre-push: blocks if no common ancestor with `origin/develop`, full
type-check when `shared/`, `packages/worker-shared/src/`, `src/types/`, `src/lib/api-client` change,
`lint:tooling:changed` (full `scripts/` + `automation/` ESLint with warning caps) when `scripts/`,
`automation/`, `package.json`, `bun.lock` or root configs change. commit-msg: commitlint
(conventional types, lower-case type/scope, header ≤ 100). `HUSKY=0`/`--no-verify` are forbidden
(`AGENTS.md:74`) and blocked by an agent guard.

**Test-round lessons (2026-10-19, Cowork device shell).** Linux VM, git 2.34 (no `merge-tree
--write-tree` → use the 3-argument form), no `bun`, `npx tsx` fails (esbuild 0.28.2 vs 0.27.7) →
`node --experimental-strip-types scripts/x.ts` works. Background processes die when a call ends →
`gate-run.py run --budget 150`. With `git archive origin/develop scripts | tar -x -C "$WORK/base"`
(`$WORK` = `tmp/ci-gate/<branch>`, git-ignored) these CI scripts run locally (verified 2026-10-19):
- Base Freshness Guard: `BASE_REF=develop STALE_BASE_THRESHOLD=200 MASS_DELETION_THRESHOLD=100 PR_LABELS='[]' GIT_REPO_DIR="$PWD" GUARD_COMMENT_FILE="$WORK/guard.md" node --experimental-strip-types --no-warnings "$WORK/base/scripts/ci/rebuild-squash-guard.ts"`
  → exit 1 + `stale-base: … commits behind`. Its advice: **don't rebase a stale branch — rebuild it**
  from fresh `origin/develop` and cherry-pick only your real commits.
- Will CI run my specs: `node --experimental-strip-types --no-warnings "$WORK/base/scripts/check-e2e-coverage-selection.ts"`
  (reads specs + workflows in the current tree) → ~650 orphaned specs on 2026-10-19, incl. all of
  `automation/admin/security/global-dlp-settings/` except `data-classification.spec.ts`. Advisory in CI.
Round-2 test (DLP specs PR, 2026-10-19): an extracted base tree needs `config/`, root `tsconfig*.json`
and `eslint.config*.js` for develop's ESLint to load; `check-e2e-domain-collection.ts` needs a small
loader for Bun-only features under Node, and its 60 domain listings don't fit one shell call (run a
focused version for the changed specs, full run = CI-only); `npx playwright test --list` can stall
~70 s in the VM; gitleaks isn't installed in the VM (the Mac's pre-commit hook needs it). Helpful
evidence: lint warnings before/after for the changed files (the `lint:tooling:automation` cap is
repo-wide, so a PR that lowers warnings can't break it).
The pre-push tooling lint refuses to run unless the working tree matches the pushed commit
(`scripts/ci/lint-tooling-changed.ts`). The device VM has ~4 GB: full `tsc -p tsconfig.eslint.json`
and wide ESLint runs hit "JavaScript heap out of memory" there → `gate-run.py` records NOT_RUN
(out of memory); lint only the changed files in small batches and leave the full type-check to CI.

**Scope selector (verified runnable locally 2026-10-19).**
```bash
git archive origin/develop scripts/detect-ci-test-scope.js scripts/test-changed.js | tar -x -C "$WORK/base"
BASE_SHA=$(git merge-base HEAD origin/develop) HEAD_SHA=HEAD node "$WORK/base/scripts/detect-ci-test-scope.js"
```
Prints `test_scope_mode`, `type_check_scope`, `lint_scope`, `frontend_strategy`, `backend_strategy`,
`automation_scope`, `ci_files_changed`, `migration_files_changed`, `deps_changed`, `locale_only`,
`harness_touched`. Docs-only → unit tests skipped; `src/` only → frontend changed-only;
`worker/`,`workers/` → backend changed-only; `package.json`, `bun.lock`, `tsconfig*`, `.github/**`,
`migrations/`, `shared/`, `src/lib/` → full; `automation/` changes → lint full-suite.

**PR workflow "Develop PR Validation"** (`develop-pr-validation.yml`, gate job `fast-gate-summary`,
publishes the required status **`validate-workflow`**). Code Quality (`_code-quality.yml`) runs:
`bun run format:check`; `type-check`, `type-check:workers`, `type-check:worker`; lint jobs
`lint:src:components`, `lint:src:other` (3 shards), `lint:worker:core`, `lint:worker:extended`,
workers (4 shards), `lint:tooling:scripts`, `lint:tooling:automation`, `boundary:check`;
`ci-policy:check` (CI files changed); **E2E Domain Collection Guard** `bun scripts/check-e2e-domain-collection.ts`
(blocking: every E2E `--grep` domain must collect ≥ 1 spec); drift checks (`ownership:check`,
`migration-slots:check`, `openapi:check`, ...); unit tests `node scripts/test-changed.js --domain
frontend|worker`; TruffleHog. Full unit suite and Snyk are meant to run in the merge queue → list as
CI-only, but don't count on them: on 2026-10-19 the queue run for a worker-only PR (#16434) skipped both.

**Mirror commands for the Cowork device shell** (Linux VM ~4 GB, no `bun`, no `gh`, no network):
- automation type-check: `npx tsc --noEmit -p tsconfig.eslint.json` (the config that includes
  `automation/`) — ran out of memory there on 2026-10-19 → expect NOT_RUN; CI is the judge.
- ESLint on changed files only, small batches: `npx eslint <files> --cache-location "$WORK/.cache/eslint"`
  (without `--cache-location` the repo cache file can't be replaced there → EPERM). For CI's warning
  caps, read the `lint:tooling:*` script in `package.json` and pass the same `--max-warnings`.
- Prettier: `npx prettier --check <changed files>`.
- Collection: `npx playwright test --list --project=chromium <spec or --grep>` (~70 s).
- `bun scripts/x.ts` → `node --experimental-strip-types --no-warnings scripts/x.ts` (substitute runtime).

**PR prerequisites.**
- *Base Freshness Guard* (not a required check, but red on stale branches): < 200 commits behind,
  < 100 deleted files, no reused migration filename. *Validate branch ancestry* also runs.
- Required on `develop` as seen on a live PR 2026-10-19: `validate-workflow`, `PR Gate
  (javascript-typescript)`, `Block New Suffix-Based Secret/Var Patterns`, `Enforce High-Impact
  Guardrails`, `two-maintainer-approval`; plus 1 code-owner approval, merge queue, linear history.
- *High-Impact PR Guard* ("Enforce High-Impact Guardrails", required): if any file matches
  `docs/sdlc/high-risk-paths.yaml` (e.g. `.github/workflows/**`, `migrations/d1/**`, `**/wrangler.toml`),
  the PR body needs **Blast radius**, **Rollback**, **Validation** with real values (`n/a`, `none`,
  `tbd`, `todo` fail); `two_reviewer` paths need two maintainer approvals (`two-maintainer-approval` status).
- *Environment Secret Pattern Guard* (required): no new `secrets.`/`vars.` names ending `_DEV`/`_STAGING`/`_PROD` in workflows.
- Workflow-file changes: `**Why:**` and `**Ticket:**` in the PR body, run `ci-policy:check` before committing, two human maintainer approvals.
- Linear ticket `FRAI-…` required; title carries `[FRAI-XXX]`; PR template sections (Outcome,
  Evidence, Tracking, Scope, Boundaries, Acceptance/Proof, Reuse, ADS). Aim < ~500 changed lines / ~20 files.
- `skip-i18n-guard` label only on locale-only PRs. Never `git add -A` / `git add .`.
- Draft PRs skip validation entirely — a draft's `validate-workflow` "success" means *skipped*, not passed.

**Round-3 test (2026-10-19).** Electron specs live in `electron-automation/`. The scope selector doesn't
know that folder, so it falls back to full-suite mode (slower CI, no extra risk). The Playwright config
registry marks the Electron suite **manual-only** (macOS app + SSO), so CI only checks it *collects*:
`npx playwright test --config electron-automation/playwright.config.ts --list` is what the E2E Domain
Collection Guard runs. Its tsconfig expects TypeScript 6.0.3 while the root has 5.9.3 → compare develop
vs branch error counts instead of trusting one run. Branches go stale fast (develop moved ~80
commits/day mid-October); the freshness limit is 200.