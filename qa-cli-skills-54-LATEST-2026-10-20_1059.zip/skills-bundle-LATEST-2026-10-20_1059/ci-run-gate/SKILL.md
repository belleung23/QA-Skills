---
name: "ci-run-gate"
description: "Get a branch or PR running in CI and drive it to a verdict (CI_GREEN / CI_RED / CI_PENDING / CI_BLOCKED): push and open the PR, add the label or dispatch the workflow that starts CI, watch the checks on the head commit, separate required from advisory, read failing logs and classify each failure. Use it for any request about a PR's or branch's CI: is PR #N green, why is a check failing or stuck on 'Expected — waiting for status', watch my checks, push and open the PR with a label, kick off or dispatch a workflow or smoke suite in GitHub Actions or GitLab. Use it even when one quick gh command looks enough: a green tick can be stale, skipped or advisory."
---

# CI Run Gate

Second of three gates:

```
ci-precheck-gate  ──►  ci-run-gate  ──►  ci-postcheck-gate
```

Job: get the change **running** in CI, make sure the right checks ran **on the right commit**,
and turn the result into a verdict a person can act on. A green tick only means something if it
is for the current head SHA, from a job that actually executed tests, on a required check. Much
of this skill is about not being fooled by green.

Not this skill: fixing the failing tests themselves (`failure-triage` → `flake-surgeon`), CI-check
repair in a repo that ships its own `ci-debug` skill (use it), answering reviewer threads
(`pr-review-response`), merge readiness (`pr-closeout`), post-merge verification (`ci-postcheck-gate`).

The agent runs everything; the user approves shared actions once and reads the report.

## Ground rules

- **One approval for shared actions.** Before doing any of these, list all of them in one message
  and wait for a yes: `git push`, opening a PR, editing title/body, marking ready / back to draft,
  adding/removing labels, posting PR comments (incl. bot commands like `@codex review`,
  `/check-coverage`), `gh workflow run`, `gh run rerun`, `gh run cancel`. Reading is always fine.
- **Never:** merge, approve, enable auto-merge, force-push a branch you didn't create, push to a
  protected branch, add bypass/override labels, edit CI files to get green, or dispatch a workflow
  that deploys to staging/production.
- **No AI attribution** in commits, PR bodies or comments unless the user asks.
- **Re-run discipline.** At most one re-run of a failed job, only when evidence says FLAKY or
  ENV, and it is recorded in the report. Re-running until green hides real bugs.
- **Same commit or it doesn't count.** Every check result is matched to the PR's current
  `headRefOid`; results for older SHAs are stale.
- **Plain language first** in the report.

## Step 0 — Access and setup

1. Find a working path to GitHub, in this order, and say which one you used:
   1. `gh` CLI: `gh auth status && gh repo view --json nameWithOwner` (in the shell that has
      network; the user's own machine shell may have none — then try the other shell).
   2. A GitHub connector/MCP tool in the session, if present.
   3. The browser (the user's logged-in Chrome or the built-in browser), read-only: PR page →
      **Checks** tab and the merge box (it shows **Required** badges and non-check requirements like
      reviews and the merge queue), each run page (job list, job summaries, annotations) and job
      logs; read with page-text tools, open your own tab and close it after. Downloading artifacts
      usually isn't possible this way — say so. This was the path that worked in Cowork testing.
      Useful URLs: `/<owner>/<repo>/pull/<N>/checks`, `/<owner>/<repo>/actions/runs/<id>`, and run
      lists filtered with `/<owner>/<repo>/actions/workflows/<file>?query=branch:<b>+event:push+created:YYYY-MM-DD`
      (also `is:success`, date ranges `A..B`). A shared browser can return a stale page — confirm
      the URL/title in the page text matches before using a read. A run page lists every job twice
      (sidebar and graph): count unique job IDs, or use the totals the Checks tab shows.
   4. Ask the user to paste the PR checks list / failing log. (Last resort.)
   Never work around a blocked domain with other HTTP tools.
2. Work dir as in `ci-precheck-gate` (`<repo>/tmp/ci-gate/<pr-or-branch>/` if git-ignored, else
   `${TMPDIR:-/tmp}/ci-gate/...`). Write `ci-map.py` and `pw-failures.py` (end of this file) there.

## Step 1 — Resolve the target

```bash
gh pr view <N|url|branch> --json number,url,title,state,isDraft,baseRefName,headRefName,headRefOid,mergeable,mergeStateStatus,labels,reviewDecision,author
```

No PR yet → the target is a branch (pushed or not). Record: PR number, base, head branch,
**head SHA**, draft state, labels, mergeable state. If `state` is MERGED, stop and offer
`ci-postcheck-gate`.

## Step 2 — Pre-flight: will CI start, and will it test anything?

1. **Pre-check.** Is there a `ci-precheck-gate` report for this head SHA? If not, run its T0–T1
   tiers at least (fast), or ask whether to run the full pre-check. Pushing a branch that fails
   format/lint locally wastes a CI cycle.
2. **What starts CI** — map the PR lane: `python3 ci-map.py --ref origin/<base> --event pull_request --branch <base> --changed <changed.txt> --expand`.
   Look for the traps:
   - `if: ...draft == false` → draft PRs run nothing (and a "skipped" required check may even
     report success).
   - `types:` lists (e.g. `labeled`, `edited`, `ready_for_review`) → which PR actions re-trigger.
   - Label opt-ins (`labels:` line in the map, e.g. `deploy`, env-slot labels) and who may add them.
   - Path filters: a **required** check whose workflow is skipped by `paths:` never reports →
     the PR waits forever on "Expected — waiting for status". Name it if you see it.
   - `concurrency` with `cancel-in-progress: true` → a newer push cancels the older run (fine) but
     a cancelled required check needs the newer run to finish.
   - `workflow_run` chains → some checks only appear after another workflow completes.
   - Comment-triggered workflows (`issue_comment` + a command string).
3. **Required vs advisory.** `gh pr checks <N> --required --json name,bucket` lists required ones;
   confirm against rulesets: `gh api repos/{owner}/{repo}/rules/branches/<base>` (also shows
   non-check rules: required reviews/code owners, merge queue, linear history). Commit *statuses*
   (not check runs) can be required too — `gh api repos/{owner}/{repo}/commits/<sha>/status`.
   Repo docs about required checks go stale fast; the live ruleset or a live PR's merge box wins.
4. **Will CI execute the tests this PR changes?** For each changed/added spec, find a lane that
   selects it (tags vs the suites' `--grep`, path lists, projects) — or run the repo's
   coverage-selection tool if it has one. A spec no lane selects can never fail in CI: say so
   plainly. For **test-only** PRs, deploying the PR to a preview environment adds nothing (the app is
   identical to the base); the proof that matters is running the changed specs against an
   environment — locally by the agent against dev/preview with evidence attached to the PR, and,
   if the team wants it in CI, a separate CI change (`qa-ci-cd`) with approval.

## Step 3 — Start CI (after the one approval)

Build the action list, ask once, then do it. If the request already approves specific actions
("push it and open the PR, add the e2e label"), that is the approval: do exactly those, in the order the
lane needs, and nothing more. Anything else you'd want (another label, a re-run, a comment) goes in the
report as a request.


- Push: `git push -u origin <branch>` (never `--force` unless the user owns the branch and asks;
  then `--force-with-lease`).
- Open PR: `gh pr create --draft --base <base> --title "<repo convention>" --body-file <body.md>`
  — body follows the repo's PR template and rules (fill every required section from the actual
  change; no placeholders like "TBD" where a guard rejects them).
- Mark ready when the PR lane skips drafts: `gh pr ready <N>`.
- Opt-in labels / comment commands exactly as the workflows expect them: `gh pr edit <N> --add-label <l>`,
  `gh pr comment <N> --body "<command>"`.
- Dispatch (suite runs, manual lanes) **only with inputs that exist in the workflow** (from
  `ci-map.py --event workflow_dispatch --file <wf>`; check choice values):
  `gh workflow run <file> --ref <branch> -f key=value ...`, then find the run:
  `gh run list --workflow <file> --branch <branch> --event workflow_dispatch -L 5 --json databaseId,headSha,status,createdAt,url`
  (pick the one created after your dispatch with your head SHA).

## Step 4 — Watch

Agent shells often kill a call after ~2–3 minutes, so poll in short calls instead of `--watch`:

```bash
gh pr checks <N> --json name,workflow,state,bucket,link,event,startedAt,completedAt > "$WORK/checks.json"; \
  jq -r 'group_by(.bucket)[] | "\(.[0].bucket): \(length)"' "$WORK/checks.json"
gh pr checks <N> --required --json name,bucket,link
gh pr view <N> --json headRefOid -q .headRefOid      # still the same SHA? (someone may have pushed)
```

`bucket` is one of pass / fail / pending / skipping / cancel. Poll every 1–3 minutes; between polls,
read logs of anything already failed (don't wait for the whole run to start diagnosing).
Stop as soon as you can answer: the runs you started or were asked about have finished. Don't wait
for scheduled or unrelated runs to get an extra data point; name them in the report as a later check.
Otherwise stop when all required checks are completed, or the time budget is spent (default: the longest
`timeout-minutes` among the workflows that fired, else 60 min) → CI_PENDING with what's still running.

Watch for: runs `waiting` on an environment approval (→ CI_BLOCKED, name the environment),
`queued` with no runner for > 15 min (ENV), cancelled by concurrency (look for a newer run on the
same SHA), checks for an older SHA (stale — ignore), and a required check that never appears.

## Step 5 — Read results and classify

For each failed or cancelled check:

```bash
RUN=<run id from .link>; gh run view $RUN --json name,event,headSha,conclusion,jobs \
  -q '.jobs[] | select(.conclusion!="success" and .conclusion!="skipped") | [.databaseId,.name,.conclusion] | @tsv'
gh run view $RUN --log-failed --job <job id> | tail -120                     # the failing step's output
gh run view $RUN --json jobs -q '.jobs[].steps[] | select(.conclusion=="failure") | .name'
gh api repos/{owner}/{repo}/check-runs/<job id>/annotations -q '.[] | "\(.annotation_level): \(.path):\(.start_line) \(.message)"'
gh run download $RUN -n "<artifact name>" -D "$WORK/artifacts/$RUN"          # test reports, traces
python3 "$WORK/pw-failures.py" "$WORK/artifacts/$RUN"                        # failed/flaky tests, errors, screenshots
```

Also look at "green" jobs that matter: a test job that collected **0 tests**, a step with
`continue-on-error` that failed (ci-map flags these), a gate job that counts `skipped` as success.
Runs triggered by a label or body edit sometimes only **re-use** an earlier result (jobs show
"Skipped" and a re-use job fails or passes) — find the newest *full* run for the head SHA and read
its jobs; that is where the real error is.

Classify every failure, with evidence:

| Class | Typical evidence | Next |
|---|---|---|
| CHANGE | error in files/tests this PR touches; reproduces locally | fix on branch (`ci-precheck-gate` → push) |
| BASE | same job red on the base branch's latest run (`gh run list --workflow <wf> --branch <base> -L 5`) | report; don't fix in this PR unless asked |
| FLAKY | passed on a retry inside the run; timing/locator flake signature; passes on one re-run | `failure-triage` → `flake-surgeon` |
| ENV / INFRA | 401/403/429/5xx from the test environment, deploy slot busy, runner lost, network, provider quota | one re-run if transient; else report owner |
| CI-CONFIG | workflow syntax, missing secret/permission, action version, cache error | repo `ci-debug` skill if it exists; report |
| METADATA | PR body section, label, title, approvals, base freshness guard | fix PR metadata (approval rule applies) |

Test failures from automation suites: hand the artifact folder to `failure-triage` for a
per-test verdict rather than guessing from one error line.

- **"A re-run won't help" needs proof.** If the run shows `Attempt #2` or more, read the earlier
  attempt's failure (`gh run view $RUN --attempt <N> --log-failed`) and compare. If you can't read it,
  say the failure reproduces locally instead of claiming both attempts failed the same way.
- **Prove the base is green** before calling a failure CHANGE: run the same test on the base locally
  (`git archive origin/<base>` into the work dir) or cite the base branch's latest run of that job.
- **Check the PR description's test claims** against what CI actually ran: list each claim (its
  Test / Verification section) next to the CI job that ran it and that job's result. A claim like
  "tests pass locally" that fails in CI, or a test file CI's changed-only lane never ran, is a finding
  for the author (offer a correcting comment for approval). A bot's comment is not evidence of what
  CI ran — the job log is.
- **Check claims about files at the commit.** For "all locales updated", "no other callers" and the
  like, read the files at the PR's head and base (`git show <sha>:<path>`, `git grep <pattern> <sha>`,
  or the raw file URLs for that SHA). GitHub code search indexes only the default branch and drops
  results, so a count from it is not evidence.
- **Merge queue groups.** A queue run tests your PR stacked on the PRs ahead of it. If the same error
  hits every group stacked on one PR and stops once that PR leaves the queue, it is that PR's problem
  (BASE for yours) — name it and offer a note to its author for approval.

## Step 6 — Review bots (listed, not part of the CI verdict)

`gh pr view <N> --json reviews,comments` and `gh api repos/{owner}/{repo}/pulls/<N>/comments` —
count unresolved bot/human threads by author (Codex, Greptile, Copilot, security bots). Hand off to
`pr-review-response` if there are open threads.

## Step 7 — Verdict and report

- **CI_GREEN** — every required check passed **on the head SHA**, each one actually executed
  (not skipped-as-success, not 0 tests). Advisory failures listed as warnings.
- **CI_RED** — at least one required check failed or was cancelled with no newer passing run. Say who
  has to act: the author (code change), or a maintainer when only their label or approval clears it.
- **CI_PENDING** — time budget spent with required checks still queued/running.
- **CI_BLOCKED** — required checks can't start or finish without a person: a run waiting on an
  environment approval, a maintainer-only label that starts them, a status that waits on approvers
  (e.g. a two-maintainer approval check), a missing permission, or a required check that can never
  report (path-filter trap).
- **UNVERIFIED** — no access path to the CI results worked. Report what was prepared (plan, PR body,
  expected checks and traps) and exactly what access is needed. Never guess a CI outcome.

The verdict is about CI. Ordinary merge requirements — review approvals, unresolved threads, the merge
queue, branch freshness — go under "Before it can merge" and don't change it: every required check
green on the head SHA with a review still pending is CI_GREEN, with the review listed.

**Re-read the PR right before you write.** PRs move while you work: someone approves, the PR joins
the merge queue, a new commit lands. Fetch the head SHA, required checks, reviews and merge/queue state
one last time and write the report from that read, with its time ("as of 17:05 UTC"). A "still needs
an approval" that was true ten minutes ago is the kind of error the reader will catch first.

**Check the report before you send it.** Every number, time, SHA, count and name in it should come
from a tool output in this run: recount anything counted by eye, take times from timestamps or
`date -u` rather than estimates, and quote key lines instead of paraphrasing them. Mark anything you
can't trace as approximate, or leave it out — a wrong detail makes the reader doubt the right ones.
In particular:
- Facts from this skill's appendix or earlier notes are untraced until you re-check them in this run;
  if you use one without re-checking, label it "(from earlier notes, not re-checked)".
- Counts of your own actions (how many times you loaded or ran something) come from the commands, not
  from memory, and durations ("within an hour") are worked out from the two timestamps.
- Name a person (author, owner, reviewer) only when a tool output names them.
- A command that failed or isn't supported proves nothing: write "couldn't check", not "there are none".
- Keep any timeline or actions table in the order things happened, with times copied from the outputs.
- Text you draft for someone else to post (a PR comment, a ticket update) states only what you
  verified. Mark inferences as such ("likely", "appears to") and leave out promises and statuses
  nobody confirmed, such as "fix in progress" or "fix to follow".
- The Scratch line covers every file you created. Keep them all in the work dir (downloads,
  `curl -o`/`-D` output, screenshots), or list any other path next to it.

Save `<PR-or-branch>_<VERDICT>_CI-Run_<YYYY-MM-DD>.md` in the work dir and deliver it. Template:

```markdown
# CI Run — PR #<N> <title>   **<VERDICT>**
_<date> · <base> ← <head> @ <sha12> · access via <gh|connector|browser>_

## In plain words
<2–4 sentences: is it green, what failed and whose problem it is, what happens next.>

## Required checks
Required list from: <ruleset API | merge box "Required" badges | repo docs (may be stale)>
| Check | Workflow | Result | Ran tests? | Duration | Link | Class |
|---|---|---|---|---|---|---|

## Advisory checks
| Check | Result | Note |
|---|---|---|

## Failures in detail
### <check / job> — <CLASS>
- Failing step: … · first error: `…` (log line / annotation)
- Tests: <n failed / n flaky> (from <artifact>) · screenshots/traces: <paths>
- Evidence for the class: …
- Next: <who does what>

## Actions taken
| Time | Action | Why |   (pushes, labels, dispatches, re-runs — or "none")

## Before it can merge
<approvals still needed, unresolved threads by reviewer (→ pr-review-response), merge queue, branch
freshness — or "nothing else">

## Next step
Scratch: `<work dir>` (<size, measured last>) — safe to delete.
```

## Mode: run a suite on an environment

"Run the smoke suite on staging", "run regression for X in CI": find the dispatch workflow with
`ci-map.py --event workflow_dispatch`, pick inputs from its real options. Before asking for approval,
check the workflow's run history (one that has never succeeded may fail for setup reasons — say so),
choose `--ref` so the test code matches what is deployed (the default branch may not), and note
summary jobs that report success even when the real test job was cancelled. If the question is
really "is the environment OK?", first read the latest post-deploy run (often enough without
dispatching anything). Never use a deploy workflow as a test. Then get the one approval,
dispatch, watch the run (Step 4 with `gh run view <id> --json status,conclusion,jobs`), download
the report artifacts, run `pw-failures.py`, hand failures to `failure-triage`. Production targets
need the user's explicit, named approval and read-only suites only.

## GitLab CI / Jenkins notes

- GitLab: `glab mr view <N>`, `glab ci status --branch <b>`, `glab ci view`, `glab ci trace <job>`,
  `glab ci run -b <branch> --variables KEY:val`, artifacts `glab job artifact <ref> <job>`. Required
  = "Pipelines must succeed" setting on the project.
- Jenkins: job page or `curl -s "$JENKINS_URL/job/<job>/lastBuild/api/json?tree=result,building,url"`
  (user API token from the user, never stored in files); console `.../consoleText`; JUnit via
  `.../testReport/api/json`.

## Helper scripts (write to the work dir exactly as given)

### ci-map.py

````python
#!/usr/bin/env python3
# ci-map v1 — read-only map of a repo's GitHub Actions / GitLab CI. Shared by ci-precheck-gate, ci-run-gate, ci-postcheck-gate.
# usage: python3 ci-map.py [--repo DIR] [--ref origin/develop] [--event pull_request|push|merge_group|schedule|workflow_dispatch|workflow_run|any]
#                          [--branch develop] [--file NAME] [--expand] [--json OUT]
import argparse, json, os, re, signal, subprocess, sys
signal.signal(signal.SIGPIPE, signal.SIG_DFL)

try:
    import yaml
except ImportError:
    sys.exit("ci-map: PyYAML missing -> python3 -m pip install --user pyyaml (or run where it exists)")

ap = argparse.ArgumentParser()
ap.add_argument("--repo", default=".")
ap.add_argument("--ref", default=None, help="read files from this git ref instead of the working tree")
ap.add_argument("--event", default="any")
ap.add_argument("--branch", default=None, help="target branch (PR base for pull_request, pushed branch for push)")
ap.add_argument("--file", default=None, help="only this workflow file (basename)")
ap.add_argument("--expand", action="store_true", help="inline local reusable workflows (uses: ./.github/workflows/_x.yml)")
ap.add_argument("--changed", default=None, help="file with changed paths (one per line): evaluates on.<event>.paths / paths-ignore")
ap.add_argument("--json", default=None)
a = ap.parse_args()
CHANGED = [l.strip() for l in open(a.changed) if l.strip()] if a.changed else None
os.chdir(a.repo)

def git(*args):
    return subprocess.run(["git", *args], capture_output=True, text=True).stdout

def ls(d):
    if a.ref:
        return sorted(p for p in git("ls-tree", "--name-only", f"{a.ref}:{d}").split() if p)
    return sorted(os.listdir(d)) if os.path.isdir(d) else []

def read(p):
    if a.ref:
        r = subprocess.run(["git", "show", f"{a.ref}:{p}"], capture_output=True, text=True)
        return r.stdout if r.returncode == 0 else None
    return open(p, encoding="utf-8").read() if os.path.exists(p) else None

def load(p):
    t = read(p)
    if t is None: return None
    try: return yaml.safe_load(t) or {}
    except yaml.YAMLError as e: return {"__error__": str(e)}

def triggers(doc):
    on = doc.get("on", doc.get(True, {}))  # PyYAML reads bare `on:` as boolean True
    if isinstance(on, str): on = {on: None}
    if isinstance(on, list): on = {k: None for k in on}
    return on or {}

def gh_glob(p):  # GitHub filter glob: ** crosses '/', * and ? do not
    r, i = "", 0
    while i < len(p):
        if p.startswith("**/", i): r += "(?:.*/)?"; i += 3
        elif p.startswith("**", i): r += ".*"; i += 2
        elif p[i] == "*": r += "[^/]*"; i += 1
        elif p[i] == "?": r += "[^/]"; i += 1
        else: r += re.escape(p[i]); i += 1
    return re.compile(r + r"\Z")

def matches(x, pats):  # ordered patterns, '!' negates
    hit = False
    for p in pats:
        neg = p.startswith("!")
        if gh_glob(p[1:] if neg else p).match(x): hit = not neg
    return hit

def glob_ok(branch, pats):
    return matches(branch, pats)

def path_verdict(cfg):
    if CHANGED is None or not isinstance(cfg, dict): return None
    if "paths" in cfg:
        hits = [f for f in CHANGED if matches(f, cfg["paths"])]
        return ("fires", hits[:5]) if hits else ("skipped-by-paths", [])
    if "paths-ignore" in cfg:
        rest = [f for f in CHANGED if not matches(f, cfg["paths-ignore"])]
        return ("fires", rest[:5]) if rest else ("skipped-by-paths-ignore", [])
    return None

def fires(on, event, branch):
    if event == "any": return True
    if event not in on: return False
    cfg = on.get(event) or {}
    if not branch or event not in ("pull_request", "pull_request_target", "push", "merge_group"): return True
    if not isinstance(cfg, dict): return True
    if "branches" in cfg: return glob_ok(branch, cfg["branches"])
    if "branches-ignore" in cfg: return not glob_ok(branch, cfg["branches-ignore"])
    return "tags" not in cfg  # tags-only push filters never fire for a branch

def short(s, n=160):
    s = " ".join(str(s).split())
    return s if len(s) <= n else s[: n - 1] + "…"

LABEL_OK = re.compile(r"^[A-Za-z0-9][\w:./ -]{1,60}$")
LABEL_RE = re.compile(r"labels\.\*\.name\s*,\s*'([^']+)'|label\.name\s*==\s*'([^']+)'|--add-label[ =]\"?([\w:./-]+)")
CTX_RE = re.compile(r"""context['"]?\s*[:=]\s*['"]([^'"$]{3,80})['"]""")

def job_info(jid, j, wf_path, depth=0):
    j = j or {}
    steps = j.get("steps") or []
    runs, uses_actions, coe = [], [], []
    for s in steps:
        if not isinstance(s, dict): continue
        if "run" in s:
            first = next((ln.strip() for ln in str(s["run"]).splitlines() if ln.strip() and not ln.strip().startswith("#")), "")
            runs.append(short(f"{s.get('name', '')}: {first}" if s.get("name") else first, 200))
        if "uses" in s: uses_actions.append(s["uses"])
        if s.get("continue-on-error") not in (None, False): coe.append(short(s.get("name") or s.get("run") or s.get("uses"), 80))
    info = {
        "id": jid, "name": short(j.get("name", jid), 90), "needs": j.get("needs"), "if": short(j["if"], 220) if "if" in j else None,
        "uses": j.get("uses"), "environment": j.get("environment"), "runs_on": j.get("runs-on"),
        "continue_on_error": j.get("continue-on-error"), "timeout": j.get("timeout-minutes"),
        "steps": len(steps), "run": runs, "actions": sorted(set(uses_actions)), "step_continue_on_error": coe,
    }
    u = j.get("uses")
    if a.expand and isinstance(u, str) and u.startswith("./.github/workflows/") and depth < 2:
        sub = load(u[2:])
        if sub and "__error__" not in sub:
            info["called_jobs"] = [job_info(k, v, u[2:], depth + 1) for k, v in (sub.get("jobs") or {}).items()]
    return info

out = {"platform": [], "workflows": [], "filter": {"event": a.event, "branch": a.branch, "ref": a.ref or "working-tree"}}
wf_dir = ".github/workflows"
files = [f for f in ls(wf_dir) if f.endswith((".yml", ".yaml"))]
if files: out["platform"].append("github-actions")
if read(".gitlab-ci.yml") is not None: out["platform"].append("gitlab-ci")
if any(f.startswith("Jenkinsfile") for f in ls(".")): out["platform"].append("jenkins")

for f in files:
    if a.file and f != a.file: continue
    p = f"{wf_dir}/{f}"
    doc = load(p)
    if doc is None: continue
    if "__error__" in doc:
        out["workflows"].append({"file": f, "error": doc["__error__"]}); continue
    on = triggers(doc)
    if not fires(on, a.event, a.branch): continue
    text = read(p) or ""
    trig = {}
    for ev, cfg in on.items():
        if isinstance(cfg, dict):
            c = {k: v for k, v in cfg.items() if k != "inputs"}
            if ev == "workflow_dispatch" or ev == "workflow_call":
                c["inputs"] = {k: {kk: vv for kk, vv in (v or {}).items() if kk in ("type", "default", "options", "required")} for k, v in (cfg.get("inputs") or {}).items()}
            trig[ev] = c
        else:
            trig[ev] = cfg
    labels = sorted({g for m in LABEL_RE.finditer(text) for g in m.groups() if g and LABEL_OK.match(g)})
    pv = path_verdict(on.get(a.event)) if a.event != "any" else None
    out["workflows"].append({
        "file": f, "name": doc.get("name", f), "reusable_only": set(on) <= {"workflow_call"}, "on": trig,
        "paths_verdict": pv,
        "concurrency": doc.get("concurrency"), "labels_referenced": labels,
        "status_contexts_published": sorted(set(CTX_RE.findall(text))),
        "jobs": [job_info(k, v, p) for k, v in (doc.get("jobs") or {}).items()],
    })

gl = read(".gitlab-ci.yml")
if gl is not None:
    try:
        d = yaml.safe_load(gl) or {}
        out["gitlab"] = {"stages": d.get("stages"), "include": d.get("include"),
                         "jobs": {k: {"stage": v.get("stage"), "rules": v.get("rules"), "only": v.get("only"), "script": [short(x) for x in (v.get("script") or [])][:6]}
                                  for k, v in d.items() if isinstance(v, dict) and ("script" in v or "trigger" in v or "extends" in v)}}
    except yaml.YAMLError as e:
        out["gitlab"] = {"error": str(e)}

if a.json:
    with open(a.json, "w") as fh: json.dump(out, fh, indent=1, default=str)

print(f"# ci-map  platform={','.join(out['platform']) or 'none found'}  filter={out['filter']}  workflows={len(out['workflows'])}")
if CHANGED is not None:
    fire = [w["file"] for w in out["workflows"] if not (w.get("paths_verdict") or ("fires",))[0].startswith("skipped")]
    skip = [w["file"] for w in out["workflows"] if (w.get("paths_verdict") or ("fires",))[0].startswith("skipped")]
    print(f"# would fire ({len(fire)}): {', '.join(fire)}")
    print(f"# skipped by path filters ({len(skip)}): {', '.join(skip)}")
    print("# note: job-level `if:` conditions (draft, labels, event type) can still skip jobs inside a firing workflow")
for w in out["workflows"]:
    if "error" in w:
        print(f"\n## {w['file']}  YAML ERROR: {short(w['error'])}"); continue
    pv = w.get("paths_verdict")
    tag = f"  [{pv[0]}{': ' + ', '.join(pv[1]) if pv[1] else ''}]" if pv else ""
    print(f"\n## {w['file']} — {w['name']}{'  [reusable]' if w['reusable_only'] else ''}{tag}")
    for ev, c in w["on"].items():
        print(f"  on.{ev}: {short(json.dumps(c, default=str), 300)}")
    if w["concurrency"]: print(f"  concurrency: {short(json.dumps(w['concurrency'], default=str))}")
    if w["labels_referenced"]: print(f"  labels: {', '.join(w['labels_referenced'])}")
    if w["status_contexts_published"]: print(f"  publishes status: {', '.join(w['status_contexts_published'])}")
    def pj(j, ind="  "):
        flags = [x for x in (f"needs={j['needs']}" if j["needs"] else "", f"if={j['if']}" if j["if"] else "",
                             f"env={j['environment']}" if j["environment"] else "", "CONTINUE-ON-ERROR" if j["continue_on_error"] else "",
                             f"uses={j['uses']}" if j["uses"] else "") if x]
        print(f"{ind}- job {j['id']} \"{j['name']}\" {' | '.join(flags)}")
        for r in j["run"][:12]: print(f"{ind}    $ {r}")
        if len(j["run"]) > 12: print(f"{ind}    … {len(j['run']) - 12} more run steps")
        if j["step_continue_on_error"]: print(f"{ind}    ! continue-on-error steps: {'; '.join(j['step_continue_on_error'])}")
        for c in j.get("called_jobs", []): pj(c, ind + "    ")
    for j in w["jobs"]: pj(j)
if "gitlab" in out:
    print("\n## .gitlab-ci.yml"); print(short(json.dumps(out["gitlab"], default=str), 4000))
````

### pw-failures.py

````python
#!/usr/bin/env python3
# pw-failures v1 — list failed / flaky / skipped tests from a Playwright JSON report (or a folder of them) and JUnit XML files.
# usage: python3 pw-failures.py <report.json|junit.xml|dir> [...]
import json, os, re, sys, xml.etree.ElementTree as ET
rows, totals = [], {"passed": 0, "failed": 0, "flaky": 0, "skipped": 0}
def walk_pw(suite, path):
    for s in suite.get("suites", []) or []: walk_pw(s, path + [s.get("title", "")])
    for spec in suite.get("specs", []) or []:
        for t in spec.get("tests", []) or []:
            st = t.get("status")  # expected | unexpected | flaky | skipped
            key = {"expected": "passed", "unexpected": "failed", "flaky": "flaky", "skipped": "skipped"}.get(st, "failed")
            totals[key] += 1
            if key in ("failed", "flaky"):
                res = t.get("results") or [{}]
                err = next((r.get("error", {}).get("message", "") for r in reversed(res) if r.get("error")), "")
                att = [x.get("path") for r in res for x in r.get("attachments", []) if x.get("path")]
                rows.append({"status": key, "file": f"{spec.get('file')}:{spec.get('line')}", "title": " › ".join([p for p in path if p] + [spec.get("title", "")]),
                             "project": t.get("projectName"), "retries": len(res) - 1, "tags": spec.get("tags"),
                             "error": re.sub(r"\x1b\[[0-9;]*m", "", err).strip().splitlines()[:3], "attachments": att[:4]})
def read(p):
    if os.path.isdir(p):
        for root, _, fs in os.walk(p):
            for f in fs:
                if f.endswith((".json", ".xml")): read(os.path.join(root, f))
        return
    if p.endswith(".json"):
        try: d = json.load(open(p))
        except Exception: return
        if isinstance(d, dict) and "suites" in d:
            for s in d["suites"]: walk_pw(s, [s.get("title", "")])
    elif p.endswith(".xml"):
        try: root = ET.parse(p).getroot()
        except Exception: return
        for tc in root.iter("testcase"):
            f = tc.find("failure") if tc.find("failure") is not None else tc.find("error")
            if tc.find("skipped") is not None: totals["skipped"] += 1
            elif f is not None:
                totals["failed"] += 1
                rows.append({"status": "failed", "file": tc.get("file") or tc.get("classname"), "title": tc.get("name"), "project": None, "retries": None,
                             "tags": None, "error": (f.get("message") or f.text or "").strip().splitlines()[:3], "attachments": []})
            else: totals["passed"] += 1
for p in sys.argv[1:]: read(p)
print(f"totals: {totals}")
if sum(totals.values()) == 0: print("WARNING: zero tests found — a green run with 0 tests proves nothing")
for r in rows:
    print(f"\n[{r['status'].upper()}] {r['title']}  ({r['file']}, project={r['project']}, retries={r['retries']})")
    for e in r["error"]: print(f"    {e[:220]}")
    for a in r["attachments"]: print(f"    attachment: {a}")
````

## Appendix — project profile: Persefoni `eng-guardrails-platform`

Learned from `origin/develop` @ `50a56fc` (2026-10-16); re-verify with `ci-map.py` before relying on it.
These notes are leads, not evidence: re-check any fact you put in a report, or label it "from earlier
notes, not re-checked".

**Access in Cowork.** The device shell has no network and no `gh`; the cloud shell may lack repo
access. Expect to use the browser path (github.com PR → Checks) unless `gh` works somewhere.

**Required for PRs into `develop`** — seen as "Required" badges on live PR #16419 (2026-10-19); Terraform
`tf/repo/eng-guardrails-platform/terragrunt.hcl` lists only the first three; `.critical/ci/STANDARDS.md`
saying develop has no required checks is outdated. Also required: 1 code-owner approval
(`@kstrohPersefoni` / `@muczynski-persefoni`), merge queue, linear history. Confirm with
`gh api repos/Persefoni-AI/eng-guardrails-platform/rules/branches/develop` when `gh` works:
- `validate-workflow` — a **commit status**, published by `validate-workflow.yaml` when
  "Develop PR Validation" finishes (pending while it runs). Drafts get "validation intentionally
  skipped" = success → meaningless; mark the PR ready.
- `PR Gate (javascript-typescript)` (codeql.yml — prints a message, no real scan on develop PRs;
  its green proves nothing).
- "Enforce High-Impact Guardrails" and "Block New Suffix-Based Secret/Var Patterns".
- `two-maintainer-approval` — "no governed paths touched" on ordinary PRs; pending until two
  maintainers approve on `two_reviewer` paths.
Not required but red on stale branches: Base Freshness Guard (> 200 behind), Validate branch ancestry.

**Develop PR Validation** (`develop-pr-validation.yml`): skips drafts; label add/remove only re-uses
the last full result (except `skip-i18n-guard`, `needs-alignment-review`, `frai-5906*`, `step-*`);
gate job `fast-gate-summary` treats Code Quality `skipped` as pass; check names include
"Detect Test Scope", "Code Quality / …", "Fixture Pin Check (N/12)". On a PR, "full-suite" scope runs
only a time-boxed **PR floor**; the full unit suite + Snyk are meant to run in the **merge queue**, but
check the queue run's job list: on 2026-10-19 the queue run for worker-only PR #16434 ran only
changed-file checks and skipped Snyk and the full suites, so the PR run was the only unit-test proof.
A green PR can still fail in the queue (e.g. Architecture Drift inherited from a PR ahead of it).

**E2E against a deployed slot (opt-in, "PR Deploy (Opt-In)" `pr-deploy.yml`):**
1. Label `dev-env:<slot>` — valid on live develop 2026-10-19: `dev-0`…`dev-4`, `dev-poc`
   (all `dev-automation-*` slots retired 2026-10-18, #16101 / FRAI-8426). Spec-only PRs get no
   automatic slot → add the `dev-env` label **before** `deploy`. Re-check the list in
   `require-dev-env-label.yml` on live develop.
2. Label `deploy` — the adder needs **admin or maintain** role; otherwise the run refuses → CI_BLOCKED,
   ask a maintainer to add it.
3. Jobs: Check Deploy Trigger → Validate Target → Detect Deploy Target → Deploy (`_ci-deploy-dev.yml`,
   app at `https://guardrails-<slot>.persefoni.workers.dev`) → Verify Deploy Outputs →
   **Platform E2E** (`_platform-critical.yml`: only `automation/__tests__/platform/critical-paths.spec.ts`,
   chromium, 2 shards; no changed-file → suite mapping) → Remove Deploy Label.
4. Artifacts: `platform-critical-merged-json` (30 d), on failure `Platform Critical Shard N of M - Failed Tests`
   and `Platform Critical - Merged Test Report`. Result in the "Test Summary" job summary; no PR comment.
5. Chat checks skip leniently when chat health fails (annotation only) — read the summary, not just the tick.
6. `auto-rerun-startup-cpu-flake.yml` auto re-runs PR Deploy up to twice only for Cloudflare startup-CPU
   error 10021 — don't add your own re-run on top.
Playwright in CI: retries 2, workers 2 (`playwright.config.ts`).

**Dispatchable suites** (real inputs):
`gh workflow run run-e2e-suite.yml --ref develop -f suite=<option> -f environment=dev|staging|production -f branch=develop -f browser=chromium -f notify_slack=false` (cannot target a slot);
`gh workflow run platform-smoke-tests.yml -f environment=dev|staging|production -f browser=chromium -f test_tags=@smoke -f notify_slack=false`;
`gh workflow run pipeline-orchestrator-dev.yml --ref develop -f target_branch=<branch> -f dev_env_override=<slot> -f pr_number=<N>` (full `_ci-e2e-suite-dev.yml`, 12 tag groups; failure artifacts `<group>-<suite>-test-results`, 7 d).
Read the `suite` options from `run-e2e-suite.yml` before dispatching.
As of 2026-10-19 `platform-smoke-tests.yml` had never completed a run (only run #1, 20 Aug, failed at
install) and its "Test Summary" job reports success even if the smoke job was cancelled — judge the
"Platform Smoke Tests (<env> - <browser>)" job and its test count; dispatch with `--ref staging` for
staging. `platform-smoke.yml` had never run. Staging's post-merge deploy skips chat checks by default
(opt-in), so "staging green" says nothing about chat.

**Label-only runs.** Adding/removing most labels starts a "Develop PR Validation" run that only re-uses
the newest full result ("Reuse full validation for irrelevant label"); the merge box then shows Code
Quality as "Skipped". The real error is in the newest full run (event `opened`/`synchronize`/`edited`).

**Architecture Drift Checks (PR0)** (Code Quality, required via `fast-gate-summary` → `validate-workflow`):
a PR that adds a new D1 operation in a file not listed in the platform-authority register fails the
digest gate ("Architecture alignment review required", "Digest gate found new unresolved
operations"). It is CHANGE, not flaky — re-runs fail the same way. Two ways out: register the
operation (owner input needed), or a trusted maintainer adds the `needs-alignment-review` label (a
reserved label, so it starts a fresh full run, not a re-use). Seen on PR #16435, 2026-10-19. In the
browser, when a raw log URL is blocked, a step's log can still be read through its `data-log-url`.

**Advisory bots/workflows:** `claude-security-review.yml` (inline comments, continue-on-error);
High-Impact notes comment `## 🛡️ High-Impact PR — Draft Audit Notes`; `/check-coverage` comment or
`check-coverage` label → comment `<!-- coverage-analysis -->`; `security-scan.yml` (fails only on new
critical/high, comment `<!-- api-security-scan-results -->`); `semgrep.yml` (new findings of custom rules);
`pr-dependency-audit.yml` (early warning). Greptile: `greptile.json` has ignore patterns, but it did
review spec-only PR #15780 — check the current file rather than assuming. Agent PRs need an
`@codex review` comment before ready (`REVIEW.md`).

**Round-5 lessons (2026-10-19, PR #16456).** Both code-owner approvals arrived and the PR joined the
merge queue while the check was running: re-read the merge box just before writing. GitHub code search
found 11 locale hits where reading the catalogs at the commit showed all 13 non-English files still had
the old key; count file claims at the commit, not with code search.

**Will CI run my specs?** Usually not for older feature folders: `scripts/check-e2e-coverage-selection.ts`
(extract `origin/develop:scripts` into a git-ignored folder inside the repo, run from the repo root with
`node --experimental-strip-types --no-warnings` where `bun` is missing) listed ~650 specs that no lane
selects on 2026-10-19 — e.g. everything in `automation/admin/security/global-dlp-settings/`
except `data-classification.spec.ts` (their tags `@suite.admin @automation.admin` / `@regression @staging @prod`
match no suite `--grep`). PR Deploy runs only `critical-paths.spec.ts`; `run-e2e-suite.yml` options and
`pipeline-orchestrator-dev.yml` groups don't include them either. For such PRs: run the changed specs
against dev or the slot URL (agent run, report + screenshots attached to the PR) and say in the PR body
that no CI lane runs them.